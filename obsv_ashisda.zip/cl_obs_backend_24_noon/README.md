# Canada Life · ARE Observability — Backend Service

FastAPI + PostgreSQL + SQLAlchemy 2.0 + Pydantic v2 backend that replaces the React
frontend's static `/public/data/*.json` fixtures with live, DB-backed REST endpoints.

## Structure (follows cl-backend-skeleton conventions)

```
app/
├── main.py                       # FastAPI app + /api/v1 router registration
├── api/v1/                       # Thin routers, try/except → HTTPException
│   ├── health.py
│   ├── journeys.py               # /journeys, /sub-journeys
│   ├── analysis.py               # /tiers?incident=, /corr-data?incident=
│   ├── alerts.py                 # /alerts, /alerts/{ref}
│   ├── rules.py                  # /rules?incident=
│   └── ai.py                     # /ai/tier-summary  (OpenAI-backed)
├── services/                     # Static-method service classes
│   ├── journey_service.py
│   ├── analysis_service.py
│   ├── alert_service.py
│   ├── rule_service.py
│   └── openai_service.py         # LLM tier summary with DB fallback
├── models/                       # SQLAlchemy 2.0 (19 tables)
├── schemas/                      # Pydantic v2 response schemas
├── core/                         # config + database engine
└── scripts/
    └── seed_data.py              # Creates schema + inserts sample data
sql/
└── schema.sql                    # Reference DDL for DBAs / migration tools
```

## Quick start

```bash
# 1. Start PostgreSQL (Docker)
docker compose up -d postgres

# 2. Install Python deps
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt

# 3. Configure
cp .env.example .env                                 # edit if needed

# 4. Create schema, seed data, run the server
./run.sh                                             # or: run.bat on Windows
```

The API is now on <http://localhost:8000> — try:

- <http://localhost:8000/api/v1/health>
- <http://localhost:8000/api/v1/journeys>
- <http://localhost:8000/api/v1/tiers?incident=INC0048291>
- <http://localhost:8000/docs>  (Swagger UI)

## Endpoints (all under `/api/v1`)

| Method | Path                             | Frontend fixture replaced         |
|--------|----------------------------------|-----------------------------------|
| GET    | `/health`                         | —                                 |
| GET    | `/journeys`                       | `journeys.json`                   |
| GET    | `/sub-journeys`                   | `subJourneys.json`                |
| GET    | `/tiers?incident=INC0048291`      | `tiers.json`                      |
| GET    | `/corr-data?incident=INC0048291`  | `corrData.json`                   |
| GET    | `/alerts`                         | `rawAlerts.json`                  |
| GET    | `/alerts/{alert_ref}`             | single-alert detail               |
| GET    | `/rules?incident=INC0048291`      | `rules.json`                      |
| POST   | `/ai/tier-summary`                | GPT-generated tier summary        |

All responses use the skeleton envelope:
```json
{ "success": true, "count": N, "data": <payload> }
```

## OpenAI configuration

In `.env`:
```
OPENAI_ENABLED=true
OPENAI_API_KEY=sk-...
OPENAI_MODEL=gpt-4o-mini
```

`POST /api/v1/ai/tier-summary` uses the OpenAI 1.x SDK to regenerate the tier summary
based on the *current* alerts for the given (incident, tier). When `OPENAI_ENABLED=false`
or the API call fails, the endpoint silently returns the DB-stored fallback text —
the UI never breaks because of an AI outage.

## React integration — replace static JSON with the live service

Replace `src/services/observabilityService.js` in the React project with:

```js
const API_BASE    = import.meta.env.VITE_API_BASE    || "http://localhost:8000/api/v1";
const INCIDENT_ID = import.meta.env.VITE_INCIDENT_ID || "INC0048291";

async function get(path) {
  const res = await fetch(`${API_BASE}${path}`);
  if (!res.ok) throw new Error(`${path} → ${res.status}`);
  const body = await res.json();
  return body.data;            // unwrap {success, count, data}
}

export const observabilityService = {
  getJourneys:    () => get("/journeys"),
  getSubJourneys: () => get("/sub-journeys"),
  getTiers:       () => get(`/tiers?incident=${INCIDENT_ID}`),
  getRawAlerts:   () => get("/alerts"),
  getCorrData:    () => get(`/corr-data?incident=${INCIDENT_ID}`),
  getRules:       () => get(`/rules?incident=${INCIDENT_ID}`),

  // Optional dynamic OpenAI-generated tier summary
  generateTierSummary: (tier_id) => fetch(`${API_BASE}/ai/tier-summary`, {
    method:  "POST",
    headers: { "Content-Type": "application/json" },
    body:    JSON.stringify({ incident_id: INCIDENT_ID, tier_id })
  }).then(r => r.json()).then(b => b.data),

  getAll: async () => {
    const [journeys, subJourneys, tiers, rawAlerts, corrData, rules] = await Promise.all([
      get("/journeys"),
      get("/sub-journeys"),
      get(`/tiers?incident=${INCIDENT_ID}`),
      get("/alerts"),
      get(`/corr-data?incident=${INCIDENT_ID}`),
      get(`/rules?incident=${INCIDENT_ID}`),
    ]);
    return { journeys, subJourneys, tiers, rawAlerts, corrData, rules };
  }
};
```

Add to the React `.env`:
```
VITE_API_BASE=http://localhost:8000/api/v1
VITE_INCIDENT_ID=INC0048291
```

Restart `npm run dev`. Every screen — Journeys, Sub-journeys, Reliability Analysis,
tier alert popups, rule modals, and the swim-lane diagram — now renders from the
FastAPI service instead of static JSON. **No presentational component changes needed.**

## Data integrity — enforced at the DB level

- `CHECK(happy_pct + unhappy_pct + frustrated_pct = 100)` on both metric tables
- `CHECK(occurrences_30d >= occurrences_7d)` on alerts
- Enum-like columns (severity, status, role, level) use `CHECK` constraints
- `UNIQUE(rule_id, incident_id)` — a rule fires at most once per incident
- `UNIQUE(alert_ref, metric_key)` — no duplicate metric rows per alert
- Every alert has valid tier + tool + component FKs
- `CASCADE` deletes on all parent tables clean up children

## Verification

Once seeded, you should see:
```
[OK] Seed complete - incident INC0048291, 19 alerts, 5 rules, 10 journeys, 11 components
```
