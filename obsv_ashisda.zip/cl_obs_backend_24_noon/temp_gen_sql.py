import uuid, datetime
from sqlalchemy import create_engine, text

engine = create_engine('postgresql://postgres:postgres@localhost:5432/postgres')
with engine.connect() as conn:
    res = conn.execute(text("SELECT a.* FROM alerts a JOIN incident_alerts ia ON a.alert_ref = ia.alert_ref WHERE ia.incident_id = 'INC0048291'"))
    rows = res.fetchall()
    
    print('INSERT INTO alerts (alert_ref, name, description, severity, tier_id, tool_id, component_id, component_display_name, detected_at, first_seen_today, occurrences_7d, occurrences_30d) VALUES')
    values = []
    for r in rows:
        new_id = 'NEW-' + str(uuid.uuid4())[:8]
        desc = r.description.replace("'", "''")
        values.append(f"('{new_id}', '{r.name}', '{desc}', '{r.severity}', '{r.tier_id}', '{r.tool_id}', '{r.component_id}', '{r.component_display_name}', CURRENT_TIMESTAMP, CURRENT_TIME, {r.occurrences_7d}, {r.occurrences_30d})")
    
    print(',\n'.join(values) + ';')
