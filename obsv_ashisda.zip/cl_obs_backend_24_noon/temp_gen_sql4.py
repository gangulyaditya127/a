import sys, os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from app.scripts.seed_data import COMPONENTS, CRIT_EDGES

# Generate incident_topology_state
print("INSERT INTO incident_topology_state (incident_id, component_id, level_at_time, is_rc_at_time) VALUES")
values1 = []
for c in COMPONENTS:
    comp_id, name, tech, tier_id, tier_order, disp_order, level, is_rc = c
    values1.append(f"('INC0048291', '{comp_id}', '{level}', {str(is_rc).lower()})")
print(',\n'.join(values1) + ';\n')

# Generate incident_critical_edges
print("INSERT INTO incident_critical_edges (incident_id, from_component, to_component) VALUES")
values2 = []
for from_c, to_c, order in CRIT_EDGES:
    values2.append(f"('INC0048291', '{from_c}', '{to_c}')")
print(',\n'.join(values2) + ';')
