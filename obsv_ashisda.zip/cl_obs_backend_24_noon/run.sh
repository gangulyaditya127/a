#!/bin/bash
set -e

# Create the virtual environment
python3.12 -m venv .venv

# Upgrade pip using the proxy
./.venv/bin/python -m pip install --upgrade pip --proxy http://185.46.212.90:443

# Install requirements using the proxy
./.venv/bin/python -m pip install -r requirements.txt --proxy http://185.46.212.90:443

# Seed the data using the virtual environment python
# ./.venv/bin/python -m app.scripts.seed_data
# ./.venv/bin/python -m app.scripts.seed_ai_discovery
# ./.venv/bin/python -m app.scripts.seed_historical_alerts 

# Start the application using the virtual environment uvicorn
./.venv/bin/uvicorn app.main:app --reload --host 0.0.0.0 --port 8011