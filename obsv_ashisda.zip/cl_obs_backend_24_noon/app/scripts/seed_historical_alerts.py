"""Seed synthetic historical alerts so the miner has data.

Generates ~30 days of alerts that recur in 3 known patterns:
    * DB failover cascade (4 tools, 4 CIs)
    * Memory leak cascade (3 tools, 3 CIs)
    * ESB backlog (2 tools, 1 CI)

Each pattern recurs 4-11 times over the 30-day window.
"""
from __future__ import annotations
import random
import uuid
from datetime import datetime, time as dtime, timedelta, timezone

from sqlalchemy import select, delete
from sqlalchemy.orm import Session

from app.core.database import SessionLocal, engine
from app.models import Base
from app.models.alerts import Alert
from app.models.reference import Component, MonitoringTool

NOW = datetime.now(timezone.utc)
random.seed(42)

PATTERN_TEMPLATES = [
    {
        "name": "db_failover_cascade",
        "recurrences": 5,
        "spread_seconds": 90,
        "signals": [
            ("oracle_em",  "ora",    "RACNodeInstanceFailover", "crit",
             "Policy Admin DB (Oracle RAC)",
             "Oracle RAC node failover detected."),
            ("appd",       "claims", "ThreadPoolExhaustion", "crit",
             "Claims Service",
             "Thread pool exhausted after DB pool starvation."),
            ("tibco_hawk", "esb",    "ProcessEngineStuckThread", "crit",
             "Enterprise Service Bus",
             "Process engine threads stuck due to DB unavailability."),
            ("splunk",     "ora",    "DBConnectionExhaustion", "high",
             "Policy Admin DB",
             "DB connection pool exhausted."),
        ],
    },
    {
        "name": "memory_leak_cascade",
        "recurrences": 7,
        "spread_seconds": 120,
        "signals": [
            ("appd",       "rating-eng", "JVMHeapExhaustion", "crit",
             "Rating Engine",
             "JVM heap exhausted after new deployment."),
            ("appd",       "rating-eng", "GCPauseTimeHigh", "crit",
             "Rating Engine",
             "GC pauses exceeding 5s."),
            ("splunk",     "rating-eng", "KafkaConsumerLag", "high",
             "Rating Engine",
             "Consumer lag climbing due to GC pauses."),
        ],
    },
    {
        "name": "esb_backlog",
        "recurrences": 11,
        "spread_seconds": 40,
        "signals": [
            ("tibco_hawk", "esb", "HighQueueDepth", "high",
             "Enterprise Service Bus",
             "Queue depth exceeded threshold."),
            ("appd",       "esb", "ESBHealthDegraded", "high",
             "Enterprise Service Bus",
             "ESB node health degraded."),
        ],
    },
]


def _pick_valid(pattern, existing_components, existing_tools):
    """Drop any signals whose component or tool doesn't exist in the DB."""
    return [
        s for s in pattern["signals"]
        if s[1] in existing_components and s[0] in existing_tools
    ]


def seed():
    print("Ensuring schema exists...")
    Base.metadata.create_all(bind=engine)
    db: Session = SessionLocal()
    try:
        existing_components = {c.component_id for c in db.execute(select(Component)).scalars().all()}
        existing_tools      = {t.tool_id      for t in db.execute(select(MonitoringTool)).scalars().all()}
        if not existing_components:
            print("[error] No components found. Run seed_data.py first.")
            return

        # Clean prior synthetic history (identified by alert_ref prefix HIST-)
        db.execute(delete(Alert).where(Alert.alert_ref.like("HIST-%")))
        db.commit()

        total = 0
        for pattern in PATTERN_TEMPLATES:
            signals = _pick_valid(pattern, existing_components, existing_tools)
            if len(signals) < 2:
                print(f"  skip {pattern['name']} (< 2 valid signals in schema)")
                continue

            for occurrence in range(pattern["recurrences"]):
                # Random day within last 30, random time of day
                days_ago = random.randint(1, 29)
                hour     = random.randint(6, 22)
                minute   = random.randint(0, 59)
                base = NOW - timedelta(days=days_ago)
                base = base.replace(hour=hour, minute=minute, second=random.randint(0, 30), microsecond=0)

                for offset_i, sig in enumerate(signals):
                    tool_id, comp_id, name, sev, comp_disp, desc = sig
                    ts = base + timedelta(seconds=offset_i * random.randint(2, pattern["spread_seconds"] // len(signals)))
                    ref = f"HIST-{pattern['name'][:4].upper()}-{occurrence:02d}-{offset_i}-{uuid.uuid4().hex[:4]}"
                    db.add(Alert(
                        alert_ref=ref,
                        name=name,
                        description=desc,
                        severity=sev,
                        tier_id=next((c.tier_id for c in db.execute(select(Component)).scalars().all() if c.component_id == comp_id), "app"),
                        tool_id=tool_id,
                        component_id=comp_id,
                        component_display_name=comp_disp,
                        detected_at=ts,
                        first_seen_today=dtime(ts.hour, ts.minute, ts.second),
                        occurrences_7d=1,
                        occurrences_30d=1,
                    ))
                    total += 1
            print(f"  seeded {pattern['recurrences']} occurrences of '{pattern['name']}'")
        db.commit()
        print(f"[OK] Seeded {total} synthetic historical alerts across "
              f"{len(PATTERN_TEMPLATES)} patterns.")
    finally:
        db.close()


if __name__ == "__main__":
    seed()
