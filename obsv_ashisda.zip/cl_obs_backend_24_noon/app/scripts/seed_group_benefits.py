"""Seed the Group Benefits Enrollment scenario (INC0048305).

Adds a second, fully self-contained incident scenario alongside the existing
Health & Dental Claim one (INC0048291). Root cause is a Rating Engine memory
leak after a v2.14.3 deployment — different pattern from the DB failover in
the original seed so both incidents make a clear demo contrast.

What this script writes / touches
---------------------------------
Configuration inserts (idempotent — deletes prior rows first):
  * 4 new components   : rating-eng, elig-svc, kafka, grpdb
  * 8 new component dependencies (4 critical, 4 normal)
  * 9 sub_journeys      for the 'group' journey (was previously empty)
  * 1 new correlation rule : RULE-COR-061
  * 3 rule inputs, 3 rule explanation paragraphs

Transaction inserts:
  * 17 new raw alerts + their metric grids
  * 1 new journey_metrics snapshot for 'group' (frustrated pct now 15)
  * 9 sub_journey_metrics rows (one per step)
  * 1 new incident   : INC0048305
  * 15 incident_alerts (SW-002 and VC-002 stay UNCORRELATED — infra is independent)
  * 5 tier_incident_summary rows (one per tier)
  * 3 rule_firings (new rule + 2 existing rules that also match)
  * ~15 rule_firing_alerts

Run:
    python -m app.scripts.seed_group_benefits

Then point the React frontend at the new incident by editing .env:
    VITE_INCIDENT_ID=INC0048305
and restart `npm run dev`.
"""
from __future__ import annotations
from datetime import datetime, time, timezone

from sqlalchemy import delete
from sqlalchemy.orm import Session

from app.core.database import SessionLocal, engine
from app.models import Base
from app.models.reference import (
    Component, ComponentDependency, SubJourney,
)
from app.models.rules import CorrelationRule, RuleCombineInput, RuleExplanation
from app.models.metrics import JourneyMetric, SubJourneyMetric
from app.models.alerts import Alert, AlertMetric
from app.models.incidents import (
    Incident, IncidentAlert, TierIncidentSummary, RuleFiring, RuleFiringAlert,
)

NOW = datetime.now(timezone.utc)
INCIDENT_ID = "INC0048305"
JOURNEY_ID  = "group"  # already exists from base seed

# ------------------------------------------------------------------
# NEW COMPONENTS (4)
# ------------------------------------------------------------------
# (component_id, name, sub_label, tier_id, layout_row, display_order, level, is_rc)
NEW_COMPONENTS = [
    ("rating-eng",   "Rating Engine",     "Spring Boot 3.2",       "app",   3, 11, "crit", True),
    ("elig-svc",     "Eligibility Svc",   "Spring Boot 3.2",       "app",   4, 12, "deg",  False),
    ("kafka",        "Message Broker",    "Confluent Kafka 7.5",   "int",   2, 13, "crit", False),
    ("grpdb",        "Group Contract DB", "Oracle RAC 19c",        "data",  3, 14, "crit", False),
]

# NEW COMPONENT DEPENDENCIES — critical (red on swim-lane) + normal
NEW_CRIT_EDGES = [
    ("gw",         "rating-eng", 20),   # Employer traffic hits Rating Engine
    ("rating-eng", "kafka",      21),   # Rating Engine publishes to Kafka
    ("rating-eng", "grpdb",      22),   # Rating Engine reads rate tables
    ("kafka",      "esb",        23),   # ESB consumes rate calc requests
]
NEW_NORMAL_EDGES = [
    ("gw",         "elig-svc",   30),
    ("elig-svc",   "grpdb",      31),
    ("rating-eng", "esxi",       32),   # Rating Engine runs on ESXi cluster
    ("grpdb",      "dyna",       33),
]

# ------------------------------------------------------------------
# SUB-JOURNEYS (9) — Group Benefits Enrollment
# ------------------------------------------------------------------
SUB_JOURNEYS = [
    # (sub_journey_id, journey_id, name, api_label, display_order)
    ("verify-employer", JOURNEY_ID, "Employer SSO Login",             "Verify Employer SSO",             0),
    ("upload-roster",   JOURNEY_ID, "Upload Employee Roster",         "Roster CSV Upload",               1),
    ("validate-roster", JOURNEY_ID, "Roster Validation & Cleansing",  "Validate Roster Records",         2),
    ("select-coverage", JOURNEY_ID, "Select Coverage Plans",          "Select Plan Options",             3),
    ("elig-check",      JOURNEY_ID, "Eligibility Verification",       "Eligibility Check (per member)",  4),
    ("rate-calc",       JOURNEY_ID, "Group Premium Rate Calculation", "Calculate Group Premium",         5),
    ("contract-prev",   JOURNEY_ID, "Contract Preview & Terms",       "Preview Contract",                6),
    ("esign-bind",      JOURNEY_ID, "e-Sign & Contract Binding",      "e-Sign & Bind Contract",          7),
    ("welcome-kit",     JOURNEY_ID, "Welcome Kit Distribution",       "Send Welcome Kits",               8),
]

# (sub_journey_id, hu(or None), avg_ms, p95_ms, err_pct, avail_pct, is_critical)
SUB_JOURNEY_METRICS = [
    ("verify-employer", None,           180,  280,  1.0,  98.50, False),
    ("upload-roster",   None,           420,  680,  2.0,  97.80, False),
    ("validate-roster", None,           520,  780,  1.0,  98.20, False),
    ("select-coverage", None,           210,  340,  1.0,  99.10, False),
    ("elig-check",      (78, 14, 8),    890,  1420, 6.0,  88.30, False),   # degraded
    ("rate-calc",       (54, 24, 22),   6200, 8100, 22.0, 63.40, True),    # CRITICAL
    ("contract-prev",   None,           240,  380,  1.0,  99.20, False),
    ("esign-bind",      None,           320,  490,  1.0,  98.90, False),
    ("welcome-kit",     None,           180,  290,  1.0,  99.40, False),
]

# ------------------------------------------------------------------
# ALERTS (17) — 15 correlated + 2 independent infra
# ------------------------------------------------------------------
# (ref, name, sev, tier, tool, comp, comp_display, time_hms, occ7, occ30, desc, metrics)
ALERTS = [
    # --- Presentation (3) — end-user impact ---------------------------------
    ("DYN-050", "BackendCallResponseTimeHigh", "crit", "pres", "dynatrace", "dyna",
     "Digital Experience Monitor", "10:12:30", 2, 5,
     "Rating quote endpoint response degraded to 5800 ms (baseline 300 ms). "
     "Impact on Group Benefits enrollment employer sessions.",
     [("Service Response Time","5800 ms"),("Baseline","300 ms"),("Deviation","19.3x"),
      ("Impacted Sessions","340 employer admins"),
      ("Business Transaction","group.rateCalc"),("Detected By","Real User Monitoring")]),

    ("DYN-051", "UserActionFailureRate", "high", "pres", "dynatrace", "dyna",
     "Digital Experience Monitor", "10:12:45", 1, 3,
     "Group rate quote submission failure rate 22% across active employer sessions.",
     [("Failure Rate","22%"),("Baseline","0.8%"),("Active Sessions","340"),
      ("User Action","submitRateQuote")]),

    ("SPL-DEM-2", "GatewayTimeoutSpike", "high", "pres", "splunk", "gw",
     "API Gateway", "10:13:05", 1, 3,
     "504 Gateway Timeout responses spiked to 180/min on /api/group/rate-calc.",
     [("Rate","180/min"),("Baseline","4/min"),("Path","/api/group/rate-calc")]),

    # --- Application (5) — ROOT CAUSE ZONE, anchor is APD-050 ----------------
    ("APD-050", "JVMHeapExhaustion", "crit", "app", "appd", "rating-eng",
     "Rating Engine", "10:15:02", 1, 2,
     "JVM Old Gen at 97% on rating-engine-04 - full GC pauses > 8s. "
     "Post-deployment memory saturation on v2.14.3.",
     [("Old Gen","97%"),("Heap Usage","7.8 GB / 8 GB"),("Full GC pause","8400 ms"),
      ("Host","rating-engine-04"),("Deployment","v2.14.3 at 09:45"),
      ("Time Since Deploy","30 min")]),

    ("APD-051", "ThreadPoolExhaustion", "crit", "app", "appd", "rating-eng",
     "Rating Engine", "10:15:20", 3, 8,
     "Thread pool exhaustion: 195/200 threads busy on rating-engine cluster.",
     [("Threads Active","195/200"),("Wait Queue","480"),
      ("Cluster","rating-engine (4 pods)"),("Node Health","18/100")]),

    ("SPL-APP-10", "ErrorLogSurge", "high", "app", "splunk", "rating-eng",
     "Rating Engine", "10:15:35", 2, 6,
     "ERROR log volume 14x baseline on GroupPremiumCalculator.java.",
     [("Log rate","850/min"),("Baseline","60/min"),("Deviation","14x"),
      ("Source","GroupPremiumCalculator.java")]),

    ("APD-052", "HighResponseTimeDeviation", "high", "app", "appd", "rating-eng",
     "Rating Engine", "10:15:45", 2, 5,
     "Average response time 6.8s exceeds baseline 240ms (28x deviation).",
     [("Avg Response","6800 ms"),("Baseline","240 ms"),("Deviation","28x"),
      ("Business Transaction","calculateGroupPremium")]),

    ("APD-053", "GCPauseTimeHigh", "crit", "app", "appd", "rating-eng",
     "Rating Engine", "10:16:10", 1, 3,
     "Full GC consuming 62% of last 5 minutes on rating-engine pods.",
     [("Full GC pause","8400 ms"),("GC time %","62%"),("Old Gen","97%"),
      ("Suspected","memory leak in v2.14.3")]),

    # --- Integration (4) — downstream backup ---------------------------------
    ("HWK-050", "HighQueueDepth", "high", "int", "tibco_hawk", "esb",
     "Enterprise Service Bus", "10:15:40", 2, 7,
     "Queue depth GRP.RATE.REQ: 3,120 messages (threshold 500).",
     [("Queue Depth","3120"),("Threshold","500"),("Queue","GRP.RATE.REQ")]),

    ("SPL-INT-2", "KafkaConsumerLag", "crit", "int", "splunk", "kafka",
     "Kafka Broker", "10:15:55", 1, 3,
     "Kafka consumer group rating-engine-group lagging by 12,400 messages "
     "on rate-calc-requests topic.",
     [("Consumer Lag","12400"),("Topic","rate-calc-requests"),
      ("Consumer Group","rating-engine-group"),("Broker","kafka-broker-02")]),

    ("HWK-051", "ProcessEngineStuckThread", "crit", "int", "tibco_hawk", "esb",
     "Enterprise Service Bus", "10:16:20", 2, 5,
     "Process engine stuck thread count: 42/50 - process "
     "'GroupRateOrchestrator.bwp' backlogged.",
     [("Stuck Threads","42/50"),("Process","GroupRateOrchestrator.bwp"),
      ("Node","tibco-bw-04")]),

    ("APD-INT-2", "ESBHealthDegraded", "high", "int", "appd", "esb",
     "Enterprise Service Bus", "10:16:35", 1, 3,
     "TIBCO BusinessWorks node health score 28/100 on tibco-bw-04.",
     [("Health Score","28/100"),("Node","tibco-bw-04")]),

    # --- Data (3) — connection pool starvation ------------------------------
    ("SPL-DB-2", "DBConnectionExhaustion", "high", "data", "splunk", "grpdb",
     "Group Contract DB", "10:16:15", 1, 4,
     "Connection pool exhausted on GRPDB-01 (150/150). Rating engine holding "
     "long-running connections during GC storms.",
     [("Pool","150/150"),("Wait Queue","62"),("App","rating-engine")]),

    ("APD-DB-2", "SQLResponseTimeSpike", "crit", "data", "appd_db", "grpdb",
     "Group Contract DB", "10:16:25", 2, 6,
     "SQL response time P95 5.4s (baseline 90 ms).",
     [("P95","5400 ms"),("Baseline","90 ms"),
      ("Top SQL","SELECT rate_table WHERE plan_id = ? AND age_band = ?")]),

    ("OEM-050", "ActiveSessionsSpike", "high", "data", "oracle_em", "grpdb",
     "Group Contract DB", "10:16:40", 1, 3,
     "Active sessions spike: 210 to 480 on Group Contract DB.",
     [("Sessions","210 to 480"),("Node","GRPDB1"),("CPU","74%")]),

    # --- Infrastructure (2) — INDEPENDENT (not part of the incident) --------
    ("SW-002", "PodOOMKilled", "high", "infra", "solarwinds", "esxi",
     "ESXi Host esxi-prod-05", "10:17:20", 1, 2,
     "Kubernetes pod other-service-02 OOMKilled at 10:17:20 - "
     "memory limit 4Gi exceeded. Unrelated to rating-engine incident.",
     [("Pod","other-service-02"),("Memory Limit","4 Gi"),
      ("Node","esxi-prod-05"),("Exit Code","137")]),

    ("VC-002", "PodRestartLoop", "high", "infra", "vmware_vc", "esxi",
     "ESXi Host esxi-prod-05", "10:17:35", 1, 2,
     "Pod other-service-02 restart loop: 3 restarts in 5 min after OOMKill.",
     [("Restarts","3 in 5min"),("Pod","other-service-02"),("Backoff","exponential")]),
]

# ------------------------------------------------------------------
# INCIDENT INC0048305
# ------------------------------------------------------------------
INCIDENT = dict(
    incident_id=INCIDENT_ID,
    title="Group Benefits Rating Engine memory saturation impacting employer enrollment",
    root_cause_desc=(
        "At 10:15:02, the Rating Engine JVM exhausted its heap on version v2.14.3 "
        "(deployed 09:45). Full GC pauses of 8+ seconds cascaded to Kafka consumer "
        "lag, ESB backlog and DB connection starvation. Suspected memory leak in the "
        "new GroupPremiumCalculator implementation."
    ),
    root_cause_component_id="rating-eng",
    affected_sub_journey_id="rate-calc",
    raw_alerts_grouped=15,
    tools_contributing=6,
    correlation_confidence_pct=91.0,
    frustrated_user_count=75,
    status="investigating",
)

# 15 alerts belong to the incident. SW-002 and VC-002 stay independent.
IN_INCIDENT_ROLES = {
    "DYN-050":    "symptom",
    "DYN-051":    "symptom",
    "SPL-DEM-2":  "symptom",
    "APD-050":    "root_cause",
    "APD-051":    "downstream",
    "APD-052":    "downstream",
    "APD-053":    "downstream",
    "SPL-APP-10": "downstream",
    "HWK-050":    "downstream",
    "SPL-INT-2":  "downstream",
    "HWK-051":    "downstream",
    "APD-INT-2":  "downstream",
    "SPL-DB-2":   "downstream",
    "APD-DB-2":   "downstream",
    "OEM-050":    "contributing",
}

# ------------------------------------------------------------------
# TIER-BY-TIER EDITORIAL SUMMARIES for INC0048305
# ------------------------------------------------------------------
TIER_SUMMARIES = [
    ("pres",  False,
     "End-user latency for employer admins. All 3 alerts trace to slow Rating "
     "Engine responses on the group premium endpoint."),
    ("app",   True,
     "Root cause. Rating Engine v2.14.3 (deployed 09:45) exhausted heap at "
     "10:15:02. Full GC pauses of 8+ seconds cascaded downstream."),
    ("int",   False,
     "Kafka consumer group lagging 12,400 messages and ESB queue backlog - "
     "both consequences of Rating Engine GC storms."),
    ("data",  False,
     "DB pool exhausted because Rating Engine holds connections through 8-second "
     "GC pauses. Not a data-tier fault."),
    ("infra", False,
     "Independent Kubernetes pod OOMKill and restart loop on ESXi host. "
     "Tracked as separate incident (not correlated here)."),
]

# ------------------------------------------------------------------
# NEW CORRELATION RULE (fires on this scenario, not on the DB one)
# ------------------------------------------------------------------
NEW_RULE = dict(
    rule_id="RULE-COR-061",
    name="Post-deployment memory leak cascade",
    score=0.91,
    plain=(
        "When a recent deployment triggers JVM heap exhaustion, GC storms cascade "
        "into downstream systems: connection pools starve, queues back up, and user "
        "latency spikes. This rule groups all symptoms into one incident with the "
        "deployment as the trigger."
    ),
    trigger_when="AppDynamics . JVMHeapExhaustion",
    trigger_target="Application service within 60 min of latest deployment",
    combine_logic=(
        "AND within 240 s AND on dependent chain "
        "(Application -> Integration -> Data)"
    ),
    output=(
        "Single incident - root cause = memory leak in latest deployment. "
        "Downstream alerts suppressed as symptoms."
    ),
    inputs=[
        ("appd",       "JVMHeapExhaustion"),
        ("appd",       "GCPauseTimeHigh / ThreadPoolExhaustion"),
        ("splunk",     "KafkaConsumerLag / DBConnectionExhaustion"),
        ("tibco_hawk", "HighQueueDepth"),
    ],
    involves=["APD-050", "APD-053", "APD-051", "SPL-INT-2", "SPL-DB-2", "HWK-050"],
    explain=[
        "JVM heap exhaustion within an hour of a deployment is a strong signal of "
        "a memory leak or misconfiguration in the new build.",
        "Because GC pauses of multiple seconds hold onto DB connections and Kafka "
        "consumer sessions, downstream services (ESB, DB pool) show symptoms even "
        "though they are healthy themselves.",
        "The topology chain check ensures we only group symptoms that lie on a real "
        "dependency path from the leaking service.",
    ],
)

# Existing rules that ALSO fire for this incident (with different alert sets
# than they had for INC0048291 — that's the whole point of a rule engine).
ADDITIONAL_RULE_FIRINGS = [
    # (rule_id, alert_refs_that_match_this_time)
    ("RULE-COR-021", ["DYN-050", "APD-052", "SPL-DEM-2"]),
    ("RULE-COR-047", ["HWK-050", "APD-INT-2"]),
]


# ------------------------------------------------------------------
# CLEAN + INSERT
# ------------------------------------------------------------------

def _cleanup(db: Session) -> None:
    """Remove any prior rows for this scenario so re-running is safe."""
    # Deleting the incident cascades to incident_alerts, tier_incident_summary,
    # rule_firings, rule_firing_alerts.
    db.execute(delete(Incident).where(Incident.incident_id == INCIDENT_ID))

    # Delete our alerts (cascades to alert_metrics)
    db.execute(delete(Alert).where(Alert.alert_ref.in_([a[0] for a in ALERTS])))

    # Delete our new rule (cascades to inputs + explanations)
    db.execute(delete(CorrelationRule).where(CorrelationRule.rule_id == NEW_RULE["rule_id"]))

    # Delete sub-journey metrics + sub-journeys for the group journey
    sub_ids = [s[0] for s in SUB_JOURNEYS]
    db.execute(delete(SubJourneyMetric).where(SubJourneyMetric.sub_journey_id.in_(sub_ids)))
    db.execute(delete(SubJourney).where(SubJourney.sub_journey_id.in_(sub_ids)))

    # Delete new component dependencies (both directions)
    new_comp_ids = [c[0] for c in NEW_COMPONENTS]
    db.execute(delete(ComponentDependency).where(
        (ComponentDependency.from_component.in_(new_comp_ids)) |
        (ComponentDependency.to_component.in_(new_comp_ids))
    ))

    # Delete new components
    db.execute(delete(Component).where(Component.component_id.in_(new_comp_ids)))

    db.commit()


def seed() -> None:
    print("Ensuring schema exists...")
    Base.metadata.create_all(bind=engine)

    db: Session = SessionLocal()
    try:
        print("Cleaning prior INC0048305 rows...")
        _cleanup(db)

        # 1. Components ------------------------------------------------------
        print(f"Seeding {len(NEW_COMPONENTS)} new components...")
        db.add_all([
            Component(component_id=cid, name=nm, sub_label=sl, tier_id=tid,
                      layout_row=lr, display_order=do, level=lv, is_rc=rc)
            for cid, nm, sl, tid, lr, do, lv, rc in NEW_COMPONENTS
        ])
        db.flush()

        # 2. Component dependencies -----------------------------------------
        db.add_all([
            ComponentDependency(from_component=a, to_component=b,
                                is_critical=True, display_order=o)
            for a, b, o in NEW_CRIT_EDGES
        ])
        db.add_all([
            ComponentDependency(from_component=a, to_component=b,
                                is_critical=False, display_order=o)
            for a, b, o in NEW_NORMAL_EDGES
        ])

        # 3. Sub-journeys + metrics -----------------------------------------
        print(f"Seeding {len(SUB_JOURNEYS)} sub-journeys for '{JOURNEY_ID}'...")
        db.add_all([
            SubJourney(sub_journey_id=sid, journey_id=jid, name=nm,
                       api_label=api, display_order=o)
            for sid, jid, nm, api, o in SUB_JOURNEYS
        ])
        db.flush()
        for sid, hu, avg, p95, err, av, crit in SUB_JOURNEY_METRICS:
            hp = up = fp = None
            if hu:
                hp, up, fp = hu
            db.add(SubJourneyMetric(
                sub_journey_id=sid,
                happy_pct=hp, unhappy_pct=up, frustrated_pct=fp,
                avg_response_ms=avg, p95_ms=p95, error_rate_pct=err,
                availability_pct=av, is_critical=crit, snapshot_at=NOW,
            ))

        # 4. Fresh 'group' journey_metrics snapshot ------------------------
        # Reflects the incident impact so JourneysView shows updated numbers.
        print("Adding refreshed journey_metrics snapshot for 'group'...")
        db.add(JourneyMetric(
            journey_id=JOURNEY_ID,
            active_users=1543,
            happy_pct=62,
            unhappy_pct=23,
            frustrated_pct=15,
            availability_pct=74.30,
            open_alerts=15,
            snapshot_at=NOW,
        ))

        # 5. New correlation rule ------------------------------------------
        print(f"Seeding new rule {NEW_RULE['rule_id']}...")
        db.add(CorrelationRule(
            rule_id=NEW_RULE["rule_id"], name=NEW_RULE["name"],
            confidence_score=NEW_RULE["score"], plain_english=NEW_RULE["plain"],
            trigger_when=NEW_RULE["trigger_when"],
            trigger_target=NEW_RULE["trigger_target"],
            combine_logic=NEW_RULE["combine_logic"],
            output_summary=NEW_RULE["output"],
        ))
        db.flush()
        for i, (tool_id, sig) in enumerate(NEW_RULE["inputs"]):
            db.add(RuleCombineInput(
                rule_id=NEW_RULE["rule_id"], tool_id=tool_id,
                signal_pattern=sig, display_order=i,
            ))
        for i, txt in enumerate(NEW_RULE["explain"]):
            db.add(RuleExplanation(
                rule_id=NEW_RULE["rule_id"], paragraph_order=i, text=txt,
            ))

        # 6. Alerts + metric grids -----------------------------------------
        print(f"Seeding {len(ALERTS)} alerts...")
        for ref, name, sev, tier, tool, comp, comp_disp, hms, o7, o30, desc, metrics in ALERTS:
            t = time.fromisoformat(hms)
            db.add(Alert(
                alert_ref=ref, name=name, description=desc, severity=sev,
                tier_id=tier, tool_id=tool, component_id=comp,
                component_display_name=comp_disp,
                detected_at=NOW.replace(
                    hour=t.hour, minute=t.minute, second=t.second, microsecond=0
                ),
                first_seen_today=t,
                occurrences_7d=o7, occurrences_30d=o30,
            ))
            db.flush()
            for i, (k, v) in enumerate(metrics):
                db.add(AlertMetric(
                    alert_ref=ref, metric_key=k, metric_value=v, display_order=i,
                ))

        # 7. Incident + role assignment + tier editorials ------------------
        print(f"Creating incident {INCIDENT_ID}...")
        db.add(Incident(**INCIDENT, detected_at=NOW))
        db.flush()
        for ref, role in IN_INCIDENT_ROLES.items():
            db.add(IncidentAlert(
                incident_id=INCIDENT_ID, alert_ref=ref, role=role,
            ))
        for tier_id, is_root, txt in TIER_SUMMARIES:
            db.add(TierIncidentSummary(
                incident_id=INCIDENT_ID, tier_id=tier_id,
                is_root_cause=is_root, summary_text=txt,
            ))

        # 8. Rule firings ---------------------------------------------------
        print("Recording rule firings...")

        # 8a. New rule
        firing = RuleFiring(
            rule_id=NEW_RULE["rule_id"], incident_id=INCIDENT_ID, fired_at=NOW,
        )
        db.add(firing)
        db.flush()
        for ref in NEW_RULE["involves"]:
            db.add(RuleFiringAlert(firing_id=firing.firing_id, alert_ref=ref))

        # 8b. Existing rules that also matched this incident's alerts
        for rule_id, alert_refs in ADDITIONAL_RULE_FIRINGS:
            firing = RuleFiring(
                rule_id=rule_id, incident_id=INCIDENT_ID, fired_at=NOW,
            )
            db.add(firing)
            db.flush()
            for ref in alert_refs:
                db.add(RuleFiringAlert(firing_id=firing.firing_id, alert_ref=ref))

        db.commit()
        print()
        print(f"[OK] Group Benefits scenario seeded.")
        print(f"     Incident       : {INCIDENT_ID}")
        print(f"     Alerts         : {len(ALERTS)} ({len(IN_INCIDENT_ROLES)} in incident, "
              f"{len(ALERTS) - len(IN_INCIDENT_ROLES)} independent)")
        print(f"     Rules fired    : {1 + len(ADDITIONAL_RULE_FIRINGS)} "
              f"(new: {NEW_RULE['rule_id']} + existing)")
        print(f"     Sub-journeys   : {len(SUB_JOURNEYS)}")
        print(f"     New components : {len(NEW_COMPONENTS)}")
        print()
        print("To view in the React frontend, set in cl-observability-react/.env:")
        print(f"     VITE_INCIDENT_ID={INCIDENT_ID}")
        print("Then restart `npm run dev`.")

    finally:
        db.close()


if __name__ == "__main__":
    seed()
