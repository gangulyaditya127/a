"""Seed sub-journey <-> component mappings.

Populates the real mappings for both scenarios. Only inserts rows where both
the sub_journey and the component actually exist, so it is safe to run even
if a project hasn't seeded every component yet.
"""
from __future__ import annotations
from sqlalchemy import delete, select
from sqlalchemy.orm import Session

from app.core.database import SessionLocal, engine
from app.models import Base
from app.models.reference import Component, SubJourney
from app.models.sub_journey_components import SubJourneyComponent


# (sub_journey_id, component_id, role)
MAPPINGS = [
    # ===== Submit Health & Dental Claim (hclaim) =====
    ("verify-id",     "portal",   "primary"),
    ("verify-id",     "sso",      "primary"),
    ("verify-id",     "ora",      "downstream"),

    ("select-plan",   "portal",   "primary"),
    ("select-plan",   "claims",   "primary"),
    ("select-plan",   "ora",      "downstream"),

    ("claim-details", "portal",   "primary"),
    ("claim-details", "claims",   "primary"),

    # The critical path — this is the one that lights up as INC0048291
    ("upload-recpt",  "portal",   "primary"),
    ("upload-recpt",  "gw",       "primary"),
    ("upload-recpt",  "claims",   "primary"),
    ("upload-recpt",  "esb",      "downstream"),
    ("upload-recpt",  "ora",      "downstream"),
    ("upload-recpt",  "fnet",     "downstream"),
    ("upload-recpt",  "dyna",     "observability"),

    ("consent",       "portal",   "primary"),
    ("consent",       "claims",   "primary"),

    ("esign",         "portal",   "primary"),
    ("esign",         "claims",   "primary"),
    ("esign",         "esb",      "downstream"),

    ("adjudicate",    "claims",   "primary"),
    ("adjudicate",    "ora",      "downstream"),

    ("eob",           "claims",   "primary"),
    ("eob",           "fnet",     "downstream"),

    ("payout",        "claims",   "primary"),
    ("payout",        "esb",      "downstream"),
    ("payout",        "legacy",   "downstream"),

    # ===== Group Benefits Enrollment (group) =====
    ("verify-employer", "portal",     "primary"),
    ("verify-employer", "sso",        "primary"),
    ("verify-employer", "ora",        "downstream"),

    ("upload-roster",   "portal",     "primary"),
    ("upload-roster",   "gw",         "primary"),
    ("upload-roster",   "fnet",       "downstream"),

    ("validate-roster", "elig-svc",   "primary"),
    ("validate-roster", "ora",        "downstream"),

    ("select-coverage", "portal",     "primary"),
    ("select-coverage", "rating-eng", "primary"),

    ("elig-check",      "elig-svc",   "primary"),
    ("elig-check",      "ora",        "downstream"),
    ("elig-check",      "grpdb",      "downstream"),

    # The critical path — this is the one that lights up as INC0048305
    ("rate-calc",       "portal",     "primary"),
    ("rate-calc",       "gw",         "primary"),
    ("rate-calc",       "rating-eng", "primary"),
    ("rate-calc",       "kafka",      "downstream"),
    ("rate-calc",       "esb",        "downstream"),
    ("rate-calc",       "grpdb",      "downstream"),
    ("rate-calc",       "dyna",       "observability"),

    ("contract-prev",   "portal",     "primary"),
    ("contract-prev",   "rating-eng", "primary"),

    ("esign-bind",      "portal",     "primary"),
    ("esign-bind",      "rating-eng", "primary"),
    ("esign-bind",      "esb",        "downstream"),

    ("welcome-kit",     "notify",     "primary"),
    ("welcome-kit",     "fnet",       "downstream"),
]


def seed():
    print("Ensuring schema exists...")
    Base.metadata.create_all(bind=engine)

    db: Session = SessionLocal()
    try:
        existing_sj    = {r[0] for r in db.execute(select(SubJourney.sub_journey_id)).all()}
        existing_comps = {r[0] for r in db.execute(select(Component.component_id)).all()}

        # Clean prior mappings for the sub-journeys we're about to seed
        touched_sj = {s for s, _, _ in MAPPINGS}
        db.execute(
            delete(SubJourneyComponent).where(
                SubJourneyComponent.sub_journey_id.in_(touched_sj)
            )
        )
        db.commit()

        added = skipped = 0
        for sj_id, comp_id, role in MAPPINGS:
            if sj_id not in existing_sj:
                skipped += 1
                continue
            if comp_id not in existing_comps:
                skipped += 1
                continue
            db.add(SubJourneyComponent(
                sub_journey_id=sj_id, component_id=comp_id, role=role,
            ))
            added += 1

        db.commit()
        print(f"[OK] Seeded {added} sub-journey <-> component mappings "
              f"({skipped} skipped due to missing sub-journey or component).")
    finally:
        db.close()


if __name__ == "__main__":
    seed()
