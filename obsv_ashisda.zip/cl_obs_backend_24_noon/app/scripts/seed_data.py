"""Seed the DB with data reproducing the React frontend JSON.

Idempotent — running twice truncates and re-inserts.
Run:
    python -m app.scripts.seed_data
"""
from datetime import datetime, time, timezone

from sqlalchemy import delete
from sqlalchemy.orm import Session

from app.core.database import SessionLocal, engine
from app.models import Base
from app.models.reference import (
    Tier, MonitoringTool, Component, ComponentDependency, Journey, SubJourney,
)
from app.models.rules import CorrelationRule, RuleCombineInput, RuleExplanation
from app.models.metrics import JourneyMetric, SubJourneyMetric
from app.models.alerts import Alert, AlertMetric
from app.models.incidents import (
    Incident, IncidentAlert, TierIncidentSummary, RuleFiring, RuleFiringAlert, IncidentSubJourney,
)
from app.models.analytics import TierHistoricalStat, TierTopCause

from app.models.ai_discovery import CiToolCoverage, DiscoveredPattern, AiRuleProposal, RuleReviewEvent

NOW = datetime.now(timezone.utc)

# ---------- Tiers ----------
TIERS = [
    ("pres",  "Presentation",   0, "\U0001f5a5\ufe0f", "crit"),
    ("app",   "Application",    1, "\u2699\ufe0f",     "crit"),
    ("int",   "Integration",    2, "\U0001f50c",        "crit"),
    ("data",  "Data",           3, "\U0001f5c4\ufe0f", "crit"),
    ("infra", "Infrastructure", 4, "\U0001f4be",        "deg"),
]

# ---------- Tools ----------
# (tool_id, name (alert.src), short_name (source-mix chip), color)
TOOLS = [
    ("dynatrace",     "Dynatrace",      None,       "#1e40af"),
    ("splunk",        "Splunk",         None,       "#b45309"),
    ("appd",          "AppDynamics",    None,       "#0f7a4d"),
    ("appd_db",       "AppDynamics DB", "AppD DB",  "#0f7a4d"),
    ("tibco_hawk",    "TIBCO Hawk",     None,       "#7c3aed"),
    ("oracle_em",     "Oracle EM",      None,       "#c8102e"),
    ("filenet_admin", "FileNet Admin",  "FileNet",  "#0e7490"),
    ("solarwinds",    "SolarWinds",     None,       "#0e7490"),
    ("vmware_vc",     "VMware vCenter", "VMware",   "#0e7490"),
    ("redis_insight", "Redis Insight",  None,       "#7c3aed"),
]

# ---------- Components (swim-lane nodes) ----------
# (component_id, name, sub_label, tier_id, layout_row, display_order, level, is_rc)
COMPONENTS = [
    ("portal",  "My CL Portal",     "React SPA",       "pres",  0, 0, "ok",   False),
    ("gw",      "API Gateway",      "Apigee",          "app",   0, 1, "deg",  False),
    ("claims",  "Claims Service",   "Spring Boot",     "app",   1, 2, "crit", False),
    ("sso",     "SSO / OIDC",       "PingFederate",    "app",   2, 3, "ok",   False),
    ("notify",  "Notification Svc", "Email / SMS",     "int",   0, 4, "crit", False),
    ("esb",     "Enterprise Bus",   "TIBCO BW",        "int",   1, 5, "crit", False),
    ("fnet",    "Document Store",   "IBM FileNet",     "data",  0, 6, "deg",  False),
    ("ora",     "Policy Admin DB",  "Oracle RAC 19c",  "data",  1, 7, "crit", True),
    ("legacy",  "Policy of Record", "Mainframe GW",    "data",  2, 8, "ok",   False),
    ("esxi",    "ESXi Host",        "esxi-prod-03",    "infra", 0, 9, "deg",  False),
    ("dyna",    "Digital Exp Mon",  "Dynatrace",       "infra", 1, 10, "ok", False),
]

# Critical (red) edges + non-critical dependencies
# display_order for stable output
CRIT_EDGES = [
    ("gw", "claims", 0),
    ("claims", "esb", 1),
    ("claims", "notify", 2),
    ("esb", "ora", 3),
    ("ora", "dyna", 4),
]
NORMAL_EDGES = [
    ("portal", "gw", 0),
    ("portal", "claims", 1),
    ("portal", "sso", 2),
    ("notify", "fnet", 3),
    ("esb", "legacy", 4),
    ("fnet", "esxi", 5),
]

# ---------- Journeys ----------
JOURNEYS = [
    ("login",   "My Canada Life Login & Registration",  "individual", 0),
    ("quote",   "Get an Insurance Quote",               "individual", 1),
    ("hclaim",  "Submit Health & Dental Claim",         "individual", 2),
    ("buy",     "Buy Life Insurance Policy",            "individual", 3),
    ("group",   "Group Benefits Enrollment",            "group",      4),
    ("wealth",  "Manage Investments / Segregated Funds","wealth",     5),
    ("annuity", "Annuity / Retirement Income Quote",    "wealth",     6),
    ("benef",   "Update Beneficiary",                   "individual", 7),
    ("premium", "Premium Payment",                      "individual", 8),
    ("advisor", "Advisor Portal | New Business",        "advisor",    9),
]
# (journey_id, users, happy, unhappy, frustrated, avail, alerts)
JOURNEY_METRICS = [
    ("login",   2140, 92, 7,  1, 99.41, 0),
    ("quote",   1685, 88, 9,  3, 96.82, 2),
    ("hclaim",  1904, 76, 16, 8, 69.56, 14),
    ("buy",     1120, 90, 8,  2, 94.10, 3),
    ("group",   1543, 89, 8,  3, 91.54, 5),
    ("wealth",  867,  93, 5,  2, 97.32, 1),
    ("annuity", 512,  94, 4,  2, 96.21, 2),
    ("benef",   734,  96, 3,  1, 98.42, 1),
    ("premium", 1298, 97, 2,  1, 98.76, 1),
    ("advisor", 640,  91, 6,  3, 95.30, 2),
]

# ---------- Sub-journeys (hclaim only, matches subJourneys.json) ----------
SUB_JOURNEYS = [
    ("verify-id",     "hclaim", "Verify Member Identity",         "Verify Member Identity",     0),
    ("select-plan",   "hclaim", "Select Policy / Benefit Plan",   "Select Benefit Plan",        1),
    ("claim-details", "hclaim", "Enter Claim Details",            "Enter Claim Details",        2),
    ("upload-recpt",  "hclaim", "Upload Receipts",                "Upload Receipts (FileNet)",  3),
    ("consent",       "hclaim", "Consent & Declaration",          "Consent & Declaration",      4),
    ("esign",         "hclaim", "e-Sign & Fraud Screening",       "e-Sign & Fraud Screening",   5),
    ("adjudicate",    "hclaim", "Adjudication (Rules Engine)",    "Adjudicate Claim",           6),
    ("eob",           "hclaim", "Explanation of Benefits (EOB)",  "Generate EOB Document",      7),
    ("payout",        "hclaim", "Direct Deposit Payout",          "Direct Deposit Payout",      8),
]
# (sub_journey_id, hu(or None), avg, p95, err, avail, critical)
SUB_JOURNEY_METRICS = [
    ("verify-id",     None,          210,  310,  2.0,  99.23, False),
    ("select-plan",   None,          135,  220,  1.0,  98.45, False),
    ("claim-details", None,          180,  290,  2.0,  97.60, False),
    ("upload-recpt",  (76, 16, 8),   5541, 7234, 18.0, 69.56, True),
    ("consent",       None,          118,  198,  2.0,  96.80, False),
    ("esign",         (91, 6, 3),    340,  512,  2.0,  96.10, False),
    ("adjudicate",    None,          820,  1240, 3.0,  97.10, False),
    ("eob",           None,          210,  340,  1.0,  99.10, False),
    ("payout",        None,          420,  680,  2.0,  97.40, False),
]

# ---------- Raw alerts ----------
# (ref, name, sev, tier, tool, comp, comp_display, time, occ7, occ30, desc, metrics_list)
ALERTS = [
    ("DYN-001", "BackendCallResponseTimeHigh", "crit", "pres", "dynatrace", "dyna",
     "Digital Experience Monitor", "14:00:06", 4, 11,
     "PolicyRecalcAdapter response time degraded to 6200 ms (baseline 400 ms).",
     [("Service Response Time","6200 ms"),("Baseline","400 ms"),("Deviation","15.5x"),
      ("Impacted Sessions","4,580"),("Business Transaction","pas.recalcBenefit"),
      ("Detected By","Real User Monitoring")]),
    ("DYN-002", "UserActionFailureRate", "high", "pres", "dynatrace", "dyna",
     "Digital Experience Monitor", "14:00:22", 3, 9,
     "Endorsement submission failure rate 18% across 4,580 active sessions.",
     [("Failure Rate","18%"),("Baseline","1.2%"),("Active Sessions","4,580"),
      ("User Action","submitEndorsement")]),
    ("SPL-DEM-1", "GatewayTimeoutSpike", "high", "pres", "splunk", "gw",
     "API Gateway", "14:00:30", 2, 7,
     "504 Gateway Timeout responses spiked to 340/min on /api/endorsement/recalc.",
     [("Rate","340/min"),("Baseline","8/min"),("Path","/api/endorsement/recalc")]),
    ("SPL-APP-1", "JVMOldGenSaturation", "crit", "app", "splunk", "claims",
     "Claims Service", "14:23:10", 2, 6,
     "JVM Old Gen at 96% on PAS_MS1 - full GC pauses > 8 s.",
     [("Old Gen","96%"),("Full GC pause","8200 ms"),("Host","pas-ms1.prod")]),
    ("APD-001", "ThreadPoolExhaustion", "crit", "app", "appd", "claims",
     "Claims Service", "14:23:18", 5, 14,
     "Thread pool exhaustion: 198/200 threads busy on managed server PAS_MS1.",
     [("Threads Active","198/200"),("Wait Queue","340"),("Managed Server","PAS_MS1"),
      ("Node Health","22/100")]),
    ("SPL-APP-2", "ErrorLogSurge", "high", "app", "splunk", "claims",
     "Claims Service", "14:23:22", 3, 8,
     "ERROR log volume 12x baseline on PolicyEndorsement.bwp.",
     [("Log rate","1240/min"),("Baseline","100/min"),("Deviation","12x")]),
    ("APD-002", "HighResponseTimeDeviation", "high", "app", "appd", "claims",
     "Claims Service", "14:23:45", 4, 11,
     "Average response time 5.2 s exceeds baseline 400 ms (13x deviation).",
     [("Avg Response","5200 ms"),("Baseline","400 ms"),("Deviation","13x"),
      ("Business Transaction","submitClaim")]),
    ("APD-003", "RuleExecutionTimeout", "crit", "app", "appd", "claims",
     "Adjudication Rules Engine", "14:24:02", 3, 8,
     "Rule execution timeout: 4.8 s per invocation (threshold 500 ms).",
     [("Exec Time","4800 ms"),("Threshold","500 ms"),("Rule Set","claims-adjudication.v42")]),
    ("HWK-001", "ProcessEngineStuckThread", "crit", "int", "tibco_hawk", "esb",
     "Enterprise Service Bus", "14:23:22", 2, 5,
     "Process engine stuck thread count: 47/50 - process PolicyEndorsement.bwp backlogged.",
     [("Stuck Threads","47/50"),("Process","PolicyEndorsement.bwp"),("Node","tibco-bw-02")]),
    ("HWK-002", "HighQueueDepth", "high", "int", "tibco_hawk", "esb",
     "Enterprise Service Bus", "14:23:35", 3, 10,
     "Queue depth PAS.ENDORSEMENT.REQ: 2,340 messages (threshold 500).",
     [("Queue Depth","2340"),("Threshold","500"),("Queue","PAS.ENDORSEMENT.REQ")]),
    ("SPL-INT-1", "ESBTransactionLatency", "high", "int", "splunk", "esb",
     "Enterprise Service Bus", "14:23:50", 2, 7,
     "ESB transaction latency P95 6.4 s (threshold 1 s).",
     [("P95","6400 ms"),("Threshold","1000 ms")]),
    ("APD-INT-1", "ESBHealthDegraded", "crit", "int", "appd", "esb",
     "Enterprise Service Bus", "14:24:04", 1, 3,
     "TIBCO BusinessWorks node health score 22/100.",
     [("Health Score","22/100"),("Node","tibco-bw-02")]),
    ("OEM-001", "RACNodeInstanceFailover", "crit", "data", "oracle_em", "ora",
     "Policy Admin DB (Oracle RAC 19c)", "14:23:05", 1, 2,
     "RAC Node-2 instance failover detected at 14:23:05 - unplanned (CHG0045231 maintenance overrun).",
     [("RAC Node Status","Node-2 DOWN"),("Cluster","PAS_RAC_CL01"),("Change Ref","CHG0045231"),
      ("Instance","PASDB2"),("Cluster Interconnect","healthy"),("Fast Start Failover","triggered")]),
    ("SPL-DB-1", "DBConnectionExhaustion", "high", "data", "splunk", "ora",
     "Policy Admin DB", "14:23:15", 2, 6,
     "Connection pool exhausted on DB-01 (200/200).",
     [("Pool","200/200"),("Wait Queue","48")]),
    ("OEM-002", "ActiveSessionsSpike", "crit", "data", "oracle_em", "ora",
     "Policy Admin DB (Oracle RAC 19c)", "14:23:20", 2, 4,
     "Active sessions spike: 340 to 890 on Node-1 (absorbing Node-2 load).",
     [("Sessions","340 to 890"),("Node","PASDB1"),("CPU","82%")]),
    ("APD-DB-1", "SQLResponseTimeSpike", "crit", "data", "appd_db", "ora",
     "Policy Admin DB", "14:23:33", 3, 9,
     "SQL response time P95 8.2 s (baseline 120 ms).",
     [("P95","8200 ms"),("Baseline","120 ms")]),
    ("FN-001", "DocRepositoryTimeout", "high", "data", "filenet_admin", "fnet",
     "IBM FileNet P8", "14:23:41", 4, 12,
     "Document repository read timeout during endorsement submit.",
     [("Timeouts/min","62"),("Object Store","PAS_DOCS")]),
    ("SW-001", "CPUReadyTimeHigh", "high", "infra", "solarwinds", "esxi",
     "ESXi Host esxi-prod-03", "14:25:00", 1, 4,
     "CPU ready time: 12 ms (threshold 5 ms) on ESXi host esxi-prod-03.",
     [("CPU Ready","12 ms"),("Threshold","5 ms"),("Host","esxi-prod-03")]),
    ("VC-001", "VMMemoryBalloonActive", "high", "infra", "vmware_vc", "esxi",
     "ESXi Host esxi-prod-03", "14:25:10", 1, 3,
     "VM memory balloon active: weblogic-pas-03 at 92% - host memory contention.",
     [("VM Memory Balloon","92%"),("VM","weblogic-pas-03"),("Host","esxi-prod-03")]),
]

# ---------- Incident + tier summaries ----------
INCIDENT_ID = "INC0048291"
INCIDENT = dict(
    incident_id=INCIDENT_ID,
    title="Payment subsystem degradation cascading to Order Service, Message Queue & Mainframe Gateway",
    root_cause_desc=(
        "At 14:23:05, RAC Node-2 of the Policy Admin database failed over. "
        "The surviving node absorbed ~2x session load, exhausting connection pools on dependent JVMs."
    ),
    root_cause_component_id="ora",
    raw_alerts_grouped=14,
    tools_contributing=6,
    correlation_confidence_pct=94.0,
    frustrated_user_count=152,
    status="investigating",
)

IN_INCIDENT_ROLES = {
    "DYN-001":"symptom","DYN-002":"symptom","SPL-DEM-1":"symptom",
    "APD-001":"downstream","APD-002":"downstream","APD-003":"downstream",
    "SPL-APP-1":"downstream","SPL-APP-2":"downstream",
    "HWK-001":"downstream","HWK-002":"downstream","SPL-INT-1":"downstream","APD-INT-1":"downstream",
    "OEM-001":"root_cause","OEM-002":"contributing","APD-DB-1":"downstream","SPL-DB-1":"downstream",
    "FN-001":"downstream",
    # SW-001 and VC-001 are NOT part of INC0048291 (independent infra)
}

TIER_SUMMARIES = [
    ("pres",  False, "End-user impact detected first. All 3 alerts trace to slow backend calls - no independent presentation-tier fault."),
    ("app",   False, "Direct downstream of the DB failover. Thread pools saturated within 13s - 3 critical + 2 high alerts in 52 seconds."),
    ("int",   False, "ESB stuck within 17s of DB failure. Queue backlog and node health both correlated as downstream symptoms."),
    ("data",  True,  "Root cause. Unplanned RAC Node-2 failover at 14:23:05 triggered every downstream alert on this incident."),
    ("infra", False, "Independent hypervisor contention on esxi-prod-03. Not part of the DB incident - tracked separately."),
]

# ---------- Historical stats + top causes ----------
TIER_STATS = [
    ("pres",  3, 2, 9,  12),
    ("app",   5, 5, 18, 22),
    ("int",   4, 3, 11, 18),
    ("data",  5, 1, 2,  28),
    ("infra", 2, 1, 5,  34),
]
TIER_CAUSES = {
    "pres":  [("Downstream backend / API latency", 56),
              ("CDN cache miss surge on portal pages", 22),
              ("Client script errors on submit form", 14)],
    "app":   [("DB connection pool exhaustion under load", 44),
              ("JVM garbage collection / heap pressure", 31),
              ("Rule engine execution timeouts", 18)],
    "int":   [("ESB process engine stuck threads", 48),
              ("Message queue backlog on endorsement", 29),
              ("BusinessWorks node health degradation", 15)],
    "data":  [("Oracle RAC node failover events", 52),
              ("Slow SQL / lock contention on core tables", 24),
              ("FileNet content-engine read stalls", 16)],
    "infra": [("ESXi host CPU contention", 45),
              ("VM memory ballooning under pressure", 28),
              ("Storage IO latency spikes", 14)],
}

# ---------- Correlation rules ----------
RULES = [
  dict(
    rule_id="RULE-COR-014", name="Database-driven service degradation cascade",
    score=0.94,
    plain=("When the primary Oracle RAC database loses a node, dependent JVMs saturate connection pools "
           "within seconds and the ESB backs up. This rule groups those symptoms into one incident."),
    trigger_when="Oracle EM | RACNodeInstanceFailover",
    trigger_target="Policy Admin DB / Oracle RAC cluster",
    combine_logic="AND within 180 s AND on dependent topology chain (Data -> Integration -> Application)",
    output="Single incident - root cause = Policy Admin DB. 12 downstream alerts suppressed.",
    inputs=[("oracle_em","RACNodeInstanceFailover"),
            ("appd","ThreadPoolExhaustion / RuleExecutionTimeout"),
            ("tibco_hawk","ProcessEngineStuckThread"),
            ("splunk","DBConnectionExhaustion")],
    involves=["OEM-001","APD-001","APD-003","SPL-DB-1","HWK-001","APD-INT-1"],
    explain=[
        "When the primary database loses a RAC node, the surviving node absorbs about 2x load. Dependent JVMs saturate their connection pools within seconds.",
        "Because the topology graph tells the engine that App -> ESB -> DB is one causal chain, alerts firing on any node on this chain are grouped rather than paged separately.",
        "The rule suppresses redundant symptomatic alerts and elevates the earliest data-tier alert as root cause.",
    ]),
  dict(
    rule_id="RULE-COR-021", name="End-user latency traced to backend slowness",
    score=0.88,
    plain=("When real-user monitoring detects slow calls in the browser and APM confirms the same latency "
           "inside the JVM within a minute, they are grouped as one user-experience incident."),
    trigger_when="Dynatrace | BackendCallResponseTimeHigh",
    trigger_target="Benefit Recalculation Service",
    combine_logic="Match on business_transaction_id AND time window <= 60 s",
    output="One user-experience incident, annotated with impacted-user count.",
    inputs=[("dynatrace","BackendCallResponseTimeHigh"),
            ("appd","HighResponseTimeDeviation"),
            ("splunk","GatewayTimeoutSpike")],
    involves=["DYN-001","APD-002","SPL-DEM-1"],
    explain=[
        "Real-user monitoring detects a slow backend call in the browser. APM confirms the same latency inside the JVM.",
        "The gateway-timeout spike at the edge is symptomatic of the same event.",
    ]),
  dict(
    rule_id="RULE-COR-033", name="Hypervisor contention triggering JVM instability",
    score=0.79,
    plain=("When the ESXi host is over-committed, guest VMs experience memory ballooning and CPU steal - "
           "the JVM inside sees GC storms."),
    trigger_when="VMware | VMMemoryBalloonActive OR SolarWinds | CPUReadyTimeHigh",
    trigger_target="ESXi host esxi-prod-03",
    combine_logic="AND on host_id within 300 s",
    output="JVM GC storm re-classified as infrastructure sub-incident.",
    inputs=[("vmware_vc","VMMemoryBalloonActive"),
            ("solarwinds","CPUReadyTimeHigh"),
            ("splunk","JVMOldGenSaturation")],
    involves=["SW-001","VC-001","SPL-APP-1"],
    explain=[
        "If the ESXi host is over-committed, guest VMs experience memory ballooning and CPU steal.",
        "Correlating hypervisor + guest signals prevents mis-attributing the fault to a code path.",
    ]),
  dict(
    rule_id="RULE-COR-047", name="Queue backlog explained by ESB degradation",
    score=0.71,
    plain=("A backing queue draining slowly is usually a consumer-side problem - here, the ESB itself is "
           "degraded because its DB writes are stalled."),
    trigger_when="TIBCO Hawk | HighQueueDepth", trigger_target="PAS.ENDORSEMENT.REQ",
    combine_logic="Match on queue_name AND health_score < 40",
    output="Merged into integration sub-incident under parent DB incident.",
    inputs=[("tibco_hawk","HighQueueDepth"),("appd","ESBHealthDegraded")],
    involves=["HWK-002","APD-INT-1"],
    explain=["A queue draining slowly is usually a consumer-side problem - here, the ESB itself is degraded because its DB writes are stalled."]),
  dict(
    rule_id="RULE-COR-052", name="Session cache pressure follows RAC failover",
    score=0.64,
    plain="When DB latency rises, application logic thrashes the session cache to compensate.",
    trigger_when="Oracle EM | ActiveSessionsSpike",
    trigger_target="Policy Admin DB / Oracle RAC",
    combine_logic="AND within 120 s",
    output="Attached as contributing evidence to parent DB incident.",
    inputs=[("redis_insight","CacheEvictionSpike"),("oracle_em","ActiveSessionsSpike")],
    involves=["OEM-002"],
    explain=["When DB latency rises, application logic thrashes the session cache to compensate."]),
]


def _truncate_all(db: Session):
    print("Truncating existing rows...")
    
    # Strictly ordered list: Children must be deleted before their Parents
    models_to_delete = [
        # 1. AI Discovery Tables (Must go first!)
        RuleReviewEvent,
        AiRuleProposal,
        DiscoveredPattern,
        CiToolCoverage,

        # 2. Analytics & Summaries
        TierIncidentSummary,
        TierHistoricalStat,
        TierTopCause,

        # 3. Incident & Alert Bridges
        IncidentSubJourney,
        IncidentAlert,
        RuleFiringAlert,
        RuleFiring,

        # 4. Base Events
        Incident,
        AlertMetric,
        Alert,

        # 5. Rules
        RuleExplanation,
        RuleCombineInput,
        CorrelationRule,

        # 6. Dependencies
        ComponentDependency,

        # 7. Architecture & Reference
        SubJourneyMetric,
        SubJourney,
        JourneyMetric,
        Journey,
        Component,         # <-- Now safe to delete!
        MonitoringTool,
        Tier
    ]

    for model in models_to_delete:
        db.execute(delete(model))

    db.commit()
def seed():
    print("Creating schema (if needed)...")
    Base.metadata.create_all(bind=engine)
    db: Session = SessionLocal()
    try:
        print("Truncating existing rows...")
        _truncate_all(db)

        print("Seeding tiers + tools...")
        db.add_all([Tier(tier_id=i, name=n, display_order=o, icon=ic, level=lv)
                    for i, n, o, ic, lv in TIERS])
        db.add_all([MonitoringTool(tool_id=t, name=n, short_name=sn, color_hex=c)
                    for t, n, sn, c in TOOLS])
        db.flush()

        print("Seeding components + dependencies...")
        db.add_all([
            Component(component_id=cid, name=nm, sub_label=sl, tier_id=tid,
                      layout_row=lr, display_order=do, level=lv, is_rc=rc)
            for cid, nm, sl, tid, lr, do, lv, rc in COMPONENTS
        ])
        db.flush()
        db.add_all([ComponentDependency(from_component=a, to_component=b,
                                        is_critical=True, display_order=o)
                    for a, b, o in CRIT_EDGES])
        db.add_all([ComponentDependency(from_component=a, to_component=b,
                                        is_critical=False, display_order=o)
                    for a, b, o in NORMAL_EDGES])

        print("Seeding journeys + metrics...")
        db.add_all([Journey(journey_id=j, name=n, segment=s, display_order=o)
                    for j, n, s, o in JOURNEYS])
        db.flush()
        db.add_all([JourneyMetric(
            journey_id=jid, active_users=u, happy_pct=h, unhappy_pct=un,
            frustrated_pct=fr, availability_pct=av, open_alerts=al, snapshot_at=NOW)
            for jid, u, h, un, fr, av, al in JOURNEY_METRICS])

        print("Seeding sub-journeys + metrics...")
        db.add_all([SubJourney(sub_journey_id=sid, journey_id=jid, name=nm,
                               api_label=api, display_order=o)
                    for sid, jid, nm, api, o in SUB_JOURNEYS])
        db.flush()
        for sid, hu, avg, p95, err, av, crit in SUB_JOURNEY_METRICS:
            hp = up = fp = None
            if hu:
                hp, up, fp = hu
            db.add(SubJourneyMetric(
                sub_journey_id=sid, happy_pct=hp, unhappy_pct=up, frustrated_pct=fp,
                avg_response_ms=avg, p95_ms=p95, error_rate_pct=err,
                availability_pct=av, is_critical=crit, snapshot_at=NOW,
            ))

        print(f"Seeding {len(ALERTS)} alerts + metrics...")
        for ref, name, sev, tier, tool, comp, comp_disp, hms, o7, o30, desc, metrics in ALERTS:
            t = time.fromisoformat(hms)
            db.add(Alert(
                alert_ref=ref, name=name, description=desc, severity=sev,
                tier_id=tier, tool_id=tool, component_id=comp,
                component_display_name=comp_disp,
                detected_at=NOW.replace(hour=t.hour, minute=t.minute, second=t.second, microsecond=0),
                first_seen_today=t, occurrences_7d=o7, occurrences_30d=o30,
            ))
            db.flush()
            for i, (k, v) in enumerate(metrics):
                db.add(AlertMetric(alert_ref=ref, metric_key=k, metric_value=v, display_order=i))

        print("Seeding incident + tier summaries...")
        db.add(Incident(**INCIDENT, detected_at=NOW))
        db.flush()
        for ref, role in IN_INCIDENT_ROLES.items():
            db.add(IncidentAlert(incident_id=INCIDENT_ID, alert_ref=ref, role=role))
        for tier_id, is_root, txt in TIER_SUMMARIES:
            db.add(TierIncidentSummary(
                incident_id=INCIDENT_ID, tier_id=tier_id, is_root_cause=is_root, summary_text=txt
            ))

        # Seed incident <-> sub-journey mapping
        for sj_id in ["upload-recpt"]:
            db.add(IncidentSubJourney(incident_id=INCIDENT_ID, sub_journey_id=sj_id))

        print("Seeding analytics (historical stats + top causes)...")
        for tier_id, tday, w7, w30, mttr in TIER_STATS:
            db.add(TierHistoricalStat(
                tier_id=tier_id, alerts_today=tday, alerts_last_7d=w7, alerts_last_30d=w30,
                median_mttr_minutes=mttr, computed_at=NOW,
            ))
        for tier_id, causes in TIER_CAUSES.items():
            for rank, (nm, pct) in enumerate(causes, start=1):
                db.add(TierTopCause(
                    tier_id=tier_id, rank=rank, cause_name=nm, percentage=pct, computed_at=NOW,
                ))

        print(f"Seeding {len(RULES)} correlation rules + firings...")
        for r in RULES:
            db.add(CorrelationRule(
                rule_id=r["rule_id"], name=r["name"], confidence_score=r["score"],
                plain_english=r["plain"], trigger_when=r["trigger_when"],
                trigger_target=r["trigger_target"], combine_logic=r["combine_logic"],
                output_summary=r["output"],
            ))
            db.flush()
            for i, (tool_id, sig) in enumerate(r["inputs"]):
                db.add(RuleCombineInput(rule_id=r["rule_id"], tool_id=tool_id,
                                        signal_pattern=sig, display_order=i))
            for i, txt in enumerate(r["explain"]):
                db.add(RuleExplanation(rule_id=r["rule_id"], paragraph_order=i, text=txt))
            firing = RuleFiring(rule_id=r["rule_id"], incident_id=INCIDENT_ID, fired_at=NOW)
            db.add(firing)
            db.flush()
            for ref in r["involves"]:
                db.add(RuleFiringAlert(firing_id=firing.firing_id, alert_ref=ref))

        db.commit()
        print(f"\n[OK] Seed complete - incident {INCIDENT_ID}, "
              f"{len(ALERTS)} alerts, {len(RULES)} rules, "
              f"{len(JOURNEYS)} journeys, {len(COMPONENTS)} components")
    finally:
        db.close()


if __name__ == "__main__":
    seed()
