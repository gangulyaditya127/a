"""Canada Life . ARE Observability - FastAPI entrypoint.

Follows the reference cl-backend-skeleton:
  app/main.py    -> FastAPI + /api/v1 router registration
  app/api/v1/*   -> thin routers, try/except -> HTTPException
  app/services/* -> static-method service classes
  app/core/*     -> config, database engine/session
"""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.core.config import settings
from app.api.v1.health import router as health_router
from app.api.v1.journeys import router as journeys_router
from app.api.v1.analysis import router as analysis_router
from app.api.v1.alerts import router as alerts_router
from app.api.v1.rules import router as rules_router
from app.api.v1.ai import router as ai_router
from app.api.v1.correlation import router as correlation_router  # NEW
# from app.api.v1.incidents import router as incidents_router          # NEW

from app.models.base import Base
from app.core.database import engine

app = FastAPI(
    title=settings.APP_NAME,
    version=settings.APP_VERSION,
    description=(
        "Backend for the Canada Life ARE Observability React frontend. "
        "Replaces the /public/data/*.json fixtures with PostgreSQL-backed endpoints."
    ),
)

@app.on_event("startup")
def startup_event():
    print("Ensuring database schema is created...")
    Base.metadata.create_all(bind=engine)


app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(health_router,       prefix="/api/v1")
app.include_router(journeys_router,     prefix="/api/v1")
app.include_router(analysis_router,     prefix="/api/v1")
app.include_router(alerts_router,       prefix="/api/v1")
app.include_router(rules_router,        prefix="/api/v1")
app.include_router(ai_router,           prefix="/api/v1")
app.include_router(correlation_router,  prefix="/api/v1")   # NEW
# app.include_router(incidents_router,  prefix="/api/v1")   # NEW



@app.get("/")
def root():
    return {"application": settings.APP_NAME, "status": "running", "version": settings.APP_VERSION}

# ============================================================================
# Combined installer patch (correlation engine + AI Rule Discovery)
# ============================================================================
try:
    from app.api.v1.correlation import router as correlation_router
    app.include_router(correlation_router, prefix="/api/v1")
except Exception as _e:
    print(f"[installer] correlation router not registered: {_e}")

try:
    from app.api.v1.rule_discovery import router as rule_discovery_router
    app.include_router(rule_discovery_router, prefix="/api/v1")
except Exception as _e:
    print(f"[installer] rule_discovery router not registered: {_e}")

try:
    from app.api.v1.incidents import router as incidents_router
    app.include_router(incidents_router, prefix="/api/v1")
except Exception as _e:
    print(f"[installer] incidents router not registered: {_e}")
# ============================================================================

# ============================================================================
# Sub-journey component mapping (installer patch)
# ============================================================================
try:
    from app.api.v1.sub_journey_analysis import router as sub_journey_analysis_router
    app.include_router(sub_journey_analysis_router, prefix="/api/v1")
except Exception as _e:
    print(f"[installer] sub_journey_analysis router not registered: {_e}")
# ============================================================================
