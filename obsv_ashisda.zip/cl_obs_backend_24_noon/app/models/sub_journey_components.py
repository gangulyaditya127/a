"""Junction table: sub-journeys <-> components.

Answers the question: "Which CIs are actually involved when a user hits step X
of journey Y?" — enabling alert lookup that is not gated by an existing incident.

role values:
    * 'primary'        - the CI is the main workload for this step
    * 'downstream'     - the CI is on the dependency chain
    * 'observability'  - the CI is only used for RUM/monitoring of this step
"""
from __future__ import annotations
from sqlalchemy import String, ForeignKey, CheckConstraint
from sqlalchemy.orm import Mapped, mapped_column

from app.models.base import Base


class SubJourneyComponent(Base):
    __tablename__ = "sub_journey_components"
    sub_journey_id: Mapped[str] = mapped_column(
        String(40),
        ForeignKey("sub_journeys.sub_journey_id", ondelete="CASCADE"),
        primary_key=True,
    )
    component_id:   Mapped[str] = mapped_column(
        String(30),
        ForeignKey("components.component_id", ondelete="CASCADE"),
        primary_key=True,
    )
    role:           Mapped[str] = mapped_column(String(20), nullable=False, default="downstream")

    __table_args__ = (
        CheckConstraint(
            "role in ('primary','downstream','observability')",
            name="sub_journey_component_role_valid",
        ),
    )
