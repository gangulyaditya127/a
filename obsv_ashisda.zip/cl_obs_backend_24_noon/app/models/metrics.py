"""Time-series metrics for journeys and sub-journeys."""
from datetime import datetime
from sqlalchemy import String, Integer, Numeric, ForeignKey, DateTime, CheckConstraint, Boolean
from sqlalchemy.orm import Mapped, mapped_column

from app.models.base import Base


class JourneyMetric(Base):
    __tablename__ = "journey_metrics"
    metric_id:        Mapped[int]      = mapped_column(Integer, primary_key=True, autoincrement=True)
    journey_id:       Mapped[str]      = mapped_column(String(30),
                                                       ForeignKey("journeys.journey_id"),
                                                       nullable=False, index=True)
    active_users:     Mapped[int]      = mapped_column(Integer, nullable=False)
    happy_pct:        Mapped[int]      = mapped_column(Integer, nullable=False)
    unhappy_pct:      Mapped[int]      = mapped_column(Integer, nullable=False)
    frustrated_pct:   Mapped[int]      = mapped_column(Integer, nullable=False)
    availability_pct: Mapped[float]    = mapped_column(Numeric(5, 2), nullable=False)
    open_alerts:      Mapped[int]      = mapped_column(Integer, nullable=False, default=0)
    snapshot_at:      Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, index=True)
    __table_args__ = (
        CheckConstraint("happy_pct + unhappy_pct + frustrated_pct = 100", name="experience_pct_sum_100"),
        CheckConstraint("happy_pct between 0 and 100", name="happy_range"),
    )


class SubJourneyMetric(Base):
    __tablename__ = "sub_journey_metrics"
    metric_id:        Mapped[int]      = mapped_column(Integer, primary_key=True, autoincrement=True)
    sub_journey_id:   Mapped[str]      = mapped_column(String(40),
                                                       ForeignKey("sub_journeys.sub_journey_id"),
                                                       nullable=False, index=True)
    happy_pct:        Mapped[int]      = mapped_column(Integer, nullable=True)
    unhappy_pct:      Mapped[int]      = mapped_column(Integer, nullable=True)
    frustrated_pct:   Mapped[int]      = mapped_column(Integer, nullable=True)
    avg_response_ms:  Mapped[int]      = mapped_column(Integer, nullable=False)
    p95_ms:           Mapped[int]      = mapped_column(Integer, nullable=False)
    error_rate_pct:   Mapped[float]    = mapped_column(Numeric(5, 2), nullable=False)
    availability_pct: Mapped[float]    = mapped_column(Numeric(5, 2), nullable=False)
    is_critical:      Mapped[bool]     = mapped_column(Boolean, nullable=False, default=False)
    snapshot_at:      Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, index=True)
