"""Incidents + alert-role bridge + tier editorial summaries + rule firings."""
from datetime import datetime
from sqlalchemy import String, Integer, Text, Numeric, DateTime, ForeignKey, Boolean, CheckConstraint, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from app.models.base import Base


class Incident(Base):
    __tablename__ = "incidents"
    incident_id:                 Mapped[str]      = mapped_column(String(20), primary_key=True)
    title:                       Mapped[str]      = mapped_column(String(300), nullable=False)
    root_cause_desc:             Mapped[str]      = mapped_column(Text, nullable=False)
    root_cause:                  Mapped[str]      = mapped_column(String(100), nullable=True)
    root_cause_component_id:     Mapped[str]      = mapped_column(String(30),
                                                                  ForeignKey("components.component_id"))

    raw_alerts_grouped:          Mapped[int]      = mapped_column(Integer, nullable=False)
    tools_contributing:          Mapped[int]      = mapped_column(Integer, nullable=False)
    correlation_confidence_pct:  Mapped[float]    = mapped_column(Numeric(5, 2), nullable=False)
    frustrated_user_count:       Mapped[int]      = mapped_column(Integer, nullable=False)
    detected_at:                 Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    resolved_at:                 Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=True)
    status:                      Mapped[str]      = mapped_column(String(20), nullable=False)
    __table_args__ = (
        CheckConstraint("status in ('open','investigating','mitigating','resolved')", name="incident_status_valid"),
    )


class IncidentAlert(Base):
    __tablename__ = "incident_alerts"
    incident_id: Mapped[str] = mapped_column(String(20),
                                             ForeignKey("incidents.incident_id", ondelete="CASCADE"),
                                             primary_key=True)
    alert_ref:   Mapped[str] = mapped_column(String(30),
                                             ForeignKey("alerts.alert_ref"),
                                             primary_key=True)
    role:        Mapped[str] = mapped_column(String(15), nullable=False)
    __table_args__ = (
        CheckConstraint("role in ('root_cause','downstream','symptom','suppressed','contributing')",
                        name="incident_alert_role_valid"),
    )


class TierIncidentSummary(Base):
    __tablename__ = "tier_incident_summary"
    id:            Mapped[int]  = mapped_column(Integer, primary_key=True, autoincrement=True)
    incident_id:   Mapped[str]  = mapped_column(String(20),
                                                ForeignKey("incidents.incident_id", ondelete="CASCADE"),
                                                nullable=False)
    tier_id:       Mapped[str]  = mapped_column(String(10),
                                                ForeignKey("tiers.tier_id"),
                                                nullable=False)
    is_root_cause: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    summary_text:  Mapped[str]  = mapped_column(Text, nullable=False)
    __table_args__ = (
        UniqueConstraint("incident_id", "tier_id", name="uq_incident_tier_summary"),
    )


class RuleFiring(Base):
    __tablename__ = "rule_firings"
    firing_id:   Mapped[int]      = mapped_column(Integer, primary_key=True, autoincrement=True)
    rule_id:     Mapped[str]      = mapped_column(String(30),
                                                  ForeignKey("correlation_rules.rule_id"),
                                                  nullable=False)
    incident_id: Mapped[str]      = mapped_column(String(20),
                                                  ForeignKey("incidents.incident_id", ondelete="CASCADE"),
                                                  nullable=False)
    fired_at:    Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    __table_args__ = (
        UniqueConstraint("rule_id", "incident_id", name="uq_rule_per_incident"),
    )


class RuleFiringAlert(Base):
    __tablename__ = "rule_firing_alerts"
    firing_id: Mapped[int] = mapped_column(Integer,
                                           ForeignKey("rule_firings.firing_id", ondelete="CASCADE"),
                                           primary_key=True)
    alert_ref: Mapped[str] = mapped_column(String(30),
                                           ForeignKey("alerts.alert_ref"),
                                           primary_key=True)


class IncidentTopologyState(Base):
    """Snapshots the health state of a component during a specific incident."""
    __tablename__ = "incident_topology_state"
    
    incident_id:   Mapped[str]  = mapped_column(String(20), ForeignKey("incidents.incident_id", ondelete="CASCADE"), primary_key=True)
    component_id:  Mapped[str]  = mapped_column(String(30), ForeignKey("components.component_id", ondelete="CASCADE"), primary_key=True)
    level_at_time: Mapped[str]  = mapped_column(String(10), nullable=False)  # 'crit', 'deg', 'ok'
    is_rc_at_time: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)


class IncidentCriticalEdge(Base):
    """Snapshots the critical cascading dependency paths for a specific incident."""
    __tablename__ = "incident_critical_edges"
    
    id:             Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    incident_id:    Mapped[str] = mapped_column(String(20), ForeignKey("incidents.incident_id", ondelete="CASCADE"), nullable=False)
    from_component: Mapped[str] = mapped_column(String(30), ForeignKey("components.component_id", ondelete="CASCADE"), nullable=False)
    to_component:   Mapped[str] = mapped_column(String(30), ForeignKey("components.component_id", ondelete="CASCADE"), nullable=False)


class IncidentSubJourney(Base):
    """Junction table: incidents <-> sub_journeys (many-to-many)."""
    __tablename__ = "incident_sub_journeys"
    incident_id:    Mapped[str] = mapped_column(String(20), ForeignKey("incidents.incident_id", ondelete="CASCADE"), primary_key=True)
    sub_journey_id: Mapped[str] = mapped_column(String(40), ForeignKey("sub_journeys.sub_journey_id", ondelete="CASCADE"), primary_key=True)
