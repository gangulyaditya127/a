"""Reference / master tables — tiers, tools, components, journeys."""
from sqlalchemy import String, Integer, ForeignKey, Boolean, UniqueConstraint, CheckConstraint
from sqlalchemy.orm import Mapped, mapped_column

from app.models.base import Base


class Tier(Base):
    __tablename__ = "tiers"
    tier_id:       Mapped[str] = mapped_column(String(10), primary_key=True)
    name:          Mapped[str] = mapped_column(String(40), nullable=False)
    display_order: Mapped[int] = mapped_column(Integer, nullable=False, unique=True)
    icon:          Mapped[str] = mapped_column(String(10), nullable=False)
    level:         Mapped[str] = mapped_column(String(10), nullable=False, default="ok")
    __table_args__ = (
        CheckConstraint("level in ('ok','deg','crit')", name="tier_level_valid"),
    )


class MonitoringTool(Base):
    __tablename__ = "monitoring_tools"
    tool_id:    Mapped[str] = mapped_column(String(30), primary_key=True)
    name:       Mapped[str] = mapped_column(String(60), nullable=False)   # full label (alert.src)
    short_name: Mapped[str] = mapped_column(String(30), nullable=True)    # compact label used in tier source mix
    color_hex:  Mapped[str] = mapped_column(String(7),  nullable=False)


class Component(Base):
    __tablename__ = "components"
    component_id: Mapped[str] = mapped_column(String(30), primary_key=True)
    name:         Mapped[str] = mapped_column(String(60), nullable=False)
    sub_label:    Mapped[str] = mapped_column(String(60))
    tier_id:      Mapped[str] = mapped_column(String(10), ForeignKey("tiers.tier_id"), nullable=False)
    layout_row:   Mapped[int] = mapped_column(Integer, nullable=False)
    display_order:Mapped[int] = mapped_column(Integer, nullable=False, default=0)  # deterministic ordering
    level:        Mapped[str] = mapped_column(String(10), nullable=False, default="ok")
    is_rc:        Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    __table_args__ = (
        CheckConstraint("level in ('ok','deg','crit')", name="component_level_valid"),
    )


class ComponentDependency(Base):
    __tablename__ = "component_dependencies"
    dep_id:         Mapped[int]  = mapped_column(Integer, primary_key=True, autoincrement=True)
    from_component: Mapped[str]  = mapped_column(String(30), ForeignKey("components.component_id"), nullable=False)
    to_component:   Mapped[str]  = mapped_column(String(30), ForeignKey("components.component_id"), nullable=False)
    is_critical:    Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    display_order:  Mapped[int]  = mapped_column(Integer, nullable=False, default=0)
    __table_args__ = (
        UniqueConstraint("from_component", "to_component", name="uq_edge"),
        CheckConstraint("from_component <> to_component", name="no_self_loop"),
    )


class Journey(Base):
    __tablename__ = "journeys"
    journey_id:    Mapped[str] = mapped_column(String(30), primary_key=True)
    name:          Mapped[str] = mapped_column(String(120), nullable=False)
    segment:       Mapped[str] = mapped_column(String(40), nullable=False)
    display_order: Mapped[int] = mapped_column(Integer, nullable=False)


class SubJourney(Base):
    __tablename__ = "sub_journeys"
    sub_journey_id: Mapped[str] = mapped_column(String(40), primary_key=True)
    journey_id:     Mapped[str] = mapped_column(String(30), ForeignKey("journeys.journey_id"), nullable=False)
    name:           Mapped[str] = mapped_column(String(120), nullable=False)
    api_label:      Mapped[str] = mapped_column(String(120), nullable=False)
    display_order:  Mapped[int] = mapped_column(Integer, nullable=False)
