from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from sqlalchemy import select

from app.core.database import get_db
from app.services.analysis_service import AnalysisService
from app.models.incidents import Incident, IncidentSubJourney

router = APIRouter()

DEFAULT_INCIDENT = "INC0048291"


@router.get("/tiers")
def get_tiers(
    incident_id: str = Query(default=DEFAULT_INCIDENT, alias="incident"),
    db: Session = Depends(get_db),
):
    try:
        data = AnalysisService.get_tier_cards(db, incident_id)
        return {"success": True, "count": len(data), "data": data}
    except ValueError as ex:
        raise HTTPException(status_code=404, detail=str(ex))
    except Exception as ex:
        raise HTTPException(status_code=500, detail=str(ex))


@router.get("/corr-data")
def get_corr_data(
    incident_id: str = Query(default=DEFAULT_INCIDENT, alias="incident"),
    subjourney_id: str | None = Query(default=None),
    db: Session = Depends(get_db),
):
    try:
        # Resolve "latest" to the most recent incident for the given sub-journey
        resolved_id = incident_id
        if incident_id.lower() == "latest":
            if not subjourney_id:
                raise ValueError("subjourney_id is required when incident=latest")
            row = db.execute(
                select(Incident.incident_id)
                .join(IncidentSubJourney, IncidentSubJourney.incident_id == Incident.incident_id)
                .where(IncidentSubJourney.sub_journey_id == subjourney_id)
                .order_by(Incident.detected_at.desc())
                .limit(1)
            ).scalar_one_or_none()
            if row is None:
                raise ValueError(f"No incident found for sub-journey '{subjourney_id}'")
            resolved_id = row
            print(f"[CORR-DATA] Resolved 'latest' for subjourney={subjourney_id} → {resolved_id}")

        data = AnalysisService.get_corr_data(db, resolved_id)
        return {"success": True, "data": data}
    except ValueError as ex:
        raise HTTPException(status_code=404, detail=str(ex))
    except Exception as ex:
        raise HTTPException(status_code=500, detail=str(ex))
