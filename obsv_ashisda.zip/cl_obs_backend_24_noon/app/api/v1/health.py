from fastapi import APIRouter

router = APIRouter()


@router.get("/health")
def health_check():
    return {"status": "healthy", "service": "Canada Life ARE Observability", "version": "1.0.0"}
