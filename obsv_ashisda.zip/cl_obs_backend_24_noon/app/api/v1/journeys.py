from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.services.journey_service import JourneyService

router = APIRouter()


@router.get("/journeys")
def list_journeys(db: Session = Depends(get_db)):
    try:
        data = JourneyService.list_journeys(db)
        return {"success": True, "count": len(data), "data": data}
    except Exception as ex:
        raise HTTPException(status_code=500, detail=str(ex))


@router.get("/sub-journeys")

def get_sub_journeys(

    journey_id: str = Query(None, description="Filter sub-journeys by journey ID"),

    db: Session = Depends(get_db)

):

    try:

        data = JourneyService.get_sub_journeys(db, journey_id)

        return {"success": True, "data": data}

    except Exception as ex:

        raise HTTPException(status_code=500, detail=str(ex))