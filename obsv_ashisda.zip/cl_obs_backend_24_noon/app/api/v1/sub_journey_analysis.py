"""Sub-journey scoped analysis endpoints.

    GET /sub-journeys/{id}/components   - CIs mapped to this step
    GET /sub-journeys/{id}/alerts       - alerts on those CIs (last N hours)
    GET /sub-journeys/{id}/tiers        - tier-grouped view (drop-in for AnalysisView)
"""
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.services.sub_journey_service import SubJourneyService

router = APIRouter()


@router.get("/sub-journeys/{sub_journey_id}/components")
def get_sub_journey_components(sub_journey_id: str, db: Session = Depends(get_db)):
    try:
        data = SubJourneyService.get_components(db, sub_journey_id)
        return {"success": True, "count": len(data), "data": data}
    except ValueError as ex:
        raise HTTPException(status_code=404, detail=str(ex))
    except Exception as ex:
        raise HTTPException(status_code=500, detail=str(ex))


@router.get("/sub-journeys/{sub_journey_id}/alerts")
def get_sub_journey_alerts(
    sub_journey_id: str,
    hours: int = Query(48, ge=1, le=720),
    db: Session = Depends(get_db),
):
    try:
        data = SubJourneyService.get_alerts(db, sub_journey_id, hours=hours)
        return {"success": True, "count": len(data), "data": data}
    except ValueError as ex:
        raise HTTPException(status_code=404, detail=str(ex))
    except Exception as ex:
        raise HTTPException(status_code=500, detail=str(ex))


@router.get("/sub-journeys/{sub_journey_id}/tiers")
def get_sub_journey_tiers(
    sub_journey_id: str,
    hours: int = Query(48, ge=1, le=720),
    db: Session = Depends(get_db),
):
    try:
        data = SubJourneyService.get_tier_grouped_view(db, sub_journey_id, hours=hours)
        return {"success": True, "count": len(data), "data": data}
    except ValueError as ex:
        raise HTTPException(status_code=404, detail=str(ex))
    except Exception as ex:
        raise HTTPException(status_code=500, detail=str(ex))
