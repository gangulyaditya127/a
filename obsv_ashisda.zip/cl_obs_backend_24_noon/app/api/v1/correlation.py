"""Correlation engine REST endpoints."""
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.services.correlation_engine import CorrelationEngine

router = APIRouter()


@router.get("/correlate/dry-run")
def dry_run(db: Session = Depends(get_db)):
    """Evaluate every rule. Returns reasoning trail. Nothing written to DB."""
    try:
        engine = CorrelationEngine(db)
        matches = engine.evaluate_all_rules()
        return {
            "success": True,
            "count": len(matches),
            "data": [m.to_dict() for m in matches],
        }
    except Exception as ex:
        raise HTTPException(status_code=500, detail=str(ex))


@router.post("/correlate")
def run_correlation(
    incident_id: str = Query(default="INC-AUTO-001"),
    db: Session = Depends(get_db),
):
    """Run the engine and persist the derived incident + groupings + firings."""
    try:
        engine = CorrelationEngine(db)
        result = engine.run(incident_id=incident_id, write_to_db=True)
        return {"success": True, "data": result.to_dict()}
    except Exception as ex:
        raise HTTPException(status_code=500, detail=str(ex))
