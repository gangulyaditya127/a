from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.services.openai_service import OpenAIService
from app.schemas.ai import TierSummaryRequest

router = APIRouter()


@router.post("/ai/tier-summary")
def tier_summary(payload: TierSummaryRequest, db: Session = Depends(get_db)):
    """Regenerate a tier's summary blurb using OpenAI (with DB fallback)."""
    try:
        data = OpenAIService.generate_tier_summary(
            db, incident_id=payload.incident_id, tier_id=payload.tier_id
        )
        # print(data)
        return {"success": True, "data": data}
    except ValueError as ex:
        raise HTTPException(status_code=404, detail=str(ex))
    except Exception as ex:
        raise HTTPException(status_code=500, detail=str(ex))
