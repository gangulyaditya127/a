"""Sub-journey analysis service.
Given a sub_journey_id, returns:
    * the components mapped to that step (with role tags),
    * the alerts currently firing on those components (regardless of incident),
    * a tier-grouped view compatible with the existing AnalysisView tier cards.
"""
from __future__ import annotations
from collections import defaultdict
from datetime import datetime, timedelta, timezone
from sqlalchemy import select, func
from sqlalchemy.orm import Session

from app.models.reference import Tier, MonitoringTool, Component, SubJourney
from app.models.alerts import Alert
from app.models.sub_journey_components import SubJourneyComponent
from app.models.analytics import TierTopCause


class SubJourneyService:

    @staticmethod
    def get_components(db: Session, sub_journey_id: str) -> list[dict]:
        sj = db.get(SubJourney, sub_journey_id)
        if sj is None:
            raise ValueError(f"Unknown sub-journey {sub_journey_id}")

        rows = db.execute(
            select(SubJourneyComponent, Component)
            .join(Component, Component.component_id == SubJourneyComponent.component_id)
            .where(SubJourneyComponent.sub_journey_id == sub_journey_id)
            .order_by(Component.display_order, Component.component_id)
        ).all()

        return [
            {
                "component_id": comp.component_id,
                "name":         comp.name,
                "sub_label":    comp.sub_label or "",
                "tier_id":      comp.tier_id,
                "level":        comp.level,
                "is_rc":        bool(comp.is_rc),
                "role":         sjc.role,
            }
            for sjc, comp in rows
        ]

    @staticmethod
    def get_alerts(db: Session, sub_journey_id: str, hours: int = 48) -> list[dict]:
        """Alerts on components of a sub-journey within the last `hours`."""
        sj = db.get(SubJourney, sub_journey_id)
        if sj is None:
            raise ValueError(f"Unknown sub-journey {sub_journey_id}")

        component_ids = [
            row[0] for row in db.execute(
                select(SubJourneyComponent.component_id)
                .where(SubJourneyComponent.sub_journey_id == sub_journey_id)
            ).all()
        ]
        if not component_ids:
            return []

        cutoff = datetime.now(timezone.utc) - timedelta(hours=hours)
        rows = db.execute(
            select(Alert, MonitoringTool)
            .join(MonitoringTool, MonitoringTool.tool_id == Alert.tool_id)
            .where(Alert.component_id.in_(component_ids))
            .where(Alert.detected_at >= cutoff)
            .order_by(Alert.detected_at.desc())
        ).all()

        return [
            {
                "ref":       a.alert_ref,
                "name":      a.name,
                "src":       t.name,
                "sev":       a.severity,
                "time":      a.first_seen_today.strftime("%H:%M:%S") if a.first_seen_today else "",
                "tier_id":   a.tier_id,
                "component_id": a.component_id,
                "component":    a.component_display_name,
                "desc":      a.description,
            }
            for a, t in rows
        ]

    @staticmethod
    def get_tier_grouped_view(db: Session, sub_journey_id: str, hours: int = 48) -> list[dict]:
        sj = db.get(SubJourney, sub_journey_id)
        if sj is None:
            raise ValueError(f"Unknown sub-journey {sub_journey_id}")

        components = SubJourneyService.get_components(db, sub_journey_id)
        alerts     = SubJourneyService.get_alerts(db, sub_journey_id, hours=hours)

        tiers = db.execute(select(Tier).order_by(Tier.display_order)).scalars().all()
        tools = {t.tool_id: t for t in db.execute(select(MonitoringTool)).scalars().all()}

        # --- FETCH TOP CAUSES FROM DB ---
        latest_causes_ts = (
            select(TierTopCause.tier_id, func.max(TierTopCause.computed_at).label("max_ts"))
            .group_by(TierTopCause.tier_id).subquery()
        )
        causes_rows = db.execute(
            select(TierTopCause)
            .join(latest_causes_ts,
                  (latest_causes_ts.c.tier_id == TierTopCause.tier_id) &
                  (latest_causes_ts.c.max_ts  == TierTopCause.computed_at))
            .order_by(TierTopCause.tier_id, TierTopCause.rank)
        ).scalars().all()
        
        causes_by_tier: dict[str, list] = defaultdict(list)
        for c in causes_rows:
            causes_by_tier[c.tier_id].append(c)

        # Group components + alerts by tier
        comps_by_tier: dict[str, list[dict]] = defaultdict(list)
        for c in components:
            comps_by_tier[c["tier_id"]].append(c)

        alerts_by_tier: dict[str, list[dict]] = defaultdict(list)
        alerts_by_tool_per_tier: dict[str, dict[str, int]] = defaultdict(lambda: defaultdict(int))
        for a in alerts:
            alerts_by_tier[a["tier_id"]].append(a)
            alerts_by_tool_per_tier[a["tier_id"]][a["src"]] += 1

        cards = []
        for t in tiers:
            tier_comps  = comps_by_tier.get(t.tier_id, [])
            tier_alerts = alerts_by_tier.get(t.tier_id, [])
            sev = {
                "crit": sum(1 for x in tier_alerts if x["sev"] == "crit"),
                "high": sum(1 for x in tier_alerts if x["sev"] == "high"),
            }
            # Source mix
            src_counts = alerts_by_tool_per_tier.get(t.tier_id, {})
            sources = [
                {"k": tool_name, "n": cnt, "c": next(
                    (tl.color_hex for tl in tools.values() if tl.name == tool_name), "#7a5a5f"
                )}
                for tool_name, cnt in sorted(src_counts.items(), key=lambda kv: -kv[1])
            ]
            is_root = any(c["is_rc"] for c in tier_comps)

            # MAP THE DB CAUSES TO THE CARD
            top_causes = [
                {"name": c.cause_name, "pct": c.percentage}
                for c in causes_by_tier.get(t.tier_id, [])
            ]

            cards.append({
                "id":          t.tier_id,
                "name":        t.name,
                "level":       t.level,
                "icon":        t.icon,
                "alertCount":  len(tier_alerts),
                "isRoot":      is_root,
                "summary":     f"{len(tier_comps)} components mapped to this sub-journey. "
                               f"{len(tier_alerts)} alerts in the last {hours}h.",
                "sev":         sev,
                "sources":     sources,
                "hist":        {"today": len(tier_alerts), "last7d": 0, "last30d": 0, "mttr": "-"},
                "topCauses":   top_causes,
                "alerts":      tier_alerts,
                "components":  tier_comps,
            })
        return cards