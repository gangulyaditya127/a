"""Raw-alert detail service — matches rawAlerts.json entry shape."""
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models.alerts import Alert, AlertMetric
from app.models.reference import MonitoringTool, Tier


class AlertService:

    @staticmethod
    def get_by_ref(db: Session, alert_ref: str) -> dict | None:
        a = db.get(Alert, alert_ref)
        if a is None:
            return None
        tool = db.get(MonitoringTool, a.tool_id)
        tier = db.get(Tier, a.tier_id)
        metrics = db.execute(
            select(AlertMetric)
            .where(AlertMetric.alert_ref == alert_ref)
            .order_by(AlertMetric.display_order)
        ).scalars().all()

        return {
            "sev":            a.severity,
            "src":            tool.name if tool else "",
            "name":           a.name,
            "tier":           tier.name if tier else "",
            "component":      a.component_display_name,
            "time":           a.first_seen_today.strftime("%H:%M:%S"),
            "desc":           a.description,
            "metrics":        [[m.metric_key, m.metric_value] for m in metrics],
            "firstSeen":      a.first_seen_today.strftime("%H:%M:%S"),
            "occurrences7d":  a.occurrences_7d,
            "occurrences30d": a.occurrences_30d,
        }

    @staticmethod
    def get_all_map(db: Session) -> dict[str, dict]:
        """Bulk load all alerts + metrics + tool/tier joins in constant queries."""
        alerts = db.execute(select(Alert).where(Alert.is_correlated == False).order_by(Alert.detected_at)).scalars().all()
        tools = {t.tool_id: t for t in db.execute(select(MonitoringTool)).scalars().all()}
        tiers = {t.tier_id: t for t in db.execute(select(Tier)).scalars().all()}

        metric_rows = db.execute(
            select(AlertMetric).order_by(AlertMetric.alert_ref, AlertMetric.display_order)
        ).scalars().all()
        metrics_by_alert: dict[str, list] = {}
        for m in metric_rows:
            metrics_by_alert.setdefault(m.alert_ref, []).append([m.metric_key, m.metric_value])

        return {
            a.alert_ref: {
                "sev":            a.severity,
                "src":            tools[a.tool_id].name if a.tool_id in tools else "",
                "name":           a.name,
                "tier":           tiers[a.tier_id].name if a.tier_id in tiers else "",
                "component":      a.component_display_name,
                "time":           a.first_seen_today.strftime("%H:%M:%S"),
                "desc":           a.description,
                "metrics":        metrics_by_alert.get(a.alert_ref, []),
                "firstSeen":      a.first_seen_today.strftime("%H:%M:%S"),
                "occurrences7d":  a.occurrences_7d,
                "occurrences30d": a.occurrences_30d,
            }
            for a in alerts
        }
