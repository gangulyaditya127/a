"""Pattern mining service - REAL implementation.

Scans the `alerts` table for the last N days, groups alerts into temporal
clusters (within `time_window_seconds` of each other), filters clusters that
touch >= 2 tools, and stores each recurring pattern in discovered_patterns.

Complexity is O(N log N) — good enough for tens of thousands of alerts.
"""
from __future__ import annotations
import json
from collections import defaultdict
from datetime import datetime, timedelta, timezone
from sqlalchemy import select, delete
from sqlalchemy.orm import Session

from app.models.alerts import Alert
from app.models.reference import Component, MonitoringTool
from app.models.ai_discovery import DiscoveredPattern


class PatternMiningService:

    # ---- Public API ------------------------------------------------------

    @staticmethod
    def list_patterns(db: Session, status: str | None = None) -> list[dict]:
        stmt = select(DiscoveredPattern).order_by(DiscoveredPattern.support_count.desc())
        if status:
            stmt = stmt.where(DiscoveredPattern.status == status)
        rows = db.execute(stmt).scalars().all()
        return [PatternMiningService._pattern_to_dict(p) for p in rows]

    @staticmethod
    def mine(db: Session, days: int = 30, time_window_seconds: int = 180) -> dict:
        """Perform the actual mining. Returns summary + discovered patterns."""
        started = datetime.now(timezone.utc)

        # Only replace existing "new" patterns; keep used/ignored ones intact
        db.execute(delete(DiscoveredPattern).where(DiscoveredPattern.status == "new"))
        db.commit()

        cutoff = datetime.now(timezone.utc) - timedelta(days=days)
        alerts = db.execute(
            select(Alert)
            .where(Alert.detected_at >= cutoff)
            .order_by(Alert.detected_at)
        ).scalars().all()

        if not alerts:
            return {
                "started_at": started.isoformat(),
                "alerts_scanned": 0, "clusters_found": 0,
                "patterns_discovered": 0,
                "patterns": [],
            }

        # Preload tool + component metadata for enrichment
        tools = {t.tool_id: t for t in db.execute(select(MonitoringTool)).scalars().all()}
        comps = {c.component_id: c for c in db.execute(select(Component)).scalars().all()}

        # 1. Cluster by temporal proximity (single-linkage in time only)
        clusters: list[list[Alert]] = []
        current: list[Alert] = []
        prev_ts = None
        for a in alerts:
            if prev_ts is None or (a.detected_at - prev_ts).total_seconds() <= time_window_seconds:
                current.append(a)
            else:
                if len(current) >= 2:
                    clusters.append(current)
                current = [a]
            prev_ts = a.detected_at
        if len(current) >= 2:
            clusters.append(current)

        # 2. Build pattern signatures - a pattern is (sorted tuple of tool_id + name)
        signature_to_clusters: dict[tuple, list[list[Alert]]] = defaultdict(list)
        for cluster in clusters:
            sig = tuple(sorted({(a.tool_id, a.name) for a in cluster}))
            if len({t for t, _ in sig}) < 2:
                # skip single-tool clusters
                continue
            signature_to_clusters[sig].append(cluster)

        # 3. Keep signatures with support >= 3
        min_support = 3
        recurring = {sig: cls for sig, cls in signature_to_clusters.items()
                     if len(cls) >= min_support}

        # 4. Write results
        discovered: list[dict] = []
        idx = 1
        for sig, cls in sorted(recurring.items(), key=lambda kv: -len(kv[1])):
            pattern_id = f"PAT-{started.strftime('%m%d')}-{idx:03d}"
            idx += 1

            # Average time delta within each cluster, then across clusters
            deltas = []
            for c in cls:
                if len(c) >= 2:
                    d = (c[-1].detected_at - c[0].detected_at).total_seconds()
                    deltas.append(d)
            avg_delta = int(sum(deltas) / len(deltas)) if deltas else 0

            signals = []
            for tool_id, sig_name in sig:
                tool = tools.get(tool_id)
                signals.append({
                    "tool_id": tool_id,
                    "tool_name": tool.name if tool else tool_id,
                    "signal": sig_name,
                })

            # CIs and tiers touched
            all_alerts = [a for c in cls for a in c]
            cis_set = {a.component_id for a in all_alerts}
            tiers_set = {a.tier_id for a in all_alerts}
            cis  = sorted(cis_set)
            tiers = sorted(tiers_set)

            top_ci = next(iter(cis)) if cis else "unknown"
            top_ci_name = comps[top_ci].name if top_ci in comps else top_ci
            pattern_name = f"{signals[0]['signal']} cascade on {top_ci_name}"

            pattern = DiscoveredPattern(
                pattern_id=pattern_id,
                name=pattern_name,
                support_count=len(cls),
                avg_time_delta_s=avg_delta,
                tool_count=len({t["tool_id"] for t in signals}),
                ci_count=len(cis),
                signals_json=json.dumps(signals),
                cis_json=json.dumps(cis),
                tiers_json=json.dumps(tiers),
                discovered_at=started,
                status="new",
            )
            db.add(pattern)
            db.flush()
            discovered.append(PatternMiningService._pattern_to_dict(pattern))

        db.commit()
        return {
            "started_at": started.isoformat(),
            "alerts_scanned": len(alerts),
            "clusters_found": len(clusters),
            "patterns_discovered": len(discovered),
            "patterns": discovered,
            "params": {"days": days, "time_window_seconds": time_window_seconds, "min_support": min_support},
        }

    # ---- Helpers ---------------------------------------------------------

    @staticmethod
    def _pattern_to_dict(p: DiscoveredPattern) -> dict:
        return {
            "pattern_id":       p.pattern_id,
            "name":             p.name,
            "support_count":    p.support_count,
            "avg_time_delta_s": p.avg_time_delta_s,
            "tool_count":       p.tool_count,
            "ci_count":         p.ci_count,
            "signals":          json.loads(p.signals_json),
            "cis":              json.loads(p.cis_json),
            "tiers":            json.loads(p.tiers_json),
            "discovered_at":    p.discovered_at.isoformat() if p.discovered_at else None,
            "status":           p.status,
        }
