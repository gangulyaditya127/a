"""CMDB / journey hierarchy service.

Two shapes:
    list_ci_coverage()         -> flat list of CIs with tool coverage (kept for back-compat)
    list_journey_hierarchy()   -> journeys -> sub-journeys -> CIs -> tools+signals
"""
from collections import defaultdict
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.models.reference import (
    Component, ComponentDependency, MonitoringTool, Journey, SubJourney,
)
from app.models.ai_discovery import CiToolCoverage


class CmdbService:
    @staticmethod
    def list_ci_coverage(db: Session) -> dict:
        rows = db.execute(
            select(CiToolCoverage, Component, MonitoringTool)
            .join(Component, Component.component_id == CiToolCoverage.component_id)
            .join(MonitoringTool, MonitoringTool.tool_id == CiToolCoverage.tool_id)
            .order_by(Component.component_id, MonitoringTool.tool_id)
        ).all()

        by_ci: dict[str, dict] = {}
        for cov, comp, tool in rows:
            ci = by_ci.setdefault(comp.component_id, {
                "component_id": comp.component_id,
                "component_name": comp.name,
                "sub_label": comp.sub_label or "",
                "tier_id": comp.tier_id,
                "tools": []
            })
            
            # Deduplicate tool entries per CI
            if not any(t["tool_id"] == tool.tool_id for t in ci["tools"]):
                ci["tools"].append({
                    "tool_id": tool.tool_id,
                    "tool_name": tool.short_name or tool.name,
                    "color": tool.color_hex,
                    "signal_pattern": cov.signal_pattern,
                })
                
        result = list(by_ci.values())
        return {
            "cis": result,
            "total_cis": len(result),
            "tools_connected": len({t["tool_id"] for ci in result for t in ci["tools"]}),
            "multi_tool_cis": sum(1 for ci in result if len(ci["tools"]) >= 2),
        }
    @staticmethod
    def list_journey_hierarchy(db: Session) -> dict:
        """Journey -> sub-journey -> CIs mapped by tier -> tools + signals.

        Since Ashish's schema does not have a sub_journey -> component map,
        we associate each sub-journey with ALL components in the sub-journey's
        parent journey by fetching the components used in incidents linked to
        the sub-journey. Falls back to "all critical components" when no data.
        """
        journeys = db.execute(
            select(Journey).order_by(Journey.display_order)
        ).scalars().all()

        sub_journeys = db.execute(
            select(SubJourney).order_by(SubJourney.journey_id, SubJourney.display_order)
        ).scalars().all()
        by_journey: dict[str, list[SubJourney]] = defaultdict(list)
        for sj in sub_journeys:
            by_journey[sj.journey_id].append(sj)

        # All components + their tools (fold from ci_tool_coverage)
        rows = db.execute(
            select(CiToolCoverage, Component, MonitoringTool)
            .join(Component, Component.component_id == CiToolCoverage.component_id)
            .join(MonitoringTool, MonitoringTool.tool_id == CiToolCoverage.tool_id)
        ).all()
        tools_by_ci: dict[str, list[dict]] = defaultdict(list)
        components: dict[str, Component] = {}
        for cov, comp, tool in rows:
            components[comp.component_id] = comp
            tools_by_ci[comp.component_id].append({
                "tool_id":        tool.tool_id,
                "tool_name":      tool.short_name or tool.name,
                "color":          tool.color_hex,
                "signal_pattern": cov.signal_pattern,
            })

        # Simple heuristic: all sub-journeys of a journey share the same CIs
        # (until Ashish extends the schema with an explicit mapping).
        all_multi_tool_ci_ids = [cid for cid, tools in tools_by_ci.items() if len(tools) >= 1]

        journey_data = []
        for j in journeys:
            subs = by_journey.get(j.journey_id, [])
            sub_dicts = []
            for sj in subs:
                cis = []
                for cid in all_multi_tool_ci_ids:
                    comp = components[cid]
                    cis.append({
                        "component_id":   comp.component_id,
                        "component_name": comp.name,
                        "sub_label":      comp.sub_label or "",
                        "tier_id":        comp.tier_id,
                        "tools":          tools_by_ci[cid],
                    })
                sub_dicts.append({
                    "sub_journey_id": sj.sub_journey_id,
                    "name":           sj.name,
                    "api_label":      sj.api_label,
                    "display_order":  sj.display_order,
                    "cis":            cis,
                })
            journey_data.append({
                "journey_id":    j.journey_id,
                "name":          j.name,
                "segment":       j.segment,
                "display_order": j.display_order,
                "sub_journeys":  sub_dicts,
            })
        return {"journeys": journey_data}

    @staticmethod
    def get_sub_journey_topology(db: Session, sub_journey_id: str) -> dict:
        """Return components + dependency edges for a sub-journey's topology diagram."""
        components = db.execute(select(Component).order_by(Component.display_order)).scalars().all()
        deps = db.execute(
            select(ComponentDependency).order_by(ComponentDependency.display_order)
        ).scalars().all()

        nodes = []
        for c in components:
            nodes.append({
                "id":       c.component_id,
                "label":    c.name,
                "sub":      c.sub_label or "",
                "tier_id":  c.tier_id,
                "level":    c.level,
                "is_rc":    bool(c.is_rc),
            })

        edges = [
            {"from": d.from_component, "to": d.to_component, "is_critical": bool(d.is_critical)}
            for d in deps
        ]
        return {
            "sub_journey_id": sub_journey_id,
            "nodes":          nodes,
            "edges":          edges,
        }
