"""Proposal lifecycle service - list/get/tune/approve/reject/deploy.

Tune allows the reviewer to edit ANY editable field before approve.
Deploy writes the rule into correlation_rules + rule_combine_inputs +
rule_explanations so the correlation engine picks it up.
"""
import json
from datetime import datetime, timezone
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models.rules import CorrelationRule, RuleCombineInput, RuleExplanation
from app.models.ai_discovery import AiRuleProposal, RuleReviewEvent


EDITABLE_FIELDS = {
    "name", "plain_english", "trigger_when", "trigger_target",
    "combine_logic", "output_summary", "confidence_score",
    "expected_precision", "expected_alert_reduction",
    "combine_inputs_json", "explanation_json",
}


class ProposalService:

    @staticmethod
    def list_proposals(db: Session, status: str | None = None) -> list[dict]:
        stmt = select(AiRuleProposal).order_by(AiRuleProposal.created_at.desc())
        if status:
            stmt = stmt.where(AiRuleProposal.status == status)
        rows = db.execute(stmt).scalars().all()
        return [ProposalService._to_dict(p) for p in rows]

    @staticmethod
    def get(db: Session, proposal_id: str) -> dict | None:
        p = db.get(AiRuleProposal, proposal_id)
        return ProposalService._to_dict(p) if p else None

    @staticmethod
    def tune(db: Session, proposal_id: str, fields: dict,
             reviewer_id: str, comment: str | None) -> dict:
        p = db.get(AiRuleProposal, proposal_id)
        if not p:
            raise ValueError(f"Unknown proposal {proposal_id}")

        # If reviewer sends combine_inputs (a list of dicts), we serialize it here
        if "combine_inputs" in fields and "combine_inputs_json" not in fields:
            fields["combine_inputs_json"] = json.dumps(fields.pop("combine_inputs"))
        if "explanation" in fields and "explanation_json" not in fields:
            fields["explanation_json"] = json.dumps(fields.pop("explanation"))

        for k, v in list(fields.items()):
            if k in EDITABLE_FIELDS:
                setattr(p, k, v)

        p.status = "tuned"
        db.add(RuleReviewEvent(
            proposal_id=proposal_id, reviewer_id=reviewer_id or "unknown",
            decision="tune", comment=comment,
            tuned_json=json.dumps(fields),
            created_at=datetime.now(timezone.utc),
        ))
        db.commit()
        return ProposalService._to_dict(p)

    @staticmethod
    def approve(db: Session, proposal_id: str, reviewer_id: str, comment: str | None) -> dict:
        p = db.get(AiRuleProposal, proposal_id)
        if not p:
            raise ValueError(f"Unknown proposal {proposal_id}")
        if p.status not in ("pending", "tuned"):
            raise ValueError(f"Cannot approve in status {p.status}")
        p.status = "approved"
        db.add(RuleReviewEvent(
            proposal_id=proposal_id, reviewer_id=reviewer_id or "unknown",
            decision="approve", comment=comment,
            created_at=datetime.now(timezone.utc),
        ))
        db.commit()
        return ProposalService._to_dict(p)

    @staticmethod
    def reject(db: Session, proposal_id: str, reviewer_id: str, comment: str | None) -> dict:
        p = db.get(AiRuleProposal, proposal_id)
        if not p:
            raise ValueError(f"Unknown proposal {proposal_id}")
        p.status = "rejected"
        db.add(RuleReviewEvent(
            proposal_id=proposal_id, reviewer_id=reviewer_id or "unknown",
            decision="reject", comment=comment,
            created_at=datetime.now(timezone.utc),
        ))
        db.commit()
        return ProposalService._to_dict(p)

    @staticmethod
    def deploy(db: Session, proposal_id: str, reviewer_id: str) -> dict:
        p = db.get(AiRuleProposal, proposal_id)
        if not p:
            raise ValueError(f"Unknown proposal {proposal_id}")
        if p.status != "approved":
            raise ValueError(f"Must be 'approved' before deploy, current: {p.status}")

        rule_id = f"RULE-AI-{p.proposal_id.replace('AI-PROP-','')}"
        existing = db.get(CorrelationRule, rule_id)
        if existing:
            p.status = "deployed"
            p.deployed_rule_id = rule_id
            db.commit()
            return ProposalService._to_dict(p)

        db.add(CorrelationRule(
            rule_id=rule_id, name=p.name,
            confidence_score=p.confidence_score,
            plain_english=p.plain_english,
            trigger_when=p.trigger_when, trigger_target=p.trigger_target,
            combine_logic=p.combine_logic, output_summary=p.output_summary,
        ))
        db.flush()

        for i, inp in enumerate(json.loads(p.combine_inputs_json)):
            db.add(RuleCombineInput(
                rule_id=rule_id, tool_id=inp.get("tool_id", ""),
                signal_pattern=inp.get("signal_pattern", ""), display_order=i,
            ))
        for i, txt in enumerate(json.loads(p.explanation_json)):
            db.add(RuleExplanation(rule_id=rule_id, paragraph_order=i, text=txt))

        p.status = "deployed"
        p.deployed_rule_id = rule_id
        db.add(RuleReviewEvent(
            proposal_id=proposal_id, reviewer_id=reviewer_id or "unknown",
            decision="deploy", comment=f"Deployed as {rule_id}",
            created_at=datetime.now(timezone.utc),
        ))
        db.commit()
        return ProposalService._to_dict(p)

    @staticmethod
    def _to_dict(p: AiRuleProposal) -> dict:
        return {
            "proposal_id":              p.proposal_id,
            "source_pattern_id":        p.source_pattern_id,
            "name":                     p.name,
            "plain_english":            p.plain_english,
            "trigger_when":             p.trigger_when,
            "trigger_target":           p.trigger_target,
            "combine_logic":            p.combine_logic,
            "output_summary":           p.output_summary,
            "combine_inputs":           json.loads(p.combine_inputs_json),
            "explanation":              json.loads(p.explanation_json),
            "confidence_score":         float(p.confidence_score),
            "expected_precision":       float(p.expected_precision),
            "expected_alert_reduction": p.expected_alert_reduction,
            "generated_by":             p.generated_by,
            "llm_model":                p.llm_model,
            "status":                   p.status,
            "deployed_rule_id":         p.deployed_rule_id,
            "created_at":               p.created_at.isoformat() if p.created_at else None,
        }
