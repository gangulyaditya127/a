"""Correlation rules — matches rules.json."""
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models.rules import CorrelationRule, RuleCombineInput, RuleExplanation
from app.models.incidents import RuleFiring, RuleFiringAlert
from app.models.reference import MonitoringTool


class RuleService:

    @staticmethod
    def list_rules_for_incident(db: Session, incident_id: str) -> list[dict]:
        firings = db.execute(
            select(RuleFiring).where(RuleFiring.incident_id == incident_id)
        ).scalars().all()
        firing_ids = {f.rule_id: f.firing_id for f in firings}
        if not firing_ids:
            return []

        rules = db.execute(
            select(CorrelationRule)
            .where(CorrelationRule.rule_id.in_(firing_ids.keys()))
            .order_by(CorrelationRule.confidence_score.desc(), CorrelationRule.rule_id)
        ).scalars().all()

        inputs = db.execute(
            select(RuleCombineInput, MonitoringTool)
            .join(MonitoringTool, MonitoringTool.tool_id == RuleCombineInput.tool_id)
            .where(RuleCombineInput.rule_id.in_(firing_ids.keys()))
            .order_by(RuleCombineInput.rule_id, RuleCombineInput.display_order)
        ).all()
        explanations = db.execute(
            select(RuleExplanation)
            .where(RuleExplanation.rule_id.in_(firing_ids.keys()))
            .order_by(RuleExplanation.rule_id, RuleExplanation.paragraph_order)
        ).scalars().all()
        involved = db.execute(
            select(RuleFiringAlert)
            .where(RuleFiringAlert.firing_id.in_(firing_ids.values()))
            .order_by(RuleFiringAlert.alert_ref)
        ).scalars().all()

        inputs_by_rule: dict[str, list] = {}
        for ri, tool in inputs:
            inputs_by_rule.setdefault(ri.rule_id, []).append(
                {"tool": tool.name, "signal": ri.signal_pattern}
            )
        expl_by_rule: dict[str, list] = {}
        for e in explanations:
            expl_by_rule.setdefault(e.rule_id, []).append(e.text)
        firing_to_rule = {v: k for k, v in firing_ids.items()}
        involved_by_rule: dict[str, list] = {}
        for ia in involved:
            involved_by_rule.setdefault(firing_to_rule[ia.firing_id], []).append(ia.alert_ref)

        return [
            {
                "id":       r.rule_id,
                "name":     r.name,
                "score":    float(r.confidence_score),
                "plain":    r.plain_english,
                "involves": involved_by_rule.get(r.rule_id, []),
                "trigger":  {"when": r.trigger_when, "target": r.trigger_target},
                "combine":  {
                    "inputs": inputs_by_rule.get(r.rule_id, []),
                    "logic":  r.combine_logic,
                },
                "output":   r.output_summary,
                "explain":  expl_by_rule.get(r.rule_id, []),
            }
            for r in rules
        ]
