# """Read incident metadata for the executive Root Cause / Business Impact card.

# Backs the GET /api/v1/incidents/{incident_id} endpoint used by AnalysisView's
# top-right "Business Impact" side card and the "Root Cause" hero card.

# Everything is computed from the DB — no hardcoded values.
# """
# from sqlalchemy import select
# from sqlalchemy.orm import Session

# from app.models.incidents import Incident
# from app.models.reference import Component, Journey, SubJourney
# from app.models.metrics import SubJourneyMetric


# class IncidentService:

#     @staticmethod
#     def get_by_id(db: Session, incident_id: str) -> dict | None:
#         inc = db.get(Incident, incident_id)
#         if inc is None:
#             return None

#         # Root cause component (nice human label with sub_label, e.g. "Rating Engine (Spring Boot 3.2)")
#         rc_component = None
#         if inc.root_cause_component_id:
#             c = db.get(Component, inc.root_cause_component_id)
#             if c:
#                 rc_component = f"{c.name} ({c.sub_label})" if c.sub_label else c.name

#         # Affected journey / sub-journey names + latest metrics for the Business Impact card
#         journey_name = sub_journey_name = None
#         availability = error_rate = p95 = frustrated_pct = None
#         if inc.affected_sub_journey_id:
#             sj = db.get(SubJourney, inc.affected_sub_journey_id)
#             if sj:
#                 sub_journey_name = sj.name
#                 j = db.get(Journey, sj.journey_id)
#                 if j:
#                     journey_name = j.name
#                 # Latest metric snapshot for this sub-journey
#                 m = db.execute(
#                     select(SubJourneyMetric)
#                     .where(SubJourneyMetric.sub_journey_id == sj.sub_journey_id)
#                     .order_by(SubJourneyMetric.snapshot_at.desc())
#                     .limit(1)
#                 ).scalar_one_or_none()
#                 if m:
#                     availability = float(m.availability_pct)
#                     error_rate = float(m.error_rate_pct)
#                     p95 = m.p95_ms
#                     frustrated_pct = m.frustrated_pct

#         return {
#             "incident_id":             inc.incident_id,
#             "title":                   inc.title,
#             "root_cause_desc":         inc.root_cause_desc,
#             "root_cause_component":    rc_component,
#             "raw_alerts_grouped":      inc.raw_alerts_grouped,
#             "tools_contributing":      inc.tools_contributing,
#             "correlation_confidence":  float(inc.correlation_confidence_pct),
#             "frustrated_user_count":   inc.frustrated_user_count,
#             "frustrated_pct":          frustrated_pct,
#             "status":                  inc.status,
#             "detected_at":             inc.detected_at.isoformat() if inc.detected_at else None,
#             "journey_name":            journey_name,
#             "sub_journey_name":        sub_journey_name,
#             "availability_pct":        availability,
#             "error_rate_pct":          error_rate,
#             "p95_ms":                  p95,
#         }
