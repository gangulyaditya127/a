"""Correlation-rule payloads (rules.json entry)."""
from typing import List
from pydantic import BaseModel


class RuleTrigger(BaseModel):
    when: str
    target: str


class RuleCombineInputOut(BaseModel):
    tool: str
    signal: str


class RuleCombine(BaseModel):
    inputs: List[RuleCombineInputOut]
    logic: str


class RuleOut(BaseModel):
    id: str
    name: str
    score: float
    plain: str
    involves: List[str]
    trigger: RuleTrigger
    combine: RuleCombine
    output: str
    explain: List[str]
