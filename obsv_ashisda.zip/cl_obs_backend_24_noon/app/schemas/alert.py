"""Raw alert detail (rawAlerts.json entry)."""
from typing import List, Tuple
from pydantic import BaseModel


class AlertOut(BaseModel):
    sev: str
    src: str
    name: str
    tier: str
    component: str
    time: str
    desc: str
    metrics: List[Tuple[str, str]]
    firstSeen: str
    occurrences7d: int
    occurrences30d: int
