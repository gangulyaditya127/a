"""Tier cards + correlation swim-lane payloads."""
from typing import List, Optional
from pydantic import BaseModel


class TierSourceMix(BaseModel):
    k: str
    n: int
    c: str


class TierSevBreakdown(BaseModel):
    crit: int
    high: int


class TierHistorical(BaseModel):
    today: int
    last7d: int
    last30d: int
    mttr: str


class TierTopCauseOut(BaseModel):
    name: str
    pct: int


class TierAlertRef(BaseModel):
    ref: str
    name: str
    src: str
    sev: str
    time: str


class TierCardOut(BaseModel):
    id: str
    name: str
    level: str
    icon: str
    alertCount: int
    isRoot: bool
    summary: str
    sev: TierSevBreakdown
    sources: List[TierSourceMix]
    hist: TierHistorical
    topCauses: List[TierTopCauseOut]
    alerts: List[TierAlertRef]


class CorrNode(BaseModel):
    id: str
    x: int
    y: int
    w: int
    h: int
    label: str
    sub: str
    level: str
    tier: int
    rc: Optional[bool] = None


class CorrLaneMeta(BaseModel):
    name: str
    level: str


class CorrDataOut(BaseModel):
    nodes: List[CorrNode]
    critEdges: List[List[str]]
    edges: List[List[str]]
    laneMeta: List[CorrLaneMeta]
