"""OpenAI tier-summary request/response."""
from typing import Optional
from pydantic import BaseModel


class TierSummaryRequest(BaseModel):
    incident_id: str
    tier_id: str


class TierSummaryResponse(BaseModel):
    tier_id: str
    incident_id: str
    summary: str
    generated_by: str
    model: Optional[str] = None
