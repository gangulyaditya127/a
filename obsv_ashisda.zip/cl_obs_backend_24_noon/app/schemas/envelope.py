"""Standard API response envelope (skeleton convention)."""
from typing import Generic, TypeVar, List
from pydantic import BaseModel

T = TypeVar("T")


class ApiResponse(BaseModel, Generic[T]):
    success: bool = True
    data: T


class ApiListResponse(BaseModel, Generic[T]):
    success: bool = True
    count: int
    data: List[T]
