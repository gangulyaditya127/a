-- Canada Life ARE Observability - reference DDL
-- The application creates these via SQLAlchemy Base.metadata.create_all().
-- This file exists for DBAs / migration tools / audits.

CREATE TABLE IF NOT EXISTS tiers (
    tier_id       VARCHAR(10)  PRIMARY KEY,
    name          VARCHAR(40)  NOT NULL,
    display_order INT          NOT NULL UNIQUE,
    icon          VARCHAR(10)  NOT NULL,
    level         VARCHAR(10)  NOT NULL DEFAULT 'ok'
        CHECK (level IN ('ok','deg','crit'))
);

CREATE TABLE IF NOT EXISTS monitoring_tools (
    tool_id    VARCHAR(30)  PRIMARY KEY,
    name       VARCHAR(60)  NOT NULL,
    short_name VARCHAR(30),
    color_hex  CHAR(7)      NOT NULL
);

CREATE TABLE IF NOT EXISTS components (
    component_id  VARCHAR(30)  PRIMARY KEY,
    name          VARCHAR(60)  NOT NULL,
    sub_label     VARCHAR(60),
    tier_id       VARCHAR(10)  NOT NULL REFERENCES tiers(tier_id),
    layout_row    INT          NOT NULL,
    display_order INT          NOT NULL DEFAULT 0,
    level         VARCHAR(10)  NOT NULL DEFAULT 'ok'
        CHECK (level IN ('ok','deg','crit')),
    is_rc         BOOLEAN      NOT NULL DEFAULT FALSE
);

CREATE TABLE IF NOT EXISTS component_dependencies (
    dep_id         SERIAL      PRIMARY KEY,
    from_component VARCHAR(30) NOT NULL REFERENCES components(component_id),
    to_component   VARCHAR(30) NOT NULL REFERENCES components(component_id),
    is_critical    BOOLEAN     NOT NULL DEFAULT FALSE,
    display_order  INT         NOT NULL DEFAULT 0,
    UNIQUE (from_component, to_component),
    CHECK (from_component <> to_component)
);

CREATE TABLE IF NOT EXISTS journeys (
    journey_id    VARCHAR(30)  PRIMARY KEY,
    name          VARCHAR(120) NOT NULL,
    segment       VARCHAR(40)  NOT NULL,
    display_order INT          NOT NULL
);

CREATE TABLE IF NOT EXISTS sub_journeys (
    sub_journey_id VARCHAR(40)  PRIMARY KEY,
    journey_id     VARCHAR(30)  NOT NULL REFERENCES journeys(journey_id),
    name           VARCHAR(120) NOT NULL,
    api_label      VARCHAR(120) NOT NULL,
    display_order  INT          NOT NULL
);

CREATE TABLE IF NOT EXISTS correlation_rules (
    rule_id          VARCHAR(30)   PRIMARY KEY,
    name             VARCHAR(200)  NOT NULL,
    confidence_score NUMERIC(3,2)  NOT NULL CHECK (confidence_score BETWEEN 0 AND 1),
    plain_english    TEXT          NOT NULL,
    trigger_when     VARCHAR(200)  NOT NULL,
    trigger_target   VARCHAR(200)  NOT NULL,
    combine_logic    TEXT          NOT NULL,
    output_summary   TEXT          NOT NULL
);

CREATE TABLE IF NOT EXISTS rule_combine_inputs (
    id             SERIAL       PRIMARY KEY,
    rule_id        VARCHAR(30)  NOT NULL REFERENCES correlation_rules(rule_id) ON DELETE CASCADE,
    tool_id        VARCHAR(30)  NOT NULL REFERENCES monitoring_tools(tool_id),
    signal_pattern VARCHAR(200) NOT NULL,
    display_order  INT          NOT NULL
);

CREATE TABLE IF NOT EXISTS rule_explanations (
    id              SERIAL       PRIMARY KEY,
    rule_id         VARCHAR(30)  NOT NULL REFERENCES correlation_rules(rule_id) ON DELETE CASCADE,
    paragraph_order INT          NOT NULL,
    text            TEXT         NOT NULL,
    UNIQUE (rule_id, paragraph_order)
);

CREATE TABLE IF NOT EXISTS journey_metrics (
    metric_id        SERIAL         PRIMARY KEY,
    journey_id       VARCHAR(30)    NOT NULL REFERENCES journeys(journey_id),
    active_users     INT            NOT NULL,
    happy_pct        INT            NOT NULL CHECK (happy_pct      BETWEEN 0 AND 100),
    unhappy_pct      INT            NOT NULL CHECK (unhappy_pct    BETWEEN 0 AND 100),
    frustrated_pct   INT            NOT NULL CHECK (frustrated_pct BETWEEN 0 AND 100),
    availability_pct NUMERIC(5,2)   NOT NULL,
    open_alerts      INT            NOT NULL DEFAULT 0,
    snapshot_at      TIMESTAMPTZ    NOT NULL,
    CHECK (happy_pct + unhappy_pct + frustrated_pct = 100)
);
CREATE INDEX IF NOT EXISTS idx_journey_metrics_latest ON journey_metrics(journey_id, snapshot_at DESC);

CREATE TABLE IF NOT EXISTS sub_journey_metrics (
    metric_id        SERIAL         PRIMARY KEY,
    sub_journey_id   VARCHAR(40)    NOT NULL REFERENCES sub_journeys(sub_journey_id),
    happy_pct        INT,
    unhappy_pct      INT,
    frustrated_pct   INT,
    avg_response_ms  INT            NOT NULL,
    p95_ms           INT            NOT NULL,
    error_rate_pct   NUMERIC(5,2)   NOT NULL,
    availability_pct NUMERIC(5,2)   NOT NULL,
    is_critical      BOOLEAN        NOT NULL DEFAULT FALSE,
    snapshot_at      TIMESTAMPTZ    NOT NULL,
    CHECK (happy_pct IS NULL OR (happy_pct + unhappy_pct + frustrated_pct = 100))
);
CREATE INDEX IF NOT EXISTS idx_sub_journey_metrics_latest ON sub_journey_metrics(sub_journey_id, snapshot_at DESC);

CREATE TABLE IF NOT EXISTS alerts (
    alert_ref              VARCHAR(30)  PRIMARY KEY,
    name                   VARCHAR(120) NOT NULL,
    description            TEXT         NOT NULL,
    severity               VARCHAR(10)  NOT NULL CHECK (severity IN ('crit','high','medium','low')),
    tier_id                VARCHAR(10)  NOT NULL REFERENCES tiers(tier_id),
    tool_id                VARCHAR(30)  NOT NULL REFERENCES monitoring_tools(tool_id),
    component_id           VARCHAR(30)  NOT NULL REFERENCES components(component_id),
    component_display_name VARCHAR(120) NOT NULL,
    detected_at            TIMESTAMPTZ  NOT NULL,
    first_seen_today       TIME         NOT NULL,
    occurrences_7d         INT          NOT NULL DEFAULT 0,
    occurrences_30d        INT          NOT NULL DEFAULT 0,
    CHECK (occurrences_30d >= occurrences_7d)
);
CREATE INDEX IF NOT EXISTS idx_alerts_by_tier ON alerts(tier_id, detected_at);

CREATE TABLE IF NOT EXISTS alert_metrics (
    id             SERIAL       PRIMARY KEY,
    alert_ref      VARCHAR(30)  NOT NULL REFERENCES alerts(alert_ref) ON DELETE CASCADE,
    metric_key     VARCHAR(80)  NOT NULL,
    metric_value   VARCHAR(200) NOT NULL,
    display_order  INT          NOT NULL,
    UNIQUE (alert_ref, metric_key)
);

CREATE TABLE IF NOT EXISTS incidents (
    incident_id                VARCHAR(20)  PRIMARY KEY,
    title                      VARCHAR(300) NOT NULL,
    root_cause_desc            TEXT         NOT NULL,
    root_cause_component_id    VARCHAR(30)  REFERENCES components(component_id),
    affected_sub_journey_id    VARCHAR(40)  REFERENCES sub_journeys(sub_journey_id),
    raw_alerts_grouped         INT          NOT NULL,
    tools_contributing         INT          NOT NULL,
    correlation_confidence_pct NUMERIC(5,2) NOT NULL,
    frustrated_user_count      INT          NOT NULL,
    detected_at                TIMESTAMPTZ  NOT NULL,
    resolved_at                TIMESTAMPTZ,
    status                     VARCHAR(20)  NOT NULL
        CHECK (status IN ('open','investigating','mitigating','resolved'))
);

CREATE TABLE IF NOT EXISTS incident_alerts (
    incident_id VARCHAR(20)  NOT NULL REFERENCES incidents(incident_id) ON DELETE CASCADE,
    alert_ref   VARCHAR(30)  NOT NULL REFERENCES alerts(alert_ref),
    role        VARCHAR(15)  NOT NULL
        CHECK (role IN ('root_cause','downstream','symptom','suppressed','contributing')),
    PRIMARY KEY (incident_id, alert_ref)
);

CREATE TABLE IF NOT EXISTS tier_incident_summary (
    id            SERIAL       PRIMARY KEY,
    incident_id   VARCHAR(20)  NOT NULL REFERENCES incidents(incident_id) ON DELETE CASCADE,
    tier_id       VARCHAR(10)  NOT NULL REFERENCES tiers(tier_id),
    is_root_cause BOOLEAN      NOT NULL DEFAULT FALSE,
    summary_text  TEXT         NOT NULL,
    UNIQUE (incident_id, tier_id)
);

CREATE TABLE IF NOT EXISTS rule_firings (
    firing_id   SERIAL       PRIMARY KEY,
    rule_id     VARCHAR(30)  NOT NULL REFERENCES correlation_rules(rule_id),
    incident_id VARCHAR(20)  NOT NULL REFERENCES incidents(incident_id) ON DELETE CASCADE,
    fired_at    TIMESTAMPTZ  NOT NULL,
    UNIQUE (rule_id, incident_id)
);

CREATE TABLE IF NOT EXISTS rule_firing_alerts (
    firing_id INT          NOT NULL REFERENCES rule_firings(firing_id) ON DELETE CASCADE,
    alert_ref VARCHAR(30)  NOT NULL REFERENCES alerts(alert_ref),
    PRIMARY KEY (firing_id, alert_ref)
);

CREATE TABLE IF NOT EXISTS tier_historical_stats (
    id                   SERIAL       PRIMARY KEY,
    tier_id              VARCHAR(10)  NOT NULL REFERENCES tiers(tier_id),
    alerts_today         INT          NOT NULL,
    alerts_last_7d       INT          NOT NULL,
    alerts_last_30d      INT          NOT NULL,
    median_mttr_minutes  INT          NOT NULL,
    computed_at          TIMESTAMPTZ  NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_tier_stat_latest ON tier_historical_stats(tier_id, computed_at DESC);

CREATE TABLE IF NOT EXISTS tier_top_causes (
    id          SERIAL       PRIMARY KEY,
    tier_id     VARCHAR(10)  NOT NULL REFERENCES tiers(tier_id),
    rank        INT          NOT NULL CHECK (rank BETWEEN 1 AND 10),
    cause_name  VARCHAR(160) NOT NULL,
    percentage  INT          NOT NULL CHECK (percentage BETWEEN 0 AND 100),
    computed_at TIMESTAMPTZ  NOT NULL,
    UNIQUE (tier_id, rank, computed_at)
);
