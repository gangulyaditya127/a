import sys, os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from app.scripts.seed_data import ALERTS

print('INSERT INTO alerts (name, description, severity, tier_id, tool_id, component_id, component_display_name, detected_at, first_seen_today, occurrences_7d, occurrences_30d) VALUES')
values = []
for r in ALERTS:
    ref, name, sev, tier, tool, comp, comp_disp, hms, o7, o30, desc, metrics = r
    desc = desc.replace("'", "''")
    values.append(f"('{name}', '{desc}', '{sev}', '{tier}', '{tool}', '{comp}', '{comp_disp}', CURRENT_TIMESTAMP, CURRENT_TIME, {o7}, {o30})")

print(',\n'.join(values) + ';')
