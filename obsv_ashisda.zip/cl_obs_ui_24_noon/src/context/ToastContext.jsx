import { createContext, useContext, useState, useCallback, useRef } from 'react';

const ToastContext = createContext(null);

export function ToastProvider({ children }) {
  const [msg, setMsg] = useState('');
  const [on, setOn] = useState(false);
  const timer = useRef(null);
  const showToast = useCallback((html) => {
    setMsg(html); setOn(true);
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(() => setOn(false), 3800);
  }, []);
  return (
    <ToastContext.Provider value={{ showToast }}>
      {children}
      <div className={'toast' + (on ? ' on' : '')} dangerouslySetInnerHTML={{__html: msg}} />
    </ToastContext.Provider>
  );
}
export function useToast() { return useContext(ToastContext); }
