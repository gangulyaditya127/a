import { useModal } from '../context/ModalContext';
import RuleBody from './modals/RuleBody';
import AlertDetailBody from './modals/AlertDetailBody';

export default function DetailView({ rules, rawAlerts, onBack }) {
  const { openModal } = useModal();

  const openRuleModal = (rid) => {
    const r = rules.find(x => x.id === rid);
    if (!r) return;
    openModal({
      title: r.name,
      id: `${r.id} · confidence ${Math.round(r.score * 100)}%`,
      body: <RuleBody rule={r} onOpenAlert={openAlertModal} />
    });
  };

  const openAlertModal = (ref) => {
    const a = rawAlerts[ref];
    if (!a) return;
    const related = rules.filter(r => r.involves.includes(ref));
    openModal({
      title: `${a.src} · ${a.name}`,
      id: `${ref} · ${a.tier} tier · ${a.time}`,
      body: <AlertDetailBody alert={a} relatedRules={related} onOpenRule={openRuleModal} />
    });
  };

  return (
    <div className="view">
      <button className="back-btn" onClick={onBack}>← Go back to analysis</button>
      <div className="eyebrow">Correlation Engine · Detailed Analysis</div>
      <h1>How the Correlation Happened</h1>
      <div className="timestamp">Rules that fired for incident INC0048291, ranked by confidence.</div>
      <div className="rules-intro">
        The correlation engine ran <b>5 rules</b> against 14 raw alerts within a 180-second sliding window. Rules are scored by <b>topology proximity + time proximity + signal specificity</b>. The top rule identified <b>Policy Admin DB (Oracle RAC)</b> as root cause with 94% confidence and suppressed 12 downstream symptomatic alerts.
      </div>
      <div>
        {rules.map(r => (
          <div
            key={r.id}
            className="rule-card"
            onClick={(e) => {
              if (e.target.classList.contains('rule-badge')) {
                e.stopPropagation();
                openAlertModal(e.target.dataset.alert);
              } else {
                openRuleModal(r.id);
              }
            }}
          >
            <div className="rule-head">
              <div style={{flex:1, minWidth:0}}>
                <div className="rule-id">{r.id} · <span className="rule-conf">confidence {Math.round(r.score * 100)}%</span></div>
                <div className="rule-name">{r.name}</div>
                <div className="rule-plain">{r.plain}</div>
                <div className="rule-badges">
                  {r.involves.map(x => (
                    <span key={x} className="rule-badge" data-alert={x}>{x}</span>
                  ))}
                </div>
              </div>
              <div className="rule-open-icon">↗</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
