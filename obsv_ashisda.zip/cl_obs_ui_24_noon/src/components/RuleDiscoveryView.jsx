// AI Rule Discovery — faithful React port of ai-rule-discovery-explainer.html

// Path: src/components/RuleDiscoveryView.jsx

//

// Renders the same 5-stage walkthrough as the HTML:

//   1. Discover  - CMDB CIs + signal graph

//   2. Mine      - Streaming alerts (dark terminal) + pattern cards

//   3. Synthesize- 3-column flow (Input -> GPT log -> Output)

//   4. Review    - Rule proposal cards with 4-cell meta + Approve/Tune/Reject

//   5. Deploy    - Pending -> Live counters + deployment log

//

// All stage-specific styles are scoped inside `.rd-root` and injected once

// via a <style> tag, so this component does NOT depend on ANY change to

// styles.css. Ashish's global classes (view, back-btn, eyebrow, timestamp,

// cta-btn) are ALSO used — those already exist in his theme.

//

// The `useLive` prop (default false) controls demo vs live mode:

//   false = render pre-defined demo data (matches the HTML explainer exactly)

//   true  = pull real data from the backend via observabilityService



import { useEffect, useRef, useState } from 'react';



// ------------------------------------------------------------------

// Static demo data — verbatim from the HTML explainer

// ------------------------------------------------------------------

const CI_DATA = [

    { name: 'Policy Admin DB', tools: [['oem', 'Oracle EM'], ['appd', 'AppD DB'], ['splunk', 'Splunk'], ['dyn', 'Dynatrace']] },

    { name: 'Claims Service', tools: [['appd', 'AppDynamics'], ['splunk', 'Splunk']] },

    { name: 'Enterprise Bus', tools: [['hawk', 'TIBCO Hawk'], ['appd', 'AppDynamics'], ['splunk', 'Splunk']] },

    { name: 'Rating Engine', tools: [['appd', 'AppDynamics'], ['splunk', 'Splunk']] },

    { name: 'Document Store', tools: [['fnet', 'FileNet Admin'], ['splunk', 'Splunk']] },

];



const STREAM_LINES = [

    { ts: '14:23:05', tool: 'Oracle EM', sig: 'RACNodeInstanceFailover', crit: true },

    { ts: '14:23:10', tool: 'Splunk', sig: 'JVMOldGenSaturation', crit: true },

    { ts: '14:23:18', tool: 'AppDynamics', sig: 'ThreadPoolExhaustion', crit: true },

    { ts: '14:23:22', tool: 'TIBCO Hawk', sig: 'ProcessEngineStuckThread', crit: true },

    { ts: '14:23:33', tool: 'AppD DB', sig: 'SQLResponseTimeSpike', crit: true },

    { ts: '14:23:41', tool: 'FileNet', sig: 'DocRepositoryTimeout', crit: false },

    { ts: '10:15:02', tool: 'AppDynamics', sig: 'JVMHeapExhaustion', crit: true },

    { ts: '10:15:20', tool: 'AppDynamics', sig: 'ThreadPoolExhaustion', crit: true },

    { ts: '10:15:40', tool: 'TIBCO Hawk', sig: 'HighQueueDepth', crit: false },

    { ts: '10:15:55', tool: 'Splunk', sig: 'KafkaConsumerLag', crit: true },

    { ts: '10:16:15', tool: 'Splunk', sig: 'DBConnectionExhaustion', crit: false },

];



const PATTERNS_DEMO = [

    {
        title: 'P-041 · DB failover cascade',

        meta: '<b>3 tools</b>, <b>4 CIs</b>, avg Δt <b>17s</b>, recurred <b>4× in 90d</b>'
    },

    {
        title: 'P-057 · Memory leak deployment cascade',

        meta: '<b>3 tools</b>, <b>4 CIs</b>, avg Δt <b>34s</b>, recurred <b>7× in 90d</b>'
    },

    {
        title: 'P-072 · ESB queue backlog',

        meta: '<b>2 tools</b>, <b>2 CIs</b>, avg Δt <b>13s</b>, recurred <b>11× in 90d</b>'
    },

];



const GPT_LOG_LINES = [

    ['prompt', 'system: You synthesize AIOps correlation rules from CMDB + alert patterns.'],

    ['prompt', 'user: Pattern P-041 with 3 signals across 3 tiers…'],

    ['comp', '{'],

    ['comp', '  "rule_id": "RULE-AI-014",'],

    ['comp', '  "name": "Database-driven service degradation cascade",'],

    ['comp', '  "trigger_when": "Oracle EM · RACNodeInstanceFailover",'],

    ['comp', '  "combine_logic": "AND within 180 s AND on dependent topology chain",'],

    ['comp', '  "confidence_score": 0.87,'],

    ['comp', '  "expected_precision": 0.91,'],

    ['comp', '  "involves": ["ora", "esb", "claims"]'],

    ['comp', '}'],

    ['out', '→ Rule proposal accepted by schema validator'],

    ['out', '→ Estimated noise reduction: 12 alerts → 1 incident'],

];



const REVIEW_RULES_DEMO = [

    {
        id: 'RULE-AI-014', conf: 0.87, name: 'Database-driven service degradation cascade',

        plain: 'When Oracle RAC loses a node, JVM connection pools saturate within seconds. Groups DB + app tier symptoms into one incident.',

        m: [['3', 'tools'], ['180s', 'window'], ['4×', 'support'], ['91%', 'precision']]
    },

    {
        id: 'RULE-AI-015', conf: 0.82, name: 'Post-deployment memory leak cascade',

        plain: 'JVM heap exhaustion within 60 min of a deployment strongly implies a memory leak — GC storms cascade to Kafka and DB pools.',

        m: [['4', 'tools'], ['240s', 'window'], ['7×', 'support'], ['86%', 'precision']]
    },

    {
        id: 'RULE-AI-016', conf: 0.74, name: 'ESB queue backlog attributed to consumer stalls',

        plain: 'Queue depth spikes together with ESB node health degradation — the ESB itself is degraded, not the producers.',

        m: [['2', 'tools'], ['120s', 'window'], ['11×', 'support'], ['81%', 'precision']]
    },

];



const DEPLOY_LOG_LINES = [

    ['act', 'Loading approved rules from review queue…'],

    ['ok', 'Rule <b>RULE-AI-014</b> written to correlation_rules'],

    ['ok', '3 inputs written to rule_combine_inputs'],

    ['ok', '2 explanation paragraphs written to rule_explanations'],

    ['ok', 'Rule marked <b>active=false</b> (shadow mode) for 7-day evaluation'],

    ['act', 'Notifying correlation engine of rule set change…'],

    ['ok', 'Engine will pick up 3 new rules on next run'],

];



const STAGE_NAMES = ['Discover', 'Mine', 'Synthesize', 'Review', 'Deploy'];



// ==================================================================

// Main component

// ==================================================================

export default function RuleDiscoveryView({ onBack }) {

    const [stage, setStage] = useState(1);

    const timersRef = useRef([]);



    // Clear pending timers on unmount + stage change

    useEffect(() => {

        return () => {

            timersRef.current.forEach(clearTimeout);

            timersRef.current = [];

        };

    }, []);



    const schedule = (fn, delay) => {

        const t = setTimeout(fn, delay);

        timersRef.current.push(t);

        return t;

    };

    const clearTimers = () => {

        timersRef.current.forEach(clearTimeout);

        timersRef.current = [];

    };



    const goToStage = (n) => {

        clearTimers();

        setStage(Math.max(1, Math.min(5, n)));

    };



    // Keyboard nav

    useEffect(() => {

        const onKey = (e) => {

            if (e.key === 'ArrowRight' && stage < 5) goToStage(stage + 1);

            if (e.key === 'ArrowLeft' && stage > 1) goToStage(stage - 1);

        };

        document.addEventListener('keydown', onKey);

        return () => document.removeEventListener('keydown', onKey);

        // eslint-disable-next-line react-hooks/exhaustive-deps

    }, [stage]);



    return (

        <>

            <ScopedStyles />

            <div className="view rd-root">

                <button className="back-btn" onClick={onBack}>&larr; Go back</button>



                <header className="rd-header">

                    <div>

                        <div className="eyebrow">ARE Platform · AI-Driven Rule Discovery</div>

                        <h1>How AI discovers correlation rules from your CMDB</h1>

                        <div className="rd-sub">

                            Instead of humans authoring correlation rules by hand, the system mines your{' '}

                            <b>CMDB</b>, <b>CI-to-tool mappings</b>, and <b>historical alert patterns</b>,

                            then uses <b>OpenAI</b> to synthesize candidate rules. A human reviewer approves,

                            tunes, or rejects each one before it goes live in the correlation engine.

                        </div>

                    </div>

                </header>



                {/* Stage strip */}

                <div className="stage-strip">

                    {STAGE_NAMES.map((name, i) => {

                        const n = i + 1;

                        const cls = 'stage-pill '

                            + (stage === n ? 'active' : '')

                            + (stage > n ? ' done' : '');

                        return (

                            <div key={name} className={cls} onClick={() => goToStage(n)}>

                                <div className="stage-num"><span className="stage-num-txt">{n}</span></div>

                                <div className="stage-title">{name}</div>

                                <div className="stage-sub">{stageSubtitle(n)}</div>

                            </div>

                        );

                    })}

                </div>



                {/* Prev / Next nav */}

                <div className="nav-bar">

                    <button className="nav ghost" onClick={() => goToStage(stage - 1)} disabled={stage === 1}>

                        &larr; Prev

                    </button>

                    <div className="nav-info">

                        Stage <b>{stage}</b> of 5 · <span>{STAGE_NAMES[stage - 1]}</span>

                    </div>

                    <button className="nav primary" onClick={() => goToStage(stage + 1)} disabled={stage === 5}>

                        {stage < 5 ? (

                            <>Next &rarr; <span className="step-indicator">{STAGE_NAMES[stage]}</span></>

                        ) : (

                            'End of walkthrough'

                        )}

                    </button>

                </div>



                {/* Canvas */}

                <div className="canvas">

                    {stage === 1 && <Stage1 schedule={schedule} key="s1" />}

                    {stage === 2 && <Stage2 schedule={schedule} key="s2" />}

                    {stage === 3 && <Stage3 schedule={schedule} key="s3" />}

                    {stage === 4 && <Stage4 schedule={schedule} key="s4" />}

                    {stage === 5 && <Stage5 schedule={schedule} key="s5" />}

                </div>



                <footer className="rd-footer">

                    Canada Life · ARE Observability Platform · AI Rule Discovery flow

                </footer>

            </div>

        </>

    );

}



function stageSubtitle(n) {

    return {

        1: 'Read CMDB & CI-to-tool mappings',

        2: 'Cluster historical alerts by topology & time',

        3: 'GPT proposes candidate rules',

        4: 'Human approves, tunes or rejects',

        5: 'Approved rules go live in the engine',

    }[n];

}



// ==================================================================

// Stage 1 - CMDB Discovery

// ==================================================================

function Stage1({ schedule }) {

    const [cis, setCis] = useState([]);



    useEffect(() => {
        let active = true;
        setCis([]);
        CI_DATA.forEach((ci, i) => {
            schedule(() => {
                if (active) setCis(prev => [...prev, ci]);
            }, i * 150);
        });
        return () => { active = false; };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);



    return (

        <div className="stage active">

            <h2 className="stage-h">Stage 1 — Discover CIs across your monitoring landscape</h2>

            <p className="stage-desc">

                The system reads your <b>CMDB</b> (or ServiceNow, Device42, etc.) and pulls every

                configuration item along with which monitoring tools cover it. This "who-watches-what"

                map is the foundation for everything else — you can't correlate signals across tools

                until you know which tool signals what.

            </p>



            <div className="cmdb-grid">

                <div className="cmdb-panel">

                    <h4>CMDB · CIs with multi-tool coverage</h4>

                    <div>

                        {cis.map((ci, i) => (

                            <div key={i} className="ci-row">

                                <div className="ci-name">{ci.name}</div>

                                <div className="ci-tools">

                                    {ci.tools.map(([cls, nm]) => (

                                        <span key={cls} className={'tool-badge ' + cls}>{nm}</span>

                                    ))}

                                </div>

                            </div>

                        ))}

                    </div>

                    <div className="cmdb-stats">

                        <div className="cmdb-stat"><div className="n">142</div><div className="l">total CIs</div></div>

                        <div className="cmdb-stat"><div className="n">6</div><div className="l">tools connected</div></div>

                        <div className="cmdb-stat"><div className="n">89%</div><div className="l">coverage</div></div>

                    </div>

                </div>



                <div className="cmdb-panel">

                    <h4>Discovered signal graph</h4>

                    <svg viewBox="0 0 400 300" style={{ width: '100%', height: 'auto', background: '#fff', borderRadius: 6 }}>

                        <defs>

                            <marker id="rd-arr1" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto">

                                <path d="M0,0 L10,5 L0,10 z" fill="#c8102e" />

                            </marker>

                        </defs>

                        <ellipse cx="200" cy="150" rx="70" ry="34" fill="#fdecee" stroke="#c8102e" strokeWidth="2" />

                        <text x="200" y="147" textAnchor="middle" fontFamily="Space Grotesk" fontSize="12" fontWeight="700" fill="#2a1418">Policy Admin DB</text>

                        <text x="200" y="163" textAnchor="middle" fontFamily="IBM Plex Mono" fontSize="9" fill="#7a5a5f">Oracle RAC 19c</text>



                        <circle cx="60" cy="60" r="24" fill="#c8102e" />

                        <text x="60" y="63" textAnchor="middle" fontFamily="Space Grotesk" fontSize="9" fontWeight="700" fill="#fff">Oracle EM</text>

                        <line x1="82" y1="72" x2="140" y2="125" stroke="#c8102e" strokeWidth="1.5" markerEnd="url(#rd-arr1)" />



                        <circle cx="340" cy="60" r="24" fill="#0f7a4d" />

                        <text x="340" y="63" textAnchor="middle" fontFamily="Space Grotesk" fontSize="9" fontWeight="700" fill="#fff">AppD DB</text>

                        <line x1="320" y1="72" x2="262" y2="128" stroke="#c8102e" strokeWidth="1.5" markerEnd="url(#rd-arr1)" />



                        <circle cx="60" cy="240" r="24" fill="#b45309" />

                        <text x="60" y="243" textAnchor="middle" fontFamily="Space Grotesk" fontSize="9" fontWeight="700" fill="#fff">Splunk</text>

                        <line x1="82" y1="230" x2="140" y2="175" stroke="#c8102e" strokeWidth="1.5" markerEnd="url(#rd-arr1)" />



                        <circle cx="340" cy="240" r="24" fill="#1e40af" />

                        <text x="340" y="243" textAnchor="middle" fontFamily="Space Grotesk" fontSize="9" fontWeight="700" fill="#fff">Dynatrace</text>

                        <line x1="320" y1="230" x2="262" y2="175" stroke="#c8102e" strokeWidth="1.5" markerEnd="url(#rd-arr1)" />



                        <text x="200" y="290" textAnchor="middle" fontFamily="IBM Plex Mono" fontSize="10" fill="#7a5a5f">

                            4 tools monitor this single CI — perfect correlation candidate

                        </text>

                    </svg>

                </div>

            </div>



            <div className="architecture-note">

                <b>Data sources:</b> ServiceNow CMDB · Device42 · custom YAML · JSON exports.

                Read via connectors under <code>app/connectors/*_connector.py</code>.

                <br /><b>Storage:</b> reference tables <code>components</code> (CIs) and{' '}

                <code>monitoring_tools</code> — extended with a new junction table{' '}

                <code>ci_tool_coverage</code> recording which tool watches which CI and via which signal names.

            </div>

        </div>

    );

}



// ==================================================================

// Stage 2 - Pattern Mining

// ==================================================================

function Stage2({ schedule }) {

    const [lines, setLines] = useState([]);

    const [patterns, setPatterns] = useState([]);

    const streamRef = useRef(null);



    useEffect(() => {
        let active = true;
        setLines([]);
        setPatterns([]);
        STREAM_LINES.forEach((l, i) => {
            schedule(() => {
                if (!active) return;
                setLines(prev => [...prev, l]);
                if (streamRef.current) streamRef.current.scrollTop = streamRef.current.scrollHeight;
            }, i * 250);
        });
        PATTERNS_DEMO.forEach((p, i) => {
            schedule(() => {
                if (active) setPatterns(prev => [...prev, p]);
            }, 1200 + i * 500);
        });
        return () => { active = false; };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);


    return (

        <div className="stage active">

            <h2 className="stage-h">Stage 2 — Mine historical alerts for co-firing patterns</h2>

            <p className="stage-desc">

                The engine ingests <b>90 days of historical alerts</b> and looks for groups that

                consistently fire together within tight time windows across CIs that are related

                in the CMDB. Every recurring co-firing pattern becomes a candidate rule seed.

            </p>



            <div className="mining-layout">

                <div className="alert-stream" ref={streamRef}>

                    <div className="hdr">RAW ALERT STREAM · LAST 90 DAYS</div>

                    {lines.map((l, i) => (

                        <div key={i} className={'alert-line' + (l.crit ? ' crit' : '')}>

                            <span className="ts">{l.ts}</span>{' '}

                            <span className="tool">[{l.tool}]</span>{' '}

                            <span className="sig">{l.sig}</span>

                        </div>

                    ))}

                </div>



                <div className="patterns-out">

                    <h4>Discovered patterns</h4>

                    {patterns.map((p, i) => (

                        <div key={i} className="pattern-card">

                            <div className="pattern-title">{p.title}</div>

                            <div className="pattern-meta" dangerouslySetInnerHTML={{ __html: p.meta }} />

                        </div>

                    ))}

                </div>

            </div>



            <div className="architecture-note">

                <b>Algorithm:</b> temporal clustering (DBSCAN on time deltas ≤ 300s) + topology

                constraint (all alerts must lie on a connected sub-graph in the CMDB) +

                minimum support (pattern must recur ≥ 3 times to be considered). Output is a

                set of <code>PatternCandidate</code> objects passed to Stage 3.

            </div>

        </div>

    );

}



// ==================================================================

// Stage 3 - AI Synthesis

// ==================================================================

function Stage3({ schedule }) {

    const [logLines, setLogLines] = useState([]);

    const logRef = useRef(null);



    useEffect(() => {
        let active = true;
        setLogLines([]);
        GPT_LOG_LINES.forEach((line, i) => {
            schedule(() => {
                if (!active) return;
                setLogLines(prev => [...prev, line]);
                if (logRef.current) logRef.current.scrollTop = logRef.current.scrollHeight;
            }, i * 280);
        });
        return () => { active = false; };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);



    return (

        <div className="stage active">

            <h2 className="stage-h">Stage 3 — OpenAI synthesizes correlation rules</h2>

            <p className="stage-desc">

                For each pattern, we send the CMDB context plus the co-firing evidence to <b>OpenAI GPT-4</b>{' '}

                with a strict system prompt. The model returns a structured rule proposal —

                trigger condition, combine logic, expected inputs, plain-English explanation, and a

                confidence estimate.

            </p>



            <div className="synth-flow">

                <div className="synth-box input">

                    <h5>Input to GPT</h5>

                    <div className="synth-content">

                        <b>Pattern seed:</b><br />

                        <code>OEM · RACNodeInstanceFailover</code> + <code>AppD · ThreadPoolExhaustion</code>{' '}

                        + <code>TIBCO · ProcessEngineStuckThread</code>

                        <br /><br />

                        <b>CMDB context:</b><br />

                        <code>ora → esb → claims</code> (topology chain)<br />

                        <code>ora</code> monitored by: <code>Oracle EM, AppD DB, Splunk</code>

                        <br /><br />

                        <b>Co-firings observed:</b><br />

                        4 times in 90d, avg Δt = 17s

                    </div>

                </div>



                <div className="synth-arrow">→</div>



                <div className="synth-box gpt">

                    <h5>GPT-4 reasoning</h5>

                    <div className="gpt-log" ref={logRef}>

                        {logLines.map(([cls, txt], i) => (

                            <div key={i} className={cls}>{txt}</div>

                        ))}

                    </div>

                </div>



                <div className="synth-arrow">→</div>



                <div className="synth-box output">

                    <h5>Structured rule proposal</h5>

                    <div className="synth-content">

                        <code>rule_id: RULE-AI-014</code><br />

                        <code>trigger_when:</code> Oracle EM · RACNodeInstanceFailover<br />

                        <code>combine_logic:</code> AND within 180s AND on chain (Data → Integration → Application)<br />

                        <code>confidence:</code> 0.87<br />

                        <code>expected_precision:</code> 91%<br />

                        <code>expected_reduction:</code> 12 alerts → 1 incident

                    </div>

                </div>

            </div>



            <div className="architecture-note">

                <b>Prompt design:</b> function-calling with a JSON schema; the model MUST return valid{' '}

                <code>CorrelationRule</code> object or the request retries with feedback. Guardrails: no

                free-form rule names, confidence must be numeric, chain must reference existing tier IDs.

            </div>

        </div>

    );

}



// ==================================================================

// Stage 4 - Human Review

// ==================================================================

function Stage4({ schedule }) {

    const [rules, setRules] = useState([]);



    useEffect(() => {
        let active = true;
        setRules([]);
        REVIEW_RULES_DEMO.forEach((r, i) => {
            schedule(() => {
                if (active) setRules(prev => [...prev, r]);
            }, i * 400);
        });
        return () => { active = false; };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);



    return (

        <div className="stage active">

            <h2 className="stage-h">Stage 4 — Human review, tune, or reject</h2>

            <p className="stage-desc">

                Every AI-generated rule lands in the <b>Rule Review</b> queue. An SRE inspects the

                plain-English summary, the involved CIs, historical support, expected precision,

                and either <b>Approves</b> (deploys as-is), <b>Tunes</b> (edits then approves), or{' '}

                <b>Rejects</b> (with a reason that trains future prompts).

            </p>



            <div className="review-list">

                {rules.map((r, i) => (

                    <div key={i} className="rule-proposal">

                        <div className="rp-hdr">

                            <div>

                                <div className="rp-id">

                                    {r.id} · <span className="rp-conf">{Math.round(r.conf * 100)}% confidence</span>

                                </div>

                                <div className="rp-name">{r.name}</div>

                            </div>

                        </div>

                        <div className="rp-plain">{r.plain}</div>

                        <div className="rp-meta">

                            {r.m.map(([v, l], j) => (

                                <div key={j} className="rp-meta-cell">

                                    <b>{v}</b><span>{l}</span>

                                </div>

                            ))}

                        </div>

                        <div className="rp-actions">

                            <button className="rp-btn approve">✓ Approve</button>

                            <button className="rp-btn tune">✎ Tune</button>

                            <button className="rp-btn reject">✗ Reject</button>

                        </div>

                    </div>

                ))}

            </div>



            <div className="architecture-note">

                <b>Governance:</b> approvals require 2 reviewers for confidence &lt; 0.80. All actions

                are logged in <code>rule_review_events</code> with reviewer_id, decision, comment.

                Rejected patterns feed back into the prompt via few-shot examples so the model learns

                what your team considers noise.

            </div>

        </div>

    );

}



// ==================================================================

// Stage 5 - Deploy

// ==================================================================

function Stage5({ schedule }) {

    const [logLines, setLogLines] = useState([]);

    const [pending, setPending] = useState(6);

    const [live, setLive] = useState(14);



    useEffect(() => {
        let active = true;
        setLogLines([]);
        setPending(6);
        setLive(14);
        DEPLOY_LOG_LINES.forEach((entry, i) => {
            schedule(() => {
                if (active) setLogLines(prev => [...prev, entry]);
            }, i * 450);
        });
        schedule(() => {
            if (active) {
                setPending(0);
                setLive(17);
            }
        }, DEPLOY_LOG_LINES.length * 450 + 200);
        return () => { active = false; };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);


    return (

        <div className="stage active">

            <h2 className="stage-h">Stage 5 — Deploy approved rules into the live engine</h2>

            <p className="stage-desc">

                Approved rules are written into the existing <b>correlation_rules</b> table (plus{' '}

                <code>rule_combine_inputs</code> and <code>rule_explanations</code>) — the same

                tables your correlation engine already reads. No engine code change needed. The next

                correlation run evaluates them automatically.

            </p>



            <div className="deploy-diagram">

                <div className="deploy-box pending">

                    <div className="deploy-num">{pending}</div>

                    <div className="deploy-lbl">Pending review</div>

                </div>

                <div className="deploy-arrow">→</div>

                <div className="deploy-box active-b">

                    <div className="deploy-num">{live}</div>

                    <div className="deploy-lbl">Live rules</div>

                </div>

            </div>



            <div className="deploy-panel">

                <div className="deploy-log-title">Deployment log</div>

                <div>

                    {logLines.map(([cls, html], i) => (

                        <div key={i} className={'deploy-log-line ' + cls}

                            dangerouslySetInnerHTML={{ __html: html }} />

                    ))}

                </div>

            </div>



            <div className="architecture-note">

                <b>Rollback:</b> soft-delete via <code>rules.active=false</code> — reversible in one click.

                <br /><b>A/B testing:</b> new rules run in <b>shadow mode</b> for 7 days by default —

                they log what they <em>would</em> have grouped without actually suppressing alerts, so

                you can measure precision on real traffic before promoting.

            </div>

        </div>

    );

}



// ==================================================================

// Scoped styles - injected once, all rules prefixed with .rd-root

// ==================================================================

function ScopedStyles() {

    return (

        <style>{`

      .rd-root { font-family: 'IBM Plex Mono', monospace; }

      .rd-root .rd-header {

        border-bottom: 3px solid #c8102e; padding-bottom: 16px; margin-bottom: 24px;

        display: flex; justify-content: space-between; align-items: flex-end;

        flex-wrap: wrap; gap: 16px;

      }

      .rd-root .rd-sub {

        color: #7a5a5f; font-size: 13px; margin-top: 8px; max-width: 800px; line-height: 1.55;

      }

      .rd-root h1 {

        font-family: 'Space Grotesk', sans-serif; font-size: 28px; font-weight: 600;

        margin: 6px 0 4px 0; letter-spacing: -.01em; color: #2a1418; line-height: 1.15;

      }

      .rd-root .stage-strip {

        display: grid; grid-template-columns: repeat(5, 1fr); gap: 12px; margin-bottom: 16px;

        padding: 12px; background: #fdf5f5; border: 1px solid #e6d5d5; border-radius: 8px;

      }

      .rd-root .stage-pill {

        background: #fff; border: 1px solid #e6d5d5; border-radius: 6px; padding: 12px 10px;

        text-align: center; transition: all .3s; position: relative; opacity: .5; cursor: pointer;

      }

      .rd-root .stage-pill:hover { opacity: .8; }

      .rd-root .stage-pill.active {

        border-color: #c8102e; background: #fdecee; opacity: 1;

        box-shadow: 0 4px 14px rgba(200,16,46,.12);

      }

      .rd-root .stage-pill.done { border-color: #0f7a4d; background: #eaf9f0; opacity: 1; }

      .rd-root .stage-num {

        display: inline-block; width: 24px; height: 24px; border-radius: 50%;

        background: #c8102e; color: #fff; font-family: 'Space Grotesk', sans-serif;

        font-weight: 700; font-size: 11px; line-height: 24px; margin-bottom: 6px;

      }

      .rd-root .stage-pill.done .stage-num { background: #0f7a4d; }

      .rd-root .stage-pill.done .stage-num::after { content: '\\2713'; }

      .rd-root .stage-pill.done .stage-num-txt { display: none; }

      .rd-root .stage-title {

        font-family: 'Space Grotesk', sans-serif; font-size: 11px; font-weight: 700;

        letter-spacing: .05em; text-transform: uppercase; color: #2a1418;

      }

      .rd-root .stage-sub {

        font-size: 9.5px; color: #7a5a5f; margin-top: 3px; line-height: 1.3;

      }

      .rd-root .nav-bar {

        display: flex; justify-content: space-between; align-items: center;

        margin-bottom: 16px; padding: 8px 4px; gap: 12px; flex-wrap: wrap;

      }

      .rd-root .nav-info {

        font-family: 'Space Grotesk', sans-serif; font-size: 11px; color: #7a5a5f;

        text-transform: uppercase; letter-spacing: .06em; font-weight: 700;

      }

      .rd-root .nav-info b { color: #9c0b23; font-size: 13px; }

      .rd-root button.nav {

        padding: 10px 20px; border-radius: 22px;

        font-family: 'Space Grotesk', sans-serif; font-weight: 700; font-size: 12px;

        letter-spacing: .05em; text-transform: uppercase; cursor: pointer;

        display: inline-flex; align-items: center; gap: 8px;

        transition: background .15s, transform .1s;

      }

      .rd-root button.nav.primary { background: #c8102e; color: #fff; border: none; }

      .rd-root button.nav.primary:hover:not(:disabled) { background: #9c0b23; }

      .rd-root button.nav.ghost { background: #fff; color: #c8102e; border: 1px solid #c8102e; }

      .rd-root button.nav.ghost:hover:not(:disabled) { background: #fdecee; }

      .rd-root button.nav:disabled { opacity: .35; cursor: not-allowed; }

      .rd-root button.nav:active:not(:disabled) { transform: scale(.97); }

      .rd-root button.nav .step-indicator {

        background: rgba(255,255,255,.25); padding: 2px 8px; border-radius: 10px;

        font-size: 10px; margin-left: 4px;

      }

      .rd-root .canvas {

        background: #fff; border: 1px solid #e6d5d5; border-radius: 10px;

        padding: 24px; min-height: 560px; position: relative; overflow: hidden;

      }

      .rd-root .stage { display: block; animation: rd-fadeIn .4s ease; }

      @keyframes rd-fadeIn { from { opacity: 0; transform: translateY(6px); } to { opacity: 1; transform: translateY(0); } }

      .rd-root h2.stage-h {

        font-family: 'Space Grotesk', sans-serif; font-size: 20px; font-weight: 600;

        margin: 0 0 6px 0; color: #9c0b23;

      }

      .rd-root .stage-desc {

        color: #7a5a5f; font-size: 13px; line-height: 1.55; max-width: 760px; margin-bottom: 20px;

      }



      /* Stage 1: CMDB */

      .rd-root .cmdb-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }

      .rd-root .cmdb-panel {

        border: 1px solid #e6d5d5; border-radius: 8px; padding: 16px; background: #fdf5f5;

      }

      .rd-root .cmdb-panel h4 {

        margin: 0 0 12px 0; font-family: 'Space Grotesk', sans-serif; font-size: 12px;

        letter-spacing: .08em; text-transform: uppercase; color: #c8102e;

      }

      .rd-root .ci-row {

        display: grid; grid-template-columns: 1fr 2fr; gap: 8px; align-items: center;

        padding: 8px 10px; margin-bottom: 6px; background: #fff; border-radius: 5px;

        border: 1px solid #e6d5d5; font-size: 11.5px;

        animation: rd-slideIn .3s ease;

      }

      @keyframes rd-slideIn { from { opacity: 0; transform: translateY(-4px); } to { opacity: 1; transform: translateY(0); } }

      .rd-root .ci-name { font-family: 'Space Grotesk', sans-serif; font-weight: 700; color: #2a1418; }

      .rd-root .ci-tools { display: flex; gap: 4px; flex-wrap: wrap; }

      .rd-root .tool-badge {

        font-size: 9px; padding: 2px 6px; border-radius: 9px;

        font-family: 'Space Grotesk', sans-serif; font-weight: 700; color: #fff;

      }

      .rd-root .tool-badge.appd   { background: #0f7a4d; }

      .rd-root .tool-badge.splunk { background: #b45309; }

      .rd-root .tool-badge.oem    { background: #c8102e; }

      .rd-root .tool-badge.dyn    { background: #1e40af; }

      .rd-root .tool-badge.hawk   { background: #7c3aed; }

      .rd-root .tool-badge.fnet   { background: #0e7490; }

      .rd-root .cmdb-stats {

        display: grid; grid-template-columns: repeat(3, 1fr); gap: 8px; margin-top: 14px;

      }

      .rd-root .cmdb-stat {

        background: #fff; border: 1px solid #e6d5d5; border-radius: 5px; padding: 8px;

        text-align: center;

      }

      .rd-root .cmdb-stat .n {

        font-family: 'Space Grotesk', sans-serif; font-weight: 700;

        font-size: 20px; color: #9c0b23;

      }

      .rd-root .cmdb-stat .l {

        font-size: 9px; color: #7a5a5f; text-transform: uppercase;

        letter-spacing: .06em; font-weight: 700; margin-top: 2px;

      }



      /* Stage 2: Pattern Mining */

      .rd-root .mining-layout { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }

      .rd-root .alert-stream {

        background: #0f172a; color: #e2e8f0; border-radius: 8px; padding: 14px;

        height: 360px; overflow: hidden;

        font-family: 'IBM Plex Mono', monospace; font-size: 10.5px; line-height: 1.6;

      }

      .rd-root .alert-stream .hdr {

        color: #64748b; margin-bottom: 8px;

        font-family: 'Space Grotesk', sans-serif; font-weight: 700;

        text-transform: uppercase; font-size: 10px; letter-spacing: .08em;

      }

      .rd-root .alert-line { padding: 2px 0; animation: rd-fadeIn .25s ease; }

      .rd-root .alert-line .ts   { color: #94a3b8; }

      .rd-root .alert-line .tool { color: #38bdf8; }

      .rd-root .alert-line .sig  { color: #f97316; }

      .rd-root .alert-line.crit .sig { color: #f43f5e; font-weight: 700; }

      .rd-root .patterns-out {

        background: #fdf5f5; border: 1px solid #e6d5d5; border-radius: 8px;

        padding: 14px; height: 360px; overflow-y: auto;

      }

      .rd-root .patterns-out h4 {

        margin: 0 0 12px 0; font-family: 'Space Grotesk', sans-serif; font-size: 12px;

        letter-spacing: .08em; text-transform: uppercase; color: #c8102e;

      }

      .rd-root .pattern-card {

        background: #fff; border: 1px solid #e6d5d5; border-left: 3px solid #c8102e;

        border-radius: 5px; padding: 10px 12px; margin-bottom: 8px;

        animation: rd-slideIn .35s ease;

      }

      .rd-root .pattern-title {

        font-family: 'Space Grotesk', sans-serif; font-weight: 700;

        font-size: 11.5px; color: #2a1418;

      }

      .rd-root .pattern-meta {

        font-size: 10px; color: #7a5a5f; margin-top: 4px; line-height: 1.5;

      }

      .rd-root .pattern-meta b { color: #9c0b23; }



      /* Stage 3: AI Synthesis */

      .rd-root .synth-flow {

        display: grid; grid-template-columns: 1fr 40px 1fr 40px 1fr;

        gap: 0; align-items: stretch;

      }

      .rd-root .synth-box {

        border: 1px solid #e6d5d5; border-radius: 8px; padding: 16px; background: #fff;

      }

      .rd-root .synth-box.input  { border-left: 4px solid #d97706; background: #fef9e7; }

      .rd-root .synth-box.gpt    { border-left: 4px solid #7c3aed; background: #f4edff; }

      .rd-root .synth-box.output { border-left: 4px solid #c8102e; background: #fdecee; }

      .rd-root .synth-arrow {

        display: flex; align-items: center; justify-content: center;

        font-size: 20px; color: #c8102e;

      }

      .rd-root .synth-box h5 {

        font-family: 'Space Grotesk', sans-serif; font-size: 11px;

        letter-spacing: .08em; text-transform: uppercase; color: #7a5a5f;

        margin: 0 0 8px 0; font-weight: 700;

      }

      .rd-root .synth-content { font-size: 11px; line-height: 1.55; color: #2a1418; }

      .rd-root .synth-content code {

        background: rgba(0,0,0,.05); padding: 1px 4px; border-radius: 2px;

        font-size: 10px; color: #9c0b23;

      }

      .rd-root .gpt-log {

        background: #1e1e2e; color: #f0f6fc; border-radius: 5px; padding: 10px;

        font-family: 'IBM Plex Mono', monospace; font-size: 10px; line-height: 1.55;

        height: 180px; overflow-y: auto; margin-top: 8px;

      }

      .rd-root .gpt-log .prompt { color: #94a3b8; }

      .rd-root .gpt-log .comp   { color: #a5f3fc; }

      .rd-root .gpt-log .out    { color: #86efac; }



      /* Stage 4: Human Review */

      .rd-root .review-list { max-width: 900px; }

      .rd-root .rule-proposal {

        background: #fff; border: 1px solid #e6d5d5; border-left: 4px solid #d97706;

        border-radius: 8px; padding: 16px 20px; margin-bottom: 14px;

        animation: rd-slideIn .35s ease;

      }

      .rd-root .rp-hdr {

        display: flex; justify-content: space-between; align-items: flex-start;

        gap: 12px; flex-wrap: wrap;

      }

      .rd-root .rp-id { font-family: 'IBM Plex Mono', monospace; font-size: 10.5px; color: #7a5a5f; }

      .rd-root .rp-name {

        font-family: 'Space Grotesk', sans-serif; font-weight: 700; font-size: 14px;

        color: #2a1418; margin: 4px 0 6px 0;

      }

      .rd-root .rp-conf {

        font-family: 'Space Grotesk', sans-serif; font-weight: 700; font-size: 13px; color: #9c0b23;

      }

      .rd-root .rp-plain {

        font-size: 12px; line-height: 1.55; color: #2a1418;

        background: #fdecee; border-left: 2px solid #c8102e;

        padding: 8px 10px; border-radius: 4px; margin: 8px 0;

      }

      .rd-root .rp-meta {

        display: grid; grid-template-columns: repeat(4, 1fr); gap: 8px;

        margin: 10px 0; font-size: 10.5px;

      }

      .rd-root .rp-meta-cell {

        text-align: center; padding: 6px; background: #fdf5f5;

        border: 1px solid #e6d5d5; border-radius: 4px;

      }

      .rd-root .rp-meta-cell b {

        display: block; font-family: 'Space Grotesk', sans-serif; color: #2a1418; font-size: 13px;

      }

      .rd-root .rp-meta-cell span {

        color: #7a5a5f; font-size: 9.5px; text-transform: uppercase;

        letter-spacing: .05em; font-weight: 700;

      }

      .rd-root .rp-actions { display: flex; gap: 8px; margin-top: 10px; }

      .rd-root .rp-btn {

        padding: 6px 14px; border-radius: 16px;

        font-family: 'Space Grotesk', sans-serif; font-weight: 700;

        font-size: 10.5px; letter-spacing: .05em; text-transform: uppercase;

        cursor: pointer; border: none;

      }

      .rd-root .rp-btn.approve { background: #0f7a4d; color: #fff; }

      .rd-root .rp-btn.tune    { background: #fff; color: #2a1418; border: 1px solid #d9bcbc; }

      .rd-root .rp-btn.reject  { background: #fff; color: #c8102e; border: 1px solid #c8102e; }



      /* Stage 5: Deployment */

      .rd-root .deploy-diagram {

        display: grid; grid-template-columns: 1fr 60px 1fr;

        gap: 0; align-items: center; margin-bottom: 20px;

      }

      .rd-root .deploy-box {

        background: #fff; border: 1px solid #e6d5d5; border-radius: 8px;

        padding: 20px; text-align: center;

      }

      .rd-root .deploy-box.pending  { border-left: 4px solid #d97706; background: #fef9e7; }

      .rd-root .deploy-box.active-b { border-left: 4px solid #0f7a4d; background: #eaf9f0; }

      .rd-root .deploy-num {

        font-family: 'Space Grotesk', sans-serif; font-weight: 700;

        font-size: 36px; color: #9c0b23;

      }

      .rd-root .deploy-lbl {

        font-family: 'Space Grotesk', sans-serif; font-size: 11px;

        letter-spacing: .08em; text-transform: uppercase; color: #7a5a5f;

        font-weight: 700; margin-top: 4px;

      }

      .rd-root .deploy-arrow { text-align: center; color: #c8102e; font-size: 28px; }

      .rd-root .deploy-panel {

        background: #fdf5f5; border: 1px solid #e6d5d5; border-radius: 8px; padding: 16px;

      }

      .rd-root .deploy-log-title {

        font-family: 'Space Grotesk', sans-serif; font-weight: 700; font-size: 12px;

        color: #c8102e; letter-spacing: .08em; text-transform: uppercase; margin-bottom: 10px;

      }

      .rd-root .deploy-log-line {

        font-family: 'IBM Plex Mono', monospace; font-size: 11px; color: #7a5a5f;

        padding: 4px 0; border-top: 1px dashed #e6d5d5;

        animation: rd-fadeIn .3s ease;

      }

      .rd-root .deploy-log-line:first-child { border-top: none; }

      .rd-root .deploy-log-line.ok::before  { content: '\\2713 '; color: #0f7a4d; font-weight: 700; }

      .rd-root .deploy-log-line.act::before { content: '\\2192 '; color: #c8102e; font-weight: 700; }

      .rd-root .deploy-log-line b { color: #2a1418; }



      .rd-root .architecture-note {

        background: #fdf5f5; border: 1px solid #e6d5d5; border-left: 4px solid #c8102e;

        border-radius: 6px; padding: 12px 16px; margin-top: 20px; font-size: 11.5px;

        line-height: 1.55; color: #7a5a5f;

      }

      .rd-root .architecture-note b { color: #2a1418; }

      .rd-root .rd-footer {

        margin-top: 24px; padding-top: 16px; border-top: 1px solid #e6d5d5;

        font-size: 10.5px; color: #b8a0a3; text-align: center;

      }



      @media (max-width: 900px) {

        .rd-root .cmdb-grid,

        .rd-root .mining-layout { grid-template-columns: 1fr; }

        .rd-root .synth-flow { grid-template-columns: 1fr; }

        .rd-root .synth-arrow { transform: rotate(90deg); padding: 8px 0; }

      }

    `}</style>

    );

}