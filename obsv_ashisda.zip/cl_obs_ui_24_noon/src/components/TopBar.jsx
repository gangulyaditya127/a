import React from 'react';

export default function TopBar({ crumbs, onNav }) {
  return (
    <div className="topbar">
      <div className="brand">
        <div className="brand-mark">CL</div>
        <div>
          <div className="brand-name">Canada Life</div>
          <div className="brand-sub">ARE · Observability</div>
        </div>
      </div>
      <div className="crumbs">
        {crumbs.map((c, i) => (
          <React.Fragment key={c.id}>
            <button
              className={'c' + (i === crumbs.length - 1 ? ' active' : '')}
              onClick={() => onNav(c.id)}
            >
              {c.label}
            </button>
            {i < crumbs.length - 1 && <span className="sep">/</span>}
          </React.Fragment>
        ))}
      </div>

      {/* Fixed: Added the closing > after the style prop */}
      <button
        className="c"
        onClick={() => onNav && onNav('rule-discovery')}
        style={{ marginRight: 12, color: 'var(--cl-red)', fontWeight: 700 }}
      >
        Rule Discovery
      </button>

      <div className="searchpill">🔍 Press <span className="kbd">⌘</span><span className="kbd">K</span></div>
    </div>
  );
}