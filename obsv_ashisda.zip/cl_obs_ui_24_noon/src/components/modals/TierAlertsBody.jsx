import { toSec } from '../../utils/time';

export default function TierAlertsBody({ tier, rawAlerts, onOpenAlert }) {
  const sorted = [...tier.alerts].sort((a, b) => toSec(a.time) - toSec(b.time));

  return (
    <table className="aa-table">
      <thead>
        <tr>
          <th>Alert</th>
          <th>Description</th>
          <th>Source</th>
          <th>Severity</th>
          <th>Time</th>
        </tr>
      </thead>
      <tbody>
        {sorted.map(r => {
          // Look up the full alert details from rawAlerts to get the description
          const fullAlert = rawAlerts[r.ref] || {};
          
          return (
            <tr key={r.ref}>
              <td>
                <div className="aa-ref">{r.ref}</div>
                <div className="aa-name">{r.name}</div>
              </td>
              {/* Added Description Column */}
              <td style={{ fontSize: '11px', color: 'var(--text-dim)', maxWidth: '300px', lineHeight: '1.4' }}>
                {fullAlert.desc}
              </td>
              <td className="aa-src">{r.src}</td>
              <td><span className={'aa-sev ' + r.sev}>{r.sev}</span></td>
              <td>{r.time}</td>
            </tr>
          );
        })}
      </tbody>
    </table>
  );
}