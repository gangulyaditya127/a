const API_BASE = import.meta.env.VITE_API_BASE || "http://localhost:8000/api/v1";
const INCIDENT_ID = import.meta.env.VITE_INCIDENT_ID || "INC0048291";
const APP_HOURS = import.meta.env.VITE_APP_HOURS || 48;

async function get(path) {
  const res = await fetch(`${API_BASE}${path}`);
  if (!res.ok) throw new Error(`${path} - ${res.status}`);
  const body = await res.json();
  return body.data;
}

async function post(path, body) {
  const res = await fetch(`${API_BASE}${path}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body || {}),
  });
  if (!res.ok) throw new Error(`${path} - ${res.status}`);
  const j = await res.json();
  return j.data;
}

export const observabilityService = {
  getJourneys: () => get("/journeys"),

  getSubJourneys: (journeyId) => {
    const path = journeyId ? `/sub-journeys?journey_id=${journeyId}` : "/sub-journeys";
    return get(path);
  },

  getTiers: () => get(`/tiers?incident=${INCIDENT_ID}`),
  getRawAlerts: () => get("/alerts"),
  getCorrData: (subjourneyId) => {
    const incidentParam = subjourneyId ? 'latest' : INCIDENT_ID;
    let path = `/corr-data?incident=${incidentParam}`;
    if (subjourneyId) {
      path += `&subjourney_id=${encodeURIComponent(subjourneyId)}`;
    }
    return get(path);
  },
  getRules: () => get(`/rules?incident=${INCIDENT_ID}`),

  generateTierSummary: (tier_id) => fetch(`${API_BASE}/ai/tier-summary`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ incident_id: INCIDENT_ID, tier_id })
  }).then(r => r.json()).then(b => b.data),

  getAll: async () => {
    const journeys = await get("/journeys");
    return { journeys, subJourneys: {}, tiers: null, rawAlerts: null, corrData: null, rules: null };
  },

  // AI Rule Discovery
  getCiCoverage: () => get("/rule-discovery/ci-coverage"),
  listPatterns: (s) => get("/rule-discovery/patterns" + (s ? `?status=${s}` : "")),
  synthesizePattern: (pid) => post(`/rule-discovery/patterns/${pid}/synthesize`, {}),
  listProposals: (s) => get("/rule-discovery/proposals" + (s ? `?status=${s}` : "")),
  approveProposal: (id, comment) => post(`/rule-discovery/proposals/${id}/approve`, { comment }),
  rejectProposal: (id, comment) => post(`/rule-discovery/proposals/${id}/reject`, { comment }),
  deployProposal: (id) => post(`/rule-discovery/proposals/${id}/deploy`, {}),
  correlateDryRun: () => get("/correlate/dry-run"),

  // --- SUB-JOURNEY METHODS RESTORED HERE ---
  getSubJourneyTiers: (id, hours = APP_HOURS) =>
    get(`/sub-journeys/${encodeURIComponent(id)}/tiers?hours=${hours}`),

  getSubJourneyAlertsMap: async (id) => {
    const alertsArray = await get(`/sub-journeys/${encodeURIComponent(id)}/alerts`);
    const alertsMap = {};
    alertsArray.forEach(a => {
      alertsMap[a.ref] = {
        ...a,
        metrics: a.metrics || [],
        firstSeen: a.time,
        occurrences7d: a.occurrences_7d || 1,
        occurrences30d: a.occurrences_30d || 1
      };
    });
    return alertsMap;
  },

  getSubJourneyAlertHierarchy: (id, hours = APP_HOURS) =>
    get(`/sub-journeys/${encodeURIComponent(id)}/alert-hierarchy?hours=${hours}`),
};