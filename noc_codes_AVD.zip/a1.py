import sqlite3
import os
import time

# ─────────────────────────────────────────────
# CONFIGURATION
# ─────────────────────────────────────────────

INPUT_LOG_FILE = "Teardown"
DB_FILE = "network_policies_optimized.db"

# Number of DB inserts per commit
BATCH_SIZE = 50000

# Number of unique keys to keep in memory
# before flushing and clearing the set
DEDUP_CHUNK_SIZE = 5000000

# ─────────────────────────────────────────────
# DATABASE SETUP
# ─────────────────────────────────────────────

def setup_database(db_path):

    conn = sqlite3.connect(db_path)

    cursor = conn.cursor()

    # PERFORMANCE PRAGMAS
    cursor.execute("PRAGMA journal_mode=WAL")
    cursor.execute("PRAGMA synchronous=OFF")
    cursor.execute("PRAGMA temp_store=MEMORY")
    cursor.execute("PRAGMA cache_size=-100000")

    # NO UNIQUE CONSTRAINT
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS network_policies (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            src TEXT,
            dst TEXT,
            dst_port TEXT,
            protocol TEXT
        )
    """)

    conn.commit()

    return conn

# ─────────────────────────────────────────────
# FAST PARSER
# ─────────────────────────────────────────────

def parse_line(line):

    if "Teardown" not in line:
        return None

    try:

        parts = line.split()

        # Example:
        #
        # Teardown TCP connection 3244091426
        # for TCSLB_TCSProdFW:10.52.161.26/32565
        # to TCS_APP_DATA:10.17.195.64/443

        protocol = parts[6]

        # Locate positions dynamically
        for_index = parts.index("for")
        to_index = parts.index("to")

        src_part = parts[for_index + 1]
        dst_part = parts[to_index + 1]

        # Split from RIGHT side only
        # because object names contain ':'

        # Source
        src_ip_port = src_part.rsplit(":", 1)[1]

        src_ip = src_ip_port.split("/")[0]

        # Destination
        dst_ip_port = dst_part.rsplit(":", 1)[1]

        dst_ip = dst_ip_port.split("/")[0]

        dst_port = dst_ip_port.split("/")[1]

        return (src_ip, dst_ip, dst_port, protocol)

    except Exception:
        return None
# ─────────────────────────────────────────────
# MAIN PROCESSOR
# ─────────────────────────────────────────────

def process_log_file(log_file, db_conn):

    cursor = db_conn.cursor()

    total_lines = 0
    total_matches = 0
    total_inserts = 0
    duplicates_skipped = 0

    batch = []

    # IN-MEMORY DEDUP
    seen = set()

    start_time = time.perf_counter()

    print(f"\n⏳ Processing started...")
    print(f"Input File : {log_file}")
    print(f"Database   : {DB_FILE}\n")

    with open(log_file, "r", encoding="utf-8", errors="ignore") as f:

        for line in f:

            total_lines += 1

            parsed = parse_line(line)

            if not parsed:
                continue

            total_matches += 1

            # FAST HASH-BASED DEDUP
            if parsed in seen:
                duplicates_skipped += 1
                continue

            seen.add(parsed)

            batch.append(parsed)

            # FLUSH TO DB
            if len(batch) >= BATCH_SIZE:

                cursor.executemany("""
                    INSERT INTO network_policies
                    (src, dst, dst_port, protocol)
                    VALUES (?, ?, ?, ?)
                """, batch)

                db_conn.commit()

                total_inserts += len(batch)

                batch.clear()

            # MEMORY CONTROL
            if len(seen) >= DEDUP_CHUNK_SIZE:
                seen.clear()

    # FINAL FLUSH
    if batch:

        cursor.executemany("""
            INSERT INTO network_policies
            (src, dst, dst_port, protocol)
            VALUES (?, ?, ?, ?)
        """, batch)

        db_conn.commit()

        total_inserts += len(batch)

    end_time = time.perf_counter()

    duration = end_time - start_time

    # ─────────────────────────────────────────
    # STATS
    # ─────────────────────────────────────────

    print("\n✅ Processing Complete")
    print("-" * 50)

    print(f"Total Lines Read       : {total_lines}")
    print(f"Matching Log Entries   : {total_matches}")
    print(f"Unique Policies Insert : {total_inserts}")
    print(f"Duplicates Skipped     : {duplicates_skipped}")

    print("-" * 50)

    print(f"Execution Time         : {duration:.2f} seconds")

    if duration > 0:
        rate = total_lines / duration
        print(f"Processing Rate        : {rate:,.0f} lines/sec")

# ─────────────────────────────────────────────
# ENTRY POINT
# ─────────────────────────────────────────────

if __name__ == "__main__":

    if not os.path.exists(INPUT_LOG_FILE):

        print(f"❌ File not found: {INPUT_LOG_FILE}")

    else:

        conn = setup_database(DB_FILE)

        try:
            process_log_file(INPUT_LOG_FILE, conn)

        finally:
            conn.close()