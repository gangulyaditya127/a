import sqlite3
import os
import time

# ─────────────────────────────────────────────
# CONFIGURATION
# ─────────────────────────────────────────────

INPUT_LOG_FILE = "Teardown"
DB_FILE = "network_policies_optimized2.db"

# Recommended:
# 50k–100k is usually optimal
BATCH_SIZE = 50000

# ─────────────────────────────────────────────
# DATABASE SETUP
# ─────────────────────────────────────────────

def setup_database(db_path):

    conn = sqlite3.connect(db_path)

    cursor = conn.cursor()

    # PERFORMANCE PRAGMAS
    cursor.execute("PRAGMA journal_mode=WAL")
    cursor.execute("PRAGMA synchronous=OFF")
    cursor.execute("PRAGMA temp_store=MEMORY")
    cursor.execute("PRAGMA cache_size=-100000")

    # TABLE WITH UNIQUE CONSTRAINT
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS network_policies (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            src TEXT,
            dst TEXT,
            dst_port TEXT,
            protocol TEXT,
            UNIQUE(src, dst, dst_port, protocol)
        )
    """)

    conn.commit()

    return conn

# ─────────────────────────────────────────────
# FAST NON-REGEX PARSER
# ─────────────────────────────────────────────

def parse_line(line):

    # Fast precheck
    if "Teardown" not in line:
        return None

    try:

        parts = line.split()

        # Example:
        #
        # 2026-02-24T10:30:01+05:30 INFRA-PRI :
        # %ASA-3-302014:
        # Teardown TCP connection 3244091426
        # for TCSLB_TCSProdFW:10.52.161.26/32565
        # to TCS_APP_DATA:10.17.195.64/443

        protocol = parts[6]

        # Dynamically locate positions
        for_index = parts.index("for")
        to_index = parts.index("to")

        src_part = parts[for_index + 1]
        dst_part = parts[to_index + 1]

        # Split from RIGHT side
        # because object names may contain ':'

        # SOURCE
        src_ip_port = src_part.rsplit(":", 1)[1]

        src_ip = src_ip_port.split("/")[0]

        # DESTINATION
        dst_ip_port = dst_part.rsplit(":", 1)[1]

        dst_ip = dst_ip_port.split("/")[0]

        dst_port = dst_ip_port.split("/")[1]

        return (
            src_ip,
            dst_ip,
            dst_port,
            protocol
        )

    except Exception:
        return None

# ─────────────────────────────────────────────
# MAIN PROCESSOR
# ─────────────────────────────────────────────

def process_log_file(log_file, db_conn):

    cursor = db_conn.cursor()

    total_lines = 0
    total_matches = 0
    total_inserted = 0
    duplicates_skipped = 0

    batch = []

    # GLOBAL IN-MEMORY DEDUP
    seen = set()

    start_time = time.perf_counter()

    print("\n⏳ Processing started...")
    print(f"Input File : {log_file}")
    print(f"Database   : {DB_FILE}\n")

    with open(log_file, "r", encoding="utf-8", errors="ignore") as f:

        for line in f:

            total_lines += 1

            parsed = parse_line(line)

            if not parsed:
                continue

            total_matches += 1

            # FAST PYTHON HASH DEDUP
            if parsed in seen:
                duplicates_skipped += 1
                continue

            seen.add(parsed)

            batch.append(parsed)

            # BULK INSERT
            if len(batch) >= BATCH_SIZE:

                cursor.executemany("""
                    INSERT OR IGNORE INTO network_policies
                    (src, dst, dst_port, protocol)
                    VALUES (?, ?, ?, ?)
                """, batch)

                db_conn.commit()

                total_inserted += cursor.rowcount

                batch.clear()

    # FINAL FLUSH
    if batch:

        cursor.executemany("""
            INSERT OR IGNORE INTO network_policies
            (src, dst, dst_port, protocol)
            VALUES (?, ?, ?, ?)
        """, batch)

        db_conn.commit()

        total_inserted += cursor.rowcount

    end_time = time.perf_counter()

    duration = end_time - start_time

    # ─────────────────────────────────────────
    # FINAL STATS
    # ─────────────────────────────────────────

    print("\n✅ Processing Complete")
    print("-" * 60)

    print(f"Total Lines Read       : {total_lines:,}")
    print(f"Matching Log Entries   : {total_matches:,}")
    print(f"Unique Policies Insert : {total_inserted:,}")
    print(f"Duplicates Skipped     : {duplicates_skipped:,}")

    print("-" * 60)

    print(f"Execution Time         : {duration:.2f} seconds")

    if duration > 0:

        rate = total_lines / duration

        print(f"Processing Rate        : {rate:,.0f} lines/sec")

# ─────────────────────────────────────────────
# ENTRY POINT
# ─────────────────────────────────────────────

if __name__ == "__main__":

    if not os.path.exists(INPUT_LOG_FILE):

        print(f"❌ Error: File not found -> {INPUT_LOG_FILE}")

    else:

        connection = setup_database(DB_FILE)

        try:

            process_log_file(INPUT_LOG_FILE, connection)

        finally:

            connection.close()