a1 - normal gpt generated
a2 - with db dedeup checked
a3 - with postgres replacing sqlite