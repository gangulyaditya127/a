import psycopg2
import csv
import os
import time

# ─────────────────────────────────────────────
# CONFIGURATION
# ─────────────────────────────────────────────

INPUT_LOG_FILE = "Teardown"

TEMP_CSV_FILE = "parsed_output.csv"

DB_CONFIG = {
    "host": "localhost",
    "port": 5433,
    "database": "n2",
    "user": "postgres",
    "password": "p@ssw0rd"
}

# ─────────────────────────────────────────────
# DATABASE SETUP
# ─────────────────────────────────────────────

def setup_database():

    conn = psycopg2.connect(**DB_CONFIG)

    cursor = conn.cursor()

    # DROP OLD TABLES
    cursor.execute("""
        DROP TABLE IF EXISTS raw_network_policies;
    """)

    cursor.execute("""
        DROP TABLE IF EXISTS network_policies;
    """)

    # RAW TABLE (NO UNIQUE CONSTRAINT)
    cursor.execute("""
        CREATE TABLE raw_network_policies (
            src TEXT,
            dst TEXT,
            dst_port TEXT,
            protocol TEXT
        );
    """)

    conn.commit()

    return conn

# ─────────────────────────────────────────────
# FAST NON-REGEX PARSER
# ─────────────────────────────────────────────

def parse_line(line):

    if "Teardown" not in line:
        return None

    try:

        parts = line.split()

        protocol = parts[6]

        for_index = parts.index("for")
        to_index = parts.index("to")

        src_part = parts[for_index + 1]
        dst_part = parts[to_index + 1]

        # RIGHT split because names may contain ':'
        src_ip_port = src_part.rsplit(":", 1)[1]

        src_ip = src_ip_port.split("/")[0]

        dst_ip_port = dst_part.rsplit(":", 1)[1]

        dst_ip = dst_ip_port.split("/")[0]

        dst_port = dst_ip_port.split("/")[1]

        return (
            src_ip,
            dst_ip,
            dst_port,
            protocol
        )

    except Exception:
        return None

# ─────────────────────────────────────────────
# STEP 1 → PARSE LOG → CSV
# ─────────────────────────────────────────────

def generate_csv():

    total_lines = 0
    total_matches = 0

    start = time.perf_counter()

    print("\n⏳ Parsing log file...")
    print(f"Input File : {INPUT_LOG_FILE}")
    print(f"CSV Output : {TEMP_CSV_FILE}\n")

    with open(INPUT_LOG_FILE, "r", encoding="utf-8", errors="ignore") as infile, \
         open(TEMP_CSV_FILE, "w", newline="", encoding="utf-8") as outfile:

        writer = csv.writer(outfile)

        # HEADER
        writer.writerow([
            "src",
            "dst",
            "dst_port",
            "protocol"
        ])

        for line in infile:

            total_lines += 1

            parsed = parse_line(line)

            if not parsed:
                continue

            total_matches += 1

            writer.writerow(parsed)

    end = time.perf_counter()

    duration = end - start

    print("✅ CSV Generation Complete")
    print("-" * 60)

    print(f"Total Lines Read       : {total_lines:,}")
    print(f"Matching Log Entries   : {total_matches:,}")

    print("-" * 60)

    print(f"CSV Generation Time    : {duration:.2f} sec")

# ─────────────────────────────────────────────
# STEP 2 → POSTGRES COPY
# ─────────────────────────────────────────────

def bulk_copy_to_postgres(conn):

    cursor = conn.cursor()

    start = time.perf_counter()

    print("\n⏳ Starting PostgreSQL COPY...")

    with open(TEMP_CSV_FILE, "r", encoding="utf-8") as f:

        cursor.copy_expert("""
            COPY raw_network_policies(src, dst, dst_port, protocol)
            FROM STDIN
            WITH CSV HEADER
        """, f)

    conn.commit()

    end = time.perf_counter()

    duration = end - start

    print("✅ PostgreSQL COPY Complete")
    print(f"COPY Time              : {duration:.2f} sec")

# ─────────────────────────────────────────────
# STEP 3 → DEDUPLICATE
# ─────────────────────────────────────────────

def deduplicate_data(conn):

    cursor = conn.cursor()

    start = time.perf_counter()

    print("\n⏳ Deduplicating data...")

    cursor.execute("""
        CREATE TABLE network_policies AS
        SELECT DISTINCT
            src,
            dst,
            dst_port,
            protocol
        FROM raw_network_policies;
    """)

    conn.commit()

    # COUNT FINAL ROWS
    cursor.execute("""
        SELECT COUNT(*) FROM network_policies;
    """)

    final_count = cursor.fetchone()[0]

    end = time.perf_counter()

    duration = end - start

    print("✅ Deduplication Complete")
    print("-" * 60)

    print(f"Final Unique Policies  : {final_count:,}")

    print("-" * 60)

    print(f"Deduplication Time     : {duration:.2f} sec")

# ─────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────

if __name__ == "__main__":

    overall_start = time.perf_counter()

    if not os.path.exists(INPUT_LOG_FILE):

        print(f"❌ File not found: {INPUT_LOG_FILE}")

    else:

        connection = setup_database()

        try:

            # STEP 1
            generate_csv()

            # STEP 2
            bulk_copy_to_postgres(connection)

            # STEP 3
            deduplicate_data(connection)

        finally:

            connection.close()

    overall_end = time.perf_counter()

    print("\n" + "=" * 60)
    print("✅ ENTIRE PIPELINE COMPLETE")
    print("=" * 60)

    print(f"Total Pipeline Time    : {(overall_end - overall_start):.2f} sec")