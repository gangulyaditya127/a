import psycopg2
import io
import os
import time

# ─────────────────────────────────────────────
# CONFIGURATION
# ─────────────────────────────────────────────

INPUT_LOG_FILE = "Teardown"

DB_CONFIG = {
    "host": "localhost",
    "port": 5433,
    "database": "n2",
    "user": "postgres",
    "password": "p@ssw0rd"
}

BATCH_SIZE = 100000

# ─────────────────────────────────────────────
# DATABASE SETUP
# ─────────────────────────────────────────────

def setup_database():

    conn = psycopg2.connect(**DB_CONFIG)

    conn.autocommit = False

    cursor = conn.cursor()

    print("\n⏳ Preparing database...")

    # PERFORMANCE SETTINGS
    cursor.execute("SET synchronous_commit TO OFF;")
    cursor.execute("SET work_mem TO '256MB';")
    cursor.execute("SET maintenance_work_mem TO '1GB';")

    # DROP OLD TABLES
    cursor.execute("DROP TABLE IF EXISTS raw_network_policies;")
    cursor.execute("DROP TABLE IF EXISTS network_policies;")

    # FAST STAGING TABLE
    cursor.execute("""
        CREATE UNLOGGED TABLE raw_network_policies (
            src INET,
            dst INET,
            dst_port INTEGER,
            protocol VARCHAR(10)
        );
    """)

    # FINAL TABLE WITH UNIQUE CONSTRAINT
    cursor.execute("""
        CREATE TABLE network_policies (
            src INET,
            dst INET,
            dst_port INTEGER,
            protocol VARCHAR(10),
            UNIQUE(src, dst, dst_port, protocol)
        );
    """)

    conn.commit()

    print("✅ Database ready")

    return conn

# ─────────────────────────────────────────────
# FAST PARSER
# ─────────────────────────────────────────────

def parse_line(line):

    if "Teardown" not in line:
        return None

    try:

        parts = line.split()

        protocol = parts[6]

        for_index = parts.index("for")
        to_index = parts.index("to")

        src_part = parts[for_index + 1]
        dst_part = parts[to_index + 1]

        src_ip_port = src_part.rsplit(":", 1)[1]
        dst_ip_port = dst_part.rsplit(":", 1)[1]

        src_ip = src_ip_port.split("/")[0]

        dst_ip = dst_ip_port.split("/")[0]
        dst_port = dst_ip_port.split("/")[1]

        return (
            src_ip,
            dst_ip,
            dst_port,
            protocol
        )

    except Exception:
        return None

# ─────────────────────────────────────────────
# COPY BATCH TO POSTGRES
# ─────────────────────────────────────────────

def copy_batch(cursor, rows):

    if not rows:
        return

    buffer = io.StringIO()

    for row in rows:
        buffer.write(
            f"{row[0]},{row[1]},{row[2]},{row[3]}\n"
        )

    buffer.seek(0)

    cursor.copy_expert("""
        COPY raw_network_policies(
            src,
            dst,
            dst_port,
            protocol
        )
        FROM STDIN
        WITH (
            FORMAT CSV
        )
    """, buffer)

# ─────────────────────────────────────────────
# PARSE + DIRECT STREAM COPY
# ─────────────────────────────────────────────

def stream_to_postgres(conn):

    cursor = conn.cursor()

    total_lines = 0
    total_matches = 0

    batch = []

    start = time.perf_counter()

    print("\n⏳ Streaming logs directly to PostgreSQL...\n")

    with open(
        INPUT_LOG_FILE,
        "r",
        encoding="utf-8",
        errors="ignore"
    ) as infile:

        for line in infile:

            total_lines += 1

            parsed = parse_line(line)

            if not parsed:
                continue

            total_matches += 1

            batch.append(parsed)

            # BATCH FLUSH
            if len(batch) >= BATCH_SIZE:

                copy_batch(cursor, batch)

                conn.commit()

                print(
                    f"✅ Inserted: {total_matches:,} rows",
                    end="\r"
                )

                batch.clear()

        # FINAL FLUSH
        if batch:

            copy_batch(cursor, batch)

            conn.commit()

    end = time.perf_counter()

    print("\n")
    print("✅ Streaming Complete")
    print("-" * 60)

    print(f"Total Lines Read       : {total_lines:,}")
    print(f"Matching Log Entries   : {total_matches:,}")

    print("-" * 60)

    print(f"Streaming Time         : {(end - start):.2f} sec")

# ─────────────────────────────────────────────
# DEDUPLICATE USING UNIQUE CONSTRAINT
# ─────────────────────────────────────────────

def deduplicate_data(conn):

    cursor = conn.cursor()

    start = time.perf_counter()

    print("\n⏳ Deduplicating intelligently...\n")

    cursor.execute("""
        INSERT INTO network_policies(
            src,
            dst,
            dst_port,
            protocol
        )
        SELECT
            src,
            dst,
            dst_port,
            protocol
        FROM raw_network_policies
        ON CONFLICT DO NOTHING;
    """)

    conn.commit()

    cursor.execute("""
        SELECT COUNT(*) FROM network_policies;
    """)

    final_count = cursor.fetchone()[0]

    end = time.perf_counter()

    print("✅ Deduplication Complete")
    print("-" * 60)

    print(f"Final Unique Policies  : {final_count:,}")

    print("-" * 60)

    print(f"Deduplication Time     : {(end - start):.2f} sec")

# ─────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────

if __name__ == "__main__":

    overall_start = time.perf_counter()

    if not os.path.exists(INPUT_LOG_FILE):

        print(f"❌ File not found: {INPUT_LOG_FILE}")

    else:

        connection = setup_database()

        try:

            # STREAM DIRECTLY
            stream_to_postgres(connection)

            # DEDUP
            deduplicate_data(connection)

        finally:

            connection.close()

    overall_end = time.perf_counter()

    print("\n" + "=" * 60)
    print("✅ ENTIRE PIPELINE COMPLETE")
    print("=" * 60)

    print(
        f"Total Pipeline Time    : "
        f"{(overall_end - overall_start):.2f} sec"
    )