import { useEffect, useState } from "react";

export default function CorrelationExecutionView({
  corrData,
  breadcrumb,
  onBack
}) {
  const incident = corrData?.incident;

  return (
    <div className="view">
      <button className="back-btn" onClick={onBack}>
        &larr; Go back
      </button>
      <div className="eyebrow">{breadcrumb} · Application: Benefits</div>
      <h1>Active Correlation Executions</h1>
      
      <div className="timestamp">Time window for correlation: 15-06-2025 within 10-12am (Last 2 hours)</div>

      {corrData && (
        <>
          <section className="analysis-section" style={{ marginTop: 24 }}>
            <div className="sec-head">
              <div className="sec-step">01</div>
              <div>
                <h2 className="sec-title">Alert Correlation</h2>
                <p className="sec-sub">
                  The single incident that ties the cluster together based on discovered correlation pattern.
                </p>
              </div>
            </div>

            <div className="exec-row">
              <div className="exec-card rc">
                <span className="exec-badge">Root Cause</span>
                <h2>
                  {incident?.root_cause || "Unknown Root Cause"}
                </h2>
                <p className="exec-desc" dangerouslySetInnerHTML={{ __html: incident?.root_cause_desc || "Loading incident details..." }}>
                </p>
                <div className="exec-metrics">
                  <div className="exec-metric">
                    <div className="m-val">{(corrData?.children?.length ?? 0) + 1}</div>
                    <div className="m-lbl">raw alerts grouped</div>
                  </div>
                  <div className="exec-metric">
                    <div className="m-val">{incident?.tools_contributing ?? "-"}</div>
                    <div className="m-lbl">tools contributing</div>
                  </div>
                  <div className="exec-metric">
                    <div className="m-val">{incident?.correlation_confidence_pct ?? "-"}%</div>
                    <div className="m-lbl">correlation confidence</div>
                  </div>
                </div>
              </div>
              <div className="exec-side">
                <h3>Business Impact</h3>
                <div className="impact-row">
                  <span className="lb2">Journey affected</span>
                  <span className="vv">{breadcrumb ? breadcrumb.split(' · ')[0] : 'Unknown Journey'}</span>
                </div>
                <div className="impact-row">
                  <span className="lb2">Sub-journey</span>
                  <span className="vv">{breadcrumb ? breadcrumb.split(' · ')[1] || 'Unknown Sub-journey' : 'Unknown Sub-journey'}</span>
                </div>
                <div className="impact-row">
                  <span className="lb2">Availability</span>
                  <span className="vv bad">94.20 %</span>
                </div>
                <div className="impact-row">
                  <span className="lb2">Frustrated users</span>
                  <span className="vv bad">10 % · {incident?.frustrated_user_count ?? 152} members</span>
                </div>
                <div className="impact-row">
                  <span className="lb2">Incident ID</span>
                  <span className="vv">{incident?.id ?? "INC0048291"}</span>
                </div>
              </div>
            </div>
          </section>

          <section className="analysis-section">
            <div className="sec-head">
              <div className="sec-step">02</div>
              <div>
                <h2 className="sec-title">Clustered Incidents Timeline</h2>
                <p className="sec-sub">
                  Cluster: {corrData.parent.extractedJob} | Pattern: {corrData.parent.grammar} | Service: {corrData.parent.service}
                </p>
              </div>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
              {/* PARENT ROW */}
              <div style={{ 
                background: 'var(--panel-bg)', 
                border: '1px solid var(--amber)', 
                borderRadius: '8px', 
                padding: '16px' 
              }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
                  <span style={{ fontWeight: 'bold', color: 'var(--amber)' }}>{corrData.parent.id} (PARENT)</span>
                  <span style={{ color: 'var(--text-dim)' }}>{corrData.parent.time}</span>
                </div>
                <div style={{ fontFamily: 'monospace', color: 'var(--text-bright)' }}>
                  {corrData.parent.description}
                </div>
              </div>

              {/* CHILDREN ROWS */}
              {corrData.children.map(child => (
                <div key={child.id} style={{ 
                  background: 'var(--panel-bg)', 
                  border: '1px solid var(--border)', 
                  borderRadius: '8px', 
                  padding: '16px',
                  marginLeft: '40px',
                  position: 'relative'
                }}>
                  <div style={{
                    position: 'absolute',
                    left: '-24px',
                    top: '24px',
                    width: '24px',
                    height: '2px',
                    background: 'var(--border)'
                  }} />
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
                    <span style={{ fontWeight: 'bold', color: 'var(--green)' }}>{child.id} (CHILD)</span>
                    <div style={{ display: 'flex', gap: '16px', color: 'var(--text-dim)' }}>
                      <span>Delta: {child.delta}</span>
                      <span>{child.time}</span>
                    </div>
                  </div>
                  <div style={{ fontFamily: 'monospace', color: 'var(--text-bright)', marginBottom: '12px' }}>
                    {child.description}
                  </div>
                  
                  {/* CONFIDENCE BAR */}
                  <div style={{ display: 'flex', alignItems: 'center', gap: '12px', fontSize: '12px' }}>
                    <span style={{ color: 'var(--text-dim)' }}>Confidence Score:</span>
                    <div style={{ flex: 1, background: 'var(--bg)', height: '6px', borderRadius: '3px', overflow: 'hidden' }}>
                      <div style={{ 
                        width: `${child.confidence * 100}%`, 
                        background: child.confidence >= 0.9 ? 'var(--green)' : 'var(--amber)', 
                        height: '100%' 
                      }} />
                    </div>
                    <span style={{ fontWeight: 'bold' }}>{(child.confidence * 100).toFixed(0)}%</span>
                  </div>
                  <div style={{ fontSize: '11px', color: 'var(--text-dim)', marginTop: '4px' }}>
                    Boosters: {child.boosters.join(', ')}
                  </div>
                </div>
              ))}
            </div>
          </section>
        </>
      )}
    </div>
  );
}
