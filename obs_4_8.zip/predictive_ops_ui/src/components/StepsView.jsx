import { nowLong } from '../utils/time';

export default function StepsView({ journeyKey, subJourneys, onBack, onOpenStep }) {
  const j = subJourneys[journeyKey];
  if (!j) return null;
  const availColor = (v, critical) => critical ? 'var(--cl-red)' : (v >= 95 ? 'var(--green)' : v >= 80 ? 'var(--amber)' : 'var(--cl-red)');
  return (
    <div className="view">
      <button className="back-btn" onClick={onBack}>← Go back</button>
      <div className="eyebrow">Journey Execution Experience</div>
      <h1>{j.title}</h1>
      <div className="timestamp">{nowLong()}</div>
      <div className="sub-hint">Select a sub-journey to inspect its tier contribution and correlated incident.</div>
      <div className="table-panel">
        <table className="j-table">
          <thead>
            <tr>
              <th>Sub-journey (step)</th>
              <th className="n">Experience Split
                <div className="sub-labels">
                  <span style={{color:'var(--green)'}}>Happy</span>
                  <span style={{color:'var(--amber)'}}>Unhappy</span>
                  <span style={{color:'var(--cl-red)'}}>Frustrated</span>
                </div>
              </th>
              <th>Actions / API</th>
              <th className="n">Avg Resp</th>
              <th className="n">P(95)</th>
              <th className="n">Error Rate</th>
              <th className="n">Availability</th>
            </tr>
          </thead>
          <tbody>
            {j.steps.map(s => (
              <tr key={s.id} className="row-click" onClick={() => onOpenStep(s.id)}>
                <td><div className="step-name" style={{ color: s.critical ? 'var(--cl-red)' : 'inherit' }}>{s.name}</div></td>
                <td className="pct multi">
                  {s.hu ? (<>
                    <span style={{color:'var(--green)'}}>{s.hu[0]}%</span>
                    <span style={{color:'var(--amber)'}}>{s.hu[1]}%</span>
                    <span style={{color:'var(--cl-red)'}}>{s.hu[2]}%</span>
                  </>) : <span style={{color:'var(--text-dimmer)', minWidth:'auto'}}>—</span>}
                </td>
                <td><span className={'step-api' + (s.critical ? ' crit' : '')}>{s.api}</span></td>
                <td className={'num-cell' + (s.critical ? ' crit' : '')}>{s.avg} ms</td>
                <td className={'num-cell' + (s.critical ? ' crit' : '')}>{s.p95} ms</td>
                <td className={'num-cell' + (s.err >= 10 ? ' crit' : '')}>{s.err} %</td>
                <td className="num-cell" style={{color: availColor(s.avail, s.critical), fontWeight:700}}>{s.avail.toFixed(2)} %</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
