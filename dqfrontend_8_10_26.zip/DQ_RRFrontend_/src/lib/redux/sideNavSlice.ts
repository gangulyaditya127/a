// src/lib/redux/slices/sideNavSlice.ts
import { createSlice, PayloadAction } from "@reduxjs/toolkit";

type SideNavState = {
  hasSideBar: boolean;
};

const initialState: SideNavState = {
  hasSideBar: true,
};

const sideNavSlice = createSlice({
  name: "sideNav",
  initialState,
  reducers: {
    setHasSideBar(state, action: PayloadAction<boolean>) {
      state.hasSideBar = action.payload;
    },
  },
});

export const { setHasSideBar } = sideNavSlice.actions;
export default sideNavSlice.reducer;