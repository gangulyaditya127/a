
import { configureStore } from "@reduxjs/toolkit";
import sidebarNavigationSlice from "@/components/layout/slice/sidebar-navigation";
import topbarNavigation from "@/components/layout/slice/topbar-navigation";
import resolutionApi from "@/application/resolution-recommender/type/resolutionApi";
import metaApi from "@/application/resolution-recommender/type/metaApi";

export const store = configureStore({
  reducer: {
    // UI slices
    sideNav: sidebarNavigationSlice,
    topNav: topbarNavigation,

    // RTK Query reducers
    [resolutionApi.reducerPath]: resolutionApi.reducer,
    [metaApi.reducerPath]: metaApi.reducer,
  },
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware().concat(
      // RTK Query middlewares
      resolutionApi.middleware,
      metaApi.middleware
    ),
});

// RTK Query listeners (refetchOnFocus/refetchOnReconnect support)
import { setupListeners } from "@reduxjs/toolkit/query";
setupListeners(store.dispatch);

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;

