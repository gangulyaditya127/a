import { useEffect } from "react";
import { SideNav } from "@/components/layout/SideNav";
import { TopNav } from "@/components/layout/TopNav";
import { useAppDispatch } from "@/lib/redux/hooks";
import { setHasSideBar } from "@/lib/redux/sideNavSlice";
import { cn } from "@/lib/tailwind.utils";
import { Outlet, ScrollRestoration } from "react-router-dom";

function App() {
  const dispatch = useAppDispatch();
  const hasSideBar = true;

  useEffect(() => {
    dispatch(setHasSideBar(true));
  }, [dispatch]);

  return (
    <div className={cn("min-h-screen w-full", hasSideBar && "pl-[56px]")}>
      { <SideNav />}
      <TopNav hasSideBar={true} />
      <main>
        <Outlet />
        <ScrollRestoration />
      </main>
    </div>
  );
}

export default App;