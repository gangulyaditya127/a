
// src/main.tsx
import { StrictMode } from "react";
import ReactDOM from "react-dom/client";
import "./index.css";

import { Provider } from "react-redux";
import { store } from "@/lib/redux/store";
import { ThemeProvider } from "@/components/theme-provider";
import { Toaster } from "@/components/ui/toaster";

import ErrorBoundry from "@/components/ux/ErrorBoundry";
import ErrorFallback from "@/components/ux/ErrorFallback";
import { RouterProvider } from "react-router-dom";
import { router } from "@/router";
import "@/lib/i18/index";

ReactDOM.createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <ErrorBoundry fallback={<ErrorFallback />}>
      <Provider store={store}>
        <ThemeProvider defaultTheme="dark" storageKey="ismart-ui-theme">
          <RouterProvider router={router} />
          <Toaster />
        </ThemeProvider>
      </Provider>
    </ErrorBoundry>
  </StrictMode>
);
