// src/application/resolution-recommender/page/ResolutionAgent.tsx
// import React from "react";
import ResolutionRecommender from "@/application/resolution-recommender/features/resolution-recommender";
import Container from "@/components/ui/container";

export default function ResolutionAgent() {
  return (
    <Container className="my-6">
      <ResolutionRecommender />
    </Container>
  );
}