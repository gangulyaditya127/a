import React, { useState, useCallback } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
import { useDropzone } from "react-dropzone";
import { UploadCloud } from "lucide-react";
import { useUploadDataMutation } from "../type/resolutionApi";

export default function UploadData() {
  const { toast } = useToast();
  const [uploadData, { isLoading }] = useUploadDataMutation();
  const [application, setApplication] = useState("");
  const [account, setAccount] = useState("");
  const [historicalFile, setHistoricalFile] = useState<File | null>(null);
  const [knowledgeBaseFile, setKnowledgeBaseFile] = useState<File | null>(null);
  const [errors, setErrors] = useState<any>({});
  const [uploadComplete, setUploadComplete] = useState(false);

  const validate = () => {
    const e: any = {};
    if (!application.trim()) e.application = "Application name required";
    if (!account.trim()) e.account = "Account name required";
    if (!historicalFile && !knowledgeBaseFile) e.files = "Upload at least one file";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const createDropzone = (setFile: React.Dispatch<React.SetStateAction<File | null>>) =>
    useCallback((acceptedFiles: File[]) => {
      const file = acceptedFiles[0];
      if (file) setFile(file);
    }, [setFile]);

  const { getRootProps: getHistRootProps, getInputProps: getHistInputProps } = useDropzone({
    onDrop: createDropzone(setHistoricalFile),
    multiple: false,
  });

  const { getRootProps: getKbRootProps, getInputProps: getKbInputProps } = useDropzone({
    onDrop: createDropzone(setKnowledgeBaseFile),
    multiple: false,
  });

 const handleReset = () => {  setApplication("");  setAccount("");  setHistoricalFile(null);  setKnowledgeBaseFile(null);};
  
const handleUpload = async () => {
  if (!validate()) return;
  try {
    const fd = new FormData();
    fd.append("application", application.trim());
    fd.append("account", account.trim());
    if (historicalFile) fd.append("historical", historicalFile);
    if (knowledgeBaseFile) fd.append("knowledgeBase", knowledgeBaseFile);

    await uploadData(fd).unwrap();

    setUploadComplete(true); 
    toast({
      title: "Upload successful",
      description: "Files uploaded successfully",
    });

    setTimeout(() => {
      setUploadComplete(false);
      setHistoricalFile(null);
      setKnowledgeBaseFile(null);
    }, 2000);
  } catch (err: any) {
    toast({
      title: "Upload failed",
      description: err?.data?.message ?? err?.message ?? "Something went wrong.",
      variant: "destructive",
    });
  }
};


  const stylePatch = (
    <style>{`
      .ud-root .rr-input-black {
        background: #000 !important;
        color: #fff !important;
        border-color: #334155 !important;
      }
      .ud-root .rr-input-black::placeholder {
        color: rgba(255,255,255,0.45) !important;
      }
      .ud-root .rr-dropzone {
        background: #071022;
        color: #e6eef8;
        border-color: rgba(148,163,184,0.25);
      }
      .ud-root .rr-dropzone:hover {
        background: #0b1728;
      }
    `}</style>
  );

  return (
    <div className="w-full flex justify-center mt-6 ud-root">
      {stylePatch}
      <Card className="max-w-4xl w-full p-6">
        {/* Header with Icon */}
        <div className="flex items-center gap-3 mb-4">
          <UploadCloud className="h-6 w-6 text-[#2469BC]" />
          <h2 className="text-2xl font-semibold">Upload Data</h2>
        </div>
          <div className="grid grid-cols-1 gap-6">
          {/* Account Name */}
          <div>
            <label className="block text-sm font-medium mb-2">Account Name</label>
            <input


className="
  w-full
  rounded-lg
  border border-slate-300 dark:border-slate-700
  bg-white dark:bg-black
  text-slate-900 dark:text-white
  px-3 py-2
  outline-none
  focus:ring-2 focus:ring-[#2469BC] focus:border-[#2469BC]
"

              value={account}
              onChange={(e) => setAccount(e.target.value)}
              placeholder="Enter account name"
            />
            {errors.account && <p className="text-xs text-red-500 mt-1">{errors.account}</p>}
          </div>
          <div className="grid grid-cols-1 gap-6">
    
          {/* Application Name */}
          <div>
            <label className="block text-sm font-medium mb-2">Application Name</label>
            <input

className="
  w-full
  rounded-lg
  border border-slate-300 dark:border-slate-700
  bg-white dark:bg-black
  text-slate-900 dark:text-white
  px-3 py-2
  outline-none
  focus:ring-2 focus:ring-[#2469BC] focus:border-[#2469BC]
"
              value={application}
              onChange={(e) => setApplication(e.target.value)}
              placeholder="Enter application name"
            />
            {errors.application && <p className="text-xs text-red-500 mt-1">{errors.application}</p>}
          </div>
        </div>
          
{/* Two Upload Boxes */}
<div className="grid grid-cols-1 md:grid-cols-2 gap-6">

  {/* Historical */}
  <div>
    <label className="block text-sm font-medium mb-2 text-slate-900 dark:text-slate-200">
      Upload Historical Data
    </label>

    <div
      {...getHistRootProps()}
      className="
        group
        rounded-lg
        border-2 border-dashed
        border-slate-300 dark:border-slate-700
        bg-white dark:bg-black
        px-4 py-4
        cursor-pointer
        transition-colors
        hover:border-[#2469BC] dark:hover:border-[#2469BC]
        focus:outline-none
        focus:ring-2 focus:ring-[#2469BC] focus:ring-offset-2 focus:ring-offset-white dark:focus:ring-offset-black
      "
      // Optional: make it focusable for keyboard users
      tabIndex={0}
      role="button"
      aria-label="Upload historical data"
    >
      <input {...getHistInputProps()} />

      <div className="flex items-center gap-3">
        <UploadCloud
          className="
            h-5 w-5
            text-slate-600 dark:text-slate-300
            group-hover:text-[#2469BC]
            transition-colors
          "
        />
        <div className="text-slate-700 dark:text-slate-200">
          {historicalFile ? (
            <div className="truncate">{historicalFile.name}</div>
          ) : (
            <div className="opacity-70">Click or drop file</div>
          )}
        </div>
      </div>

      {historicalFile && (
        <button
          className="
            mt-2 text-xs underline
            text-slate-700 dark:text-slate-300
            hover:text-[#2469BC]
          "
          onClick={(e) => {
            e.stopPropagation();
            setHistoricalFile(null);
          }}
          type="button"
        >
          Remove
        </button>
      )}
    </div>
  </div>

{/* Knowledge Base */}
<div>
  <label className="block text-sm font-medium mb-2 text-slate-700 dark:text-slate-300">
    Upload Knowledge Base
  </label>
  <div 
    {...getKbRootProps()} 
    className="border-2 border-dashed border-slate-300 dark:border-slate-600 bg-slate-50 dark:bg-black hover:bg-slate-100 dark:hover:bg-slate-700 rounded-lg p-4 cursor-pointer transition-colors"
  >
    <input {...getKbInputProps()} />
    <div className="flex items-center gap-3">
      <UploadCloud className="h-5 w-5 text-slate-500 dark:text-slate-400" />
      <div className="text-slate-700 dark:text-slate-200">
        {knowledgeBaseFile ? (
          <div>{knowledgeBaseFile.name}</div>
        ) : (
          <div className="opacity-70">Click or drop file</div>
        )}
      </div>
    </div>
    {knowledgeBaseFile && (
      <button
        className="mt-2 text-xs underline text-slate-600 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200"
        onClick={(e) => {
          e.stopPropagation();
          setKnowledgeBaseFile(null);
        }}
      >
        Remove
      </button>
    )}
  </div>
</div>
          </div>

          {errors.files && <p className="text-xs text-red-500 mt-1">{errors.files}</p>}

          {/* Upload Button */}
          <div className="flex justify-end gap gap-x-4">
            <Button variant="outline" onClick={handleReset} className="min-w-[120px]">Reset</Button>
            <Button onClick={handleUpload} disabled={isLoading} className="min-w-[160px]">
              {isLoading ? "Uploading…" : "Upload Data"}
            </Button>
          </div>
        
          
          {(isLoading || uploadComplete) && (
            <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
              <div className="bg-white rounded-lg shadow-lg p-6 flex flex-col items-center gap-4">
                {!uploadComplete ? (
                  <>
                  <div className="animate-spin rounded-full h-12 w-12 border-4 border-blue-500 border-t-transparent"></div>
                    <div className="text-gray-800 text-lg font-semibold">Uploading…</div>
                    
                  </>
                ) : (
                  <>
                    
                    <div className="flex items-center justify-center h-12 w-12 rounded-full bg-green-100">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-8 w-8 text-green-600"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                        strokeWidth={3}
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                      </svg>
                    
                    </div>
                    <div className="text-green-600 text-lg font-semibold">Upload Completed</div>
                  </>
                )}
              </div>
            </div>
          )}
        </div>
      </Card>
    </div>
  );
}
