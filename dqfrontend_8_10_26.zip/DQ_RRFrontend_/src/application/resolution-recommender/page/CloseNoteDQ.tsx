import React, { useState } from "react";
import {
  useValidateClosingNoteMutation,
  useGenerateClosingNoteMutation,
  useValidateInvestigationAnalysisMutation,
  useGenerateInvestigationAnalysisMutation
} from "../type/resolutionApi";
import { Loader } from "lucide-react";

/* ---------------- Types ---------------- */

type ValidationResponse = {
  format_valid: boolean;
  content_relevant: boolean;
  classification?: string;
  explanation: string;
};

type AnyMap = Record<string, string>;

/* ---------------- Helpers ---------------- */

const isValid = (r?: ValidationResponse | null) =>
  r?.format_valid === true && r?.content_relevant === true;

const Section = ({ title, content }: { title: string; content?: string }) =>
  content ? (
    <div>
      <h4 className="text-sm font-semibold text-gray-700 mb-1">{title}</h4>
      <p className="text-sm bg-gray-50 p-3 rounded border whitespace-pre-wrap">
        {content}
      </p>
    </div>
  ) : null;

const Textarea = ({ label, value, set, mono = false }: any) => (
  <div className="mb-4">
    <label className="block font-medium mb-1">{label}</label>
    <textarea
      rows={5}
      value={value}
      onChange={(e) => set(e.target.value)}
      className={"flex field-sizing-content min-h-16 w-full rounded-lg border border-input bg-transparent px-2.5 py-2 text-base transition-colors outline-none placeholder:text-muted-foreground focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 disabled:cursor-not-allowed disabled:bg-input/50 disabled:opacity-50 aria-invalid:border-destructive aria-invalid:ring-3 aria-invalid:ring-destructive/20 md:text-sm dark:bg-input/30 dark:disabled:bg-input/80 dark:aria-invalid:border-destructive/50 dark:aria-invalid:ring-destructive/40"}
    />
  </div>
);

const ValidationCard = ({ title, result }: any) => {
  if (!result) return null;
  const ok = isValid(result);
  return (
    <div
      className={`p-4 rounded border ${
        ok ? "bg-green-100 border-green-400" : "bg-red-100 border-red-400"
      }`}
    >
      <h3 className="font-semibold mb-1">
        {ok ? "✅" : "❌"} {title}
      </h3>
      <div>format_valid: <b>{String(result.format_valid)}</b></div>
      <div>content_relevant: <b>{String(result.content_relevant)}</b></div>
      <div className="text-sm mt-1">{result.explanation}</div>
    </div>
  );
};

const Tab = ({ label, active, onClick }: any) => (
  <button
    onClick={onClick}
    className={`px-4 py-2 ${
      active
        ? "border-b-2 border-blue-600 font-semibold text-blue-600"
        : "text-gray-500 hover:text-gray-700"
    }`}
  >
    {label}
  </button>
);

/* ---------------- Component ---------------- */

const ValidationUI: React.FC = () => {
  const [alertDetails, setAlertDetails] = useState("");
  const [investigationAnalysis, setInvestigationAnalysis] = useState("");
  const [closingNote, setClosingNote] = useState("");

  const [closingValidation, setClosingValidation] =
    useState<ValidationResponse | null>(null);
  const [investigationValidation, setInvestigationValidation] =
    useState<ValidationResponse | null>(null);

  const [closingOutput, setClosingOutput] = useState<AnyMap | null>(null);
  const [investigationOutput, setInvestigationOutput] =
    useState<AnyMap | null>(null);

  const [validated, setValidated] = useState(false);
  const [showPopup, setShowPopup] = useState(false);
  const [activeTab, setActiveTab] =
    useState<"closing" | "investigation">("closing");

  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  const [validateClosing] = useValidateClosingNoteMutation();
  const [validateInvestigation] =
    useValidateInvestigationAnalysisMutation();
  const [generateClosing,responseClosing] = useGenerateClosingNoteMutation();
  const [generateInvestigation,responseInvestigation] =
    useGenerateInvestigationAnalysisMutation();

  /* ---------------- Actions ---------------- */

  const handleValidate = async () => {
    setLoading(true);
    try {
      const alertJson = JSON.parse(alertDetails);

      const [cn, ia] = await Promise.all([
        validateClosing({
          Alert_details: alertJson,
          closing_note: closingNote
        }).unwrap(),
        validateInvestigation({
          Alert_details: alertJson,
          investigation_analysis: investigationAnalysis
        }).unwrap()
      ]);

      setClosingValidation(cn);
      setInvestigationValidation(ia);
      setValidated(true);
    } catch {
      alert("Validation failed. Check JSON or API response.");
    } finally {
      setLoading(false);
    }
  };

  /**
   * ✅ MAIN CHANGE IS HERE
   * If content_relevant === false → DO NOT send user text
   */
  const handleGenerate = async () => {
    setLoading(true);
    try {
      const alertJson = JSON.parse(alertDetails);

      // ----- Closing Note -----
      if (!isValid(closingValidation)) {
        const payload: any = { Alert_details: alertJson };

        if (closingValidation?.content_relevant !== false) {
          payload.closing_note = closingNote;
        }

        const res = await generateClosing(payload).unwrap();
        setClosingOutput(res.close_note_recommendation);
      }

      // ----- Investigation -----
      if (!isValid(investigationValidation)) {
        const payload: any = { Alert_details: alertJson };

        if (investigationValidation?.content_relevant !== false) {
          payload.investigation_analysis = investigationAnalysis;
        }

        const res = await generateInvestigation(payload).unwrap();
        setInvestigationOutput(res.investigation_recommendation);
      }

      setShowPopup(true);
    } catch {
      alert("Generate failed.");
    } finally {
      setLoading(false);
    }
  };

  const copyRaw = () => {
    const data =
      activeTab === "closing" ? closingOutput : investigationOutput;
    if (!data) return;
    navigator.clipboard.writeText(JSON.stringify(data, null, 2));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const showGenerateButton =
    validated && (!isValid(closingValidation) || !isValid(investigationValidation));

  /* ---------------- UI ---------------- */

  return (
    <div className="min-h-screen  p-6 flex justify-center">
      <div className=" w-full max-w-5xl rounded-xl shadow p-8">

        <h2 className="text-2xl font-semibold mb-6">
          Validation & Recommendation
        </h2>

        <Textarea
          label="Alert Details (JSON)"
          value={alertDetails}
          set={setAlertDetails}
          mono
        />

        <Textarea
          label="Investigation Analysis"
          value={investigationAnalysis}
          set={setInvestigationAnalysis}
        />

        <Textarea
          label="Closing Note"
          value={closingNote}
          set={setClosingNote}
        />

        {!validated && (
          <button
            onClick={handleValidate}
            disabled={loading}
            
            className={`px-4 py-2 rounded text-white transition
                ${loading 
                  ? "bg-blue-400 cursor-not-allowed" 
                  : "bg-blue-600 hover:bg-blue-700"}
              `}
            >
              {loading ? "Validating..." : "Validate"}

          </button>
        )}

        {validated && (
          <div className="grid grid-cols-2 gap-4 mt-6">
            <ValidationCard title="Closing Note" result={closingValidation} />
            <ValidationCard
              title="Investigation Analysis"
              result={investigationValidation}
            />
          </div>
        )}

       {showGenerateButton && (
  <button
    onClick={handleGenerate}
    disabled={responseClosing?.isLoading || responseInvestigation?.isLoading}
    className={`mt-6 px-4 py-2 rounded text-white flex items-center gap-2
      ${
        responseClosing?.isLoading || responseInvestigation?.isLoading
          ? "bg-slate-400 cursor-not-allowed"
          : "bg-gray-800 hover:bg-gray-900"
      }
    `}
  >
    {responseClosing?.isLoading || responseInvestigation?.isLoading ? (
      <>
        Generate Recommendation
        <Loader />
      </>
    ) : (
      "Generate Recommendation"
    )}
  </button>
)}
      </div>

      {/* Popup */}
      {showPopup && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center">
          <div className="bg-white w-3/4 max-h-[80vh] p-6 rounded-lg flex flex-col">

            <div className="flex gap-4 border-b mb-4">
              <Tab
                label="Closing Note"
                active={activeTab === "closing"}
                onClick={() => setActiveTab("closing")}
              />
              <Tab
                label="Investigation Recommendation"
                active={activeTab === "investigation"}
                onClick={() => setActiveTab("investigation")}
              />
            </div>

            <div className="flex-1 overflow-auto space-y-4">
              {activeTab === "closing" &&
                closingOutput &&
                Object.entries(closingOutput).map(([k, v]) => (
                  <Section key={k} title={k} content={v} />
                ))}

              {activeTab === "investigation" &&
                investigationOutput &&
                Object.entries(investigationOutput).map(([k, v]) => (
                  <Section key={k} title={k} content={v} />
                ))}
            </div>

            <div className="flex justify-between mt-4">
              <button
                onClick={copyRaw}
                className={`px-4 py-2 text-white rounded ${
                  copied ? "bg-green-600" : "bg-blue-600"
                }`}
              >
                {copied ? "✅ Copied!" : "Copy Raw JSON"}
              </button>
              <button
                onClick={() => setShowPopup(false)}
                className="bg-gray-700 text-white px-4 py-2 rounded"
              >
                Close
              </button>
            </div>

          </div>
        </div>
      )}
    </div>
  );
};

export default ValidationUI;