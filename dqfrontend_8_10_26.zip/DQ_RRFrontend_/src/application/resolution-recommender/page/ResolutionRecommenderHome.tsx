// src/application/resolution-recommender/page/ResolutionRecommenderHome.tsx
import { useCallback, useState } from "react";
import Container from "@/components/ui/container";
import {Card} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { SingleSelectCombobox } from "@/components/ui/single-select-combobox";
import { UploadCloud, X, Sparkles } from "lucide-react";
import { useDropzone } from "react-dropzone";
import { useToast } from "@/components/ui/use-toast";
import { useGetApplicationsQuery, useGetAccountsQuery } from "@/application/resolution-recommender/type/metaApi";

export default function ResolutionRecommenderHome() {
  const [application, setApplication] = useState<string>("");
  const [account, setAccount] = useState<string>("");
  const [logFile, setLogFile] = useState<File | null>(null);
  const { toast } = useToast ? useToast() : { toast: (x: any) => console.log(x) };

  const MAX_LOG_SIZE = 5 * 1024 * 1024;

  const { data: appList = [], isLoading: appsLoading } = useGetApplicationsQuery();
  const { data: accountList = [], isLoading: accountsLoading } = useGetAccountsQuery();

  const onDropLog = useCallback(
    (acceptedFiles: File[], fileRejections: any[]) => {
      if (fileRejections?.length) {
        toast?.({ title: "Log rejected", description: fileRejections[0].errors?.[0]?.message ?? "Invalid file", variant: "destructive" });
        return;
      }
      const f = acceptedFiles[0];
      if (!f) return;
      if (!f.name.toLowerCase().endsWith(".log")) {
        toast?.({ title: "Only .log allowed", variant: "destructive" });
        return;
      }
      if (f.size > MAX_LOG_SIZE) {
        toast?.({ title: "Log too large", description: "Max 5 MB", variant: "destructive" });
        return;
      }
      setLogFile(f);
    },
    [toast]
  );

  const { getRootProps: getLogRoot, getInputProps: getLogInput } = useDropzone({
    onDrop: onDropLog,
    multiple: false,
    accept: { "text/plain": [".log"] },
    maxSize: MAX_LOG_SIZE,
  });

  const canGenerate = !!application && !!account;

  const handleGenerate = () => {
    if (!canGenerate) {
      toast?.({ title: "Missing inputs", description: "Select application and account before generating", variant: "destructive" });
      return;
    }
    toast?.({ title: "Generate started", description: `Generating for ${application} / ${account}` });
  };

  const resetAll = () => {
    setApplication("");
    setAccount("");
    setLogFile(null);
  };

  return (
    <Container className="my-6">
      <div className="flex items-center gap-3 mb-4">
        <Sparkles className="h-6 w-6 text-[#2469BC]" />
        <h1 className="text-2xl font-semibold">Smart Incident Resolution Recommender</h1>
      </div>

      <Card className="p-6 max-w-4xl">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
          <div>
            <label className="block text-sm font-medium mb-2">Application</label>
            <SingleSelectCombobox
              optionList={appsLoading ? [] : appList}
              field="application"
              setValue={(v: any) => setApplication(v)}
              value={application}
              placeholder={appsLoading ? "Loading applications..." : "Select application"}
              widthClass="w-full"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Account</label>
            <SingleSelectCombobox
              optionList={accountsLoading ? [] : accountList}
              field="account"
              setValue={(v: any) => setAccount(v)}
              value={account}
              placeholder={accountsLoading ? "Loading accounts..." : "Select account"}
              widthClass="w-full"
            />
          </div>

          <div className="flex items-center gap-3">
            <Button onClick={handleGenerate} disabled={!canGenerate}>
              Generate
            </Button>
            <Button variant="outline" onClick={resetAll}>
              Reset
            </Button>
          </div>
        </div>

        <div className="mt-6">
          <h3 className="text-lg font-medium mb-2">Optional log file</h3>
          <div {...getLogRoot()} className="group rounded-lg border-2 border-dashed p-3 flex items-center justify-between cursor-pointer">
            <input {...getLogInput()} />
            <div className="flex items-center gap-3">
              <UploadCloud className="h-5 w-5 text-slate-600" />
              <div>
                <div className="text-sm font-medium">{logFile ? logFile.name : "Drag & drop a .log file or click"}</div>
                <div className="text-xs text-muted-foreground">{logFile ? `${Math.round(logFile.size / 1024)} KB` : "Optional (useful for context)"}</div>
              </div>
            </div>
            {logFile && <button onClick={(e) => { e.stopPropagation(); setLogFile(null); }} className="px-2"><X className="h-4 w-4" /></button>}
          </div>
        </div>
      </Card>
    </Container>
  );
}