import React, { useCallback, useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
import { useDropzone } from "react-dropzone";
import { UploadCloud } from "lucide-react";
import html2pdf from "html2pdf.js";

import { useUploadDataV2Mutation } from "../type/resolutionApi";

export default function UploadFilePage() {
  const { toast } = useToast();
  const [uploadData, { isLoading }] = useUploadDataV2Mutation();

  const [file, setFile] = useState<File | null>(null);
  const [error, setError] = useState<string | null>(null);

  // ✅ store report HTML returned by backend
  const [reportHtml, setReportHtml] = useState<string | null>(null);

  const onDrop = useCallback((accepted: File[]) => {
    const selected = accepted[0];
    if (!selected) return;

    const isExcel =
      selected.name.toLowerCase().endsWith(".xls") ||
      selected.name.toLowerCase().endsWith(".xlsx");

    if (!isExcel) {
      setError("Only Excel files (.xls, .xlsx) are allowed");
      setFile(null);
      return;
    }

    setFile(selected);
    setError(null);
  }, []);

  const { getRootProps, getInputProps, isDragReject } = useDropzone({
    onDrop,
    multiple: false,
    accept: {
      "application/vnd.ms-excel": [".xls"],
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": [
        ".xlsx",
      ],
    },
  });

  const handleUpload = async () => {
    if (!file) {
      setError("File is required");
      return;
    }

    try {
      const fd = new FormData();
      fd.append("historical", file);

      const response = await uploadData(fd).unwrap();

      toast({
        title: "Upload successful",
        description: response?.message ?? "File uploaded successfully",
      });

      // ✅ set report HTML
      setReportHtml(response?.report ?? null);
      setFile(null);
    } catch (err: any) {
      toast({
        title: "Upload failed",
        description: err?.data?.message ?? "Something went wrong",
        variant: "destructive",
      });
    }
  };

  // ✅ FIXED PDF DOWNLOAD
  const downloadPdf = () => {
  const element = document.getElementById("report-container");
  if (!element) return;

  const options: any = {
    margin: [20, 15, 20, 15],
    filename: "CrowdStrike_Detection_Efficacy_Report.pdf",
    image: { type: "jpeg", quality: 0.98 },
    html2canvas: {
      scale: 2,
      useCORS: true,
      scrollY: 0,
      windowWidth: element.scrollWidth,
    },
    jsPDF: {
      unit: "mm",
      format: "a4",
      orientation: "portrait",
    },
    pagebreak: {
      mode: ["avoid-all", "css"],
      avoid: ["h1", "h2", "h3", "h4", "table", "thead", "tr"],
    },
  };

  html2pdf().set(options).from(element).save();
};


  return (
    <div className="w-full flex flex-col items-center mt-6 gap-6">
      {/* ✅ Upload Card (UNCHANGED) */}
      <Card className="max-w-xl w-full p-6">
        <div className="flex items-center gap-3 mb-6">
          <UploadCloud className="h-6 w-6 text-[#2469BC]" />
          <h2 className="text-2xl font-semibold">
            Upload Historical Incidents
          </h2>
        </div>

        <div
          {...getRootProps()}
          className={`border-2 border-dashed rounded-lg p-4 cursor-pointer transition
            ${
              isDragReject
                ? "border-red-400 bg-red-50"
                : "hover:border-[#2469BC]"
            }`}
        >
          <input {...getInputProps()} />
          <div className="flex items-center gap-3">
            <UploadCloud className="h-5 w-5 text-slate-500" />
            {file ? (
              <span className="truncate">{file.name}</span>
            ) : (
              <span className="opacity-70">
                Click or drop an Excel file (.xls, .xlsx)
              </span>
            )}
          </div>
        </div>

        {error && <p className="text-xs text-red-500 mt-2">{error}</p>}

        <div className="flex justify-end mt-6">
          <Button onClick={handleUpload} disabled={isLoading || !file}>
            {isLoading ? "Uploading…" : "Upload"}
          </Button>
        </div>
      </Card>

      {/* ✅ Local CSS – prevents header/table splitting */}
      <style>
        {`
          #report-container,
          #report-container * {
            page-break-inside: avoid;
            break-inside: avoid;
          }

          h1, h2, h3, h4 {
            page-break-after: avoid;
            break-after: avoid;
          }

          table, thead, tbody, tr, td {
            page-break-inside: avoid;
            break-inside: avoid;
          }
        `}
      </style>

      {/* ✅ Report Display + PDF Download */}
      {reportHtml && (
        <Card className="w-full max-w-5xl p-6">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-xl font-semibold">
              Generated Detection Efficacy Report
            </h3>
            <Button variant="outline" onClick={downloadPdf}>
              Download PDF
            </Button>
          </div>

          <div
            id="report-container"
            className="prose max-w-none"
            dangerouslySetInnerHTML={{ __html: reportHtml }}
          />
        </Card>
      )}
    </div>
  );
}