import React, { useMemo, useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
import { useSubmitJsonMutation } from "../type/resolutionApi";

type RecommendResponse = {
  status?: boolean;

  confidence?: string;
  summary?: string;
  likely_root_cause?: string;
  notes?: string;

  investigation_conclusion?: string;
  investigation_confidence?: number;

  investigation_steps_recommended?: string[];
  key_indicators?: string[];
  recommended_actions?: string[];

  Action?: string;
  Message?: string;
  New_Data?: Record<string, any>;

  [k: string]: any;
};

export default function JsonInputPage() {
  const { toast } = useToast();
  const [submitJson, { data, isLoading }] = useSubmitJsonMutation();

  const [jsonText, setJsonText] = useState("");
  const [localError, setLocalError] = useState<string | null>(null);

  /* ✅ Normalize API response safely */
  const response: RecommendResponse = useMemo(() => {
    if (!data) return {};
    if (typeof data === "string") {
      try {
        return JSON.parse(data);
      } catch {
        return {};
      }
    }
    return data as RecommendResponse;
  }, [data]);

  const isStatusTrue = response.status === true;
  const isStatusFalse = response.status === false;

  const confidencePct =
    typeof response.investigation_confidence === "number"
      ? Math.round(response.investigation_confidence * 100)
      : null;

  const handleSubmit = async () => {
    try {
      setLocalError(null);
      JSON.parse(jsonText);
      await submitJson(jsonText).unwrap();
      toast({ title: "Request successful" });
    } catch {
      setLocalError("Error Processing Json");
    }
  };

  return (
    <div className="w-full flex justify-center mt-6">
      <Card className="max-w-4xl w-full p-6 space-y-6">
        <h2 className="text-2xl font-semibold">Enter Alert Details</h2>

        {/* ✅ JSON INPUT */}
        <textarea
          className="
            w-full h-64 font-mono text-sm rounded-lg
            border border-slate-300 dark:border-slate-700
            bg-white dark:bg-black
            text-slate-900 dark:text-slate-100
            p-3
          "
          value={jsonText}
          onChange={(e) => setJsonText(e.target.value)}
        />

        {localError && (
          <p className="text-xs text-red-500">{localError}</p>
        )}

        <div className="flex justify-end">
          <Button onClick={handleSubmit} disabled={isLoading}>
            {isLoading ? "Submitting…" : "Submit JSON"}
          </Button>
        </div>

        {/* ---------------- RESPONSE ---------------- */}
        {Object.keys(response).length > 0 && (
          <div className="rounded-lg border p-5 space-y-6">
            <h3 className="text-lg font-semibold">Response</h3>

            {/* ✅ COMMON — ALWAYS SHOWN */}
            <section className="space-y-2">
              {/* {response.confidence && (
                <p className="text-sm">
                  <strong>Confidence:</strong> {response.confidence}
                </p>
              )} */}

              {response.summary && (
                <p className="text-sm">{response.summary}</p>
              )}

              {response.likely_root_cause && (
                <p className="text-sm">
                  <strong>Likely root cause:</strong>{" "}
                  {response.likely_root_cause}
                </p>
              )}
            </section>

            {Array.isArray(response.key_indicators) && (
              <section>
                <h4 className="font-semibold">Key indicators</h4>
                <ul className="list-disc pl-5 text-sm">
                  {response.key_indicators.map((k, i) => (
                    <li key={i}>{k}</li>
                  ))}
                </ul>
              </section>
            )}

            {Array.isArray(response.investigation_steps_recommended) && (
              <section>
                <h4 className="font-semibold">
                  Investigation steps recommended
                </h4>
                <ol className="list-decimal pl-5 text-sm">
                  {response.investigation_steps_recommended.map((s, i) => (
                    <li key={i}>{s}</li>
                  ))}
                </ol>
              </section>
            )}

            {Array.isArray(response.recommended_actions) && (
              <section>
                <h4 className="font-semibold">Recommended actions</h4>
                <ol className="list-decimal pl-5 text-sm">
                  {response.recommended_actions.map((a, i) => (
                    <li key={i}>{a}</li>
                  ))}
                </ol>
              </section>
            )}

            {response.notes && (
              <p className="text-xs text-slate-500">
                Notes: {response.notes}
              </p>
            )}

            {/* ✅ STATUS = TRUE → Investigation fields ONLY */}
            {isStatusTrue && (
              <section className="border-t pt-4 space-y-2">
                <h4 className="font-semibold">Investigation Result</h4>

                {response.investigation_conclusion && (
                  <p className="text-sm">
                    <strong>Conclusion:</strong>{" "}
                    {response.investigation_conclusion}
                  </p>
                )}

                {confidencePct !== null && (
                  <p className="text-sm">
                    <strong>Investigation confidence:</strong>{" "}
                    {confidencePct}%
                  </p>
                )}
              </section>
            )}

            {/* ❌ STATUS = FALSE → Show ONLY Action / Message / New_Data */}
            {isStatusFalse && (
              <section className="border-t pt-4 bg-amber-50 p-4 rounded space-y-2">
                <h4 className="font-semibold text-amber-800">
                  Prediction Aborted
                </h4>

                {response.Message && <p>{response.Message}</p>}

                {response.Action && (
                  <p className="font-medium">
                    Action: {response.Action}
                  </p>
                )}

                {response.New_Data && (
                  <pre className="text-xs bg-amber-100 p-2 rounded">
                    {JSON.stringify(response.New_Data, null, 2)}
                  </pre>
                )}
              </section>
            )}
          </div>
        )}
      </Card>
    </div>
  );
}