// src/application/resolution-recommender/hooks/useGetResolution.tsx
import { useCallback } from "react";
import { useGenerateResolutionMutation } from "@/application/resolution-recommender/type/resolutionApi";
import type { GenerateParams } from "@/application/resolution-recommender/type/resolutionApi";
 

export default function useGetResolution() {
  const [generateMutation, { isLoading }] = useGenerateResolutionMutation();
 
  const trigger = useCallback(
    (params: GenerateParams) => {
      return generateMutation(params);
    },
    [generateMutation]
  );
 
  return { trigger, isLoading };
}