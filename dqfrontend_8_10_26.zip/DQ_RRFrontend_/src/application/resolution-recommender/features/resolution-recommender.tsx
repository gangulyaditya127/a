import { useCallback, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Loader2, UploadCloud, X, Sparkles } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import { useDropzone } from "react-dropzone";

import { useGenerateResolutionMutation } from "../type/resolutionApi"; 
import ResolutionOutput from "./resolution-output";

export default function ResolutionRecommender() {
  const { toast } = useToast ? useToast() : { toast: (t: any) => console.log("TOAST", t) };
  
  const [generateResolution, { isLoading }] = useGenerateResolutionMutation() as any;

  // fields
  const [application, setApplication] = useState("");
  const [account, setAccount] = useState("");
  const [ticketNumber, setTicketNumber] = useState("");
  const [query, setQuery] = useState("");
  const [logFile, setLogFile] = useState<File | null>(null);
  const [errors, setErrors] = useState<{ [k: string]: string }>({});

  // modal + payload
  const [outputPayload, setOutputPayload] = useState<any | null>(null);
  const [isOutputOpen, setIsOutputOpen] = useState(false);
  
  // dropzone
  const MAX_LOG_SIZE = 5 * 1024 * 1024;
  const onDrop = useCallback(
    (acceptedFiles: File[], fileRejections: any[]) => {
      if (fileRejections?.length) {
        toast?.({
          title: "Invalid file",
          description: fileRejections[0]?.errors?.[0]?.message ?? "File rejected",
          variant: "destructive",
        });
        return;
      }
      const f = acceptedFiles[0];
      if (!f) return;
      if (!f.name.toLowerCase().endsWith(".log")) {
        toast?.({ title: "Only .log allowed", description: "Upload a .log file", variant: "destructive" });
        return;
      }
      if (f.size > MAX_LOG_SIZE) {
        toast?.({ title: "File too large", description: "Max allowed: 5 MB", variant: "destructive" });
        return;
      }
      setLogFile(f);
    },
    [toast]
  );

  const { getRootProps, getInputProps } = useDropzone({
    onDrop,
    multiple: false,
    accept: { "text/plain": [".log"] },
    maxSize: MAX_LOG_SIZE,
  });

  // validation
  const validate = () => {
    const e: any = {};
    if (!application.trim()) e.application = "Application name required";
    if (!account.trim()) e.account = "Account name required";
    if (!ticketNumber.trim()) e.ticket = "Ticket number required";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleGenerate = async () => {
    setErrors({});
    if (!validate()) return;

    try {
      const params: any = {
        application: application.trim() || undefined,
        account: account.trim() || undefined,
        ticketNumber: ticketNumber.trim() || undefined,
        query: query.trim() || undefined,
        file: logFile ?? undefined,
      };

      const raw = await (generateResolution as any)(params);
      const data = raw?.data ?? raw;

      if (raw?.error || data?.status === "error") {
        const statusCode = raw?.error?.status ?? data?.status ?? "Unknown";
        const errorMessage = raw?.error?.data?.message ?? data?.message ?? "Failed to generate resolution";

        toast?.({
          title: `Error ${statusCode}`,
          description: errorMessage,
          variant: "destructive",
        });

        return;
      }

      if (!data || typeof data !== "object") {
        toast?.({
          title: "No response",
          description: "Server returned empty/unexpected response",
          variant: "destructive",
        });
        return;
      }

      const payload = {
        ...data,
        historical: data.historical ?? data.result?.historical ?? null,
        knowledgeBase: data.knowledgeBase ?? data.result?.knowledgeBase ?? null,
        finalRecommendation: data.finalRecommendation ?? data.result?.finalRecommendation ?? data.final ?? null,
      };

      setOutputPayload(payload);
      setIsOutputOpen(true);
      toast?.({ title: "Generated", description: "Resolution recommendation received" });
    } catch (err: any) {
      const statusCode = err?.status ?? "Unknown";
      const errorMessage = err?.data?.message ?? err?.message ?? String(err);

      toast?.({
        title: `Error (${statusCode})`,
        description: `Error: (${errorMessage})`,
        variant: "destructive",
      });
    }
  };

  const handleReset = () => {
    setApplication("");
    setAccount("");
    setTicketNumber("");
    setQuery("");
    setLogFile(null);
    setErrors({});
    setOutputPayload(null);
    setIsOutputOpen(false);
  };

  return (
    <div className="w-full flex justify-center mt-6">
      <Card className="max-w-4xl w-full p-6 relative overflow-visible bg-white dark:bg-black">
        <div className="flex items-center gap-3 mb-4">
          <Sparkles className="h-6 w-6 text-[#2469BC]" />
          <h2 className="text-2xl font-semibold text-slate-900 dark:text-slate-100">
            Smart Incident Resolution Recommender
          </h2>
        </div>



{isLoading && (
  <>
    {/* Fullscreen overlay with backdrop blur */}
    <div
      className="
        fixed inset-0 z-[9998]
        bg-black/30
        backdrop-blur-sm
       
        backdrop-saturate-150
      "
    />

    {/* Centered loader panel */}
    <div
      className="
        fixed inset-0 z-[9999]
        flex items-center justify-center
        pointer-events-none
      "
      aria-hidden="true"
    >
      <div
        className="
          pointer-events-auto
          flex flex-col items-center gap-4
          rounded-lg bg-white dark:bg-black
          p-6 shadow-lg
        "
      >
        <Loader2 className="h-20 w-20 animate-spin text-slate-900 dark:text-white" />
        <div className="text-lg font-semibold text-slate-900 dark:text-white">
          Generating resolution…
        </div>
      </div>
    </div>
  </>
)}


            
        <div className="grid grid-cols-1 gap-6">
          <div>
            <label className="block text-sm font-medium mb-2 text-slate-700 dark:text-slate-300">
              Account Name
            </label>
            <input
              value={account}
              onChange={(e) => setAccount(e.target.value)}
              placeholder="Enter account name"
              className="w-full rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-black text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500 px-3 py-2 focus:ring-2 focus:ring-[#2469BC] outline-none"
            />
            {errors.application && <p className="text-xs text-red-500 mt-1">{errors.application}</p>}
          </div>
          
          <div>
            <label className="block text-sm font-medium mb-2 text-slate-700 dark:text-slate-300">
              Application Name
            </label>
            <input
              value={application}
              onChange={(e) => setApplication(e.target.value)}
              placeholder="Enter application name"
              className="w-full rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-black text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500 px-3 py-2 focus:ring-2 focus:ring-[#2469BC] outline-none"
            />
            {errors.account && <p className="text-xs text-red-500 mt-1">{errors.account}</p>}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-start">
            <div>
              <label className="block text-sm font-medium mb-2 text-slate-700 dark:text-slate-300">
                Ticket / Incident Number
              </label>
              <input
                value={ticketNumber}
                onChange={(e) => setTicketNumber(e.target.value)}
                placeholder="e.g. INC12345678"
                className="w-full rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-black text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500 px-3 py-2 focus:ring-2 focus:ring-[#2469BC] outline-none"
              />
              {errors.ticket && <p className="text-xs text-red-500 mt-1">{errors.ticket}</p>}
            </div>
            
            <div>
              <label className="block text-sm font-medium mb-2 text-slate-700 dark:text-slate-300">
                Upload .log File (optional)
              </label>
              <div
                {...getRootProps()}
                className="border-2 border-dashed border-slate-300 dark:border-slate-600 bg-slate-50 dark:bg-black hover:bg-slate-100 dark:hover:bg-slate-700 rounded-lg p-3 flex items-center justify-between cursor-pointer transition-colors"
                tabIndex={0}
              >
                <input {...getInputProps()} />
                <div className="flex items-center gap-3">
                  <UploadCloud className="h-5 w-5 text-slate-500 dark:text-slate-400" />
                  <div>
                    <div className="text-sm font-medium text-slate-700 dark:text-slate-200">
                      {logFile ? logFile.name : "Click or drop a .log file"}
                    </div>
                    <div className="text-xs text-slate-500 dark:text-slate-400">
                      {logFile ? `${Math.round(logFile.size / 1024)} KB` : "Optional"}
                    </div>
                  </div>
                </div>
                {logFile && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setLogFile(null);
                    }}
                    className="p-1 hover:bg-slate-200 dark:hover:bg-slate-600 rounded"
                  >
                    <X className="h-4 w-4 text-slate-700 dark:text-slate-300" />
                  </button>
                )}
              </div>
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium mb-2 text-slate-700 dark:text-slate-300">
              Describe Issue / Query (optional)
            </label>
            <textarea
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              rows={5}
              placeholder="Describe your issue…"
              className="w-full rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-black text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500 p-3 resize-none focus:ring-2 focus:ring-[#2469BC] outline-none"
            />
            {errors.query && <p className="text-xs text-red-500 mt-1">{errors.query}</p>}
          </div>
          
          <div className="flex gap-3 justify-end">
            <Button variant="outline" onClick={handleReset} className="min-w-[120px]">
              Reset
            </Button>
            <Button onClick={handleGenerate} disabled={isLoading} className="min-w-[160px]">
              {isLoading ? "Generating…" : "Generate Resolution"}
            </Button>
          </div>
        </div>
      </Card>
      
      {/* Output modal */}
      <ResolutionOutput
        isOpen={isOutputOpen}
        setIsOpen={setIsOutputOpen}
        ticketNumber={ticketNumber}
        historical={outputPayload?.historical ?? null}
        knowledgeBase={outputPayload?.knowledgeBase ?? null}
        incidentDescription={outputPayload?.incidentDescription ?? null}
        incidentShortDescription={outputPayload?.incidentShortDescription ?? null}
        issueCategory={outputPayload?.issueCategory ?? null}
        issueSubCategory={outputPayload?.issueSubCategory ?? null}
        final={outputPayload?.final ?? null}
      />
    </div>
  );
}