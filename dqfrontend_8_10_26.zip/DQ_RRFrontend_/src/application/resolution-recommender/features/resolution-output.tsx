// src/components/ResolutionOutputRows.tsx
import React, { useState } from "react";

type Props = {
  isOpen: boolean;
  setIsOpen?: (v: boolean) => void;
  ticketNumber?: string | null;
  incidentNumber?: string | null; 
  incident_id?: string | null; 
  incidentDescription?: string | null;
  incidentShortDescription?: string | null;
  issueCategory?: string | null;
  issueSubCategory?: string | null;
  incident?: { number?: string; description?: string; shortDescription?: string; category?: string; subCategory?: string } | null;

  historical?: string | null;
  knowledgeBase?: string | null;
  final?: string | null;
}

function toSafeString(v: any): string {
  if (v == null) return "";
  if (typeof v === "string") return v.replace(/\\n/g, "\n");
  if (Array.isArray(v)) return v.map((x) => String(x ?? "")).join("").replace(/\\n/g, "\n");
  if (typeof v === "object") {
    const keys = Object.keys(v).filter((k) => /^\d+$/.test(k));
    if (keys.length > 0) {
      keys.sort((a, b) => Number(a) - Number(b));
      return keys.map((k) => String((v as any)[k] ?? "")).join("").replace(/\\n/g, "\n");
    }
    try {
      return JSON.stringify(v);
    } catch {
      return String(v);
    }
  }
  return String(v);
}

function getSteps(value: any): string[] {
  let text = "";

  if (typeof value === "string") text = value;
  else if (Array.isArray(value)) text = value.map(v => v ?? "").join("");
  else if (typeof value === "object" && value !== null) {
    const keys = Object.keys(value).filter(k => /^\d+$/.test(k)).sort((a,b)=>+a-+b);
    text = keys.length ? keys.map(k => value[k] ?? "").join("") : String(value);
  } else {
    text = String(value ?? "");
  }

  text = text.replace(/\\n/g, "\n");
  return [text.trim()];
}

function useCopyToClipboard() {
  async function copy(text: string) {
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(text);
      } else {
        const ta = document.createElement("textarea");
        ta.value = text;
        ta.style.position = "fixed";
        ta.style.left = "-9999px";
        document.body.appendChild(ta);
        ta.focus();
        ta.select();
        try {
          document.execCommand("copy");
        } catch {}
        ta.remove();
      }
      return true;
    } catch {
      return false;
    }
  }
  return copy;
}

// icons
const IconCopy = ({ className = "w-4 h-4" }: { className?: string }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" aria-hidden>
    <rect x="9" y="9" width="9" height="11" rx="2" stroke="currentColor" strokeWidth="1.5" />
    <rect x="6" y="4" width="11" height="11" rx="2" stroke="currentColor" strokeWidth="1.5" />
  </svg>
);

const IconChevron = ({ open = false, className = "w-4 h-4" }: { open?: boolean; className?: string }) => (
  <svg className={`${className} transform ${open ? "rotate-180" : "rotate-0"} transition-transform`} viewBox="0 0 24 24" fill="none" aria-hidden>
    <path d="M6 9l6 6 6-6" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

export default function ResolutionOutputRows(props: Props) {
  const {
    isOpen,
    setIsOpen,
    ticketNumber,
    incidentNumber,
    incident_id,
    incidentDescription,
    incidentShortDescription,
    issueCategory,
    issueSubCategory,
    incident,
    historical,
    knowledgeBase,
    final,
  } = props;

  const resolvedTicket =
    toSafeString(ticketNumber) ||
    toSafeString(incidentNumber) ||
    toSafeString(incident_id) ||
    (incident && (toSafeString((incident as any).number) || toSafeString((incident as any).ticketNumber))) ||
    "";

  const resolvedShortDesc =
    toSafeString(incidentShortDescription) ||
    (incident && (toSafeString((incident as any).shortDescription) || toSafeString((incident as any).short_desc))) ||
    "";

  const resolvedDesc =
    toSafeString(incidentDescription) ||
    (incident && (toSafeString((incident as any).description) || toSafeString((incident as any).desc))) ||
    "";

  const resolvedCategory =
    toSafeString(issueCategory) ||
    (incident && (toSafeString((incident as any).category) || toSafeString((incident as any).issueCategory))) ||
    "";

  const resolvedSubCategory =
    toSafeString(issueSubCategory) ||
    (incident && (toSafeString((incident as any).subCategory) || toSafeString((incident as any).issueSubCategory))) ||
    "";

  const histText = toSafeString(historical);
  const kbText = toSafeString(knowledgeBase);
  const finalText = toSafeString(final);

  const histSteps = getSteps(histText);
  const kbSteps = getSteps(kbText);
  const finalSteps = getSteps(finalText);

  const copy = useCopyToClipboard();

  const [collapsedIncident, setCollapsedIncident] = useState(false);
  const [collapsedHist, setCollapsedHist] = useState(false);
  const [collapsedKb, setCollapsedKb] = useState(false);
  const [collapsedFinal, setCollapsedFinal] = useState(false);

  if (!isOpen) return null;

const CardWrapper = ({ title, subtitle, collapsed, onToggle, children }: {
  title: string;
  subtitle?: string;
  collapsed: boolean;
  onToggle: () => void;
  children: React.ReactNode;
}) => (
  <div className="w-full rounded-2xl border border-neutral-200 dark:border-neutral-800 bg-white dark:bg-black">
    <div className="flex items-center justify-between px-6 py-5">
      <div className="flex flex-col gap-1">
        <div className="flex items-center gap-3">
          <h3 className="text-black dark:text-white text-lg font-semibold">
            {title}
          </h3>
          {subtitle ? (
            <span className="text-sm text-neutral-500">{subtitle}</span>
          ) : null}
        </div>
      </div>

      <button
        onClick={onToggle}
        aria-expanded={!collapsed}
        className="inline-flex items-center justify-center rounded-md px-3 py-1.5 text-sm
                   text-neutral-700 dark:text-neutral-300
                   border border-neutral-300 dark:border-neutral-700
                   hover:bg-neutral-100 dark:hover:bg-neutral-900"
      >
        <IconChevron open={!collapsed} />
      </button>
    </div>

    <div
      className={`transition-all duration-200 ${
        collapsed
          ? "max-h-0 opacity-0 overflow-hidden"
          : "max-h-[48vh] opacity-100"
      }`}
    >
      <div className="px-6 py-5 border-t border-neutral-200 dark:border-neutral-800">
        {children}
      </div>
    </div>
  </div>
);

const StepsContent = ({ id, steps }: { id: string; steps: string[] }) => {
  const allText = steps.join("\n");
    return (
    <div className="space-y-4">
      <div className="flex justify-end">
        <button
          onClick={() => {
            copy(allText);
            const el = document.getElementById(`${id}-copy-feedback`);
            if (el) {
              el.textContent = "Copied";
              setTimeout(() => (el.textContent = ""), 1400);
            }
          }}
          className="inline-flex items-center gap-2 rounded-md px-3 py-1.5 text-sm
                     border border-neutral-300 dark:border-neutral-700
                     text-neutral-700 dark:text-neutral-300
                     hover:bg-neutral-100 dark:hover:bg-neutral-900"
        >
          <IconCopy />
          <span>Copy All</span>
        </button>
      </div>

      <div className="max-h-[36vh] overflow-auto space-y-4">
        {steps.length ? (
          steps.map((s, i) => (
            <div
              key={i}
              className="flex items-start justify-between gap-6
                         rounded-xl border border-neutral-200 dark:border-neutral-800
                         bg-white dark:bg-black
                         px-6 py-5"
            >
              <div className="min-w-0">
                <div className="text-lg font-medium text-black dark:text-white whitespace-pre-wrap leading-relaxed">
                  {s}
                </div>
              </div>

              <div className="flex flex-col items-end gap-1">
                <button
                  onClick={() => {
                    copy(s);
                    const el = document.getElementById(`${id}-copy-${i}`);
                    if (el) {
                      el.textContent = "Copied";
                      setTimeout(() => (el.textContent = ""), 1200);
                    }
                  }}
                  className="inline-flex items-center justify-center rounded-md px-2 py-1
                             border border-neutral-300 dark:border-neutral-700
                             text-neutral-700 dark:text-neutral-300
                             hover:bg-neutral-100 dark:hover:bg-neutral-900"
                >
                  <IconCopy />
                  <span className="sr-only">Copy step</span>
                </button>
                <div
                  id={`${id}-copy-${i}`}
                  className="text-xs text-neutral-500"
                  aria-hidden
                />
              </div>
            </div>
          ))
        ) : (
          <div className="text-sm text-neutral-500">No steps found</div>
        )}
      </div>
    </div>
  );
};

const IncidentContent = () => (
  <div className="max-h-[42vh] overflow-auto">
    <div className="grid grid-cols-1 gap-6 px-3 py-2">
      {[
        ["Ticket / Incident Number", resolvedTicket],
        ["Issue Category", resolvedCategory],
        ["Issue Sub Category", resolvedSubCategory],
        ["Short Description", resolvedShortDesc],
        ["Description", resolvedDesc],
      ].map(([label, value]) => (
        <div key={label as string} className="space-y-1">
          <div className="text-base font-medium text-neutral-500">{label}</div>
          <div className="text-base font-medium  text-black dark:text-white whitespace-pre-wrap">
            {value || "N/A"}
          </div>
        </div>
      ))}
    </div>
  </div>
);

  return (
  <div className="fixed inset-0 z-50 flex items-center justify-center p-6 bg-black/70 backdrop-blur-md">
    <div className="mx-auto w-full max-w-6xl h-[90vh] flex flex-col">
      <div className="rounded-3xl overflow-hidden border border-neutral-200 dark:border-neutral-800 bg-white dark:bg-black flex flex-col h-full">
        {/* header */}
        <div className="flex items-start justify-between px-6 py-5 border-b border-neutral-200 dark:border-neutral-800">
          <div>
            <h2 className="text-2xl font-semibold text-black dark:text-white">
              Recommended Resolution{" "}
              {resolvedTicket && (
                <span className="text-sm text-neutral-500">
                  ({resolvedTicket})
                </span>
              )}
            </h2>
            <p className="text-sm text-neutral-500 mt-1">
              Stacked cards — collapse, copy, and scroll independently.
            </p>
          </div>

          <button
            onClick={() => (setIsOpen ? setIsOpen(false) : null)}
            aria-label="Close dialog"
            className="rounded-full p-2 border border-neutral-300 dark:border-neutral-700
                       text-neutral-700 dark:text-neutral-300
                       hover:bg-neutral-100 dark:hover:bg-neutral-900"
          >
            ✕
          </button>
        </div>

        {/* content */}
        <div className="flex-1 overflow-auto px-4 py-6 space-y-10 bg-white dark:bg-black">
          <CardWrapper
            title={`Incident Details for ${resolvedTicket || ""}`}
            collapsed={collapsedIncident}
            onToggle={() => setCollapsedIncident((s) => !s)}
          >
            <IncidentContent />
          </CardWrapper>

          <CardWrapper
            title="Recommended Resolution from Historical Data"
            collapsed={collapsedHist}
            onToggle={() => setCollapsedHist((s) => !s)}
          >
            <StepsContent id="historical" steps={histSteps} />
          </CardWrapper>

          <CardWrapper
            title="Recommended Resolution from Knowledge Base"
            collapsed={collapsedKb}
            onToggle={() => setCollapsedKb((s) => !s)}
          >
            <StepsContent id="kb" steps={kbSteps} />
          </CardWrapper>

          <CardWrapper
            title="Final Recommendation"
            collapsed={collapsedFinal}
            onToggle={() => setCollapsedFinal((s) => !s)}
          >
            <StepsContent id="final" steps={finalSteps} />
          </CardWrapper>
        </div>

        {/* footer */}
        <div className="flex items-center justify-between px-6 py-4 border-t border-neutral-200 dark:border-neutral-800">
          <div className="text-sm text-neutral-500">
            Tip: Use Copy All to paste multiple steps into your ticket.
          </div>
          <button
            onClick={() => (setIsOpen ? setIsOpen(false) : null)}
            className="rounded-md px-4 py-1.5 border border-neutral-300 dark:border-neutral-700
                       text-neutral-700 dark:text-neutral-300
                       hover:bg-neutral-100 dark:hover:bg-neutral-900"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  </div>
)}