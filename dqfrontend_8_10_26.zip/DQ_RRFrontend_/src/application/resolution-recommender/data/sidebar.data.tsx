// src/application/resolution-recommender/data/sidebar.data.tsx
import { SideBarNavData } from "@/components/layout/slice/sidebar-navigation";

const SIDEBAR_DATA: SideBarNavData = {
  hasSideBar: true,
  sideBarNavList: [
    {
      group: "resolution-recommender",
      groupList: [
        {
          key: "1",
          content: "Upload JSON",
          icon: "home",
          route: "/",
        },
        {
          key: "2",
          content: "Upload Historical Incidents",
          icon: "upload",
          route: "/uploadData",
        },
      ],
    },
  ],
  bottomNavList: [],
};

export default SIDEBAR_DATA;