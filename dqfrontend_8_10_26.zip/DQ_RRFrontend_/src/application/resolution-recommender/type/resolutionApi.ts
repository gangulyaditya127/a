// src/application/resolution-recommender/type/resolutionApi.ts
import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";

const BASE_URL = import.meta.env.VITE_API_BASE_URL ?? "";

/* ---------------- Types ---------------- */

export type GenerateParams = {
  ticketNumber?: string;
  query?: string;
  file?: File | null;
  application?: string;
  account?: string;
};

export type ResolutionStep = {
  title: string;
  description?: string;
  [k: string]: any;
};

export type SourceResult = {
  source?: string;
  resolutionSteps?: ResolutionStep[] | string[];
  confidence?: number;
  meta?: Record<string, any>;
};

export type GenerateResponse = {
  status?: "ok" | "error";
  ticket?: string;
  historical?: SourceResult | null;
  knowledgeBase?: SourceResult | null;
  finalRecommendation?: SourceResult | null;
  meta?: Record<string, any>;
  [k: string]: any;
};

export type UploadResponse = {
  status: "ok" | "error";
  saved_to?: string;
  both_present?: boolean;
  missing?: string[];
  files?: {
    historical?: string[];
    knowledge_base?: string[];
  };
  message?: string;
  [k: string]: any;
};

export type UploadStatusResponse = {
  status: "ok" | "error";
  files: {
    historical: string[];
    knowledge_base: string[];
  };
  both_present: boolean;
  missing: string[];
  [k: string]: any;
};

/* ---------------- Closing Note Validation Types ---------------- */

export type ClosingNotePayload = {
  Alert_details: Record<string, any>; // JSON (required)
  closing_note: string;                // free text
};

export type ClosingNoteValidationResponse = {
  classification: string;
  format_valid: boolean;
  content_relevant: boolean;
  explanation: string;
};


/* ---------------- Investigation Analysis Types ---------------- */

export type InvestigationPayload = {
  Alert_details: Record<string, any>;
  investigation_analysis: string;
};

export type InvestigationValidationResponse = {
  classification: string;
  format_valid: boolean;
  content_relevant: boolean;
  explanation: string;
};

/* ---------------- Helpers ---------------- */

const normalizeGenerateResponse = (resp: any): GenerateResponse => {
  if (!resp || typeof resp !== "object") return resp;
  const out: any = { ...resp };

  if (!out.finalRecommendation && Array.isArray(out.recommendation_steps)) {
    out.finalRecommendation = { resolutionSteps: out.recommendation_steps };
  }
  if (!out.finalRecommendation && out.result) {
    if (Array.isArray(out.result)) out.finalRecommendation = { resolutionSteps: out.result };
    else if (typeof out.result === "string") out.finalRecommendation = { resolutionSteps: [out.result] };
  }

  const ensureSrc = (s: any) => {
    if (!s) return null;
    const copy = { ...s };
    if (Array.isArray(copy.resolutionSteps)) return copy;
    if (Array.isArray(copy.steps)) copy.resolutionSteps = copy.steps;
    else if (Array.isArray(copy.recommendation_steps)) copy.resolutionSteps = copy.recommendation_steps;
    else if (copy.resolutionSteps) copy.resolutionSteps = Array.isArray(copy.resolutionSteps) ? copy.resolutionSteps : [copy.resolutionSteps];
    else copy.resolutionSteps = [];
    return copy;
  };

  out.historical = ensureSrc(out.historical);
  out.knowledgeBase = ensureSrc(out.knowledgeBase);
  out.finalRecommendation = ensureSrc(out.finalRecommendation);

  return out as GenerateResponse;
};

/* ---------------- API ---------------- */

export const resolutionApi = createApi({
  reducerPath: "resolutionApi",
  baseQuery: fetchBaseQuery({
    baseUrl: BASE_URL,
    prepareHeaders: (headers) => headers,
  }),
  tagTypes: ["Resolution"],
  endpoints: (builder) => ({
    generateResolution: builder.mutation<GenerateResponse, GenerateParams>({
      query: (params) => {
        const fd = new FormData();
      console.log("[resolutionApi] generateResolution called — params (raw):", params);

      try {
        const safeForJson: any = {};
        for (const k of Object.keys(params || {})) {
          const v = (params as any)[k];
          if (typeof v === "object" && v instanceof File) safeForJson[k] = { __isFile: true, name: v.name };
          else safeForJson[k] = v;
        }
        fd.append("rawParams", JSON.stringify(safeForJson));
      } catch (err) {
        console.warn("[resolutionApi] could not append rawParams:", err);
}

        if (params.application && params.application.trim() !== "") fd.append("application", params.application);
        if (params.account && params.account.trim() !== "") fd.append("account", params.account);
        if (params.ticketNumber !== undefined && params.ticketNumber !== null && String(params.ticketNumber).trim() !== "")
          fd.append("ticketNumber", String(params.ticketNumber));
        if (params.query !== undefined && params.query !== null && String(params.query).trim() !== "")
          fd.append("query", String(params.query));
        if (params.file) fd.append("logFile", params.file, params.file.name);

        const fallback = {
          ticketNumber: params.ticketNumber ?? null,
          query: params.query ?? null,
          application: params.application ?? null,
          account: params.account ?? null,
        };
        fd.append("payload", JSON.stringify(fallback));

        try {
          for (const entry of (fd as any).entries()) {
            const [k, v] = entry;
            if (typeof File !== "undefined" && v instanceof File) {
              console.log("[FormData] key:", k, "-> File:", v.name, "size:", v.size);
            } else {
              console.log("[FormData] key:", k, "->", v);
            }
          }
        } catch (err) {
          console.warn("[FormData] listing failed:", err);
        }

        return {
          url: "/resolution/generate",
          method: "POST",
          body: fd,
        } as any;
      },
      transformResponse: (response: any) => normalizeGenerateResponse(response),
      invalidatesTags: (res) => (res ? [{ type: "Resolution" as const }] : []),
    }),

    uploadData: builder.mutation<UploadResponse, FormData>({
      query: (formData) => ({
        url: "/resolution/upload",
        method: "POST",
        body: formData,
      }),
      invalidatesTags: (res) => (res ? [{ type: "Resolution" as const }] : []),
    }),

    uploadStatus: builder.query<UploadStatusResponse, { account: string; application: string }>({
      query: ({ account, application }) => ({
        url: `/resolution/upload/status?account=${encodeURIComponent(account)}&application=${encodeURIComponent(application)}`,
        method: "GET",
      }),
    }),

    checkHealth: builder.query<any, void>({
      query: () => "/health",
    }),
      submitJson: builder.mutation<any, string | Record<string, any>>({
      query: (payload) => {
        const isString = typeof payload === "string";
        return {
          url: "/resolution/recommend",
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          // If a string is passed, send as-is; if object, stringify it.
          body: isString ? payload : JSON.stringify(payload),
        };
      },
      invalidatesTags: (res) => (res ? [{ type: "Resolution" as const }] : []),
    }),




    // ✅ NEW: Upload file to /resolution/uploadData
    // Accepts incoming FormData; if it has "historical" but not "file",
    // add "file" with the same value so backend receives the expected key.
    uploadDataV2: builder.mutation<UploadResponse, FormData>({
      query: (formDataIn) => {
        const fd = new FormData();
        let hasFile = false;
        let historicalBlob: File | Blob | null = null;

        for (const [k, v] of formDataIn.entries()) {
          fd.append(k, v as any);
          if (k === "file") hasFile = true;
          if (k === "historical") historicalBlob = v as any;
        }

        // Map "historical" → "file" only if "file" is not already present
        if (!hasFile && historicalBlob) {
          if (typeof File !== "undefined" && historicalBlob instanceof File) {
            fd.append("file", historicalBlob, historicalBlob.name);
          } else {
            fd.append("file", historicalBlob);
          }
        }

        return {
          url: "/resolution/uploadData",
          method: "POST",
          body: fd,
        };
      },
      invalidatesTags: (res) => (res ? [{ type: "Resolution" as const }] : []),
    }),
    validateClosingNote: builder.mutation<ClosingNoteValidationResponse,ClosingNotePayload>({
      query: (payload) => ({
        url: "/dqCheck/validateClosingNote",
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: payload,
      }),
    }),

    
    generateClosingNote: builder.mutation<any,ClosingNotePayload>({
      query: (payload) => ({
        url: "/dqCheck/recommendClosingNote",
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(payload),
      }),
    }),
    
    validateInvestigationAnalysis: builder.mutation<InvestigationValidationResponse,InvestigationPayload>({
      query: (payload) => ({
        url: "/dqCheck/validateInvestigationAnalysis",
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      }),
    }),

    generateInvestigationAnalysis: builder.mutation<any, InvestigationPayload>({
      query: (payload) => ({
        url: "/dqCheck/recommendInvestigationAnalysis",
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      }),
    }),

  }),
});

/* ---------------- Hooks export ---------------- */

export const {
  useGenerateResolutionMutation,
  useUploadDataMutation,
  useUploadStatusQuery,
  useCheckHealthQuery,

  useSubmitJsonMutation,
  useUploadDataV2Mutation,

  useValidateClosingNoteMutation,
  useGenerateClosingNoteMutation,
  
  useValidateInvestigationAnalysisMutation,
  useGenerateInvestigationAnalysisMutation,

} = resolutionApi;

export default resolutionApi;