// src/application/resolution-recommender/type/metaApi.ts
import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";

export type SelectOption = { value: string; label: string };

// API returns array of { value, label } objects for both endpoints
export const metaApi = createApi({
  reducerPath: "metaApi",
  baseQuery: fetchBaseQuery({
    baseUrl: import.meta.env.VITE_API_BASE_URL ?? "",
    prepareHeaders: (headers) => {
      return headers;
    },
  }),
  endpoints: (builder) => ({
    getApplications: builder.query<SelectOption[], void>({
      query: () => "/meta/applications",
      transformResponse: (response: any) => {
        if (!response) return [];
        if (Array.isArray(response)) {
          return response.map((r: any) =>
            typeof r === "string" ? { value: r, label: r } : { value: r.value ?? r.id ?? r.name, label: r.label ?? r.name ?? r.title ?? String(r.value ?? r.id) }
          );
        }
        return [];
      },
    }),
    getAccounts: builder.query<SelectOption[], void>({
      query: () => "/meta/accounts",
      transformResponse: (response: any) => {
        if (!response) return [];
        if (Array.isArray(response)) {
          return response.map((r: any) =>
            typeof r === "string" ? { value: r, label: r } : { value: r.value ?? r.id ?? r.name, label: r.label ?? r.name ?? r.title ?? String(r.value ?? r.id) }
          );
        }
        return [];
      },
    }),
  }),
});

export const { useGetApplicationsQuery, useGetAccountsQuery } = metaApi;
export default metaApi;