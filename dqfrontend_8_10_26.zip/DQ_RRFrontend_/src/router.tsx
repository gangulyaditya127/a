import { createHashRouter } from "react-router-dom";
import App from "./App";
import ResolutionRecommenderTemplateLayout from "./application/resolution-recommender/ResolutionRecommenderTemplateLayout";
// import UploadData from "./application/resolution-recommender/page/UploadData";
// import ResolutionAgent from "./application/resolution-recommender/page/ResolutionAgent";
import UploadHistorical from "@/application/resolution-recommender/page/UploadFilePage";
import UploadJson from "@/application/resolution-recommender/page/JsonInputPage";
import ValidationUI from "./application/resolution-recommender/page/CloseNoteDQ";
export const router = createHashRouter([
  {
    path: "/",
    element: <App />,
    children: [
      {
        path: "",
        element: <ResolutionRecommenderTemplateLayout />,
        children: [
          {
            path: "",
            element: < UploadJson/>,
          },
          // {
          //   path: "home",
          //   element: <ResolutionAgent />,
          // },
          // {
          //   path: "upload",
          //   element: <UploadData />,
          // },
          {
            path: "uploadData",
            element: < UploadHistorical/>,
        },
        {
            path: "uploadJson",
            element: < UploadJson/>,
        },
        {
            path: "DqCloseNote",
            element: < ValidationUI/>,
        },
        ],
      },
      // {
      //   path: "resolution-recommender",
      //   element: <ResolutionRecommenderTemplateLayout />,
      //   children: [
      //     {
      //       path: "home",
      //       element: < UploadJson/>,
      //     },
      //     //           {
      //     //   path: "home",
      //     //   element: <ResolutionAgent />,
      //     // },
      //     // {
      //     //   path: "upload",
      //     //   element: <UploadData />,
      //     // },
      //     {
      //       path: "uploadData",
      //       element: < UploadHistorical/>,
      //   },
      //   {
      //       path: "uploadJson",
      //       element: < UploadJson/>,
      //   },
    
      //   ],
      // },
    ],
  },
]);

