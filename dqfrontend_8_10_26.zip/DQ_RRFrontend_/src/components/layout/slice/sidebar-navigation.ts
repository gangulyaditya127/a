import { createSlice } from "@reduxjs/toolkit";
import dynamicIconImports from "lucide-react/dynamicIconImports";
export interface SideBarNavElement {
  key: string;
  content: string;
  icon: keyof typeof dynamicIconImports;
  route: string;
}
export interface SideBarNavElementGroup {
  group: string;
  groupList: SideBarNavElement[] | never[];
}
export interface SideBarNavData {
  hasSideBar: boolean;
  sideBarNavList: SideBarNavElementGroup[] | never[];
  bottomNavList: SideBarNavElement[] | never[];
}

const initialState: SideBarNavData = {
  hasSideBar: false,
  sideBarNavList: [],
  bottomNavList: [],
};

export const sidebarNavigationSlice = createSlice({
  initialState,
  name: "sidebarNavigation",
  reducers: {
    updateSideBarNavigation: (state, action) => {
      state.hasSideBar = action.payload.hasSideBar;
      state.sideBarNavList = action.payload.sideBarNavList;
      state.bottomNavList = action.payload.bottomNavList;
    },
  },
});

export const { updateSideBarNavigation } = sidebarNavigationSlice.actions;
export default sidebarNavigationSlice.reducer;
