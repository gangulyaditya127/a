
// src/components/layout/AppShell.tsx
import {TopNav} from "./TopNav";
import {SideNav} from "./SideNav";
import Container from "@/components/ui/container";

export default function AppShell({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex min-h-screen">
      <SideNav />
      <div className="flex-1 flex flex-col">
        <TopNav />
        <main className="p-4">
          {/* Optional – keep consistent page padding */}
          <Container className="my-6">{children}</Container>
        </main>
      </div>
    </div>
  );
}
