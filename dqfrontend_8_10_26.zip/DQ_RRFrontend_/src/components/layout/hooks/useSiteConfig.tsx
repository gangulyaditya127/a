import { Icon, IconNameProp } from "../../../components/ui/icon";
import { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";

/* ---------- TYPES ---------- */

type AppListItem = {
  displayText: string;
  key: number;
  openInNew: boolean;
  route: string;
  description: string;
  icon: IconNameProp;
};

type DocListItem = {
  title: string;
  href: string;
  description: string;
};

type SiteConfigItem = {
  id: number;
  group: string;
  list: {
    displayText: string;
    key: number;
    openInNew: boolean;
    route: string;
    description: string;
    icon: React.ReactNode;
  }[];
};

export const useSiteConfig = () => {
  const { t, ready, i18n } = useTranslation("next-gen-ams/AMSDropdown");
  const {
    t: appOperateT,
    ready: isAppOperateReady,
  } = useTranslation("ismart_app_operate");

  const [siteConfig, setSiteConfig] = useState<SiteConfigItem[]>([]);

  useEffect(() => {
    if (!ready || !isAppOperateReady) return;

    /* ---------- SAFE HELPERS ---------- */

    const safeArray = <T,>(value: unknown): T[] =>
      Array.isArray(value) ? (value as T[]) : [];

    /* ---------- APP OPERATE ---------- */

    const rawAppOperate = appOperateT("app", {
      returnObjects: true,
    });

    const appOperateList = safeArray<AppListItem>(rawAppOperate).map(
      (el) => ({
        ...el,
        icon: <Icon name='home' className="mr-2" />,
      })
    );

    /* ---------- DOC SECTIONS ---------- */

    const buildDocList = (
      key: string
    ): SiteConfigItem["list"] =>
      safeArray<DocListItem>(
        t(key, { returnObjects: true })
      ).map((el, i) => ({
        icon: <Icon name="circle-dot-dashed" className="mr-2" />,
        displayText: el.title,
        description: el.description,
        route: el.href,
        openInNew: false,
        key: i,
      }));

    /* ---------- FINAL CONFIG ---------- */

    setSiteConfig([
      {
        id: 1,
        group: appOperateT("title") || "Application",
        list: appOperateList,
      },
      {
        id: 2,
        group: t("onboardingComponents.title") || "Onboard",
        list: buildDocList("onboardingComponents.content"),
      },
      {
        id: 3,
        group: t("transformComponent.title") || "Transform",
        list: buildDocList("transformComponent.content"),
      },
      {
        id: 4,
        group: t("frameWorkComponent.title") || "Framework",
        list: buildDocList("frameWorkComponent.content"),
      },
      {
        id: 5,
        group: t("caseStudiesComponent.title") || "Case Studies",
        list: buildDocList("caseStudiesComponent.content"),
      },
      {
        id: 6,
        group: t("offeringComponent.title") || "Offerings",
        list: buildDocList("offeringComponent.content"),
      },
    ]);
  }, [ready, isAppOperateReady, i18n.language]);

  return siteConfig;
};