
'use client';

import { Menu } from "lucide-react";
import { Suspense, lazy, useEffect, useState } from "react";
import { Link, NavLink } from "react-router-dom";

import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { ModeToggle } from "@/components/theme/ModeToggle";
import { cn } from "@/lib/tailwind.utils";
import { useAppSelector } from "@/lib/redux/hooks";
import { TopNavItem } from "./slice/topbar-navigation";

import TATA_LOGO from "@/assets/logo/tata-logo-1.svg";
import ARE_LOGO_WHITE from "@/assets/logo/TCS Application Reliability Engineering_White.png";

import { useTranslation } from "react-i18next";

const AMSShiftDropdown = lazy(() => import("./AMSShiftDropdown"));

export function TopNav({
  hasSideBar,
  className,
}: {
  hasSideBar?: boolean;
  className?: string;
}) {
  const { t, ready, i18n } = useTranslation("common");
  const {
    navList: topNavItemList,
    isIsmartHome,
    isAMSHome,
    className: topNavStoreClass,
  } = useAppSelector((state) => state.topNav);

  const [, setAppName] = useState("");

  useEffect(() => {
    if (ready) {
      setAppName(t("ismartName"));
    }
  }, [i18n.language, ready, t]);

  return (
    <div
      className={cn(
        "sticky top-0 z-50 flex h-[57px] border-b border-border",
        isIsmartHome || isAMSHome
          ? "dark fixed left-0 right-0 bg-black/90 backdrop-blur"
          : "bg-background/98 backdrop-blur supports-[backdrop-filter]:bg-background/60",
        topNavStoreClass,
        className
      )}
    >
      <header
        className={cn(
          "flex grow items-center gap-4 px-4",
          hasSideBar ? "border-l" : ""
        )}
      >
        {!hasSideBar && (
          <div className="h-full flex items-center">
            <Link to="/" className="flex items-center font-semibold">
              <img
                src={ARE_LOGO_WHITE}
                alt="ARE logo"
                width={198.27}
                height={36}
                className="h-9"
              />
            </Link>
          </div>
        )}

        {/* Desktop nav */}
        <nav className="hidden gap-2 md:flex md:flex-row md:items-center md:text-sm">

          <div className="flex-col gap-6 text-lg font-medium md:flex md:flex-row md:items-center md:gap-5 md:text-sm lg:gap-6">
            {topNavItemList?.map(({ content, key, route }: TopNavItem) => (
              <NavLink
                to={route}
                key={key}
                className={({ isActive }) =>
                  cn(
                    "text-muted-foreground transition-colors hover:text-foreground",
                    isActive ? "text-foreground" : "text-muted-foreground"
                  )
                }
              >
                {content}
              </NavLink>
            ))}

            {(isAMSHome || isIsmartHome) && (
              <div className="ml-1">
                <Suspense fallback="">
                  <AMSShiftDropdown />
                </Suspense>
              </div>
            )}
          </div>
        </nav>

        {/* Mobile nav trigger */}
        <Sheet>
          <SheetTrigger asChild>
            <Button
              variant="outline"
              size="icon"
              className="shrink-0 md:hidden"
            >
              <Menu className="h-5 w-5" />
              <span className="sr-only">Toggle navigation menu</span>
            </Button>
          </SheetTrigger>
          <SheetContent side="left">
            <nav className="grid gap-6 text-lg font-medium">
              <NavLink
                to="/"
                className={({ isActive }) =>
                  cn(
                    "transition-colors hover:text-foreground",
                    isActive ? "text-foreground" : "text-muted-foreground"
                  )
                }
              >
                iSmart
              </NavLink>

              {topNavItemList?.map(({ content, key, route }: TopNavItem) => (
                <NavLink
                  to={route}
                  key={key}
                  className="text-muted-foreground transition-colors hover:text-foreground"
                >
                  {content}
                </NavLink>
              ))}
            </nav>
          </SheetContent>
        </Sheet>

        {/* Right actions */}
        <div className="ml-auto flex items-center gap-4 md:gap-2 lg:gap-4">
          <div className="flex gap-1">
            {/* <CommandMenu /> */}
            <ModeToggle className={isIsmartHome || isAMSHome ? "text-white" : ""} />
            {/* User menu removed intentionally */}
          </div>

          {/* Brand marks */}
          <img
            src={TATA_LOGO}
            alt="Tata"
            className="size-10 invert dark:hidden"
          />
          <img
            src={TATA_LOGO}
            alt="Tata"
            className="hidden size-10 dark:block"
          />
        </div>
      </header>
    </div>
  );
}
