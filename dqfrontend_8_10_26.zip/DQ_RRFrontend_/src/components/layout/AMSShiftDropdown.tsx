import React, { useEffect, useMemo, useState } from "react";
import { ChevronDown } from "lucide-react";
import { AnimatePresence, motion } from "framer-motion";
import { Link } from "react-router-dom";
import { cn } from "@/lib/tailwind.utils";
import { Button } from "../ui/button";
import { Icon } from "../ui/icon";
import { useTranslation } from "react-i18next";
const AMSShiftDropdown = () => {
  const { ready, t, i18n } = useTranslation('/next-gen-ams/AMSDropdown')
  const { ready: r, t: operateT } = useTranslation('ismart_app_operate')
  if (!ready || !r) return null;

  const TAB_GROUP = useMemo(() => [
    {
      tab: [
        {
          id: 1,
          title: t('offeringComponent.title'),
          Component: () => (
            <SingleColDropDownContent itemList={(t("offeringComponent.content", { returnObjects: true }) as itemListProp) ?? []} />
          ),
          hasContent: true,
        },
        {
          id: 2,
          title: t('onboardingComponents.title'),
          Component: () => (
            <SingleColDropDownContent itemList={(t("onboardingComponents.content", { returnObjects: true }) as itemListProp) ?? []} />
          ),
          hasContent: true,
        },
      ],
    },
    {
      tab: [
        {
          id: 3,
          title: operateT('title'),
          Component: IsmartDropdownContent,
          hasContent: true,
        },
        {
          id: 4,
          title: t('transformComponent.title'),
          Component: () => (
            <SingleColDropDownContent itemList={(t("transformComponent.content", { returnObjects: true }) as itemListProp) ?? []} />
          ),
          hasContent: true,
        },
        {
          id: 5,
          title: t('frameWorkComponent.title'),
          Component: () => (<SingleColDropDownContent itemList={(t("frameWorkComponent.content", { returnObjects: true }) as itemListProp) ?? []} className="md:grid-cols-2 md:w-[600px]" />),
          hasContent: true,
        },
      ],
    },
    {
      tab: [
        {
          id: 6,
          title: t('caseStudiesComponent.title'),
          Component: () => (
            <CaseStudiesContent itemList={(t("caseStudiesComponent.content", { returnObjects: true }) as itemListProp) ?? []} />
          ),
          hasContent: true,
        },
        {
          id:7,
          hasContent:false,
          title:t('help.title'),
          Component:()=>null,
          href:'/help'
        }
      ],
    },
  ], [i18n.language])


  return (
    <div className="flex items-center gap-2">
      {TAB_GROUP?.map((el, i) => <DropdownTab TABS={el.tab} id={i} key={i}/>)}
    </div>
  );
};
type DropDownTabProp = {
  id: number;
  title: string;
  Component: () => JSX.Element;
  hasContent: boolean;
  href?: string;
};
const DropdownTab = ({ TABS, id }: { TABS: DropDownTabProp[] | any; id: number }) => {
  const [selected, setSelected] = useState<any>(null);
  const [dir, setDir] = useState<any>(null);
  const handleSetSelected = (val: any) => {
    if (typeof selected === "number" && typeof val === "number") {
      setDir(selected > val ? "r" : "l");
    } else if (val === null) {
      setDir(null);
    }
    setSelected(val);
  };
  return (
    <div
      onMouseLeave={() => handleSetSelected(null)}
      className="relative flex h-fit gap-2"
    >
      {TABS.map((t: any) => {
        return (
          <Tab
            key={t.id}
            selected={selected}
            handleSetSelected={handleSetSelected}
            tab={t.id}
            hasContent={t.hasContent}
            route={t.href}
          >
            {t.title}
          </Tab>
        );
      })}
      {
        <AnimatePresence>
          {selected && (
            <Content
              dir={dir}
              selected={selected}
              TABS={TABS}
              id={id}
              handleSetSelected={handleSetSelected}
            />
          )}
        </AnimatePresence>
      }
    </div>
  );
};

const Tab = ({
  children,
  tab,
  handleSetSelected,
  selected,
  hasContent,
  route,
}: any) => {
  return (
    <button
      id={`shift-tab-${tab}`}
      onMouseEnter={() => {
        handleSetSelected(tab);
      }}
      onClick={() => {
        handleSetSelected(tab);
      }}
      className={`flex items-center gap-1 rounded-full px-3 py-1.5 text-sm transition-colors whitespace-nowrap font-normal ${selected === tab
        ? "bg-neutral-800 text-neutral-100"
        : "text-neutral-100"
        }`}
      data-has-content={hasContent}
    >
      {route ? <Link to={route}>{children}</Link> : <span>{children}</span>}
      {hasContent && (
        <ChevronDown
          className={`size-3 transition-transform ${selected === tab ? "rotate-180" : ""
            }`}
        />
      )}
    </button>
  );
};

const Content = ({ selected, dir, TABS, id, handleSetSelected }: any) => {
  return (
    <motion.div
      id={`overlay-content-${id}`}
      initial={{
        opacity: 0,
        y: 8,
      }}
      animate={{
        opacity: 1,
        y: 0,
      }}
      exit={{
        opacity: 0,
        y: 8,
      }}
      className="absolute left-0 top-[calc(100%_+_24px)] rounded-lg border border-neutral-700 bg-background p-0 backdrop-blur-2xl"
    >
      <Bridge />
      <Nub selected={selected} id={id} />

      {TABS.map((t: any) => {
        return (
          <div
            className="overflow-hidden"
            key={t.id}
            onClick={() => handleSetSelected(null)}
          >
            {selected === t.id && (
              <motion.div
                initial={{
                  opacity: 0,
                  x: dir === "l" ? 100 : dir === "r" ? -100 : 0,
                }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.25, ease: "easeInOut" }}
              >
                <t.Component />
              </motion.div>
            )}
          </div>
        );
      })}
    </motion.div>
  );
};

const Bridge = () => (
  <div className="absolute -top-[24px] left-0 right-0 h-[24px]" />
);

const Nub = ({ selected, id }: any) => {
  const [left, setLeft] = useState(0);
  const [isVisible, setIsVisible] = useState(true);
  useEffect(() => {
    moveNub();
  }, [selected]);

  const moveNub = () => {
    if (selected) {
      setIsVisible(true);
      const hoveredTab = document.getElementById(`shift-tab-${selected}`);
      const overlayContent = document.getElementById(`overlay-content-${id}`);

      if (!hoveredTab || !overlayContent) return;

      if (hoveredTab?.dataset?.hasContent == "false") {
        setIsVisible(false);
        return;
      }

      const tabRect = hoveredTab.getBoundingClientRect();
      const { left: contentLeft } = overlayContent.getBoundingClientRect();

      const tabCenter = tabRect.left + tabRect.width / 2 - contentLeft;

      setLeft(tabCenter);
    }
  };

  return (
    <motion.span
      style={{
        clipPath: "polygon(0 0, 100% 0, 50% 50%, 0% 100%)",
      }}
      animate={{ left }}
      transition={{ duration: 0.25, ease: "easeInOut" }}
      className={`absolute left-1/2 top-0 h-4 w-4 -translate-x-1/2 -translate-y-1/2 rotate-45 rounded-tl border border-neutral-600 bg-background ${isVisible ? "opacity-100" : "opacity-0"}`}
    />
  );
};

type itemListProp = { title: string; href: string; description: string }[]

type SingleColDropDownContentProps = {
  className?: string;
  itemList: { title: string; href: string; description: string }[];
};
const SingleColDropDownContent = ({
  className,
  itemList,
}: SingleColDropDownContentProps) => (
  <div
    className={cn(
      "grid w-[200px] gap-3 p-4 md:w-[300px] md:grid-cols-1",
      className,
    )}
  >
    {itemList.map((component) => (
      <ListItem
        key={component.title}
        title={component.title}
        href={component.href}
      >
        {component.description}
      </ListItem>
    ))}
  </div>
);

const IsmartDropdownContent = () => {
  const { ready, t } = useTranslation('ismart_app_operate')
  if (!ready) return null;
  const APP_LIST = t("app", { returnObjects: true }) as any
  return (
    <div className="grid w-[750px] gap-2 p-4 md:grid-cols-2">
      {APP_LIST
        .filter((_: any, i: number) => i < 4)
        .map((component: any) => (
          <ListItem
            key={component.key}
            title={component.displayText}
            href={component.route}
            openInNew={component.openInNew}
            className="flex h-full flex-col"
          >
            {component.description}
          </ListItem>
        ))}
      <Link to="/operate">
        <Button variant="link" className="mr-auto h-full gap-2">
          <span>View All</span>
          <Icon name="move-right" className="size-4"></Icon>
        </Button>
      </Link>
    </div>
  );
};

const CaseStudiesContent = ({
  className,
  itemList,
}: SingleColDropDownContentProps) => {
  return (<div
    className={cn(
      "grid w-[200px] gap-3 p-4 md:w-[300px] md:grid-cols-1", className
    )}
  >
    {itemList.filter((_, i) => i < 2).map((component) => (
      <ListItem
        key={component.title}
        title={component.title}
        href={component.href}
      >
        {component.description}
      </ListItem>
    ))}
    <Link to="/doc/case-study">
      <Button variant="link" className="mr-auto h-full gap-2">
        <span>View All</span>
        <Icon name="move-right" className="size-4"></Icon>
      </Button>
    </Link>
  </div>)
}
type ListItemProps = React.ComponentPropsWithoutRef<"a"> & {
  href: string;
  openInNew?: boolean;
};

const ListItem = React.forwardRef<React.ElementRef<"a">, ListItemProps>(
  ({ className, title, children, href, ...props }, ref) => {
    return (
      <Link
        ref={ref}
        className={cn(
          "block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground",
          className,
        )}
        target={props?.openInNew ? "_blank" : "_self"}
        to={href}
        {...props}
      >
        <div className="text-sm font-medium leading-none text-foreground">
          {title}
        </div>
        <p className="line-clamp-2 text-sm leading-snug text-muted-foreground">
          {children}
        </p>
      </Link>
    );
  },
);
ListItem.displayName = "ListItem";

export default AMSShiftDropdown;
