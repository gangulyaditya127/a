import { lazy, Suspense } from "react";
import { LucideProps } from "lucide-react";
import dynamicIconImports from "lucide-react/dynamicIconImports";

const fallback = <div style={{ background: "#ddd", width: 24, height: 24 }} />;

export interface IconProps extends Omit<LucideProps, "ref"> {
  name: keyof typeof dynamicIconImports;
}
export type IconNameProp = keyof typeof dynamicIconImports;

export const Icon = ({ name, ...props }: IconProps) => {
  // const LucideIcon = lazy(dynamicIconImports[name]);
  const LucideIcon = lazy(() => {
    return dynamicIconImports[name]();
  });

  return (
    <Suspense fallback={fallback}>
      <LucideIcon {...props} />
    </Suspense>
  );
};
