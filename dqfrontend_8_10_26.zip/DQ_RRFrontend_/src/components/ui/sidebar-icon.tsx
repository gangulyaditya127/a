import { Home, LayoutDashboard, LucideProps,Upload } from "lucide-react";
import dynamicIconImports from "lucide-react/dynamicIconImports";

// Map of icon names to direct imports
const iconMap = {
  "home": Home,
  "layout-dashboard": LayoutDashboard,
  "upload":Upload,
  // Add more icons here as you add more sidebar items
} as const;

export interface SidebarIconProps extends Omit<LucideProps, "ref"> {
  name: keyof typeof dynamicIconImports;
}

export const SidebarIcon = ({ name, ...props }: SidebarIconProps) => {
  const IconComponent = iconMap[name as keyof typeof iconMap];
  
  if (!IconComponent) {
    return <div style={{ width: 24, height: 24, background: "#ddd" }} />;
  }
  
  return <IconComponent {...props} />;
};