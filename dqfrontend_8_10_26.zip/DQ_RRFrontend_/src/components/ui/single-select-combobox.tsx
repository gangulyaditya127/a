import * as React from "react";
import { Icon } from "@/components/ui/icon";
import { cn } from "@/lib/tailwind.utils";
import { Button } from "@/components/ui/button";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
} from "@/components/ui/command";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { CommandList } from "cmdk";

export interface SelectOption {
  value: string | undefined;
  label: string | number;
}

export interface SingleSelectComboboxProps {
  optionList: SelectOption[];
  value: any;
  setValue: any;
  placeholder?: string;
  widthClass?: string;
  field?: string;
  placeholderClass?: string
}

export function SingleSelectCombobox({
  optionList,
  value,
  setValue,
  placeholder,
  widthClass,
  field,
  placeholderClass
}: SingleSelectComboboxProps) {
  const [open, setOpen] = React.useState(false);
  const buttonRef = React.useRef<HTMLButtonElement>(null)
  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          ref={buttonRef}
          variant="outline"
          role="combobox"
          aria-expanded={open}
          className={cn("w-[200px] justify-between truncate text-muted-foreground font-normal", widthClass)}
        >
          {value
            ?
            <span className="text-foreground">{optionList?.find((option: SelectOption) => option.value === value)
              ?.label}</span>
            :
            <span className={cn('capitalize', placeholderClass)}>{`${field}`}</span>

          }
          <Icon
            name="chevrons-up-down"
            className="ml-2 h-4 w-4 shrink-0 opacity-50"
          />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="p-0 z-[300]" style={
        {
          width: buttonRef.current?.clientWidth ?? '100%'
        }

      }>
        <Command className="w-full">
          <CommandInput
            placeholder={placeholder ?? "Search ..."}
            className="h-9"
          />
          <CommandList>
            <CommandEmpty>No {field} found.</CommandEmpty>
            <CommandGroup>
              {optionList?.map((option: SelectOption) => (
                <CommandItem
                  key={option.value}
                  value={option.value}
                  onSelect={(currentValue) => {
                    setValue(currentValue === value ? "" : currentValue);
                    setOpen(false);
                  }}
                >
                  {option.label}
                  <Icon
                    name="check"
                    className={cn(
                      "ml-auto h-4 w-4",
                      value === option.value ? "opacity-100" : "opacity-0",
                    )}
                  />
                </CommandItem>
              ))}
              {/* {optionList.map((framework) => (
              
            ))} */}
            </CommandGroup>
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  );
}
