import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import {
  ArrowLeft, Sparkles, Loader2, Send, Copy, Edit, Check, FileText, BookOpen, ShieldCheck,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { AdminLayout } from "@/components/admin/AdminLayout";
import { toast } from "@/hooks/use-toast";
import {
  fetchAdminOnboarding,
  generateRecommendations,
  getRecommendations,
  updateRecommendation,
  sendToUser,
  type AdminOnboarding,
  type RecommendationItem,
} from "@/lib/adminApi";

const AdminRecommendations = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();

  const [data, setData] = useState<AdminOnboarding | null>(null);
  const [loading, setLoading] = useState(true);
  const [recs, setRecs] = useState<RecommendationItem[]>([]);
  const [generating, setGenerating] = useState(false);
  const [sendDialogOpen, setSendDialogOpen] = useState(false);
  const [sending, setSending] = useState(false);
  const [editingRec, setEditingRec] = useState<RecommendationItem | null>(null);

  const loadData = () => {
    if (!id) return;
    setLoading(true);
    Promise.all([
      fetchAdminOnboarding(id),
      getRecommendations(id).catch(() => []),
    ])
      .then(([onb, r]) => {
        setData(onb);
        setRecs(r.length > 0 ? r : onb.recommendations ?? []);
      })
      .catch(() => toast({ title: "Error", description: "Failed to load data.", variant: "destructive" }))
      .finally(() => setLoading(false));
  };

  useEffect(() => { loadData(); }, [id]);

  const handleGenerate = async () => {
    if (!id) return;
    setGenerating(true);
    try {
      const generated = await generateRecommendations(id);
      setRecs(generated);
      toast({ title: "Approval Checklist Generated", description: `${generated.length} approval checklist items created.` });
    } catch {
      toast({ title: "Error", description: "Failed to generate approval checklist.", variant: "destructive" });
    } finally {
      setGenerating(false);
    }
  };

  const handleSendToUser = async () => {
    if (!id) return;
    setSending(true);
    try {
      await sendToUser(id);
      toast({ title: "Sent to User", description: "Approval checklist and cost are now visible to the user." });
      setSendDialogOpen(false);
      navigate('/admin');
    } catch {
      toast({ title: "Error", description: "Failed to send to user.", variant: "destructive" });
    } finally {
      setSending(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({ title: "Copied", description: "Copied to clipboard." });
  };

  const gpsRecs = recs.filter((r) => r.category === 'gps');
  const rfcRecs = recs.filter((r) => r.category === 'rfc');
  const approvalRecs = recs.filter((r) => r.category === 'approval');

  if (loading) {
    return (
      <AdminLayout>
        <div className="flex items-center justify-center py-20">
          <Loader2 className="h-8 w-8 animate-spin text-amber-500" />
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout>
      <div className="space-y-6 max-w-5xl">
        {/* Header */}
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="sm" onClick={() => navigate('/admin')}>
            <ArrowLeft className="h-4 w-4 mr-1" /> Back
          </Button>
          <div className="flex-1">
            <h1 className="text-xl font-semibold">{data?.name ?? 'Onboarding'}</h1>
            <p className="text-sm text-muted-foreground">Approval Checklist</p>
          </div>
          <Badge className={`text-xs ${recs.length > 0 ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700'}`}>
            {recs.length > 0 ? `${recs.length} Approval Checklist Items` : 'Pending Generation'}
          </Badge>
        </div>

        {/* Generate Section */}
        {recs.length === 0 && !generating && (
          <Card className="border-dashed border-2 border-amber-300 bg-amber-50/50 dark:bg-amber-950/10">
            <CardContent className="p-12 text-center space-y-4">
              <div className="h-16 w-16 mx-auto rounded-full bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center shadow-lg">
                <Sparkles className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-lg font-semibold">Generate Approval Checklist</h3>
              <p className="text-sm text-muted-foreground max-w-md mx-auto">
                Generate required approval checklist based on the project solution type and governance rules.
              </p>
              <Button
                onClick={handleGenerate}
                size="lg"
                className="bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white"
              >
                <Sparkles className="h-5 w-5 mr-2" /> Generate Approval Checklist
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Generating Progress */}
        {generating && (
          <Card>
            <CardContent className="p-12 text-center space-y-4">
              <Loader2 className="h-12 w-12 animate-spin text-amber-500 mx-auto" />
              <h3 className="text-lg font-semibold">Generating Approval Checklist…</h3>
              <p className="text-sm text-muted-foreground">This may take 10-30 seconds.</p>
              <div className="max-w-xs mx-auto h-2 bg-muted rounded-full overflow-hidden">
                <div className="h-full bg-gradient-to-r from-amber-500 to-orange-500 rounded-full animate-pulse" style={{ width: '70%' }} />
              </div>
            </CardContent>
          </Card>
        )}

        {/* Recommendations Tabs */}
        {recs.length > 0 && !generating && (
          <>
            <Tabs defaultValue="gps" className="space-y-4">
              <TabsList className="grid grid-cols-3">
                <TabsTrigger value="gps" className="gap-2">
                  <FileText className="h-3.5 w-3.5" /> GPS ({gpsRecs.length})
                </TabsTrigger>
                <TabsTrigger value="rfcs" className="gap-2">
                  <BookOpen className="h-3.5 w-3.5" /> RFCs ({rfcRecs.length})
                </TabsTrigger>
                <TabsTrigger value="approvals" className="gap-2">
                  <ShieldCheck className="h-3.5 w-3.5" /> Approvals ({approvalRecs.length})
                </TabsTrigger>
              </TabsList>

              {/* GPS Tab */}
              <TabsContent value="gps" className="space-y-4">
                {gpsRecs.length === 0 ? (
                  <Card><CardContent className="p-8 text-center text-muted-foreground text-sm">No GPS recommendations.</CardContent></Card>
                ) : (
                  gpsRecs.map((rec) => (
                    <Card key={rec.id} className="shadow-card">
                      <CardHeader className="pb-3">
                        <div className="flex items-start justify-between">
                          <CardTitle className="text-base">{rec.title}</CardTitle>
                          <div className="flex items-center gap-1.5">
                            <Button variant="ghost" size="sm" onClick={() => setEditingRec(rec)}>
                              <Edit className="h-3.5 w-3.5" />
                            </Button>
                            <Button variant="ghost" size="sm" onClick={() => copyToClipboard(rec.copy_text || rec.summary)}>
                              <Copy className="h-3.5 w-3.5" />
                            </Button>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent className="space-y-3">
                        <p className="text-sm text-muted-foreground">{rec.summary}</p>
                        {rec.parameters && rec.parameters.length > 0 && (
                          <Table>
                            <TableHeader>
                              <TableRow>
                                <TableHead>Parameter</TableHead>
                                <TableHead>Value</TableHead>
                              </TableRow>
                            </TableHeader>
                            <TableBody>
                              {rec.parameters.map((p) => (
                                <TableRow key={p.label}>
                                  <TableCell className="font-medium text-sm">{p.label}</TableCell>
                                  <TableCell className="text-sm">{p.value}</TableCell>
                                </TableRow>
                              ))}
                            </TableBody>
                          </Table>
                        )}
                      </CardContent>
                    </Card>
                  ))
                )}
              </TabsContent>

              {/* RFCs Tab */}
              <TabsContent value="rfcs" className="space-y-4">
                {rfcRecs.length === 0 ? (
                  <Card><CardContent className="p-8 text-center text-muted-foreground text-sm">No RFC recommendations.</CardContent></Card>
                ) : (
                  rfcRecs.map((rec) => (
                    <Card key={rec.id} className="shadow-card">
                      <CardHeader className="pb-3">
                        <div className="flex items-start justify-between">
                          <div>
                            <CardTitle className="text-base">{rec.title}</CardTitle>
                            <Badge variant="secondary" className="mt-1 text-[10px]">RFC</Badge>
                          </div>
                          <div className="flex items-center gap-1.5">
                            <Button variant="ghost" size="sm" onClick={() => setEditingRec(rec)}>
                              <Edit className="h-3.5 w-3.5" />
                            </Button>
                            <Button variant="ghost" size="sm" onClick={() => copyToClipboard(rec.copy_text || rec.summary)}>
                              <Copy className="h-3.5 w-3.5" />
                            </Button>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent className="space-y-3">
                        <p className="text-sm text-muted-foreground">{rec.summary}</p>
                        {rec.parameters && rec.parameters.length > 0 && (
                          <div className="grid grid-cols-2 gap-2">
                            {rec.parameters.map((p) => (
                              <div key={p.label} className="bg-muted/50 rounded p-2">
                                <p className="text-[10px] text-muted-foreground">{p.label}</p>
                                <p className="text-xs font-medium">{p.value}</p>
                              </div>
                            ))}
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  ))
                )}
              </TabsContent>

              {/* Approvals Tab */}
              <TabsContent value="approvals" className="space-y-4">
                {approvalRecs.length === 0 ? (
                  <Card><CardContent className="p-8 text-center text-muted-foreground text-sm">No approval requirements.</CardContent></Card>
                ) : (
                  <div className="space-y-3">
                    {approvalRecs.map((rec) => (
                      <Card key={rec.id} className="shadow-card">
                        <CardContent className="p-4 flex items-center gap-4">
                          <div className="h-10 w-10 rounded-full bg-purple-100 text-purple-600 flex items-center justify-center shrink-0">
                            <ShieldCheck className="h-5 w-5" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium">{rec.title}</p>
                            <p className="text-xs text-muted-foreground">{rec.summary}</p>
                          </div>
                          {rec.parameters?.find((p) => p.label === 'mandatory')?.value === 'true' && (
                            <Badge className="bg-red-50 text-red-700 border-red-200 text-[10px]">Mandatory</Badge>
                          )}
                          <Badge variant="outline" className="text-[10px]">
                            {rec.parameters?.find((p) => p.label === 'approver_role' || p.label === 'Approver Role')?.value ?? 'Approver'}
                          </Badge>
                          {data?.admin_status !== 'approval_checklist_sent' && (
                            <Button variant="ghost" size="sm" onClick={() => setEditingRec({ ...rec })}>
                              <Edit className="h-3.5 w-3.5" />
                            </Button>
                          )}
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </TabsContent>
            </Tabs>

            {/* Send to User Action */}
            <Separator />
            <div className="flex items-center justify-between">
              <Button variant="outline" onClick={() => navigate(`/admin/cost/${id}`)}>
                <ArrowLeft className="h-4 w-4 mr-1" /> Back to Cost
              </Button>
              <Dialog open={sendDialogOpen} onOpenChange={setSendDialogOpen}>
                <DialogTrigger asChild>
                  <Button className="bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white">
                    <Send className="h-4 w-4 mr-2" /> Send to User
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Send Approval Checklist to User</DialogTitle>
                    <DialogDescription>
                      This will make the approval checklist and cost estimation visible to the user. Are you sure you want to continue?
                    </DialogDescription>
                  </DialogHeader>
                  <DialogFooter>
                    <Button variant="outline" onClick={() => setSendDialogOpen(false)}>Cancel</Button>
                    <Button onClick={handleSendToUser} disabled={sending} className="bg-amber-600 hover:bg-amber-700 text-white">
                      {sending ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <Check className="h-4 w-4 mr-2" />}
                      Confirm & Send
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </div>
          </>
        )}

        {/* Edit Dialog */}
        {editingRec && (
          <Dialog open={!!editingRec} onOpenChange={() => setEditingRec(null)}>
            <DialogContent className="max-w-lg">
              <DialogHeader>
                <DialogTitle>Edit Approval Checklist Item</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div className="space-y-2">
                  <label htmlFor="edit-rec-title" className="text-sm font-medium">Title</label>
                  <Input
                    id="edit-rec-title"
                    value={editingRec.title}
                    onChange={(e) => setEditingRec({ ...editingRec, title: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <label htmlFor="edit-rec-summary" className="text-sm font-medium">Summary</label>
                  <Textarea
                    id="edit-rec-summary"
                    value={editingRec.summary}
                    onChange={(e) => setEditingRec({ ...editingRec, summary: e.target.value })}
                    rows={3}
                  />
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setEditingRec(null)}>Cancel</Button>
                <Button
                  onClick={async () => {
                    if (!id || !editingRec) return;
                    try {
                      const updated = await updateRecommendation(id, editingRec.id, {
                        title: editingRec.title,
                        summary: editingRec.summary,
                      });
                      setRecs((prev) => prev.map((r) => r.id === editingRec.id ? { ...r, ...updated, title: editingRec.title, summary: editingRec.summary } : r));
                      setEditingRec(null);
                      toast({ title: "Updated", description: "Approval checklist item saved." });
                    } catch {
                      toast({ title: "Error", description: "Failed to save approval item.", variant: "destructive" });
                    }
                  }}
                  className="bg-amber-600 hover:bg-amber-700 text-white"
                >
                  Save Changes
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        )}
      </div>
    </AdminLayout>
  );
};

export default AdminRecommendations;