import { useEffect, useRef, useState } from "react";
import { STEPS, type OnboardingState, type RequirementAssessment } from "@/types/onboarding";
import { StepIndicator } from "./StepIndicator";
import { TopNav } from "./TopNav";
import { StepAccountDetails } from "./steps/StepAccountDetails";
import { StepRequirementAssessment } from "./steps/StepRequirementAssessment";
import { StepCloudResources } from "./steps/StepCloudResources";
import { StepArchitectureOverview } from "./steps/StepArchitectureOverview";
import StepCostEstimation from "./steps/StepCostEstimation";
import { StepRecommendations } from "./steps/StepRecommendations";
import { StepApprovalTracker } from "./steps/StepApprovalTracker";
import { StepServiceIdCreation } from "./steps/StepServiceIdCreation";
import { InteractionTimeline, type InteractionEvent } from "./InteractionTimeline";
import { Button } from "./ui/button";
import { Textarea } from "./ui/textarea";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "./ui/sheet";
import { AlertTriangle, Check, CheckCircle2, ChevronLeft, ChevronRight, Clock, FileCheck, FileWarning, History, LayoutDashboard, Loader2, RefreshCw, Save, Send } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { createOnboarding, updateOnboarding, getOnboarding, upsertAccountDetails, upsertRequirements, upsertCloudResourceBucket, resubmitOnboarding, fetchUserEvents, submitApprovalScreenshots, type ApiInteractionEvent } from "@/lib/api";
import type { ApiOnboardingFull } from "@/lib/api";

const initialState: OnboardingState = {
  currentStep: 1,
  accountDetails: {
    projectName: "", isu: "", accountName: "", owner: "", empId: "", description: "", businessUnit: "",
  },
  requirementAssessment: {
    solutionType: "", deploymentEnvironments: [], cloudProvider: "", region: "",
  },
  cloudResources: [],
  architectureOverview: {
    uploadedDiagram: null, generatedFromBucket: false, securityViolations: [], revisedDiagram: null, analysisComplete: false, userContext: "",
  },
  recommendations: [],
  approvals: [],
  cbId: {
    cbId: "", serviceId: "", status: "not-started", disTeamAssigned: "", createdDate: null,
  },
  serviceId: {
    cbId: "", serviceId: "", status: "not-started", disTeamAssigned: "", createdDate: null,
  },
  rfcs: [],
};

interface Props {
  initialTemplate?: Partial<OnboardingState> | null;
  existing?: ApiOnboardingFull | null;
  onBackToDashboard?: () => void;
}

const TOTAL = STEPS.length;

/** Steps 1–4 are user-fillable. Steps 5+ require admin approval first. */
const USER_STEPS = 4;

// 1. Extracted State Initializer
const initializeState = (existing: ApiOnboardingFull | null | undefined, initialTemplate: Partial<OnboardingState> | null | undefined): OnboardingState => {
  if (existing) {
    const acct = existing.account_details;
    const req = existing.requirement_assessment;
    const remaining = (existing.remaining_state ?? {}) as Partial<OnboardingState>;
    return {
      ...initialState,
      currentStep: existing.current_step,
      accountDetails: acct ? {
        projectName: acct.project_name,
        isu: acct.isu,
        accountName: acct.account_name,
        owner: acct.owner,
        empId: acct.emp_id,
        description: acct.description,
        businessUnit: acct.business_unit,
      } : initialState.accountDetails,
      requirementAssessment: req ? {
        solutionType: (req.solution_type || '') as RequirementAssessment['solutionType'],
        deploymentEnvironments: req.deployment_environments ?? [],
        cloudProvider: req.cloud_provider ?? '',
        region: req.region ?? '',
      } : initialState.requirementAssessment,
      cloudResources: remaining.cloudResources ?? initialState.cloudResources,
      architectureOverview: remaining.architectureOverview ?? initialState.architectureOverview,
      recommendations: remaining.recommendations ?? initialState.recommendations,
      approvals: remaining.approvals ?? initialState.approvals,
      cbId: remaining.cbId ?? remaining.serviceId ?? initialState.cbId,
      serviceId: remaining.cbId ?? remaining.serviceId ?? initialState.serviceId,
      rfcs: remaining.rfcs ?? initialState.rfcs,
    };
  }
  return { ...initialState, ...initialTemplate, currentStep: 1 };
};

// 2. Extracted the remaining state builder
const buildRemainingState = (s: OnboardingState) => {
  const { cloudResources, architectureOverview, recommendations, approvals, cbId, serviceId, rfcs } = s;
  const resolvedCbId = cbId ?? serviceId ?? initialState.cbId;
  return { cloudResources, architectureOverview, recommendations, approvals, cbId: resolvedCbId, serviceId: resolvedCbId, rfcs };
};

// 3. Extracted to flatten step-based operations
const saveCurrentStepData = async (id: string, s: OnboardingState, targetStep?: number): Promise<void> => {
  if (!id) return;
  const stepToSave = targetStep ?? s.currentStep;
  const remainingState = buildRemainingState(s);
  const name = s.accountDetails.projectName?.trim() || 'Untitled Onboarding';
  
  const updateData = { name, current_step: stepToSave, remaining_state: remainingState };

  if (s.currentStep === 1) {
    await Promise.all([
      updateOnboarding(id, updateData),
      upsertAccountDetails(id, {
        project_name: s.accountDetails.projectName,
        isu: s.accountDetails.isu,
        account_name: s.accountDetails.accountName,
        owner: s.accountDetails.owner,
        emp_id: s.accountDetails.empId,
        description: s.accountDetails.description,
        business_unit: s.accountDetails.businessUnit,
      }),
    ]);
  } else if (s.currentStep === 2) {
    await Promise.all([
      updateOnboarding(id, updateData),
      upsertRequirements(id, {
        solution_type: s.requirementAssessment.solutionType,
        deployment_environments: s.requirementAssessment.deploymentEnvironments,
        cloud_provider: s.requirementAssessment.cloudProvider,
        region: s.requirementAssessment.region,
      }),
    ]);
  } else if (s.currentStep === 3) {
    const currentProvider = s.requirementAssessment.cloudProvider || 'AWS';
    const bucket = s.cloudResources.find(b => b.provider === currentProvider) || { provider: currentProvider, resources: [] };
    await Promise.all([
      updateOnboarding(id, updateData),
      upsertCloudResourceBucket(id, {
        provider: bucket.provider,
        resources: bucket.resources.map((r) => ({
          service: r.service,
          count: r.count,
          configDetails: r.configDetails,
        })),
      }),
    ]);
  } else {
    await updateOnboarding(id, updateData);
  }
};

interface PendingReviewViewProps {
  isSentBack: boolean;
  latestComment: any;
  adminComments: any[];
  resubmitComment: string;
  setResubmitComment: (value: string) => void;
  saving: boolean;
  handleResubmit: () => void;
  onGoBack: () => void;
  adminStatus?: string;
}

// 4. Extracted View for Pending/Changes Requested logic
const PendingReviewView = ({
  isSentBack, latestComment, adminComments, resubmitComment, setResubmitComment, saving, handleResubmit, onGoBack, adminStatus
}: PendingReviewViewProps) => (
  <div className="max-w-2xl mx-auto py-12 px-6 text-center">
    {isSentBack ? (
      <div className="space-y-6">
        <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-amber-100">
          <FileWarning className="h-10 w-10 text-amber-600" />
        </div>
        <div>
          <h2 className="text-2xl font-semibold text-foreground">Changes Requested by Admin</h2>
          <p className="text-muted-foreground mt-2">
            The admin has reviewed your submission and requested some changes. Please review all the feedback below, go back to the relevant sections, make corrections, and resubmit.
          </p>
        </div>

        {latestComment && (
          <div className="bg-card rounded-lg border shadow-card text-left overflow-hidden">
            <div className="px-5 py-4 bg-amber-50 border-b border-amber-200">
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-full bg-amber-200 flex items-center justify-center shrink-0 mt-0.5">
                  <span className="text-xs font-bold text-amber-800">{(latestComment.admin_name || 'A').charAt(0).toUpperCase()}</span>
                </div>
                <div>
                  <span className="font-semibold text-sm text-amber-900">{latestComment.admin_name}</span>
                  <span className="text-xs text-amber-600 ml-2">Overall Comment</span>
                  <p className="mt-1 text-sm text-amber-800">{latestComment.comment}</p>
                </div>
              </div>
            </div>

            {latestComment.section_comments && latestComment.section_comments.length > 0 && (
              <div className="divide-y">
                <div className="px-5 py-3 bg-red-50/50 border-b">
                  <h4 className="text-xs font-semibold text-red-700 uppercase tracking-wider flex items-center gap-1.5">
                    <AlertTriangle className="h-3.5 w-3.5" /> Section-wise Feedback
                  </h4>
                </div>
                {latestComment.section_comments.map((sc: any, index: number) => (
                  <div key={sc.section || sc.section_label || index} className="px-5 py-3 flex items-start gap-3">
                    <div className="w-6 h-6 rounded bg-red-100 flex items-center justify-center shrink-0 mt-0.5">
                      <span className="text-[10px] font-bold text-red-600">{index + 1}</span>
                    </div>
                    <div>
                      <span className="text-xs font-semibold text-red-700 uppercase tracking-wider">{sc.section_label}</span>
                      <p className="mt-0.5 text-sm text-muted-foreground">{sc.comment}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {adminComments.length > 1 && (
          <details className="text-left">
            <summary className="text-xs text-muted-foreground cursor-pointer hover:text-foreground transition-colors">
              View {adminComments.length - 1} previous review round{adminComments.length > 2 ? 's' : ''}
            </summary>
            <div className="mt-2 space-y-2">
              {adminComments.slice(0, -1).reverse().map((c: any) => (
                <div key={c.timestamp || c.comment} className="bg-muted/30 rounded-lg p-3 text-sm">
                  <span className="font-semibold text-foreground">{c.admin_name}:</span>
                  <span className="ml-1 text-muted-foreground">{c.comment}</span>
                  {c.section_comments && c.section_comments.length > 0 && (
                    <ul className="mt-1.5 space-y-0.5 ml-4">
                      {c.section_comments.map((sc: any) => (
                        <li key={sc.section || sc.section_label} className="text-xs text-muted-foreground">
                          <span className="font-medium text-foreground">{sc.section_label}:</span> {sc.comment}
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              ))}
            </div>
          </details>
        )}

        <div className="flex flex-col items-center gap-3 pt-2 w-full max-w-lg mx-auto">
          <div className="w-full">
            <label htmlFor="resubmit-comment" className="text-xs font-medium text-muted-foreground mb-1.5 block text-left">
              Add a comment for the admin (optional)
            </label>
            <Textarea
              id="resubmit-comment"
              value={resubmitComment}
              onChange={(e) => setResubmitComment(e.target.value)}
              placeholder="Describe what changes you made or any notes for the reviewer…"
              className="min-h-[80px] text-sm"
            />
          </div>
          <div className="flex items-center gap-3">
            <Button variant="outline" onClick={onGoBack}>
              <ChevronLeft className="h-4 w-4 mr-1" /> Go Back to Edit
            </Button>
            <Button onClick={handleResubmit} disabled={saving} className="gradient-primary text-primary-foreground">
              {saving ? <><Loader2 className="h-4 w-4 mr-1 animate-spin" /> Resubmitting...</> : <><RefreshCw className="h-4 w-4 mr-1" /> Resubmit for Review</>}
            </Button>
          </div>
        </div>
      </div>
    ) : (
      <div className="space-y-6">
        <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-blue-100">
          <FileCheck className="h-10 w-10 text-blue-600" />
        </div>
        <div>
          <h2 className="text-2xl font-semibold text-foreground">Pending with Admin for Review</h2>
          <p className="text-muted-foreground mt-2">
            Your onboarding has been submitted successfully and is now pending admin review and approval.
            You'll be notified once the admin completes the review.
          </p>
        </div>
        <div className="bg-card rounded-lg border shadow-card p-6 text-left space-y-4">
          <h3 className="text-sm font-semibold text-foreground">What happens next?</h3>
          <ol className="space-y-3 text-sm text-muted-foreground">
            <li className="flex items-start gap-3">
              <span className="w-6 h-6 rounded-full bg-blue-100 text-blue-700 font-semibold text-xs flex items-center justify-center shrink-0 mt-0.5">1</span>
              <span>A <strong>SuperAdmin</strong> will assign your onboarding to a <strong>DIS Admin</strong> for review.</span>
            </li>
            <li className="flex items-start gap-3">
              <span className="w-6 h-6 rounded-full bg-blue-100 text-blue-700 font-semibold text-xs flex items-center justify-center shrink-0 mt-0.5">2</span>
              <span>The admin will review all sections — account details, requirements, resources, and architecture.</span>
            </li>
            <li className="flex items-start gap-3">
              <span className="w-6 h-6 rounded-full bg-blue-100 text-blue-700 font-semibold text-xs flex items-center justify-center shrink-0 mt-0.5">3</span>
              <span>Once approved, the admin will generate <strong>cost estimation</strong> and <strong>approval checklist</strong> for you.</span>
            </li>
            <li className="flex items-start gap-3">
              <span className="w-6 h-6 rounded-full bg-blue-100 text-blue-700 font-semibold text-xs flex items-center justify-center shrink-0 mt-0.5">4</span>
              <span>You'll then be able to proceed with the remaining steps of the onboarding.</span>
            </li>
          </ol>
        </div>
        <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground">
          <Clock className="h-4 w-4 animate-pulse" />
          <span>
            Status: <strong className="text-foreground">{adminStatus?.replace(/_/g, ' ').replace(/\b\w/g, (l: string) => l.toUpperCase())}</strong>
          </span>
        </div>
      </div>
    )}
  </div>
);

// 5. Extracted renderStep logic
interface StepRendererProps {
  state: OnboardingState;
  updateState: <K extends keyof OnboardingState>(key: K, value: OnboardingState[K]) => void;
  onboardingId: string;
  adminStatus?: string;
  onAdminStatusChange?: (status: string) => void;
}

const StepRenderer = ({ state, updateState, onboardingId, adminStatus, onAdminStatusChange }: StepRendererProps) => {
  switch (state.currentStep) {
    case 1: return <StepAccountDetails data={state.accountDetails} onChange={(d) => updateState("accountDetails", d)} />;
    case 2: return <StepRequirementAssessment data={state.requirementAssessment} onChange={(d) => updateState("requirementAssessment", d)} />;
    case 3: return <StepCloudResources data={state.cloudResources} provider={state.requirementAssessment.cloudProvider} onboardingId={onboardingId} onChange={(d) => updateState("cloudResources", d)} />;
    case 4: return <StepArchitectureOverview data={state.architectureOverview} onboardingId={onboardingId} onChange={(d) => updateState("architectureOverview", d)} />;
    case 5: return <StepCostEstimation onboardingId={onboardingId} />;
    case 6: return <StepRecommendations data={state.recommendations} solutionType={state.requirementAssessment.solutionType} onboardingId={onboardingId} onChange={(d) => updateState("recommendations", d)} />;
    case 7: return <StepApprovalTracker data={state.approvals} solutionType={state.requirementAssessment.solutionType} onboardingId={onboardingId} adminStatus={adminStatus} onAdminStatusChange={onAdminStatusChange} onChange={(d) => updateState("approvals", d)} />;
    case 8: return <StepServiceIdCreation data={state.cbId || state.serviceId} onboardingId={onboardingId} onChange={(d) => {
      updateState("cbId", d);
      updateState("serviceId", d);
    }} />;
    default: return null;
  }
};

export const OnboardingWizard = ({ initialTemplate, existing, onBackToDashboard }: Props) => {
  const [state, setState] = useState<OnboardingState>(() => initializeState(existing, initialTemplate));
  const isExistingComplete = existing?.status === "Complete" || existing?.status === "complete";
  const [highestStep, setHighestStep] = useState<number>(() =>
    isExistingComplete ? STEPS.length + 1 : initializeState(existing, initialTemplate).currentStep
  );
  const [isCompleted, setIsCompleted] = useState<boolean>(isExistingComplete);

  const idRef = useRef<string>(existing?.id ?? '');
  const createdRef = useRef<string>(existing?.created_at ?? new Date().toISOString());
  const [ready, setReady] = useState(!!existing);
  const [saving, setSaving] = useState(false);
  const [resubmitComment, setResubmitComment] = useState('');
  const [events, setEvents] = useState<InteractionEvent[]>([]);

  // Admin review status
  const [adminStatus, setAdminStatus] = useState<string | undefined>(existing?.admin_status ?? 'pending_assignment');
  const adminComments = existing?.admin_comments ?? [];

  useEffect(() => {
    if (existing?.admin_status) {
      setAdminStatus(existing.admin_status);
    }
  }, [existing?.admin_status]);

  useEffect(() => {
    if (existing?.status === "Complete" || existing?.status === "complete") {
      setIsCompleted(true);
      setHighestStep(STEPS.length + 1);
    }
  }, [existing?.status]);

  const pendingAdminStatuses = ['pending_assignment', 'assigned', 'under_review', 'cost_pending', 'approved'];
  const isSentBack = adminStatus === 'sent_back';
  const costPublishedStatuses = [
    'cost_done',
    'approval_checklist_sent',
    'approvals_under_review',
    'approvals_sent_back',
    'approvals_approved',
    'cb_id_created',
    'completed',
  ];
  const isCostPublished = adminStatus != null && costPublishedStatuses.includes(adminStatus);
  const isPendingAdmin = !isCostPublished && !isSentBack;
  const checklistUnlockedStatuses = [
    'approval_checklist_sent',
    'approvals_under_review',
    'approvals_sent_back',
    'approvals_approved',
    'cb_id_created',
    'completed',
  ];
  const isAdminDone = adminStatus != null && checklistUnlockedStatuses.includes(adminStatus);
  const areApprovalsApproved = adminStatus === 'approvals_approved' || adminStatus === 'cb_id_created' || adminStatus === 'completed';

  const showPendingView = (isPendingAdmin || isSentBack) && state.currentStep > USER_STEPS && !isCostPublished;

  // Background poll to automatically reflect admin decisions when review is pending
  useEffect(() => {
    if (!idRef.current) return;
    if (adminStatus === 'approvals_under_review' || adminStatus === 'under_review' || isPendingAdmin) {
      const timer = setInterval(() => {
        getOnboarding(idRef.current)
          .then((data) => {
            if (data.admin_status && data.admin_status !== adminStatus) {
              setAdminStatus(data.admin_status);
            }
          })
          .catch(() => {});
      }, 5000);
      return () => clearInterval(timer);
    }
  }, [adminStatus, isPendingAdmin]);

  useEffect(() => {
    if (!existing) {
      const name = initialTemplate?.accountDetails?.projectName || 'Untitled Onboarding';
      createOnboarding({ name }).then((data) => {
        idRef.current = data.id;
        createdRef.current = data.created_at;
        setAdminStatus(data.admin_status || 'pending_assignment');
        setReady(true);
      });
    }
  }, [existing, initialTemplate]);

  useEffect(() => {
    if (!idRef.current) return;
    fetchUserEvents(idRef.current)
      .then((evts: ApiInteractionEvent[]) => {
        setEvents(evts.map((e) => ({
          id: e.id, ts: e.ts, actor: e.actor as InteractionEvent['actor'], actorName: e.actor_name,
          kind: e.kind as InteractionEvent['kind'],
          title: e.title, body: e.body ?? undefined, scope: e.scope ?? undefined,
        })));
      })
      .catch(() => {});
  }, [existing]);

  const saveCurrentStep = async (s: OnboardingState, targetStep?: number): Promise<void> => {
    await saveCurrentStepData(idRef.current, s, targetStep);
  };

  const updateState = <K extends keyof OnboardingState>(key: K, value: OnboardingState[K]) => {
    setState((prev) => ({ ...prev, [key]: value }));
  };

  const isAccountDetailsValid = () => {
    const { projectName, accountName, empId } = state.accountDetails;
    return Boolean(projectName?.trim() && accountName?.trim() && empId?.trim());
  };

  const goNext = async () => {
    if (state.currentStep >= TOTAL || saving) return;

    if (state.currentStep === 1 && !isAccountDetailsValid()) {
      toast({
        title: "Required Fields Missing",
        description: "Please fill in all mandatory fields (Project Name, Account Name, and Owner Employee ID) before proceeding.",
        variant: "destructive",
      });
      return;
    }

    if (state.currentStep >= USER_STEPS && !isCostPublished) {
      toast({
        title: "Admin Review Required",
        description: "The admin must approve all sections and publish the cost estimation before you can proceed to the next step.",
        variant: "destructive",
      });
      return;
    }

    if (state.currentStep === 7 && !areApprovalsApproved) {
      toast({
        title: "Approvals Pending Admin Verification",
        description: "All approval screenshots must be reviewed and approved by the DIS Admin before proceeding to CB ID creation.",
        variant: "destructive",
      });
      return;
    }

    setSaving(true);
    try {
      await saveCurrentStep(state, state.currentStep + 1);
      setState((p) => ({ ...p, currentStep: p.currentStep + 1 }));
      setHighestStep((prev) => Math.max(prev, state.currentStep + 1));
    } catch {
      toast({ title: "Save Failed", description: "Could not save progress. Please try again.", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  const handleSubmitForReview = async () => {
    if (saving) return;
    setSaving(true);
    try {
      await saveCurrentStep(state, USER_STEPS + 1);
      setAdminStatus((prev) => prev || 'pending_assignment');
      setState((p) => ({ ...p, currentStep: USER_STEPS + 1 }));
      setHighestStep((prev) => Math.max(prev, USER_STEPS + 1));
      toast({ title: "Submitted for Review", description: "Your onboarding has been submitted. An admin will review it shortly." });
    } catch {
      toast({ title: "Submit Failed", description: "Could not submit. Please try again.", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  const goPrev = () => state.currentStep > 1 && setState((p) => ({ ...p, currentStep: p.currentStep - 1 }));
  
  const goToStep = (step: number) => {
    if (state.currentStep === 1 && step > 1 && !isAccountDetailsValid()) {
      toast({
        title: "Required Fields Missing",
        description: "Please fill in all mandatory fields (Project Name, Account Name, and Owner Employee ID) before proceeding.",
        variant: "destructive",
      });
      return;
    }
    // Block navigating beyond Step 4 if cost has not been published yet
    if (step > USER_STEPS && !isCostPublished) {
      toast({
        title: "Admin Review Required",
        description: "The admin must approve all sections and publish the cost estimation before you can proceed to this step.",
        variant: "destructive",
      });
      return;
    }
    // Block navigating to steps 8+ if approvals are not approved by admin
    if (step >= 8 && !areApprovalsApproved) {
      toast({
        title: "Approvals Pending Admin Verification",
        description: "All approval screenshots must be reviewed and approved by the DIS Admin before proceeding to CB ID creation.",
        variant: "destructive",
      });
      return;
    }
    if (step <= USER_STEPS || isCostPublished) {
      setState((p) => ({ ...p, currentStep: step }));
    }
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      await saveCurrentStep(state);
      toast({ title: "Progress Saved", description: "Onboarding saved to the server." });
    } catch {
      toast({ title: "Save Failed", description: "Could not save progress.", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  const handleResubmit = async () => {
    if (!idRef.current || saving) return;
    setSaving(true);
    try {
      await saveCurrentStep(state, USER_STEPS + 1);
      await resubmitOnboarding(idRef.current, resubmitComment || undefined);
      setState((p) => ({ ...p, currentStep: USER_STEPS + 1 }));
      setResubmitComment('');
      toast({ title: "Resubmitted Successfully", description: "Your onboarding has been resubmitted for admin review." });
      window.location.reload();
    } catch {
      toast({ title: "Resubmit Failed", description: "Could not resubmit. Please try again.", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  const handleSubmitApprovals = async () => {
    if (!idRef.current || saving) return;
    setSaving(true);
    try {
      const res = await submitApprovalScreenshots(idRef.current);
      if (res.ok) {
        setAdminStatus("approvals_under_review");
        toast({
          title: "Submitted for Admin Review",
          description: "Your approval proofs have been submitted to the DIS Admin.",
        });
      }
    } catch {
      toast({
        title: "Submit Failed",
        description: "Could not submit approval proofs. Please attach screenshots for required items.",
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  };

  const handleFinish = async () => {
    if (saving) return;
    setSaving(true);
    try {
      if (idRef.current) {
        await updateOnboarding(idRef.current, { status: "Complete" });
      }
      setIsCompleted(true);
      setHighestStep(STEPS.length + 1);
      toast({
        title: "Onboarding Completed",
        description: "CB ID creation completed.",
      });
    } catch {
      setIsCompleted(true);
      setHighestStep(STEPS.length + 1);
      toast({
        title: "Onboarding Completed",
        description: "CB ID creation completed.",
      });
    } finally {
      setSaving(false);
    }
  };

  // 6. Extracted Nested Ternary Logic for bottom action buttons
  const renderActionButtons = () => {
    if (showPendingView) {
      return <div />;
    }

    if (state.currentStep === USER_STEPS) {
      return (
        <Button onClick={handleSubmitForReview} disabled={saving} className="gradient-primary text-primary-foreground">
          {saving ? <><Loader2 className="h-4 w-4 mr-1 animate-spin" /> Submitting...</> : <><Send className="h-4 w-4 mr-1" /> Submit for Review</>}
        </Button>
      );
    }

    if (state.currentStep === 7 && !areApprovalsApproved) {
      if (adminStatus === "approvals_under_review") {
        return (
          <Button disabled className="opacity-60 cursor-not-allowed bg-slate-200 text-slate-500 hover:bg-slate-200">
            Awaiting Admin Approval <ChevronRight className="h-4 w-4 ml-1" />
          </Button>
        );
      }
      return (
        <Button onClick={handleSubmitApprovals} disabled={saving} className="gradient-primary text-primary-foreground">
          {saving ? <><Loader2 className="h-4 w-4 mr-1 animate-spin" /> Submitting...</> : <><Send className="h-4 w-4 mr-1" /> Submit for Admin Review</>}
        </Button>
      );
    }

    if (state.currentStep < TOTAL) {
      return (
        <Button onClick={goNext} disabled={saving} className="gradient-primary text-primary-foreground">
          {saving ? <><Loader2 className="h-4 w-4 mr-1 animate-spin" /> Saving...</> : <>Next <ChevronRight className="h-4 w-4 ml-1" /></>}
        </Button>
      );
    }

    if (isCompleted) {
      return (
        <Button
          onClick={() => onBackToDashboard?.()}
          className="bg-success hover:bg-success/90 text-success-foreground"
        >
          <Check className="h-4 w-4 mr-1.5" /> Completed · Back to Dashboard
        </Button>
      );
    }

    return (
      <Button
        onClick={handleFinish}
        disabled={saving}
        className="gradient-accent text-accent-foreground"
      >
        {saving ? (
          <>
            <Loader2 className="h-4 w-4 mr-1 animate-spin" /> Completing...
          </>
        ) : (
          <>
            <Check className="h-4 w-4 mr-1" /> Finish
          </>
        )}
      </Button>
    );
  };

  const latestComment = adminComments.length > 0 ? adminComments[adminComments.length - 1] : null;

  if (!ready) {
    return (
      <div className="min-h-screen flex flex-col bg-background">
        <TopNav />
        <div className="flex-1 flex items-center justify-center">
          <p className="text-muted-foreground">Initializing onboarding...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <TopNav />
      <div className="flex-1 flex flex-col">
        <div className="border-b bg-card px-6 py-4 flex items-center gap-4">
          <div className="flex-1">
            <StepIndicator steps={STEPS} currentStep={state.currentStep} highestStep={highestStep} isCompleted={isCompleted} onStepClick={goToStep} />
          </div>
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="outline" size="sm" className="gap-1.5 shrink-0">
                <History className="h-3.5 w-3.5" />
                Activity
                {events.length > 0 && (
                  <span className="ml-1 h-4 min-w-[16px] px-1 rounded-full bg-primary text-primary-foreground text-[10px] font-semibold flex items-center justify-center">
                    {events.length}
                  </span>
                )}
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-[420px] p-0">
              <SheetHeader className="px-4 pt-4 pb-2">
                <SheetTitle>User ↔ Admin Activity</SheetTitle>
              </SheetHeader>
              <div className="px-4 pb-4 h-[calc(100vh-5rem)]">
                <InteractionTimeline
                  events={events}
                  compact
                  emptyHint="No activity yet. Submissions, comments and decisions will appear here."
                />
              </div>
            </SheetContent>
          </Sheet>
        </div>

        <div className="flex-1 overflow-auto">
          {showPendingView ? (
            <PendingReviewView
              isSentBack={isSentBack}
              latestComment={latestComment}
              adminComments={adminComments}
              resubmitComment={resubmitComment}
              setResubmitComment={setResubmitComment}
              saving={saving}
              handleResubmit={handleResubmit}
              onGoBack={() => setState((p) => ({ ...p, currentStep: 1 }))}
              adminStatus={adminStatus}
            />
          ) : (
            <div className="max-w-6xl mx-auto px-6 py-8">
              <div className="mb-6">
                <h2 className="text-2xl font-semibold text-foreground">{STEPS[state.currentStep - 1].title}</h2>
              </div>
              <div className="bg-card rounded-lg border shadow-card p-6">
                <StepRenderer state={state} updateState={updateState} onboardingId={idRef.current} adminStatus={adminStatus} onAdminStatusChange={setAdminStatus} />
              </div>
            </div>
          )}
        </div>
        <div className="border-t bg-card px-6 py-4">
          <div className="max-w-6xl mx-auto flex items-center justify-between">
            <div className="flex items-center gap-2">
              {onBackToDashboard && (
                <Button variant="ghost" onClick={onBackToDashboard}>
                  <LayoutDashboard className="h-4 w-4 mr-1" /> Dashboard
                </Button>
              )}
              {!showPendingView && (
                <Button variant="outline" onClick={goPrev} disabled={state.currentStep === 1 || saving}>
                  <ChevronLeft className="h-4 w-4 mr-1" /> Previous
                </Button>
              )}
            </div>
            {!showPendingView && (
              <Button variant="ghost" onClick={handleSave} disabled={saving}>
                {saving ? <Loader2 className="h-4 w-4 mr-1 animate-spin" /> : <Save className="h-4 w-4 mr-1" />} Save Draft
              </Button>
            )}
            
            {renderActionButtons()}

          </div>
        </div>
      </div>
    </div>
  );
};