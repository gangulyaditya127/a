import { useState, useEffect, useRef } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Upload,
  CheckCircle2,
  Clock,
  RotateCcw,
  FileImage,
  AlertCircle,
  Loader2,
  Scan,
  RefreshCw,
  FileText,
  Eye,
  Trash2,
  Plus,
  Send,
  Info,
} from "lucide-react";
import { toast } from "@/hooks/use-toast";
import {
  fetchUserRecommendations,
  uploadApprovalScreenshot,
  getApprovalScreenshots,
  deleteApprovalScreenshot,
  submitApprovalScreenshots,
  type ApiApprovalScreenshotMeta,
  type ApiRecommendation,
} from "@/lib/api";
import type { ApprovalItem } from "@/types/onboarding";

interface Props {
  data: ApprovalItem[];
  solutionType: string;
  onChange: (data: ApprovalItem[]) => void;
  onboardingId?: string;
  adminStatus?: string;
  onAdminStatusChange?: (status: string) => void;
}

interface ApprovalCard {
  rec_id: string;
  title: string;
  summary: string;
  approverRole: string;
  isGenAI: boolean;
  isFallback?: boolean;
  screenshotGroup?: ApiApprovalScreenshotMeta;
  uploading?: boolean;
}

const DEFAULT_APPROVAL_ITEMS: { title: string; summary: string; approverRole: string; isGenAI: boolean }[] = [
  {
    title: "ISM Approval",
    summary: "Information Security Manager must approve the cloud infrastructure provisioning to ensure compliance with security policies.",
    approverRole: "ISM",
    isGenAI: false,
  },
  {
    title: "Delivery Head Sign-off",
    summary: "Delivery Head must sign off on the infrastructure costs and resource allocation.",
    approverRole: "Delivery Head",
    isGenAI: false,
  },
  {
    title: "Architecture Review Board",
    summary: "Architecture review board must validate the proposed cloud architecture design.",
    approverRole: "Architecture Board",
    isGenAI: false,
  },
  {
    title: "Data Privacy Approval",
    summary: "Data Privacy Officer must approve data handling procedures, especially for GenAI solutions processing sensitive data.",
    approverRole: "Data Privacy",
    isGenAI: true,
  },
  {
    title: "Legal Approval",
    summary: "Legal team must review and approve any GenAI solutions for compliance with regulatory requirements.",
    approverRole: "Legal",
    isGenAI: true,
  },
  {
    title: "DIS CloudOps Final Approval",
    summary: "DIS CloudOps team provides final approval before cloud account provisioning begins.",
    approverRole: "DIS CloudOps",
    isGenAI: false,
  },
];
const BASE_URL = `${import.meta.env.VITE_API_BASE_URL}`;

// ── Status Badge ──────────────────────────────────────────────────────────────
const UploadStatusBadge = ({ status }: { status: ApiApprovalScreenshotMeta | undefined }) => {
  if (!status) {
    return (
      <Badge className="bg-amber-50 text-amber-700 border-amber-200/80 gap-1.5 font-normal rounded-full px-3 py-0.5">
        <Clock className="h-3 w-3 text-amber-600" /> Pending Upload
      </Badge>
    );
  }
  if (status.admin_status === "approved") {
    return (
      <Badge className="bg-emerald-50 text-emerald-700 border-emerald-200/80 gap-1.5 font-medium rounded-full px-3 py-0.5">
        <CheckCircle2 className="h-3 w-3 text-emerald-600" /> Verified
      </Badge>
    );
  }
  if (status.admin_status === "sent_back") {
    return (
      <Badge className="bg-red-50 text-red-700 border-red-200/80 gap-1.5 font-normal rounded-full px-3 py-0.5">
        <RotateCcw className="h-3 w-3 text-red-600" /> Needs Re-upload
      </Badge>
    );
  }
  return (
    <Badge className="bg-blue-50 text-blue-700 border-blue-200/80 gap-1.5 font-normal rounded-full px-3 py-0.5">
      <FileImage className="h-3 w-3 text-blue-600" /> Under Review
    </Badge>
  );
};

// ── Upload Drop Zone ──────────────────────────────────────────────────────────
const UploadZone = ({
  onFiles,
  uploading,
  compact = false,
}: {
  onFiles: (files: File[]) => void;
  uploading: boolean;
  compact?: boolean;
}) => {
  const inputRef = useRef<HTMLInputElement>(null);
  const [dragOver, setDragOver] = useState(false);

  const handleFiles = (files: FileList | null) => {
    if (!files || files.length === 0) return;
    const allowed = ["image/png", "image/jpeg", "image/jpg", "application/pdf", "image/gif", "image/webp"];
    const validFiles: File[] = [];

    for (let i = 0; i < files.length; i++) {
      const f = files[i];
      if (!allowed.includes(f.type)) {
        toast({ title: "Invalid file type", description: `${f.name}: Supports PNG, JPG, JPEG, PDF.`, variant: "destructive" });
        continue;
      }
      if (f.size > 10 * 1024 * 1024) {
        toast({ title: "File too large", description: `${f.name}: Maximum file size is 10 MB.`, variant: "destructive" });
        continue;
      }
      validFiles.push(f);
    }

    if (validFiles.length > 0) {
      onFiles(validFiles);
    }
  };

  if (compact) {
    return (
      <div
        className={`border border-dashed rounded-lg px-4 py-3 flex items-center gap-3 cursor-pointer transition-colors
          ${dragOver ? "border-blue-500 bg-blue-50/50" : "border-slate-200 bg-slate-50/50 hover:border-blue-400 hover:bg-blue-50/30"}`}
        onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
        onDragLeave={() => setDragOver(false)}
        onDrop={(e) => { e.preventDefault(); setDragOver(false); handleFiles(e.dataTransfer.files); }}
        onClick={() => !uploading && inputRef.current?.click()}
        role="button"
        tabIndex={0}
      >
        <input ref={inputRef} type="file" multiple className="hidden" accept=".png,.jpg,.jpeg,.pdf,.gif,.webp" onChange={(e) => handleFiles(e.target.files)} />
        {uploading
          ? <Loader2 className="h-4 w-4 text-blue-600 animate-spin shrink-0" />
          : <Plus className="h-4 w-4 text-blue-600 shrink-0" />
        }
        <span className="text-xs font-medium text-slate-700">{uploading ? "Uploading…" : "Add Another Screenshot"}</span>
      </div>
    );
  }

  return (
    <div
      className={`border-2 border-dashed rounded-lg p-6 flex flex-col items-center justify-center gap-1.5 cursor-pointer transition-colors
        ${dragOver ? "border-blue-500 bg-blue-50/50" : "border-slate-200 bg-slate-50/50 hover:border-blue-400 hover:bg-blue-50/30"}`}
      onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
      onDragLeave={() => setDragOver(false)}
      onDrop={(e) => { e.preventDefault(); setDragOver(false); handleFiles(e.dataTransfer.files); }}
      onClick={() => !uploading && inputRef.current?.click()}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => e.key === "Enter" && !uploading && inputRef.current?.click()}
    >
      <input ref={inputRef} type="file" multiple className="hidden" accept=".png,.jpg,.jpeg,.pdf,.gif,.webp" onChange={(e) => handleFiles(e.target.files)} />
      {uploading ? (
        <Loader2 className="h-9 w-9 text-blue-600 animate-spin" />
      ) : (
        <div className="h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center mb-1">
          <Upload className="h-5 w-5 text-blue-600" />
        </div>
      )}
      <p className="text-sm font-semibold text-slate-800">
        {uploading ? "Uploading proof…" : "Click to Upload Screenshot(s)"}
      </p>
      <p className="text-xs text-slate-400">Supports multiple PNG, JPG, JPEG, PDF up to 10MB each</p>
    </div>
  );
};

// ── Main Component ────────────────────────────────────────────────────────────
export const StepApprovalTracker = ({
  data,
  solutionType,
  onChange,
  onboardingId,
  adminStatus,
  onAdminStatusChange,
}: Props) => {
  const [cards, setCards] = useState<ApprovalCard[]>([]);
  const [loading, setLoading] = useState(true);
  const [scanning, setScanning] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [viewMode, setViewMode] = useState<"auto" | "manage">("auto");
  const [isFallback, setIsFallback] = useState(false);

  const verifiedCount = cards.filter((c) => c.screenshotGroup?.admin_status === "approved").length;
  const attachedCount = cards.filter((c) => c.screenshotGroup && c.screenshotGroup.images.length > 0).length;
  const totalCount = cards.length;
  const isAllApproved =
    adminStatus === "approvals_approved" ||
    adminStatus === "cb_id_created" ||
    adminStatus === "completed" ||
    (totalCount > 0 && verifiedCount === totalCount);

  const loadData = () => {
    if (!onboardingId) {
      const isGenAI = solutionType === "generative-ai" || solutionType === "genai";
      const fallback: ApprovalCard[] = DEFAULT_APPROVAL_ITEMS
        .filter((d) => !d.isGenAI || isGenAI)
        .map((d, i) => ({
          rec_id: `fallback-rec-${i}`,
          title: `[Fallback] ${d.title}`,
          summary: d.summary,
          approverRole: d.approverRole,
          isGenAI: d.isGenAI,
          isFallback: true,
        }));
      setCards(fallback);
      setIsFallback(true);
      setLoading(false);
      return;
    }

    setLoading(true);
    Promise.all([
      fetchUserRecommendations(onboardingId).catch(() => ({ status: "pending", recommendations: [] })),
      getApprovalScreenshots(onboardingId).catch(() => []),
    ])
      .then(([recsRes, screenshotGroups]) => {
        let approvalRecs: ApiRecommendation[] =
          recsRes.status === "published"
            ? recsRes.recommendations.filter((r) => r.category === "approval")
            : [];

        if (approvalRecs.length === 0) {
          const isGenAI = solutionType === "generative-ai" || solutionType === "genai";
          const fallback: ApprovalCard[] = DEFAULT_APPROVAL_ITEMS
            .filter((d) => !d.isGenAI || isGenAI)
            .map((d, i) => ({
              rec_id: `default-appr-${i}`,
              title: `[Fallback] ${d.title}`,
              summary: d.summary,
              approverRole: d.approverRole,
              isGenAI: d.isGenAI,
              isFallback: true,
            }));
          setCards(fallback);
          setIsFallback(true);
          setLoading(false);
          return;
        }

        setIsFallback(false);

        const screenshotMap = new Map<string, ApiApprovalScreenshotMeta>(
          (screenshotGroups as ApiApprovalScreenshotMeta[]).map((g) => [g.rec_id, g]),
        );

        const built: ApprovalCard[] = approvalRecs.map((rec) => ({
          rec_id: rec.id,
          title: rec.title.replace(/^Approval\s*[–-]\s*/i, ""),
          summary: rec.summary,
          approverRole: rec.parameters?.find((p) => p.label === "Approver Role")?.value ?? "Approver",
          isGenAI:
            (rec.parameters?.find((p) => p.label === "Applies To")?.value ?? "")
              .toLowerCase()
              .includes("generative") ||
            rec.title.toLowerCase().includes("genai") ||
            rec.title.toLowerCase().includes("llm"),
          screenshotGroup: screenshotMap.get(rec.id),
        }));

        setCards(built);

        if (data.length === 0 && built.length > 0) {
          onChange(
            built.map((c) => ({
              id: c.rec_id,
              type: "other" as const,
              title: c.title,
              status: c.screenshotGroup?.admin_status === "approved" ? "approved" : "pending",
              approver: c.approverRole,
              submittedDate: new Date().toISOString().split("T")[0],
              lastReminder: null,
              reminderCount: 0,
              comments: [],
              screenshotFilename: c.screenshotGroup?.images[0]?.filename,
              adminStatus: (c.screenshotGroup?.admin_status as ApprovalItem["adminStatus"]) ?? "pending_upload",
              adminComment: c.screenshotGroup?.admin_comment ?? undefined,
            })),
          );
        }
      })
      .catch(() => {
        const isGenAI = solutionType === "generative-ai" || solutionType === "genai";
        const fallback: ApprovalCard[] = DEFAULT_APPROVAL_ITEMS
          .filter((d) => !d.isGenAI || isGenAI)
          .map((d, i) => ({
            rec_id: `default-appr-${i}`,
            title: `[Fallback] ${d.title}`,
            summary: d.summary,
            approverRole: d.approverRole,
            isGenAI: d.isGenAI,
            isFallback: true,
          }));
        setCards(fallback);
        setIsFallback(true);
        setLoading(false);
      })
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    loadData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [onboardingId]);

  const handleUpload = async (recId: string, files: File[]) => {
    if (!onboardingId) {
      const mockImages = files.map((file, idx) => ({
        id: `mock-${Date.now()}-${idx}`,
        filename: file.name,
        content_type: file.type,
        admin_status: "uploaded" as const,
        admin_comment: null,
        uploaded_at: new Date().toISOString(),
      }));
      setCards((prev) =>
        prev.map((c) => {
          if (c.rec_id !== recId) return c;
          const currentGroup = c.screenshotGroup ?? {
            rec_id: recId,
            admin_status: "uploaded",
            admin_comment: null,
            images: [],
          };
          return {
            ...c,
            screenshotGroup: {
              ...currentGroup,
              admin_status: "uploaded",
              images: [...currentGroup.images, ...mockImages],
            },
          };
        }),
      );
      toast({ title: "Uploaded", description: `${files.length} screenshot(s) attached for review.` });
      return;
    }

    setCards((prev) =>
      prev.map((c) => (c.rec_id === recId ? { ...c, uploading: true } : c)),
    );

    try {
      for (const file of files) {
        await uploadApprovalScreenshot(onboardingId, recId, file);
      }
      // Refresh to get the updated grouped data
      const updatedGroups = await getApprovalScreenshots(onboardingId);
      const updatedMap = new Map<string, ApiApprovalScreenshotMeta>(
        updatedGroups.map((g) => [g.rec_id, g]),
      );
      const updatedCards = cards.map((c) => ({
        ...c,
        uploading: false,
        screenshotGroup: updatedMap.get(c.rec_id) ?? c.screenshotGroup,
      }));
      setCards(updatedCards);

      toast({
        title: "Uploaded Successfully",
        description: `${files.length} screenshot${files.length > 1 ? "s" : ""} saved.`,
      });
    } catch {
      setCards((prev) =>
        prev.map((c) => (c.rec_id === recId ? { ...c, uploading: false } : c)),
      );
      toast({ title: "Upload failed", description: "Could not upload the file(s). Please try again.", variant: "destructive" });
    }
  };

  const handleDelete = async (recId: string, screenshotId: string) => {
    if (!onboardingId) return;
    try {
      await deleteApprovalScreenshot(onboardingId, screenshotId);
      const updatedGroups = await getApprovalScreenshots(onboardingId);
      const updatedMap = new Map<string, ApiApprovalScreenshotMeta>(
        updatedGroups.map((g) => [g.rec_id, g]),
      );
      setCards((prev) =>
        prev.map((c) => ({
          ...c,
          screenshotGroup: updatedMap.get(c.rec_id) ?? (c.rec_id === recId ? undefined : c.screenshotGroup),
        })),
      );
      toast({ title: "Removed", description: "Screenshot removed." });
    } catch {
      toast({ title: "Remove failed", description: "Could not remove the screenshot.", variant: "destructive" });
    }
  };

  // Submit all proofs explicitly for DIS Admin review
  const handleSubmitForReview = async () => {
    if (!onboardingId) {
      toast({ title: "Preview Mode", description: "Submit is available in live onboarding." });
      return;
    }
    if (isAllApproved) {
      toast({
        title: "Already Approved",
        description: "All approval documents have already been approved by the admin.",
      });
      return;
    }
    const unattached = cards.filter((c) => !c.screenshotGroup || c.screenshotGroup.images.length === 0);
    if (unattached.length > 0) {
      toast({
        title: "Missing Approvals",
        description: `Please attach screenshot proof for all approval items before submitting (${unattached.length} remaining: ${unattached.map((u) => u.title).join(", ")}).`,
        variant: "destructive",
      });
      return;
    }

    setSubmitting(true);
    try {
      const res = await submitApprovalScreenshots(onboardingId);
      if (res.ok) {
        setViewMode("auto");
        onAdminStatusChange?.(res.admin_status || "approvals_under_review");
        loadData();
        toast({
          title: "Submitted for Admin Review",
          description: "Your approval proofs have been submitted to the DIS Admin for review.",
        });
      }
    } catch {
      toast({
        title: "Submission Failed",
        description: "Could not submit for review. Please try again.",
        variant: "destructive",
      });
    } finally {
      setSubmitting(false);
    }
  };

  // Run Automated Scan (simulation)
  const handleRunScan = () => {
    if (attachedCount === 0) {
      toast({
        title: "No Screenshots Attached",
        description: "Please upload approval screenshots first.",
        variant: "destructive",
      });
      return;
    }
    setScanning(true);
    setTimeout(() => {
      setScanning(false);
      toast({
        title: "Automated Scan Complete",
        description: `Verified OCR readability and compliance metadata for ${attachedCount} document(s). Ready for DIS Admin review.`,
      });
    }, 1200);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20 gap-3">
        <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
        <p className="text-sm text-muted-foreground">Loading approval items…</p>
      </div>
    );
  }

  // ── Under Review Waiting State ────────────────────────────────────────────
  const isUnderReview = adminStatus === "approvals_under_review";

  if (isUnderReview && viewMode === "auto") {
    return (
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between gap-4">
          <div className="flex items-center gap-2.5">
            {/* <div className="h-8 w-8 rounded-lg bg-amber-50 border border-amber-200 flex items-center justify-center">
              <FileText className="h-5 w-5 text-amber-600" />
            </div> */}
            {/* <h2 className="text-2xl font-bold tracking-tight text-slate-900">Upload Approvals</h2>
            <span className="bg-slate-100 text-slate-700 text-xs px-2.5 py-0.5 rounded-full font-medium border border-slate-200">
              {verifiedCount} / {totalCount} Verified
            </span> */}
            {isFallback && (
              <span className="bg-amber-100 text-amber-800 text-xs px-2.5 py-0.5 rounded-full font-medium border border-amber-300 flex items-center gap-1">
                <Info className="h-3 w-3 text-amber-600" /> Fallback Template Active
              </span>
            )}
          </div>
          {/* <Button
            variant="outline"
            size="sm"
            onClick={() => setViewMode("manage")}
            className="text-xs gap-1.5"
          >
            <FileImage className="h-3.5 w-3.5 text-blue-600" />
            Manage / Upload More Proofs
          </Button> */}
        </div>

        {/* Waiting card — styled exactly like StepCostEstimation */}
        <div className="rounded-lg border-2 border-dashed border-muted-foreground/25 bg-muted/30 p-10 text-center space-y-4">
          <div className="h-14 w-14 rounded-full bg-blue-50 flex items-center justify-center mx-auto">
            <Clock className="h-7 w-7 text-blue-600" />
          </div>
          <h3 className="text-base font-semibold text-foreground">
            Approvals Under Review
          </h3>
          <p className="text-sm text-muted-foreground max-w-md mx-auto">
            Your uploaded approval proofs have been submitted to the DIS Admin for verification.
            You will be able to proceed to the next step once all screenshots have been approved.
          </p>
          <div className="flex items-center justify-center gap-3 pt-2 flex-wrap">
            <Badge className="bg-blue-500/10 text-blue-600 border-blue-500/20">
              <Clock className="h-3 w-3 mr-1" /> Awaiting admin action
            </Badge>
            <Badge className="bg-slate-100 text-slate-700 border-slate-200">
              {attachedCount} of {totalCount} approvals submitted
            </Badge>
          </div>
        </div>

        {/* Read-only view of uploaded files */}
        {cards.some((c) => c.screenshotGroup && c.screenshotGroup.images.length > 0) && (
          <div className="space-y-3">
            <h3 className="text-sm font-semibold text-slate-700">Submitted Approvals</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {cards.map((card) => {
                if (!card.screenshotGroup || card.screenshotGroup.images.length === 0) return null;
                return (
                  <div key={card.rec_id} className="rounded-xl border bg-white p-4 space-y-2 shadow-sm">
                    <div className="flex items-center justify-between gap-2">
                      <p className="text-sm font-semibold text-slate-900 truncate">{card.title}</p>
                      <UploadStatusBadge status={card.screenshotGroup} />
                    </div>
                    {card.screenshotGroup.images.map((img) => (
                      <div key={img.id} className="flex items-center gap-2 text-xs bg-slate-50 border border-slate-200/80 rounded-lg px-3 py-2">
                        <FileImage className="h-3.5 w-3.5 text-blue-600 shrink-0" />
                        <span className="font-medium text-slate-800 truncate flex-1">{img.filename}</span>
                        <a
                          href={`${BASE_URL}/api/approval-screenshots/${onboardingId}/image/${img.id}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-blue-600 hover:text-blue-800 hover:underline flex items-center gap-1 shrink-0"
                        >
                          <Eye className="h-3.5 w-3.5" /> View
                        </a>
                      </div>
                    ))}
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* If in manage mode while under review, show return banner */}
      {isUnderReview && viewMode === "manage" && (
        <div className="rounded-lg bg-blue-50 border border-blue-200 p-3 flex items-center justify-between text-xs text-blue-800">
          <span className="flex items-center gap-1.5 font-medium">
            <Clock className="h-3.5 w-3.5 text-blue-600 shrink-0" />
            Proofs submitted and awaiting review. You can attach additional screenshots or return to the review status.
          </span>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setViewMode("auto")}
            className="text-xs text-blue-700 hover:text-blue-900 shrink-0"
          >
            Back to Review Status
          </Button>
        </div>
      )}

      {/* ── Top Header ── */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        {/* <div className="space-y-1">
          <div className="flex items-center gap-2.5 flex-wrap">
            <div className="h-8 w-8 rounded-lg bg-amber-50 border border-amber-200 flex items-center justify-center">
              <FileText className="h-5 w-5 text-amber-600" />
            </div>
            <h2 className="text-2xl font-bold tracking-tight text-slate-900">Upload Approvals</h2>
            <span className="bg-slate-100 text-slate-700 text-xs px-2.5 py-0.5 rounded-full font-medium border border-slate-200">
              {verifiedCount} / {totalCount} Verified
            </span>
            {isFallback && (
              <span className="bg-amber-100 text-amber-800 text-xs px-2.5 py-0.5 rounded-full font-medium border border-amber-300 flex items-center gap-1">
                <Info className="h-3 w-3 text-amber-600" /> Fallback Template Active
              </span>
            )}
          </div>
          <p className="text-xs text-muted-foreground max-w-2xl">
            Attach screenshot proofs for mandatory approvals before completing the onboarding process.
          </p>
        </div> */}
      </div>

      {/* ── Fallback Template Notice Banner ── */}
      {isFallback && (
        <div className="rounded-lg bg-amber-50/90 border border-amber-200 p-4 flex items-start gap-3 text-xs text-amber-900 shadow-sm">
          <Info className="h-4 w-4 text-amber-600 shrink-0 mt-0.5" />
          <div className="space-y-0.5">
            <div className="font-semibold text-amber-950 flex items-center gap-2 text-sm">
              <span>Showing Fallback Approval Template</span>
              <span className="bg-amber-200/80 text-amber-900 text-[10px] px-1.5 py-0.2 rounded font-medium">
                Fallback
              </span>
            </div>
            <p className="text-amber-800 leading-relaxed">
              Official approval checklist from admin review is not currently published for this onboarding. Displaying standard fallback approval rules ({cards.length} items) for reference.
            </p>
          </div>
        </div>
      )}

      {/* ── 2-Column Grid of Approval Cards ── */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {cards.map((card) => {
          const group = card.screenshotGroup;
          const sentBackComment =
            group?.admin_status === "sent_back" ? group.admin_comment : null;
          const isApproved = group?.admin_status === "approved";

          return (
            <div
              key={card.rec_id}
              className={`rounded-xl border bg-white p-5 space-y-4 shadow-sm transition-all
                ${isApproved ? "border-emerald-200 bg-emerald-50/20" : "border-slate-200"}
                ${group?.admin_status === "sent_back" ? "border-red-200 bg-red-50/20" : ""}
                ${card.isFallback ? "border-amber-200/80 bg-amber-50/10" : ""}
              `}
            >
              {/* Top: Title, GenAI Badge, and Status Badge */}
              <div className="flex items-start justify-between gap-3">
                <div className="space-y-1 flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <h3 className="font-semibold text-base text-slate-900 leading-snug">{card.title}</h3>
                    {card.isFallback && (
                      <span className="bg-amber-100 text-amber-800 text-[11px] px-2 py-0.5 rounded font-medium border border-amber-200 flex items-center gap-1">
                        <Info className="h-3 w-3 text-amber-600" /> Fallback Template
                      </span>
                    )}
                    {card.isGenAI && (
                      <span className="bg-purple-100 text-purple-700 text-[11px] px-2 py-0.5 rounded font-medium border border-purple-200">
                        GenAI Required
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-slate-500 leading-relaxed">{card.summary}</p>
                </div>
                <div className="shrink-0">
                  <UploadStatusBadge status={group} />
                </div>
              </div>

              {/* Admin Note if sent back */}
              {sentBackComment && (
                <div className="flex items-start gap-2 rounded-lg bg-red-50 border border-red-200 px-3 py-2 text-xs text-red-700">
                  <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-semibold">Changes requested by Admin:</span> {sentBackComment}
                  </div>
                </div>
              )}

              {/* Uploaded images list */}
              {group && group.images.length > 0 && (
                <div className="space-y-2">
                  <p className="text-xs font-medium text-slate-600">{group.images.length} screenshot{group.images.length > 1 ? "s" : ""} uploaded:</p>
                  {group.images.map((img) => (
                    <div key={img.id} className="flex items-center justify-between text-xs bg-slate-50 border border-slate-200/80 rounded-lg px-3.5 py-2.5">
                      <div className="flex items-center gap-2 min-w-0 flex-1">
                        <FileImage className="h-4 w-4 text-blue-600 shrink-0" />
                        <span className="font-medium text-slate-800 truncate">{img.filename}</span>
                      </div>
                      <div className="flex items-center gap-2 shrink-0 ml-2">
                        {onboardingId && !card.rec_id.startsWith("fallback") && (
                          <a
                            href={`${BASE_URL}//api/approval-screenshots/${onboardingId}/image/${img.id}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-blue-600 hover:text-blue-800 hover:underline flex items-center gap-1"
                          >
                            <Eye className="h-3.5 w-3.5" /> View
                          </a>
                        )}
                        {!isApproved && onboardingId && (
                          <button
                            onClick={() => handleDelete(card.rec_id, img.id)}
                            className="text-red-400 hover:text-red-600 transition-colors ml-1"
                            title="Remove this screenshot"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Upload Zone: shown if not approved */}
              {!isApproved && (
                group && group.images.length > 0
                  ? (
                    <UploadZone
                      onFiles={(files) => handleUpload(card.rec_id, files)}
                      uploading={!!card.uploading}
                      compact
                    />
                  )
                  : (
                    <UploadZone
                      onFiles={(files) => handleUpload(card.rec_id, files)}
                      uploading={!!card.uploading}
                    />
                  )
              )}
            </div>
          );
        })}
      </div>

      {/* ── Bottom Bar: Automated Approval Scanner Status ── */}
      {/* <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3 w-full sm:w-auto">
          <div className="h-10 w-10 rounded-lg bg-blue-600 text-white flex items-center justify-center shrink-0 shadow-sm">
            <Scan className="h-5 w-5" />
          </div>
          <div>
            <h4 className="text-sm font-semibold text-slate-900">Automated Approval Scanner Status</h4>
            <p className="text-xs text-slate-500">
              {attachedCount} of {totalCount} screenshots attached • {verifiedCount} verified
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3 w-full sm:w-auto justify-end">
          <Button
            variant="outline"
            size="sm"
            onClick={handleRunScan}
            disabled={scanning}
            className="text-xs gap-1.5 border-slate-200 text-slate-700"
          >
            {scanning ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <RefreshCw className="h-3.5 w-3.5" />}
            Run Automated Scan
          </Button>

          <Button
            size="sm"
            onClick={handleSubmitForReview}
            disabled={submitting || attachedCount === 0 || isAllApproved}
            title={isAllApproved ? "All approval documents have been approved by the admin" : undefined}
            className={
              isAllApproved
                ? "opacity-60 cursor-not-allowed bg-slate-200 text-slate-500 text-xs gap-1.5 shadow-sm"
                : "gradient-primary text-white text-xs gap-1.5 shadow-sm"
            }
          >
            {submitting ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Send className="h-3.5 w-3.5" />}
            Submit for Admin Review
          </Button>
        </div>
      </div> */}
    </div>
  );
};
