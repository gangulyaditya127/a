export type CorrelationIncident = {
  id: string
  title: string
  severity: "critical" | "high" | "medium" | "low"
  affectedApps: string[]
  alertCount: number
  correlatedAt: string
  rootCause: string
  rootCauseConfidence: number
  blastRadius: { users: number; transactions: number; apps: number }
  symptoms: string[]
  evidence: { source: string; type: string; detail: string; weight: number }[]
  dependencyPath: string[]
  recommendations: string[]
  narrative: string
}

export type HealingLog = {
  id: string
  action: string
  target: string
  status: "success" | "failed" | "in-progress"
  triggeredAt: string
  duration: string
  result: string
}

export type PredictiveRisk = {
  id: string
  title: string
  probability: number
  eta: string
  trend: "rising" | "stable" | "falling"
  affectedApp: string
  indicator: string
}

export const CORRELATION_INCIDENTS: CorrelationIncident[] = [
  {
    id: "COR-001",
    title: "Oracle RAC Failover Cascade — Cross-App Connection Pool Exhaustion",
    severity: "critical",
    affectedApps: ["Policy Administration", "Claims Management", "Customer Portal"],
    alertCount: 16,
    correlatedAt: "2 minutes ago",
    rootCause: "Oracle RAC Node-2 unplanned failover during CHG0045231 maintenance window — all 200 active connections invalidated, causing pool exhaustion across 3 applications sharing the CanaraPolicyDS datasource",
    rootCauseConfidence: 94,
    blastRadius: { users: 4580, transactions: 2340, apps: 3 },
    symptoms: [
      "Benefit Recalculation Service: p95 latency 7.8s, 18% error rate (Policy Admin)",
      "TIBCO BusinessWorks process stuck threads: 47/50 (Integration Tier)",
      "WebLogic thread pool exhaustion: 198/200 on PAS_MS1",
      "IBM MQ queue depth: 4,500/5,000 on DEV.PAS.ENDORSEMENT.Q1",
      "Redis cache miss rate spiked to 67% (stale policy data post-failover)",
    ],
    evidence: [
      { source: "Oracle Enterprise Manager", type: "Database Alert", detail: "RAC Node-2 instance failover at 14:23:05 — active sessions on Node-1 spiked 340→890", weight: 95 },
      { source: "Splunk", type: "Log Pattern", detail: "ORA-12516: TNS listener could not find available handler — 230 rejections in 2 min", weight: 92 },
      { source: "AppDynamics", type: "APM Trace", detail: "Connection pool 'CanaraPolicyDS' wait time: 4,200ms (baseline: 15ms) — pool maxActive=200 exhausted", weight: 88 },
      { source: "TIBCO Hawk", type: "Middleware Alert", detail: "Process engine stuck thread count: 47/50 — 'PolicyEndorsement.bwp' activity 'InvokeOracleDB' timeout", weight: 90 },
      { source: "Dynatrace", type: "Service Anomaly", detail: "Response time anomaly: Benefit Recalculation Service at 13x baseline deviation", weight: 85 },
      { source: "ServiceNow", type: "Change Record", detail: "CHG0045231 — Planned RAC maintenance window exceeded by 18 min before failover", weight: 78 },
    ],
    dependencyPath: [
      "Oracle RAC 19c (Node-2 failover @ 14:23:05)",
      "Connection Pool 'CanaraPolicyDS' (maxActive: 200 → exhausted)",
      "TIBCO BusinessWorks 6.x (ESB process stall → queue backlog)",
      "IBM MQ 9.3 (queue depth: 4,500/5,000)",
      "Oracle WebLogic 14c (thread pool: 198/200)",
      "Drools Rules Engine (rule execution timeout: 4.8s)",
      "Benefit Recalculation Service (18% error rate → endorsement failures)",
    ],
    recommendations: [
      "Increase Oracle connection pool maxActive from 200 to 400 with validation query",
      "Enable connection pool warm-up and stale connection eviction after RAC failover",
      "Implement circuit breaker on Drools Rules Engine with cached fallback for non-critical endorsements",
      "Add retry with exponential backoff on TIBCO-to-Oracle JDBC connections",
      "Configure Redis cache invalidation hook on Oracle failover event",
      "Update CHG0045231 maintenance SOP with pre-failover connection drain",
    ],
    narrative: "At 14:23, Oracle RAC Node-2 underwent an unplanned failover during scheduled maintenance window CHG0045231. The maintenance overran by 18 minutes, causing an abrupt switchover. All 200 active connections in the shared 'CanaraPolicyDS' connection pool were invalidated simultaneously. Three applications — Policy Administration, Claims Management, and Customer Portal — competed for new connections on the surviving Node-1, causing pool exhaustion within 30 seconds. The TIBCO ESB, which holds long-lived database transactions for endorsement processing, was most severely impacted with 47 of 50 process threads stuck. This cascaded into WebLogic thread pool exhaustion and Drools rule evaluation timeouts. The correlation engine identified this as a single root cause affecting 4,580 policyholders across 2,340 in-flight transactions by analyzing 16 alerts from 9 different monitoring connectors across all 5 technical tiers.",
  },
  {
    id: "COR-002",
    title: "TPA Gateway SSL Certificate Expiry — Claims Assessment Failure",
    severity: "high",
    affectedApps: ["Claims Management"],
    alertCount: 12,
    correlatedAt: "18 minutes ago",
    rootCause: "Third-party TPA (HealthNet) gateway SSL certificate expired, causing connection failures through MuleSoft ESB, triggering retry storm and downstream PostgreSQL lock contention",
    rootCauseConfidence: 91,
    blastRadius: { users: 980, transactions: 520, apps: 1 },
    symptoms: [
      "Hospital Network Verification: p95 latency 7.2s, 16% error rate",
      "MuleSoft circuit breaker OPEN: 340 consecutive failures to TPA endpoint",
      "Retry storm: 1,200 retry attempts/min through ESB",
      "PostgreSQL lock contention: 45 queries waiting on 'claim_assessments' table",
    ],
    evidence: [
      { source: "Splunk", type: "Log Pattern", detail: "javax.net.ssl.SSLHandshakeException: PKIX path building failed — TPA gateway cert expired 2h ago", weight: 94 },
      { source: "MuleSoft Anypoint Monitoring", type: "API Gateway", detail: "Circuit breaker OPEN on 'hospital-network-v2' — 340 consecutive HTTP 503 from tpa-gateway.healthnet.co.in", weight: 91 },
      { source: "Azure Monitor", type: "Database Alert", detail: "Lock contention: 45 queries waiting on 'claim_assessments' — caused by retry-generated long transactions", weight: 86 },
      { source: "Confluent Control Center", type: "Streaming Alert", detail: "Consumer lag on 'claims.assessment.events': 8,400 messages behind", weight: 82 },
    ],
    dependencyPath: [
      "HealthNet TPA Gateway (SSL cert expired)",
      "MuleSoft Anypoint (circuit breaker → retry storm)",
      "JBoss EAP 8.0 (HTTP pool saturated: 50/50)",
      "PostgreSQL 16 (lock contention on claim_assessments)",
      "Hospital Network Verification Service (16% error rate)",
    ],
    recommendations: [
      "Contact HealthNet TPA to renew SSL certificate immediately",
      "Implement certificate expiry monitoring with 30-day advance alerting",
      "Reduce MuleSoft max-retries from 3 to 1 with circuit breaker cool-off period",
      "Add statement timeout on PostgreSQL to prevent long-running retry transactions",
    ],
    narrative: "The HealthNet TPA gateway SSL certificate expired approximately 2 hours ago, causing all HTTPS connections from MuleSoft to fail with SSLHandshakeException. MuleSoft's retry policy (3 retries per request) amplified the failure 4x, creating a retry storm of 1,200 attempts/min. Each retry held a database transaction open, causing lock contention on the 'claim_assessments' table in PostgreSQL. The correlation engine linked SSL errors from Splunk, circuit breaker status from MuleSoft Monitoring, and lock contention from Azure Monitor to identify the certificate expiry as the single root cause.",
  },
  {
    id: "COR-003",
    title: "MIB External API Rate Limit — Medical Underwriting Delays",
    severity: "medium",
    affectedApps: ["Underwriting Workbench"],
    alertCount: 10,
    correlatedAt: "35 minutes ago",
    rootCause: "MIB (Medical Information Bureau) external API daily quota exceeded due to batch reprocessing job, causing Kong API Gateway throttling and underwriting delays",
    rootCauseConfidence: 87,
    blastRadius: { users: 420, transactions: 180, apps: 1 },
    symptoms: [
      "Medical History API: p95 latency 5.8s, 14% error rate",
      "Kong rate limit: 340 requests rejected with HTTP 429",
      "RabbitMQ response queue backlog: 2,100 messages",
    ],
    evidence: [
      { source: "Kong Vitals", type: "API Gateway", detail: "Rate limit plugin triggered: API key 'canara-uw-prod' exceeded 500 req/min quota — 340 HTTP 429 responses", weight: 89 },
      { source: "Datadog APM", type: "Service Trace", detail: "medical-history-svc p95: 3,500ms with 60% Hystrix circuit breaker failure rate", weight: 85 },
      { source: "Splunk", type: "Log Pattern", detail: "Batch reprocessing job 'UW_MIB_BACKFILL' consumed 80% of daily MIB API quota in 45 minutes", weight: 88 },
    ],
    dependencyPath: [
      "MIB External API (rate limit: 500 req/min exceeded)",
      "Kong Gateway Enterprise (throttling → HTTP 429)",
      "Spring Boot 'medical-history-svc' (Hystrix circuit breaker at 60%)",
      "RabbitMQ 3.13 (response queue backlog: 2,100)",
      "Medical History API (14% error rate → UW delays)",
    ],
    recommendations: [
      "Kill the UW_MIB_BACKFILL batch job and reschedule to off-peak hours",
      "Implement separate API quota pools for real-time vs batch processing",
      "Add request prioritization in Kong with premium tier for live underwriting",
      "Configure RabbitMQ consumer auto-scaling based on queue depth",
    ],
    narrative: "A batch reprocessing job 'UW_MIB_BACKFILL' was inadvertently scheduled during peak hours, consuming 80% of the daily MIB API quota in 45 minutes. This triggered Kong's rate limiting plugin, rejecting 340 real-time underwriting requests with HTTP 429. The correlation engine identified the batch job as the root cause by linking Kong rate limit events, Datadog service traces, and Splunk log patterns showing the batch job's API consumption.",
  },
]

export const HEALING_LOGS: HealingLog[] = [
  { id: "HL-001", action: "Oracle Connection Pool Scale-Up", target: "Policy Admin → WebLogic 'CanaraPolicyDS'", status: "success", triggeredAt: "1 min ago", duration: "28s", result: "Pool maxActive increased 200→400; active connections stabilized at 220, wait time dropped to 18ms" },
  { id: "HL-002", action: "TIBCO ESB Process Restart (Rolling)", target: "Policy Admin → TIBCO BW 'PolicyEndorsement.bwp'", status: "success", triggeredAt: "2 min ago", duration: "45s", result: "Process engine restarted; stuck threads cleared, queue depth dropping at 150 msg/min" },
  { id: "HL-003", action: "Circuit Breaker Activation", target: "Policy Admin → Drools Rules Engine", status: "success", triggeredAt: "3 min ago", duration: "2s", result: "Circuit opened; fallback to cached benefit calculation for non-critical endorsement types" },
  { id: "HL-004", action: "Redis Cache Flush & Warm-up", target: "Policy Admin → Redis Cluster", status: "success", triggeredAt: "4 min ago", duration: "12s", result: "Stale policy cache invalidated; warm-up from Oracle completed, miss rate dropped 67%→15%" },
  { id: "HL-005", action: "IBM MQ Queue Drain", target: "Policy Admin → DEV.PAS.ENDORSEMENT.Q1", status: "success", triggeredAt: "5 min ago", duration: "35s", result: "Dead-letter queue consumer activated; backlog cleared from 4,500 to 280 messages" },
  { id: "HL-006", action: "MuleSoft Circuit Breaker Reset", target: "Claims Mgmt → MuleSoft 'hospital-network-v2'", status: "in-progress", triggeredAt: "12 min ago", duration: "—", result: "Awaiting TPA certificate renewal; fallback to manual verification workflow activated" },
  { id: "HL-007", action: "Oracle RAC Node-2 Recovery", target: "Data Tier → Oracle RAC 19c", status: "success", triggeredAt: "15 min ago", duration: "120s", result: "Node-2 recovered and rejoined cluster; connections rebalanced across both nodes" },
  { id: "HL-008", action: "Kong Rate Limit Override", target: "Underwriting → Kong Gateway 'canara-uw-prod'", status: "success", triggeredAt: "20 min ago", duration: "3s", result: "Temporary rate limit increase to 1000 req/min for real-time UW; batch job paused" },
  { id: "HL-009", action: "PostgreSQL Lock Cleanup", target: "Claims Mgmt → Azure PostgreSQL 'claim_assessments'", status: "success", triggeredAt: "22 min ago", duration: "8s", result: "Long-running transactions terminated; lock wait count dropped from 45 to 0" },
  { id: "HL-010", action: "Auto-Scale Pods", target: "Claims Mgmt → AKS 'claims-assessment' deployment", status: "success", triggeredAt: "25 min ago", duration: "65s", result: "Scaled from 3→6 pods; request queue clearing at 200 req/s" },
]

export const PREDICTIVE_RISKS: PredictiveRisk[] = [
  { id: "PR-001", title: "WebLogic JVM Heap Pressure — Policy Admin", probability: 78, eta: "~45 min", trend: "rising", affectedApp: "Policy Administration", indicator: "JVM heap usage trending from 87%→92% post-recovery; full GC frequency increased 3x. Risk of OutOfMemoryError if endorsement backlog processes." },
  { id: "PR-002", title: "TLS Certificate Expiry — Agent Portal API Gateway", probability: 65, eta: "~6 hours", trend: "stable", affectedApp: "Agent & Distributor Portal", indicator: "Kong TLS certificate for agent-portal.canaralife.com expires in 6 hours; no automated renewal job detected in cert-manager." },
  { id: "PR-003", title: "Storage Capacity — FileNet Policy Documents", probability: 58, eta: "~2 days", trend: "rising", affectedApp: "Policy Administration", indicator: "IBM FileNet P8 document store volume at 87% capacity; growth rate 2.1 GB/day from endorsement document uploads." },
  { id: "PR-004", title: "Kafka Consumer Lag — Claims Event Stream", probability: 52, eta: "~90 min", trend: "rising", affectedApp: "Claims Management", indicator: "Consumer lag on 'claims.assessment.events' at 8,400 messages; if TPA gateway remains down, lag will exceed 50K in ~90 min." },
  { id: "PR-005", title: "Oracle RAC Tablespace — POLICY_DATA", probability: 45, eta: "~3 days", trend: "falling", affectedApp: "Policy Administration", indicator: "POLICY_DATA tablespace at 82% capacity; trending down post-recovery as stale sessions are cleared." },
]

export const NOISE_REDUCTION = {
  raw: 4280,
  deduplicated: 1850,
  correlated: 420,
  actionable: 185,
  reductionPercent: 95.7,
}

export const OPTIMIZATION_METRICS = {
  hoursSaved: 1240,
  autoResolved: 812,
  mttrBefore: "45 min",
  mttrAfter: "4.2 min",
  costSavings: "₹1.54 Cr",
  predictionAccuracy: 91,
  automationCoverage: 87,
}

export function generateChartData(points: number, base: number, variability: number) {
  return Array.from({ length: points }, (_, i) => {
    const date = new Date(Date.now() - (points - i - 1) * 5 * 60000)
    const spikeAt = Math.floor(points * 0.7)
    let value = base + (Math.random() - 0.5) * 2 * variability
    if (i >= spikeAt && i <= spikeAt + 2) value = base * 2.5 + Math.random() * variability
    return {
      time: date.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" }),
      value: Math.max(0, Math.round(value * 100) / 100),
    }
  })
}
