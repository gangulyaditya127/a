import { createHashRouter } from "react-router-dom"
import App from "./App"
import { lazy, Suspense } from "react"

const S5Catalog = lazy(() => import("./pages/S5Catalog"))
const S5Home = lazy(() => import("./pages/S5Home"))
const S5Details = lazy(() => import("./pages/S5Details"))
const S5Timeline = lazy(() => import("./pages/S5Timeline"))
const S5Dashboard = lazy(() => import("./pages/S5Dashboard"))

const Loader = () => (
  <div className="flex items-center justify-center min-h-screen">
    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
  </div>
)

export const router = createHashRouter([
  {
    path: "/",
    element: <App />,
    children: [
      {
        path: "",
        element: <Suspense fallback={<Loader />}><S5Catalog /></Suspense>,
      },
      {
        path: ":appId",
        element: <Suspense fallback={<Loader />}><S5Home /></Suspense>,
      },
      {
        path: ":appId/:journey",
        element: <Suspense fallback={<Loader />}><S5Details /></Suspense>,
      },
      {
        path: ":appId/:journey/timeline",
        element: <Suspense fallback={<Loader />}><S5Timeline /></Suspense>,
      },
      {
        path: ":appId/:journey/detail",
        element: <Suspense fallback={<Loader />}><S5Dashboard /></Suspense>,
      },
    ],
  },
])
