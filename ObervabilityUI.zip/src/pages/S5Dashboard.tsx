import { useParams, Link } from "react-router-dom"
import { getApp } from "@/data/applications"
import {
  CORRELATION_INCIDENTS, HEALING_LOGS, PREDICTIVE_RISKS,
  NOISE_REDUCTION, generateChartData,
  type CorrelationIncident,
} from "@/data/dashboard"
import { useAppSelector, useAppDispatch } from "@/lib/hooks"
import { runAutoFixFlow } from "@/features/agent-flow-slice"
import { cn } from "@/lib/utils"
import { useState, useMemo } from "react"
import {
  AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer,
} from "recharts"
import {
  ArrowLeft, ChevronRight, ChevronDown, Zap, Activity, Shield,
  AlertTriangle, TrendingUp, TrendingDown, Minus, Clock, CheckCircle2,
  Loader2, Circle, Brain, Sparkles, ArrowRight, Target, Users, Layers,
} from "lucide-react"

// ─── Chart Card ──────────────────────────────────────────
function MetricChart({ title, description, data, color, className }: {
  title: string; description: string; data: { time: string; value: number }[]; color: string; className?: string
}) {
  return (
    <div className={cn("rounded-xl border border-border bg-card p-4", className)}>
      <p className="text-sm font-semibold text-foreground">{title}</p>
      <p className="text-xs text-muted-foreground mb-3">{description}</p>
      <ResponsiveContainer width="100%" height={160}>
        <AreaChart data={data}>
          <defs>
            <linearGradient id={`grad-${title.replace(/\s/g, "")}`} x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor={color} stopOpacity={0.3} />
              <stop offset="95%" stopColor={color} stopOpacity={0} />
            </linearGradient>
          </defs>
          <XAxis dataKey="time" tick={{ fontSize: 10, fill: "#888" }} axisLine={false} tickLine={false} />
          <YAxis tick={{ fontSize: 10, fill: "#888" }} axisLine={false} tickLine={false} width={40} />
          <Tooltip contentStyle={{ background: "#1a1a2e", border: "1px solid #333", borderRadius: "8px", fontSize: 12 }} />
          <Area type="monotone" dataKey="value" stroke={color} fill={`url(#grad-${title.replace(/\s/g, "")})`} strokeWidth={2} />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  )
}

// ─── Severity Badge ──────────────────────────────────────
function SeverityBadge({ severity }: { severity: string }) {
  const styles: Record<string, string> = {
    critical: "bg-red-500/10 text-red-400 border-red-500/20",
    high: "bg-orange-500/10 text-orange-400 border-orange-500/20",
    medium: "bg-yellow-500/10 text-yellow-400 border-yellow-500/20",
    low: "bg-green-500/10 text-green-400 border-green-500/20",
  }
  return (
    <span className={cn("text-xs font-medium px-2 py-0.5 rounded-full border", styles[severity] ?? styles.low)}>
      {severity.charAt(0).toUpperCase() + severity.slice(1)}
    </span>
  )
}

// ─── Correlation Row (expandable) ────────────────────────
function CorrelationRow({ incident }: { incident: CorrelationIncident }) {
  const [open, setOpen] = useState(false)
  return (
    <>
      <tr
        className="border-b border-border hover:bg-accent/20 cursor-pointer transition-colors"
        onClick={() => setOpen(!open)}
      >
        <td className="px-4 py-3 text-sm font-mono text-primary">{incident.id}</td>
        <td className="px-4 py-3 text-sm font-medium text-foreground">{incident.title}</td>
        <td className="px-4 py-3"><SeverityBadge severity={incident.severity} /></td>
        <td className="px-4 py-3 text-sm text-muted-foreground">{incident.affectedApps.join(", ")}</td>
        <td className="px-4 py-3 text-sm text-center text-foreground">{incident.alertCount}</td>
        <td className="px-4 py-3 text-sm text-muted-foreground">{incident.correlatedAt}</td>
        <td className="px-4 py-3">
          <ChevronDown className={cn("h-4 w-4 text-muted-foreground transition-transform", open && "rotate-180")} />
        </td>
      </tr>
      {open && (
        <tr>
          <td colSpan={7} className="p-0">
            <div className="bg-card/50 border-t border-border p-6 space-y-6">
              {/* Root Cause */}
              <div>
                <h5 className="text-sm font-semibold text-foreground flex items-center gap-2 mb-2">
                  <Target className="h-4 w-4 text-red-400" /> Root Cause Analysis
                </h5>
                <p className="text-sm text-foreground mb-2">{incident.rootCause}</p>
                <div className="flex items-center gap-3">
                  <span className="text-xs text-muted-foreground">Confidence:</span>
                  <div className="flex-1 max-w-xs h-2 bg-border rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-blue-500 to-cyan-400 rounded-full transition-all"
                      style={{ width: `${incident.rootCauseConfidence}%` }}
                    />
                  </div>
                  <span className="text-xs font-semibold text-cyan-400">{incident.rootCauseConfidence}%</span>
                </div>
              </div>

              {/* Blast Radius */}
              <div>
                <h5 className="text-sm font-semibold text-foreground flex items-center gap-2 mb-3">
                  <Layers className="h-4 w-4 text-orange-400" /> Blast Radius
                </h5>
                <div className="grid grid-cols-3 gap-3">
                  <div className="rounded-lg border border-border p-3 text-center">
                    <Users className="h-4 w-4 text-blue-400 mx-auto mb-1" />
                    <p className="text-lg font-bold text-foreground">{incident.blastRadius.users.toLocaleString()}</p>
                    <p className="text-xs text-muted-foreground">Affected Users</p>
                  </div>
                  <div className="rounded-lg border border-border p-3 text-center">
                    <Activity className="h-4 w-4 text-purple-400 mx-auto mb-1" />
                    <p className="text-lg font-bold text-foreground">{incident.blastRadius.transactions.toLocaleString()}</p>
                    <p className="text-xs text-muted-foreground">Transactions</p>
                  </div>
                  <div className="rounded-lg border border-border p-3 text-center">
                    <Layers className="h-4 w-4 text-orange-400 mx-auto mb-1" />
                    <p className="text-lg font-bold text-foreground">{incident.blastRadius.apps}</p>
                    <p className="text-xs text-muted-foreground">Applications</p>
                  </div>
                </div>
              </div>

              {/* Evidence */}
              <div>
                <h5 className="text-sm font-semibold text-foreground flex items-center gap-2 mb-2">
                  <Shield className="h-4 w-4 text-green-400" /> Evidence
                </h5>
                <div className="rounded-lg border border-border overflow-hidden">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-border bg-card">
                        <th className="text-left text-xs font-medium text-muted-foreground px-3 py-2">Source</th>
                        <th className="text-left text-xs font-medium text-muted-foreground px-3 py-2">Type</th>
                        <th className="text-left text-xs font-medium text-muted-foreground px-3 py-2">Detail</th>
                        <th className="text-right text-xs font-medium text-muted-foreground px-3 py-2 w-32">Weight</th>
                      </tr>
                    </thead>
                    <tbody>
                      {incident.evidence.map((ev, i) => (
                        <tr key={i} className="border-b border-border last:border-0">
                          <td className="px-3 py-2">
                            <span className="text-xs font-medium px-2 py-0.5 rounded bg-primary/10 text-primary">{ev.source}</span>
                          </td>
                          <td className="px-3 py-2 text-xs text-muted-foreground">{ev.type}</td>
                          <td className="px-3 py-2 text-xs text-foreground">{ev.detail}</td>
                          <td className="px-3 py-2">
                            <div className="flex items-center gap-2">
                              <div className="flex-1 h-1.5 bg-border rounded-full overflow-hidden">
                                <div className="h-full bg-green-500 rounded-full" style={{ width: `${ev.weight}%` }} />
                              </div>
                              <span className="text-xs text-green-400 w-8 text-right">{ev.weight}</span>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Dependency Path */}
              <div>
                <h5 className="text-sm font-semibold text-foreground flex items-center gap-2 mb-3">
                  <ArrowRight className="h-4 w-4 text-cyan-400" /> Dependency Path
                </h5>
                <div className="flex items-center gap-2 flex-wrap">
                  {incident.dependencyPath.map((node, i) => (
                    <div key={i} className="flex items-center gap-2">
                      <span className={cn(
                        "text-xs px-3 py-1.5 rounded-lg border",
                        i === 0 ? "bg-red-500/10 border-red-500/20 text-red-400 font-medium" : "bg-card border-border text-foreground"
                      )}>{node}</span>
                      {i < incident.dependencyPath.length - 1 && <ArrowRight className="h-3 w-3 text-muted-foreground shrink-0" />}
                    </div>
                  ))}
                </div>
              </div>

              {/* Recommendations */}
              <div>
                <h5 className="text-sm font-semibold text-foreground flex items-center gap-2 mb-2">
                  <Sparkles className="h-4 w-4 text-yellow-400" /> Recommendations
                </h5>
                <ul className="space-y-1.5">
                  {incident.recommendations.map((rec, i) => (
                    <li key={i} className="flex items-start gap-2 text-sm text-foreground">
                      <CheckCircle2 className="h-4 w-4 text-green-400 mt-0.5 shrink-0" />{rec}
                    </li>
                  ))}
                </ul>
              </div>

              {/* Narrative */}
              <div className="rounded-lg border border-border bg-card p-4">
                <h5 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">Executive Narrative</h5>
                <p className="text-sm text-foreground leading-relaxed">{incident.narrative}</p>
              </div>
            </div>
          </td>
        </tr>
      )}
    </>
  )
}

// ─── Main Dashboard ──────────────────────────────────────
export default function S5Dashboard() {
  const { appId, journey } = useParams()
  const app = getApp(appId ?? "")
  const journeyName = decodeURIComponent(journey ?? "")
  const dispatch = useAppDispatch()
  const agentFlow = useAppSelector(s => s.agentFlow)

  const charts = useMemo(() => ({
    errorRate: generateChartData(30, 5, 3),
    responseTime: generateChartData(30, 800, 400),
    cpu: generateChartData(30, 55, 15),
    memory: generateChartData(30, 68, 10),
    connections: generateChartData(30, 150, 50),
    latency: generateChartData(30, 45, 20),
  }), [])

  return (
    <div className="max-w-7xl mx-auto px-6 my-6 mb-16">
      {/* Back + Breadcrumb */}
      <Link to={`/${appId}/${journey}/timeline`} className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground mb-4 transition-colors">
        <ArrowLeft className="h-4 w-4" /> Back to Technical Layer
      </Link>
      <nav className="flex items-center gap-1.5 text-sm text-muted-foreground mb-4 flex-wrap">
        <Link to="/" className="hover:text-foreground">Home</Link><ChevronRight className="h-3 w-3" />
        <Link to={`/${appId}`} className="hover:text-foreground">{app?.name}</Link><ChevronRight className="h-3 w-3" />
        <Link to={`/${appId}/${journey}`} className="hover:text-foreground">{journeyName}</Link><ChevronRight className="h-3 w-3" />
        <Link to={`/${appId}/${journey}/timeline`} className="hover:text-foreground">Timeline</Link><ChevronRight className="h-3 w-3" />
        <span className="text-foreground font-medium">Investigation</span>
      </nav>

      {/* Alert Banner */}
      <div className="flex items-start justify-between gap-4 mb-6">
        <div>
          <div className="flex items-center gap-3 mb-1">
            {agentFlow.fixed
              ? <span className="text-xs font-medium px-2.5 py-1 rounded-full bg-green-500/10 border border-green-500/20 text-green-400">Resolved</span>
              : <span className="text-xs font-medium px-2.5 py-1 rounded-full bg-red-500/10 border border-red-500/20 text-red-400">Critical</span>}
          </div>
          <h2 className="text-2xl font-bold text-foreground">
            {agentFlow.fixed ? "Issue resolved" : "Performance degradation detected"} — {journeyName}
          </h2>
          <div className="flex gap-3 mt-3 flex-wrap">
            <span className="text-xs px-3 py-1.5 rounded-lg bg-card border border-border text-foreground"><span className="text-muted-foreground">Affected:</span> {app?.name}</span>
            <span className="text-xs px-3 py-1.5 rounded-lg bg-card border border-border text-foreground"><span className="text-muted-foreground">Error Rate:</span> 18%</span>
            <span className="text-xs px-3 py-1.5 rounded-lg bg-card border border-border text-foreground"><span className="text-muted-foreground">First Seen:</span> 43 min ago</span>
            <span className="text-xs px-3 py-1.5 rounded-lg bg-card border border-border text-foreground"><span className="text-muted-foreground">Correlated Alerts:</span> 7</span>
          </div>
        </div>
        <button
          onClick={() => dispatch(runAutoFixFlow())}
          disabled={agentFlow.running || agentFlow.fixed}
          className={cn(
            "px-5 py-2.5 rounded-lg text-sm font-semibold flex items-center gap-2 transition-all shrink-0",
            agentFlow.fixed ? "bg-green-600/20 text-green-400 border border-green-500/20 cursor-default"
              : agentFlow.running ? "bg-blue-600/20 text-blue-400 border border-blue-500/20 cursor-wait"
              : "bg-blue-600 hover:bg-blue-700 text-white shadow-lg shadow-blue-500/20 hover:shadow-blue-500/30"
          )}
        >
          {agentFlow.fixed ? <><CheckCircle2 className="h-4 w-4" /> Resolved</>
            : agentFlow.running ? <><Loader2 className="h-4 w-4 animate-spin" /> Running...</>
            : <><Zap className="h-4 w-4" /> Auto-Fix</>}
        </button>
      </div>

      {/* Agent Flow Progress */}
      {(agentFlow.running || agentFlow.fixed) && (
        <div className="rounded-xl border border-border bg-card p-5 mb-6">
          <h4 className="text-sm font-semibold text-foreground mb-4 flex items-center gap-2">
            <Brain className="h-4 w-4 text-purple-400" /> AI Agent Execution Flow
          </h4>
          <div className="flex items-center gap-1 overflow-x-auto pb-2">
            {agentFlow.steps.map((step, i) => (
              <div key={step.key} className="flex items-center gap-1">
                <div className="flex flex-col items-center min-w-[90px]">
                  <div className={cn(
                    "h-8 w-8 rounded-full grid place-items-center text-xs font-bold",
                    step.status === "completed" && "bg-green-500/20 text-green-400",
                    step.status === "running" && "bg-blue-500/20 text-blue-400",
                    step.status === "idle" && "bg-border text-muted-foreground",
                  )}>
                    {step.status === "completed" ? <CheckCircle2 className="h-4 w-4" />
                      : step.status === "running" ? <Loader2 className="h-4 w-4 animate-spin" />
                      : <Circle className="h-3 w-3" />}
                  </div>
                  <p className="text-[10px] text-center mt-1 text-foreground leading-tight w-20">{step.title}</p>
                  <p className="text-[9px] text-muted-foreground text-center">{step.agent}</p>
                </div>
                {i < agentFlow.steps.length - 1 && (
                  <div className={cn(
                    "h-0.5 w-6 shrink-0 mb-8",
                    step.status === "completed" ? "bg-green-500" : "bg-border"
                  )} />
                )}
              </div>
            ))}
          </div>
          {agentFlow.activity.length > 0 && (
            <div className="mt-4 max-h-32 overflow-y-auto rounded-lg bg-background/50 p-3 space-y-1">
              {agentFlow.activity.slice(-8).map((log, i) => (
                <p key={i} className="text-xs text-muted-foreground">
                  <span className="text-primary font-medium">[{log.scope}]</span> {log.message}
                </p>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Charts */}
      <div className="grid grid-cols-3 gap-4 mb-6">
        <MetricChart title="Error Rate" description="Errors per minute across services" data={charts.errorRate} color="#ef4444" />
        <MetricChart title="Response Time" description="Average response time (ms)" data={charts.responseTime} color="#3b82f6" />
        <MetricChart title="CPU Usage" description="Server CPU utilization (%)" data={charts.cpu} color="#f59e0b" />
        <MetricChart title="Memory Usage" description="Heap / RSS memory (%)" data={charts.memory} color="#8b5cf6" />
        <MetricChart title="Active Connections" description="Database & service connections" data={charts.connections} color="#06b6d4" />
        <MetricChart title="Network Latency" description="Inter-service latency (ms)" data={charts.latency} color="#10b981" />
      </div>

      {/* Event Correlation */}
      <div className="rounded-xl border border-border overflow-hidden mb-6">
        <div className="bg-card px-5 py-4 border-b border-border flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="relative">
              <div className="h-2.5 w-2.5 rounded-full bg-green-500" />
              <div className="absolute inset-0 h-2.5 w-2.5 rounded-full bg-green-500 animate-ping opacity-75" />
            </div>
            <h3 className="text-base font-semibold text-foreground">Event Correlation Engine</h3>
            <span className="text-xs font-medium px-2 py-0.5 rounded-full bg-green-500/10 text-green-400">Active</span>
          </div>
          <div className="flex items-center gap-4 text-xs text-muted-foreground">
            <span>Interval: <span className="text-foreground">30s</span></span>
            <span>Last Run: <span className="text-foreground">12s ago</span></span>
            <span>Incidents: <span className="text-foreground font-semibold">{CORRELATION_INCIDENTS.length}</span></span>
          </div>
        </div>
        <table className="w-full">
          <thead>
            <tr className="border-b border-border bg-card/50">
              <th className="text-left text-xs font-medium text-muted-foreground px-4 py-2.5">ID</th>
              <th className="text-left text-xs font-medium text-muted-foreground px-4 py-2.5">Incident</th>
              <th className="text-left text-xs font-medium text-muted-foreground px-4 py-2.5">Severity</th>
              <th className="text-left text-xs font-medium text-muted-foreground px-4 py-2.5">Affected Apps</th>
              <th className="text-center text-xs font-medium text-muted-foreground px-4 py-2.5">Alerts</th>
              <th className="text-left text-xs font-medium text-muted-foreground px-4 py-2.5">Correlated</th>
              <th className="w-8"></th>
            </tr>
          </thead>
          <tbody>
            {CORRELATION_INCIDENTS.map(inc => <CorrelationRow key={inc.id} incident={inc} />)}
          </tbody>
        </table>
      </div>

      {/* Noise Reduction Funnel */}
      <div className="rounded-xl border border-border bg-card p-5 mb-6">
        <h3 className="text-base font-semibold text-foreground mb-1">Intelligent Noise Reduction</h3>
        <p className="text-xs text-muted-foreground mb-4">{NOISE_REDUCTION.reductionPercent}% noise reduction — from {NOISE_REDUCTION.raw.toLocaleString()} raw alerts to {NOISE_REDUCTION.actionable} actionable</p>
        <div className="space-y-3">
          {[
            { label: "Raw Alerts", value: NOISE_REDUCTION.raw, pct: 100, color: "from-red-500 to-red-600" },
            { label: "Deduplicated", value: NOISE_REDUCTION.deduplicated, pct: (NOISE_REDUCTION.deduplicated / NOISE_REDUCTION.raw) * 100, color: "from-orange-500 to-orange-600" },
            { label: "Correlated", value: NOISE_REDUCTION.correlated, pct: (NOISE_REDUCTION.correlated / NOISE_REDUCTION.raw) * 100, color: "from-yellow-500 to-yellow-600" },
            { label: "Actionable", value: NOISE_REDUCTION.actionable, pct: (NOISE_REDUCTION.actionable / NOISE_REDUCTION.raw) * 100, color: "from-green-500 to-green-600" },
          ].map(item => (
            <div key={item.label} className="flex items-center gap-4">
              <span className="text-xs text-muted-foreground w-24 text-right">{item.label}</span>
              <div className="flex-1 h-7 bg-border/30 rounded-full overflow-hidden">
                <div
                  className={cn("h-full rounded-full bg-gradient-to-r flex items-center justify-end pr-3 transition-all duration-700", item.color)}
                  style={{ width: `${Math.max(item.pct, 6)}%` }}
                >
                  <span className="text-xs font-bold text-white">{item.value.toLocaleString()}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Self-Healing Logs */}
      <div className="rounded-xl border border-border overflow-hidden mb-6">
        <div className="bg-card px-5 py-4 border-b border-border">
          <h3 className="text-base font-semibold text-foreground flex items-center gap-2">
            <Zap className="h-4 w-4 text-yellow-400" /> Self-Healing Automation
          </h3>
          <p className="text-xs text-muted-foreground mt-0.5">Automated remediation actions triggered by the correlation engine</p>
        </div>
        <table className="w-full">
          <thead>
            <tr className="border-b border-border bg-card/50">
              <th className="text-left text-xs font-medium text-muted-foreground px-4 py-2.5">Action</th>
              <th className="text-left text-xs font-medium text-muted-foreground px-4 py-2.5">Target</th>
              <th className="text-center text-xs font-medium text-muted-foreground px-4 py-2.5">Status</th>
              <th className="text-left text-xs font-medium text-muted-foreground px-4 py-2.5">Triggered</th>
              <th className="text-right text-xs font-medium text-muted-foreground px-4 py-2.5">Duration</th>
              <th className="text-left text-xs font-medium text-muted-foreground px-4 py-2.5">Result</th>
            </tr>
          </thead>
          <tbody>
            {HEALING_LOGS.map(log => (
              <tr key={log.id} className="border-b border-border last:border-0 hover:bg-accent/20 transition-colors">
                <td className="px-4 py-3 text-sm font-medium text-foreground">{log.action}</td>
                <td className="px-4 py-3 text-sm text-muted-foreground">{log.target}</td>
                <td className="px-4 py-3 text-center">
                  <span className={cn("text-xs font-medium px-2 py-0.5 rounded-full",
                    log.status === "success" && "bg-green-500/10 text-green-400",
                    log.status === "failed" && "bg-red-500/10 text-red-400",
                    log.status === "in-progress" && "bg-yellow-500/10 text-yellow-400",
                  )}>
                    {log.status === "in-progress" ? "In Progress" : log.status.charAt(0).toUpperCase() + log.status.slice(1)}
                  </span>
                </td>
                <td className="px-4 py-3 text-xs text-muted-foreground">{log.triggeredAt}</td>
                <td className="px-4 py-3 text-xs text-right text-foreground">{log.duration}</td>
                <td className="px-4 py-3 text-xs text-foreground max-w-xs">{log.result}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Predictive Risks */}
      <div className="mb-6">
        <h3 className="text-base font-semibold text-foreground flex items-center gap-2 mb-4">
          <Brain className="h-4 w-4 text-purple-400" /> Predictive Risk Detection
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {PREDICTIVE_RISKS.map(risk => (
            <div key={risk.id} className="rounded-xl border border-border bg-card p-4 hover:border-primary/30 transition-colors">
              <div className="flex items-start justify-between mb-3">
                <h4 className="text-sm font-semibold text-foreground pr-2">{risk.title}</h4>
                <div className="relative h-12 w-12 shrink-0">
                  <svg viewBox="0 0 36 36" className="h-12 w-12 -rotate-90">
                    <circle cx="18" cy="18" r="15.5" fill="none" strokeWidth="3" className="stroke-border" />
                    <circle cx="18" cy="18" r="15.5" fill="none" strokeWidth="3"
                      className={cn(risk.probability >= 70 ? "stroke-red-500" : risk.probability >= 50 ? "stroke-yellow-500" : "stroke-green-500")}
                      strokeDasharray={`${risk.probability} ${100 - risk.probability}`}
                      strokeLinecap="round" />
                  </svg>
                  <span className="absolute inset-0 flex items-center justify-center text-xs font-bold text-foreground">{risk.probability}%</span>
                </div>
              </div>
              <div className="flex items-center gap-2 mb-2">
                <span className="text-xs px-2 py-0.5 rounded bg-card border border-border text-muted-foreground flex items-center gap-1">
                  <Clock className="h-3 w-3" /> ETA: {risk.eta}
                </span>
                <span className="text-xs px-2 py-0.5 rounded bg-card border border-border flex items-center gap-1">
                  {risk.trend === "rising" ? <TrendingUp className="h-3 w-3 text-red-400" />
                    : risk.trend === "falling" ? <TrendingDown className="h-3 w-3 text-green-400" />
                    : <Minus className="h-3 w-3 text-yellow-400" />}
                  <span className={cn("text-xs",
                    risk.trend === "rising" && "text-red-400",
                    risk.trend === "falling" && "text-green-400",
                    risk.trend === "stable" && "text-yellow-400",
                  )}>{risk.trend}</span>
                </span>
              </div>
              <p className="text-xs text-muted-foreground">{risk.indicator}</p>
              <p className="text-[10px] text-primary mt-2">{risk.affectedApp}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
