import { useEffect, useState } from "react";
import TierCard from "./TierCard";
import CorrelationDiagram from "./CorrelationDiagram";
import { useModal } from "../context/ModalContext";
import { useToast } from "../context/ToastContext";
import AlertDetailBody from "./modals/AlertDetailBody";
import TierAlertsBody from "./modals/TierAlertsBody";
import AutoFixModalBody from './modals/AutoFixModalBody';

export default function AnalysisView({
  tiers,
  corrData,
  incident,
  rawAlerts,
  rules,
  breadcrumb,
  onBack,
  onGoDetail,
  subJourneyId
}) {
  const { openModal } = useModal();
  const { showToast } = useToast();
  const [activeSection, setActiveSection] = useState("sec-tiers");
  const [isFixing, setIsFixing] = useState(false);

  const subJourneyMode = Boolean(subJourneyId);

  useEffect(() => {
    const onScroll = () => {
      const sections = ["sec-tiers", "sec-corr"];
      let currentIdx = 0;
      const scrollPos = window.pageYOffset + 180;
      sections.forEach((sid, i) => {
        const el = document.getElementById(sid);
        if (el && el.offsetTop <= scrollPos) currentIdx = i;
      });
      setActiveSection(sections[currentIdx]);
    };
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const jumpTo = (id) => {
    const el = document.getElementById(id);
    if (!el) return;
    const y = el.getBoundingClientRect().top + window.pageYOffset - 120;
    window.scrollTo({ top: y, behavior: "smooth" });
  };

  const openAlertModal = (ref) => {
    const a = rawAlerts && rawAlerts[ref];
    if (!a) return;
    const related = rules.filter((r) => r.involves && r.involves.includes(ref));
    openModal({
      title: `${a.src} · ${a.name}`,
      id: `${ref} · ${a.tier} tier · ${a.time}`,
      body: (
        <AlertDetailBody alert={a} relatedRules={related} onOpenRule={() => { }} />
      ),
    });
  };

  const openTierModal = (tier) => {
    openModal({
      title: `${tier.name} Tier · All Alerts`,
      id: `${tier.alertCount} alerts today · click a row for detail`,
      body: (
        <TierAlertsBody tier={tier} rawAlerts={rawAlerts || {}} onOpenAlert={openAlertModal} />
      ),
    });
  };

  const handleAutoFix = () => {
    setIsFixing(true);
    const incidentId = incident?.incident_id || 'INC0048291';
    openModal({
      title: 'Self-Healing Agent',
      id: `Executing Automated Mitigation for ${incidentId}`,
      body: <AutoFixModalBody onComplete={() => {
        setIsFixing(false);
        showToast(`<b>Auto Fix Complete:</b> Mitigation applied successfully.`);
      }} />
    });
  };

  const inc = incident || {};

  return (
    <div className="view">
      <button className="back-btn" onClick={onBack}>
        &larr; Go back
      </button>
      <div className="eyebrow">{breadcrumb}</div>
      <h1>Reliability Analysis</h1>

      <div className="timestamp">
        {subJourneyMode
          ? `Live sub-journey view - alerts on mapped CIs (last ${import.meta.env.VITE_APP_HOURS || 48}h)`
          : `Alert statistics per tier and the derived incident${inc.incident_id ? ` (${inc.incident_id})` : ''}.`}
      </div>

      <div className="section-jump">
        <button
          className={"sj" + (activeSection === "sec-tiers" ? " active" : "")}
          onClick={() => jumpTo("sec-tiers")}
        >
          1 · Tier Contribution
        </button>
        {corrData && (
          <button
            className={"sj" + (activeSection === "sec-corr" ? " active" : "")}
            onClick={() => jumpTo("sec-corr")}
          >
            2 · Alert Correlation
          </button>
        )}
      </div>

      <section id="sec-tiers" className="analysis-section">
        <div className="sec-head">
          <div className="sec-step">01</div>
          <div>
            <h2 className="sec-title">
              {subJourneyMode ? 'CIs and alerts on this sub-journey' : 'Tier Contribution to Incident'}
            </h2>
            <p className="sec-sub">
              {subJourneyMode
                ? 'Live view - alerts scoped to the CIs actually used in this step.'
                : 'Alert statistics grouped by tier - laid out left-to-right in application flow.'}
            </p>
          </div>
        </div>
        <div className="stat-grid">
          {(tiers || []).map((t) => (
            <TierCard key={t.id} tier={t} onViewAll={openTierModal} />
          ))}
        </div>
      </section>

      {corrData && (
        <section id="sec-corr" className="analysis-section">
          <div className="sec-head">
            <div className="sec-step">02</div>
            <div>
              <h2 className="sec-title">Alert Correlation</h2>
              <p className="sec-sub">
                The single incident that ties everything above together.
              </p>
            </div>
          </div>

          <div className="exec-row">
            <div className="exec-card rc">
              <span className="exec-badge">Root Cause</span>
              <h2>
                {incident?.root_cause || "Unknown Root Cause"} {" "}
                <span className="rc-target">{incident?.title || "Incident details missing"}</span>
              </h2>
              <p className="exec-desc" dangerouslySetInnerHTML={{ __html: incident?.root_cause_desc || "Loading incident details..." }}>
              </p>
              <div className="exec-metrics">
                <div className="exec-metric">
                  <div className="m-val">{incident?.raw_alerts_grouped ?? "-"}</div>
                  <div className="m-lbl">raw alerts grouped</div>
                </div>
                <div className="exec-metric">
                  <div className="m-val">{incident?.tools_contributing ?? "-"}</div>
                  <div className="m-lbl">tools contributing</div>
                </div>
                <div className="exec-metric">
                  <div className="m-val">{incident?.correlation_confidence_pct ?? "-"}%</div>
                  <div className="m-lbl">correlation confidence</div>
                </div>
              </div>
            </div>
            <div className="exec-side">
              <h3>Business Impact</h3>
              <div className="impact-row">
                <span className="lb2">Journey affected</span>
                <span className="vv">Health &amp; Dental Claims</span>
              </div>
              <div className="impact-row">
                <span className="lb2">Sub-journey</span>
                <span className="vv">Upload Receipts</span>
              </div>
              <div className="impact-row">
                <span className="lb2">Availability</span>
                <span className="vv bad">69.56 %</span>
              </div>
              <div className="impact-row">
                <span className="lb2">Frustrated users</span>
                <span className="vv bad">8 % · {incident?.frustrated_user_count ?? 152} members</span>
              </div>
              <div className="impact-row">
                <span className="lb2">P95 response</span>
                <span className="vv bad">7,234 ms</span>
              </div>
              <div className="impact-row">
                <span className="lb2">Error rate</span>
                <span className="vv bad">18 %</span>
              </div>
              <div className="impact-row">
                <span className="lb2">Incident ID</span>
                <span className="vv">{incident?.id ?? "INC0048291"}</span>
              </div>
            </div>
          </div>

          <div
            style={{
              display: "flex",
              justifyContent: "flex-start",
              marginBottom: "24px",
            }}
          >
            <button
              className="cta-btn"
              onClick={handleAutoFix}
              disabled={isFixing}
              style={{
                display: "flex",
                alignItems: "center",
                gap: "8px",
                opacity: isFixing ? 0.7 : 1,
                cursor: isFixing ? "wait" : "pointer",
              }}
            >
              <span>{isFixing ? " " : " "}</span>
              {isFixing ? "AUTO FIX IN PROGRESS..." : "AUTO FIX"}
            </button>
          </div>

          <CorrelationDiagram corrData={corrData} tiers={tiers} />

          <div
            style={{
              display: "flex",
              justifyContent: "flex-end",
              alignItems: "center",
              gap: 14,
              marginTop: 20,
            }}
          >
            <span style={{ fontSize: 12, color: "var(--text-dim)" }}>
              Want to see how the engine arrived at this?
            </span>
            <button className="cta-btn ghost" onClick={onGoDetail}>
              Detailed analysis &rarr;
            </button>
          </div>
        </section>
      )}
    </div>
  );
}