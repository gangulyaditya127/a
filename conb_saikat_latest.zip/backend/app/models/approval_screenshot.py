"""SQLAlchemy model for approval screenshot uploads."""

from datetime import datetime
from typing import Optional

from sqlalchemy import ForeignKey, Text, func
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base


class ApprovalScreenshot(Base):
    """Stores a screenshot uploaded by the user as proof for an approval item."""

    __tablename__ = "approval_screenshots"

    id: Mapped[str] = mapped_column(primary_key=True)
    onboarding_id: Mapped[str] = mapped_column(
        ForeignKey("onboardings.id", ondelete="CASCADE"),
    )
    # rec_id corresponds to a Recommendation.id (category='approval')
    rec_id: Mapped[str] = mapped_column(
        ForeignKey("recommendations.id", ondelete="CASCADE"),
    )
    image_data: Mapped[str] = mapped_column(Text)        # base64-encoded file
    filename: Mapped[str] = mapped_column()              # original filename
    content_type: Mapped[str] = mapped_column()          # MIME type
    # Admin review status: 'uploaded', 'approved', 'sent_back'
    admin_status: Mapped[str] = mapped_column(default="uploaded")
    admin_comment: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    uploaded_at: Mapped[datetime] = mapped_column(server_default=func.now())
    reviewed_at: Mapped[Optional[datetime]] = mapped_column(nullable=True)
