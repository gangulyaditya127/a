"""Application configuration using Pydantic Settings."""

from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """Application settings loaded from environment variables or .env file."""

    
    DATABASE_URL:str = ""


    APP_NAME: str = "CloudOps Onboarding API"
    DEBUG: bool = False

    # LLM Configuration
    GEMINI_API_KEY: str = ""
    LLM_MODEL: str = "gemini-2.5-flash"

    model_config = {"env_file": ".env"}


settings = Settings()
