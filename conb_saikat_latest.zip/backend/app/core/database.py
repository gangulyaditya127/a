"""Database engine, session factory, and base model."""

from sqlalchemy import create_engine
from sqlalchemy.orm import DeclarativeBase, Session, sessionmaker
from typing import Generator

from app.core.config import settings


engine = create_engine(settings.DATABASE_URL, echo=settings.DEBUG)

SessionLocal: sessionmaker[Session] = sessionmaker(
    autocommit=False,
    autoflush=False,
    bind=engine,
)


class Base(DeclarativeBase):
    """SQLAlchemy declarative base for all models."""
    pass


def get_db() -> Generator[Session, None, None]:
    """FastAPI dependency that yields a database session and ensures cleanup."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def init_db() -> None:
    """Create all tables defined by Base metadata."""
    # Import all models so they are registered on Base.metadata before create_all
    import app.models  # noqa: F401
    from sqlalchemy import text

    Base.metadata.create_all(bind=engine)

    # Ensure newly added columns on existing tables exist
    with engine.begin() as conn:
        try:
            conn.execute(text("ALTER TABLE architecture_validations ADD COLUMN IF NOT EXISTS user_context TEXT;"))
        except Exception:
            pass
