"""LLM utility for the CloudOps API.

Proxy configuration is explicitly set in main.py during startup.
"""

import logging
from typing import Any

from app.core.config import settings
from app.core.logger import get_logger

logger = get_logger(__name__)

# ---------------------------------------------------------------------------
# Gemini LLM invocation
# ---------------------------------------------------------------------------

def gemini_invoke(
    system_prompt: str,
    history: list[dict[str, str]],
    message: str,
) -> str:
    """Call Gemini LLM and return the raw response text.

    Args:
        system_prompt: The system-level instruction for the model.
        history: List of previous turns as [{"role": "user"|"model", "text": "..."}].
        message: The latest user message.

    Returns:
        Raw LLM response text (may contain markdown, JSON blocks, etc.).
    """
    try:
        import google.generativeai as genai
    except ImportError as exc:
        raise RuntimeError(
            "google-generativeai is not installed. Run: pip install google-generativeai"
        ) from exc

    if not settings.GEMINI_API_KEY:
        raise ValueError(
            "GEMINI_API_KEY is not set. Add it to backend/.env or the environment."
        )

    genai.configure(api_key=settings.GEMINI_API_KEY)

    model = genai.GenerativeModel(
        model_name=settings.LLM_MODEL,
        system_instruction=system_prompt,
    )

    # Convert our history format to Gemini format
    formatted_history = [
        {"role": msg["role"], "parts": [msg["text"]]}
        for msg in history
    ]

    chat = model.start_chat(history=formatted_history)
    response = chat.send_message(message)
    return response.text


# ---------------------------------------------------------------------------
# Gemini multimodal (image + text) invocation
# ---------------------------------------------------------------------------

def invoke_with_image(
    system_prompt: str,
    image_base64: str,
    image_mime: str,
    message: str,
) -> str:
    """Call Gemini with an image for multimodal analysis.

    Args:
        system_prompt: System-level instruction for the model.
        image_base64: Base64-encoded image data.
        image_mime: MIME type of the image (e.g. "image/png").
        message: The user's text message/prompt.

    Returns:
        Raw LLM response text.
    """
    import base64

    try:
        import google.generativeai as genai
    except ImportError as exc:
        raise RuntimeError(
            "google-generativeai is not installed. Run: pip install google-generativeai"
        ) from exc

    if not settings.GEMINI_API_KEY:
        raise ValueError(
            "GEMINI_API_KEY is not set. Add it to backend/.env or the environment."
        )

    genai.configure(api_key=settings.GEMINI_API_KEY)

    model = genai.GenerativeModel(
        model_name=settings.LLM_MODEL,
        system_instruction=system_prompt,
    )

    # Build multimodal content: image + text
    image_bytes = base64.b64decode(image_base64)

    logger.debug(
        "invoke_with_image — model=%s image_size=%d mime=%s",
        settings.LLM_MODEL, len(image_bytes), image_mime,
    )

    response = model.generate_content([
        {
            "mime_type": image_mime,
            "data": image_bytes,
        },
        message,
    ])
    return response.text


# ---------------------------------------------------------------------------
# BFSI LLM invocation
# ---------------------------------------------------------------------------

def bfsi_invoke(
    system_prompt: str,
    history: list[dict[str, str]],
    message: str,
) -> str:
    """Call TCS BFSI GenAI LLM and return the raw response text."""
    try:
        from langchain_tcs_bfsi_genai import APIClient, Auth, TCSLLMs
    except ImportError as exc:
        raise RuntimeError(
            "langchain_tcs_bfsi_genai is not installed."
        ) from exc

    # In a real app, you'd add LLM_USERNAME and LLM_PASSWORD to settings.
    # We fallback to hardcoded for this reference if not found.
    username = getattr(settings, "LLM_USERNAME", "152459")
    password = getattr(settings, "LLM_PASSWORD", "Surajit@152459")
    model_name = "gpt-4o"

    client = APIClient()
    auth = Auth(client)
    auth.login(username, password)

    llm = TCSLLMs(
        client=client,
        model_name=model_name
    )

    history_text = ""
    if history:
        turns = [
            f"{'User' if msg.get('role', '').lower() == 'user' else 'Assistant'}: {msg.get('text', '')}"
            for msg in history
        ]
        history_text = f"\nConversation history:\n{chr(10).join(turns)}\n"

    prompt = f"""{system_prompt}

{history_text}

Latest user message:
User: {message}

Assistant:
"""

    llm_response = llm.invoke(prompt)

    if isinstance(llm_response, str):
        return llm_response
    if hasattr(llm_response, "content"):
        return llm_response.content
    if isinstance(llm_response, dict):
        return (
            llm_response.get("content") or 
            llm_response.get("text") or 
            llm_response.get("response") or 
            str(llm_response)
        )

    return str(llm_response)


# ---------------------------------------------------------------------------
# Public dispatch — call this from service code
# ---------------------------------------------------------------------------

def invoke(
    system_prompt: str,
    history: list[dict[str, str]],
    message: str,
) -> str:
    """Invoke the configured LLM provider.

    Currently uses Gemini as per the user's request. 
    To switch providers in the future, just call bfsi_invoke instead.
    """
    logger.debug("LLM invoke — model=%s history_turns=%d", settings.LLM_MODEL, len(history))
    return gemini_invoke(system_prompt, history, message)