"""Service layer for architecture diagram validation."""

import base64
import json
import re
import uuid
from datetime import datetime, timezone

from fastapi import UploadFile
from sqlalchemy.orm import Session

from app.core import llm as llm_client
from app.core.logger import get_logger
from app.models.architecture_rules import ArchitectureRule
from app.models.architecture_validation import ArchitectureValidation
from app.models.requirements import RequirementAssessment

logger = get_logger(__name__)


async def upload_image(
    db: Session,
    onboarding_id: str,
    file: UploadFile,
    user_context: str | None = None,
) -> ArchitectureValidation:
    """Upload/replace the architecture diagram for an onboarding.

    Resets verdict and violations when a new image is uploaded.
    """
    contents = await file.read()
    image_b64 = base64.b64encode(contents).decode("utf-8")

    existing = (
        db.query(ArchitectureValidation)
        .filter(ArchitectureValidation.onboarding_id == onboarding_id)
        .first()
    )

    if existing:
        existing.image_data = image_b64
        existing.image_filename = file.filename or "diagram.png"
        existing.image_content_type = file.content_type or "image/png"
        if user_context is not None:
            existing.user_context = user_context.strip() if user_context.strip() else None
        existing.verdict = None
        existing.violations = []
        existing.validated_at = None
        db.commit()
        db.refresh(existing)
        return existing

    record = ArchitectureValidation(
        id=str(uuid.uuid4()),
        onboarding_id=onboarding_id,
        image_data=image_b64,
        image_filename=file.filename or "diagram.png",
        image_content_type=file.content_type or "image/png",
        user_context=user_context.strip() if user_context and user_context.strip() else None,
        verdict=None,
        violations=[],
        validated_at=None,
    )
    db.add(record)
    db.commit()
    db.refresh(record)
    return record


def get_validation(
    db: Session,
    onboarding_id: str,
) -> ArchitectureValidation | None:
    """Return the architecture validation record, or None."""
    return (
        db.query(ArchitectureValidation)
        .filter(ArchitectureValidation.onboarding_id == onboarding_id)
        .first()
    )


def validate_architecture(
    db: Session,
    onboarding_id: str,
    user_context: str | None = None,
) -> ArchitectureValidation:
    """Run LLM validation of the uploaded diagram against provider-specific rules."""
    # 1. Get the validation record (must have an uploaded image)
    record = get_validation(db, onboarding_id)
    if not record or not record.image_data:
        raise ValueError("No architecture diagram uploaded for this onboarding.")

    if user_context is not None:
        record.user_context = user_context.strip() if user_context.strip() else None

    # 2. Get the cloud provider from requirements
    req = (
        db.query(RequirementAssessment)
        .filter(RequirementAssessment.onboarding_id == onboarding_id)
        .first()
    )
    cloud_provider = req.cloud_provider if req else "AWS"

    # 3. Get rules for this provider
    rules = (
        db.query(ArchitectureRule)
        .filter(ArchitectureRule.cloud_provider == cloud_provider)
        .all()
    )

    if not rules:
        logger.warning("No architecture rules found for provider=%s", cloud_provider)

    # 4. Build the rules payload for the LLM
    rules_json = json.dumps(
        [
            {
                "category": r.category,
                "rule_text": r.rule_text,
                "severity": r.severity,
            }
            for r in rules
        ],
        indent=2,
    )

    # 5. Build the system prompt
    system_prompt = (
        f"You are a Cloud Architecture Security Analyst specializing in {cloud_provider}.\n"
        "You will be given an image, optional user architecture context/notes, and a set of validation rules.\n\n"
        "You MUST follow these steps IN ORDER:\n\n"
        "STEP 1 — DIAGRAM VERIFICATION:\n"
        "First, determine whether the uploaded image is actually a cloud architecture diagram.\n"
        f"Specifically, check if it is a {cloud_provider} architecture diagram or a generic cloud architecture diagram.\n"
        "If the image is NOT a cloud architecture diagram (e.g. it is a photo, screenshot, flowchart, "
        "org chart, random image, or a diagram for a completely different cloud provider with no relevance), "
        'then respond with verdict \"not_a_diagram\" and explain why in the violations array.\n\n'
        "STEP 2 — RULE VALIDATION (only if Step 1 passes):\n"
        "If the image IS a valid cloud architecture diagram, analyze it against EVERY rule provided and determine:\n"
        '- Whether the architecture is compliant ("valid") or has violations ("invalid")\n'
        "- For each violated rule, describe the specific finding in the diagram\n"
        "- If the user has provided additional Architecture Context/notes, take them into account when evaluating the diagram.\n\n"
        "You MUST respond with ONLY a JSON object in the following format, with no other text:\n"
        "{\n"
        '  "verdict": "valid" or "invalid" or "not_a_diagram",\n'
        '  "violations": [\n'
        "    {\n"
        '      "category": "the rule category",\n'
        '      "rule_text": "the rule that was violated",\n'
        '      "severity": "the severity level",\n'
        '      "finding": "specific description of what in the diagram violates this rule"\n'
        "    }\n"
        "  ]\n"
        "}\n\n"
        "Rules for the verdict field:\n"
        '- "not_a_diagram": Image is not a cloud architecture diagram. '
        "Include one violation with category \"Diagram Verification\", severity \"CRITICAL\", "
        "and a finding explaining what the image actually appears to be.\n"
        '- "valid": Image is a valid architecture diagram and passes all rules. Empty violations array.\n'
        '- "invalid": Image is a valid architecture diagram but has rule violations. List all violations.\n\n'
        "If you cannot clearly determine compliance for a rule, err on the side of flagging it.\n"
        "Only return the JSON object, nothing else."
    )

    context_section = ""
    if record.user_context:
        context_section = f"User-Provided Architecture Context / Notes:\n\"{record.user_context}\"\n\n"

    message = (
        f"Analyze this image. First verify it is a {cloud_provider} cloud architecture diagram. "
        f"{context_section}"
        f"If it is, validate it against these {cloud_provider} rules:\n\n"
        f"{rules_json}\n\n"
        "Return the JSON verdict."
    )

    # 6. Call the multimodal LLM
    logger.info(
        "Validating architecture for onboarding=%s provider=%s rules=%d has_context=%s",
        onboarding_id,
        cloud_provider,
        len(rules),
        bool(record.user_context),
    )
    raw_response = llm_client.invoke_with_image(
        system_prompt=system_prompt,
        image_base64=record.image_data,
        image_mime=record.image_content_type,
        message=message,
    )

    # 7. Parse the LLM response
    verdict = "invalid"
    violations: list[dict] = []

    try:
        # Try to extract JSON from the response (may be wrapped in ```json blocks)
        json_match = re.search(r"```json\s*(.*?)\s*```", raw_response, re.DOTALL)
        if json_match:
            parsed = json.loads(json_match.group(1))
        else:
            # Try parsing the entire response as JSON
            parsed = json.loads(raw_response.strip())

        verdict = parsed.get("verdict", "invalid")
        violations = parsed.get("violations", [])
    except (json.JSONDecodeError, AttributeError) as e:
        logger.error("Failed to parse LLM validation response: %s", e)
        violations = [
            {
                "category": "Parse Error",
                "rule_text": "LLM response parsing",
                "severity": "HIGH",
                "finding": f"Could not parse LLM response. Raw output: {raw_response[:500]}",
            }
        ]

    # 8. Update the record
    record.verdict = verdict
    record.violations = violations
    record.validated_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(record)

    logger.info("Validation complete: verdict=%s violations=%d", verdict, len(violations))
    return record
