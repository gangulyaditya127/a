from typing import Annotated, Optional
from fastapi import APIRouter, Depends, HTTPException, Response, UploadFile, File, Form, Body
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.domains.architecture import service
from app.domains.architecture.schemas import UploadResponse, ValidationResponse, ValidateRequest

NOT_FOUND_RESPONSE = {404: {"description": "Not found"}}
VALIDATE_RESPONSES = {
    400: {"description": "Bad Request - Validation Error"},
    500: {"description": "Internal Server Error - Validation Failed"},
}

router = APIRouter()


@router.post("/{onboarding_id}/upload", response_model=UploadResponse)
async def upload_diagram(
    onboarding_id: str,
    file: Annotated[UploadFile, File(...)],
    db: Annotated[Session, Depends(get_db)],
    user_context: Annotated[Optional[str], Form()] = None,
):
    """Upload or replace the architecture diagram for an onboarding."""
    record = await service.upload_image(db, onboarding_id, file, user_context=user_context)
    return UploadResponse(
        id=record.id,
        onboarding_id=record.onboarding_id,
        image_filename=record.image_filename,
        user_context=record.user_context,
        message="Diagram uploaded successfully.",
    )


@router.post("/{onboarding_id}/validate", response_model=ValidationResponse, responses=VALIDATE_RESPONSES)
def validate_diagram(
    onboarding_id: str,
    db: Annotated[Session, Depends(get_db)],
    payload: Optional[ValidateRequest] = Body(default=None),
):
    """Trigger LLM validation of the uploaded architecture diagram."""
    try:
        user_context = payload.user_context if payload else None
        return service.validate_architecture(db, onboarding_id, user_context=user_context)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Validation failed: {str(e)}")


@router.get("/{onboarding_id}", response_model=ValidationResponse, responses=NOT_FOUND_RESPONSE)
def get_validation(
    onboarding_id: str,
    db: Annotated[Session, Depends(get_db)],
):
    """Return the current validation state (image info + verdict + violations)."""
    record = service.get_validation(db, onboarding_id)
    if not record:
        raise HTTPException(status_code=404, detail="No architecture validation found")
    return record


@router.get("/{onboarding_id}/image", responses=NOT_FOUND_RESPONSE)
def get_image(
    onboarding_id: str,
    db: Annotated[Session, Depends(get_db)],
):
    """Return the uploaded architecture diagram as a binary image response."""
    import base64

    record = service.get_validation(db, onboarding_id)
    if not record or not record.image_data:
        raise HTTPException(status_code=404, detail="No diagram image found")

    image_bytes = base64.b64decode(record.image_data)
    return Response(
        content=image_bytes,
        media_type=record.image_content_type,
        headers={"Content-Disposition": f'inline; filename="{record.image_filename}"'},
    )