"""Service layer for user-facing approval screenshot uploads."""

import base64
import uuid
from datetime import datetime, timezone

from sqlalchemy.orm import Session

from app.models.approval_screenshot import ApprovalScreenshot
from app.models.recommendation import Recommendation
from app.models.interaction_event import InteractionEvent


def _log_event(
    db: Session,
    onboarding_id: str,
    actor: str,
    actor_name: str,
    kind: str,
    title: str,
    body: str | None = None,
    scope: str | None = None,
) -> None:
    event = InteractionEvent(
        id=str(uuid.uuid4()),
        onboarding_id=onboarding_id,
        actor=actor,
        actor_name=actor_name,
        kind=kind,
        title=title,
        body=body,
        scope=scope,
    )
    db.add(event)


async def upload_screenshot(
    db: Session,
    onboarding_id: str,
    rec_id: str,
    file,
    user_name: str | None = None,
) -> ApprovalScreenshot:
    """Save an uploaded screenshot for a specific approval item."""
    content = await file.read()
    encoded = base64.b64encode(content).decode("utf-8")

    # Create a new screenshot record for this approval item (supports multiple proofs)
    screenshot = ApprovalScreenshot(
        id=str(uuid.uuid4()),
        onboarding_id=onboarding_id,
        rec_id=rec_id,
        image_data=encoded,
        filename=file.filename,
        content_type=file.content_type,
        admin_status="uploaded",
    )
    db.add(screenshot)

    # Fetch the recommendation title for the event log
    rec = db.query(Recommendation).filter(Recommendation.id == rec_id).first()
    title_label = rec.title if rec else rec_id

    _log_event(
        db, onboarding_id,
        "user", user_name or "Requestor",
        "publish",
        f"Uploaded screenshot for: {title_label}",
        scope="Approval Upload",
    )

    # Clear sent_back status on previous screenshots for this rec_id since a new proof has been provided
    prev_sent_backs = (
        db.query(ApprovalScreenshot)
        .filter(
            ApprovalScreenshot.onboarding_id == onboarding_id,
            ApprovalScreenshot.rec_id == rec_id,
            ApprovalScreenshot.admin_status == "sent_back",
        )
        .all()
    )
    for ps in prev_sent_backs:
        ps.admin_status = "uploaded"

    # Sync status to the parent onboarding table
    from app.models.onboarding import Onboarding
    ob = db.query(Onboarding).filter(Onboarding.id == onboarding_id).first()
    if ob:
        # Note: We do NOT automatically move admin_status to approvals_under_review here.
        # The user will explicitly click "Submit for Admin Review" when all proofs are attached.

        # Sync into remaining_state['approvals'] if present
        if ob.remaining_state and "approvals" in ob.remaining_state:
            rem_state = dict(ob.remaining_state)
            approvals_list = list(rem_state.get("approvals", []))
            found = False
            for item in approvals_list:
                if item.get("id") == rec_id or item.get("title") == title_label:
                    item["screenshotFilename"] = file.filename
                    item["adminStatus"] = "uploaded"
                    item["adminComment"] = None
                    found = True
            if not found:
                approvals_list.append({
                    "id": rec_id,
                    "title": title_label,
                    "screenshotFilename": file.filename,
                    "adminStatus": "uploaded",
                    "adminComment": None,
                    "status": "pending",
                })
            rem_state["approvals"] = approvals_list
            ob.remaining_state = rem_state

    db.commit()
    db.refresh(screenshot)
    return screenshot


def get_screenshot(
    db: Session,
    onboarding_id: str,
    rec_id: str,
) -> ApprovalScreenshot | None:
    return (
        db.query(ApprovalScreenshot)
        .filter(
            ApprovalScreenshot.onboarding_id == onboarding_id,
            ApprovalScreenshot.rec_id == rec_id,
        )
        .order_by(ApprovalScreenshot.uploaded_at.desc())
        .first()
    )


def get_screenshot_by_id(
    db: Session,
    screenshot_id: str,
    onboarding_id: str,
) -> ApprovalScreenshot | None:
    return (
        db.query(ApprovalScreenshot)
        .filter(
            ApprovalScreenshot.id == screenshot_id,
            ApprovalScreenshot.onboarding_id == onboarding_id,
        )
        .first()
    )


def delete_screenshot(
    db: Session,
    screenshot_id: str,
    onboarding_id: str,
) -> bool:
    screenshot = (
        db.query(ApprovalScreenshot)
        .filter(
            ApprovalScreenshot.id == screenshot_id,
            ApprovalScreenshot.onboarding_id == onboarding_id,
        )
        .first()
    )
    if not screenshot:
        return False

    rec_id = screenshot.rec_id
    db.delete(screenshot)
    db.commit()

    # Check remaining screenshots for this onboarding and rec_id
    remaining = (
        db.query(ApprovalScreenshot)
        .filter(ApprovalScreenshot.onboarding_id == onboarding_id)
        .all()
    )
    remaining_for_rec = [s for s in remaining if s.rec_id == rec_id]

    from app.models.onboarding import Onboarding
    ob = db.query(Onboarding).filter(Onboarding.id == onboarding_id).first()
    if ob and ob.remaining_state and "approvals" in ob.remaining_state:
        rem_state = dict(ob.remaining_state)
        approvals_list = list(rem_state.get("approvals", []))
        for item in approvals_list:
            if item.get("id") == rec_id:
                if remaining_for_rec:
                    item["screenshotFilename"] = remaining_for_rec[-1].filename
                    item["adminStatus"] = remaining_for_rec[-1].admin_status
                else:
                    item["screenshotFilename"] = None
                    item["adminStatus"] = "pending_upload"
        rem_state["approvals"] = approvals_list
        ob.remaining_state = rem_state
        db.commit()

    return True


def list_screenshots(
    db: Session,
    onboarding_id: str,
) -> list[dict]:
    """Return grouped metadata for all uploaded approval screenshots for an onboarding."""
    screenshots = (
        db.query(ApprovalScreenshot)
        .filter(ApprovalScreenshot.onboarding_id == onboarding_id)
        .order_by(ApprovalScreenshot.uploaded_at.asc())
        .all()
    )
    grouped: dict[str, dict] = {}
    for s in screenshots:
        if s.rec_id not in grouped:
            grouped[s.rec_id] = {
                "id": s.id,
                "rec_id": s.rec_id,
                "filename": s.filename,
                "content_type": s.content_type,
                "admin_status": s.admin_status,
                "admin_comment": s.admin_comment,
                "uploaded_at": s.uploaded_at.isoformat() if s.uploaded_at else None,
                "images": [],
            }
        grouped[s.rec_id]["images"].append({
            "id": s.id,
            "filename": s.filename,
            "content_type": s.content_type,
            "admin_status": s.admin_status,
            "admin_comment": s.admin_comment,
            "uploaded_at": s.uploaded_at.isoformat() if s.uploaded_at else None,
        })

    for rec_id, g in grouped.items():
        imgs = g["images"]
        if all(i["admin_status"] == "approved" for i in imgs):
            g["admin_status"] = "approved"
            g["admin_comment"] = None
        elif any(i["admin_status"] == "uploaded" for i in imgs):
            g["admin_status"] = "uploaded"
            g["admin_comment"] = None
        elif any(i["admin_status"] == "sent_back" for i in imgs):
            g["admin_status"] = "sent_back"
            comments = [i["admin_comment"] for i in imgs if i["admin_status"] == "sent_back" and i["admin_comment"]]
            g["admin_comment"] = comments[-1] if comments else None
        else:
            g["admin_status"] = "uploaded"
            g["admin_comment"] = None

    return list(grouped.values())


def submit_approval_screenshots(
    db: Session,
    onboarding_id: str,
    user_name: str | None = None,
) -> dict:
    """Explicitly submit all uploaded approval screenshots for admin review."""
    from app.models.onboarding import Onboarding
    from app.models.approval_screenshot import ApprovalScreenshot

    ob = db.query(Onboarding).filter(Onboarding.id == onboarding_id).first()
    if not ob:
        return {"ok": False, "error": "Onboarding not found"}

    ob.admin_status = "approvals_under_review"

    # Reset any sent-back screenshots so they are now in review
    sent_backs = (
        db.query(ApprovalScreenshot)
        .filter(
            ApprovalScreenshot.onboarding_id == onboarding_id,
            ApprovalScreenshot.admin_status == "sent_back",
        )
        .all()
    )
    for s in sent_backs:
        s.admin_status = "uploaded"

    # Sync into remaining_state['approvals'] if present
    if ob.remaining_state and "approvals" in ob.remaining_state:
        rem_state = dict(ob.remaining_state)
        approvals_list = list(rem_state.get("approvals", []))
        for item in approvals_list:
            if item.get("adminStatus") == "sent_back":
                item["adminStatus"] = "uploaded"
        rem_state["approvals"] = approvals_list
        ob.remaining_state = rem_state

    _log_event(
        db, onboarding_id,
        "user", user_name or "Requestor",
        "publish",
        "Submitted approval proofs for admin review",
        scope="Approval Workflow",
    )
    db.commit()
    return {"ok": True, "admin_status": "approvals_under_review"}
