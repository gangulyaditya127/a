"""API router for the cloud resources domain."""

from typing import Annotated
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.domains.cloud_resources import service
from app.domains.cloud_resources.schemas import (
    BucketResponse,
    BucketUpsert,
    ChatRequest,
    ChatResponse,
)

CHAT_RESPONSES = {500: {"description": "Internal Server Error - Chat failed"}}
NOT_FOUND_RESPONSE = {404: {"description": "Cloud resource bucket not found"}}

router = APIRouter()


@router.post("/chat", responses=CHAT_RESPONSES)
def chat_with_architect(request: ChatRequest) -> ChatResponse:
    """Run a conversational turn with the AI Cloud Architect.

    The LLM may return proposed resources embedded in a ```json block.
    The endpoint parses and returns them separately from the reply text.
    """
    try:
        return service.chat(request)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@router.get("/{onboarding_id}/bucket", responses=NOT_FOUND_RESPONSE)
def get_bucket(
    onboarding_id: str,
    db: Annotated[Session, Depends(get_db)],
) -> BucketResponse:
    """Retrieve the approved cloud resource bucket for an onboarding."""
    bucket = service.get_bucket(db, onboarding_id)
    if bucket is None:
        raise HTTPException(status_code=404, detail="Cloud resource bucket not found")
    return bucket


@router.put("/{onboarding_id}/bucket")
def upsert_bucket(
    onboarding_id: str,
    data: BucketUpsert,
    db: Annotated[Session, Depends(get_db)],
) -> BucketResponse:
    """Create or update the approved cloud resource bucket for an onboarding."""
    return service.upsert_bucket(db, onboarding_id, data)