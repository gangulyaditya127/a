"""Admin API router for DIS Admin onboarding management."""

from typing import Annotated
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.domains.auth.dependencies import require_admin
from app.models.user import User
from app.admin.disadmin import service
from app.admin.disadmin.schemas import (
    AdminDashboardData,
    CostEstimationResponse,
    CostEstimationUpsert,
    FeedbackCreate,
    FeedbackResponse,
    OnboardingDetail,
    OnboardingSummary,
    OtherOnboardingsResponse,
    RecommendationResponse,
    RecommendationUpdate,
    SendBackRequest,
)

ONBOARDING_NOT_FOUND_MSG = "Onboarding not found"
RECOMMENDATION_NOT_FOUND_MSG = "Recommendation not found"
COST_NOT_FOUND_MSG = "Cost estimation not found"

NOT_FOUND_RESPONSE = {404: {"description": ONBOARDING_NOT_FOUND_MSG}}
REC_NOT_FOUND_RESPONSE = {404: {"description": RECOMMENDATION_NOT_FOUND_MSG}}
COST_NOT_FOUND_RESPONSE = {404: {"description": COST_NOT_FOUND_MSG}}
BAD_REQUEST_RESPONSE = {400: {"description": "Bad Request - Invalid parameters or state"}}

router = APIRouter()


@router.get("/dashboard")
def dashboard(
    db: Annotated[Session, Depends(get_db)],
    admin: Annotated[User, Depends(require_admin)],
    status: str | None = None,
    search: str | None = None,
) -> AdminDashboardData:
    """Return onboardings assigned to the current admin."""
    return service.get_dashboard(db, admin, status=status, search=search)


@router.get("/onboardings/{onboarding_id}", responses=NOT_FOUND_RESPONSE)
def get_onboarding(
    onboarding_id: str,
    db: Annotated[Session, Depends(get_db)],
    admin: Annotated[User, Depends(require_admin)],
) -> OnboardingDetail:
    """Return full onboarding detail for admin review."""
    ob, is_read_only = service.get_onboarding_detail(db, onboarding_id, admin)
    if ob is None:
        raise HTTPException(status_code=404, detail=ONBOARDING_NOT_FOUND_MSG)
    detail = OnboardingDetail.model_validate(ob)
    detail.is_read_only = is_read_only
    return detail


@router.get("/other-onboardings")
def other_onboardings(
    db: Annotated[Session, Depends(get_db)],
    admin: Annotated[User, Depends(require_admin)],
    offset: int = 0,
    limit: int = 10,
    search: str | None = None,
) -> OtherOnboardingsResponse:
    """Return onboardings NOT assigned to the current admin (paginated)."""
    return service.get_other_onboardings(db, admin, offset=offset, limit=limit, search=search)


@router.post("/onboardings/{onboarding_id}/feedback", status_code=201, responses=BAD_REQUEST_RESPONSE)
def submit_feedback(
    onboarding_id: str,
    data: FeedbackCreate,
    db: Annotated[Session, Depends(get_db)],
    admin: Annotated[User, Depends(require_admin)],
) -> FeedbackResponse:
    """Submit validation feedback for an onboarding section."""
    valid_sections = {"account_details", "requirements", "cloud_resources", "architecture"}
    if data.section not in valid_sections:
        raise HTTPException(status_code=400, detail=f"Invalid section. Must be one of: {valid_sections}")

    valid_statuses = {"approved", "rejected", "comment"}
    if data.status not in valid_statuses:
        raise HTTPException(status_code=400, detail=f"Invalid status. Must be one of: {valid_statuses}")

    return service.submit_feedback(db, onboarding_id, admin, data)


@router.post("/onboardings/{onboarding_id}/approve", responses=BAD_REQUEST_RESPONSE)
def approve_onboarding(
    onboarding_id: str,
    db: Annotated[Session, Depends(get_db)],
    admin: Annotated[User, Depends(require_admin)],
) -> dict:
    """Approve an onboarding — all 4 sections must be individually approved first."""
    success = service.approve_onboarding(db, onboarding_id, admin)
    if not success:
        raise HTTPException(
            status_code=400,
            detail="Cannot approve: all sections (account_details, requirements, cloud_resources, architecture) must be approved first",
        )
    return {"message": "Onboarding approved", "admin_status": "cost_pending"}


@router.post("/onboardings/{onboarding_id}/send-back", responses=NOT_FOUND_RESPONSE)
def send_back(
    onboarding_id: str,
    data: SendBackRequest,
    db: Annotated[Session, Depends(get_db)],
    admin: Annotated[User, Depends(require_admin)],
) -> dict:
    """Send onboarding back to user with a comment."""
    success = service.send_back(db, onboarding_id, admin, data.comment)
    if not success:
        raise HTTPException(status_code=404, detail=ONBOARDING_NOT_FOUND_MSG)
    return {"message": "Onboarding sent back to user", "admin_status": "sent_back"}


@router.put("/onboardings/{onboarding_id}/cost")
def upsert_cost(
    onboarding_id: str,
    data: CostEstimationUpsert,
    db: Annotated[Session, Depends(get_db)],
    admin: Annotated[User, Depends(require_admin)],
) -> CostEstimationResponse:
    """Create or update cost estimation for an onboarding."""
    return service.upsert_cost(db, onboarding_id, admin, data)


@router.get("/onboardings/{onboarding_id}/cost/seed-from-bucket")
def seed_cost_from_bucket(
    onboarding_id: str,
    admin: Annotated[User, Depends(require_admin)],
    db: Annotated[Session, Depends(get_db)],
) -> list[dict]:
    """Return cost line items pre-populated from cloud resource bucket."""
    return service.seed_cost_from_bucket(db, onboarding_id)


@router.get("/onboardings/{onboarding_id}/cost", responses=COST_NOT_FOUND_RESPONSE)
def get_cost(
    onboarding_id: str,
    db: Annotated[Session, Depends(get_db)],
    admin: Annotated[User, Depends(require_admin)],
) -> CostEstimationResponse | None:
    """Get cost estimation for an onboarding."""
    cost = service.get_cost(db, onboarding_id)
    if cost is None:
        raise HTTPException(status_code=404, detail=COST_NOT_FOUND_MSG)
    return cost


@router.post(
    "/onboardings/{onboarding_id}/recommendations/generate",
    responses=NOT_FOUND_RESPONSE,
)
def generate_recommendations(
    onboarding_id: str,
    db: Annotated[Session, Depends(get_db)],
    admin: Annotated[User, Depends(require_admin)],
) -> list[RecommendationResponse]:
    """Generate GPS, RFC, and approval recommendations using LLM."""
    try:
        # Fixed: Removed the 'admin' parameter to match the updated service layer
        return service.generate_recommendations(db, onboarding_id)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc))


@router.get("/onboardings/{onboarding_id}/recommendations")
def get_recommendations(
    onboarding_id: str,
    db: Annotated[Session, Depends(get_db)],
    admin: Annotated[User, Depends(require_admin)],
) -> list[RecommendationResponse]:
    """Get existing recommendations for an onboarding."""
    return service.get_recommendations(db, onboarding_id)


@router.put(
    "/onboardings/{onboarding_id}/recommendations/{rec_id}",
    responses=REC_NOT_FOUND_RESPONSE,
)
def update_recommendation(
    onboarding_id: str,
    rec_id: str,
    data: RecommendationUpdate,
    db: Annotated[Session, Depends(get_db)],
    admin: Annotated[User, Depends(require_admin)],
) -> RecommendationResponse:
    """Edit a specific recommendation."""
    rec = service.update_recommendation(db, rec_id, data)
    if rec is None:
        raise HTTPException(status_code=404, detail=RECOMMENDATION_NOT_FOUND_MSG)
    return rec


@router.post("/onboardings/{onboarding_id}/send-to-user", responses=NOT_FOUND_RESPONSE)
def send_to_user(
    onboarding_id: str,
    db: Annotated[Session, Depends(get_db)],
    admin: Annotated[User, Depends(require_admin)],
) -> dict:
    """Send recommendations and cost to user."""
    success = service.send_to_user(db, onboarding_id)
    if not success:
        raise HTTPException(status_code=404, detail=ONBOARDING_NOT_FOUND_MSG)
    return {"message": "Recommendations sent to user", "admin_status": "approval_checklist_sent"}


@router.get("/onboardings/{onboarding_id}/events")
def get_events(
    onboarding_id: str,
    db: Annotated[Session, Depends(get_db)],
    admin: Annotated[User, Depends(require_admin)],
) -> list[dict]:
    """Return interaction events for activity timeline."""
    return service.get_interaction_events(db, onboarding_id)


@router.get("/onboardings/{onboarding_id}/approval-screenshots")
def get_approval_screenshots(
    onboarding_id: str,
    db: Annotated[Session, Depends(get_db)],
    admin: Annotated[User, Depends(require_admin)],
) -> list[dict]:
    """Return all uploaded approval screenshots for admin review."""
    return service.get_approval_screenshots(db, onboarding_id)


@router.post("/onboardings/{onboarding_id}/approval-screenshots/{rec_id}/approve")
def admin_approve_screenshot(
    onboarding_id: str,
    rec_id: str,
    db: Annotated[Session, Depends(get_db)],
    admin: Annotated[User, Depends(require_admin)],
) -> dict:
    """Approve a user-uploaded approval screenshot."""
    success = service.admin_approve_screenshot(db, onboarding_id, rec_id, admin)
    if not success:
        raise HTTPException(status_code=404, detail="Screenshot not found")
    return {"ok": True}


@router.post("/onboardings/{onboarding_id}/approval-screenshots/{rec_id}/send-back")
def admin_send_back_screenshot(
    onboarding_id: str,
    rec_id: str,
    data: SendBackRequest,
    db: Annotated[Session, Depends(get_db)],
    admin: Annotated[User, Depends(require_admin)],
) -> dict:
    """Send back an approval screenshot to the user for re-upload."""
    success = service.admin_send_back_screenshot(db, onboarding_id, rec_id, admin, data.comment)
    if not success:
        raise HTTPException(status_code=404, detail="Screenshot not found")
    return {"ok": True}