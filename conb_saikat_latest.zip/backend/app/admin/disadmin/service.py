"""Service layer for DIS Admin operations."""

import json
import uuid

from sqlalchemy.orm import Session, joinedload

from app.core.llm import gemini_invoke
from app.core.logger import get_logger
from app.models.admin_assignment import AdminAssignment
from app.models.approval_rule import ApprovalRule
from app.models.cost_estimation import CostEstimation
from app.models.onboarding import Onboarding
from app.models.recommendation import Recommendation
from app.models.user import User
from app.models.validation_feedback import ValidationFeedback
from app.models.interaction_event import InteractionEvent
from app.admin.disadmin.schemas import (
    CostEstimationUpsert,
    FeedbackCreate,
    RecommendationUpdate,
)

logger = get_logger(__name__)


# ── Helpers ──────────────────────────────────────────────────────────────────

def _log_event(
    db: Session,
    onboarding_id: str,
    actor: str,
    actor_name: str,
    kind: str,
    title: str,
    body: str | None = None,
    scope: str | None = None,
) -> InteractionEvent:
    """Append an interaction event to the onboarding's activity timeline."""
    event = InteractionEvent(
        id=str(uuid.uuid4()),
        onboarding_id=onboarding_id,
        actor=actor,
        actor_name=actor_name,
        kind=kind,
        title=title,
        body=body,
        scope=scope,
    )
    db.add(event)
    return event


def _load_onboarding(db: Session, onboarding_id: str) -> Onboarding:
    """Load an onboarding with all eager-loaded relationships."""
    ob = (
        db.query(Onboarding)
        .options(
            joinedload(Onboarding.account_details),
            joinedload(Onboarding.requirement_assessment),
            joinedload(Onboarding.cloud_resource_bucket),
            joinedload(Onboarding.architecture_validation),
            joinedload(Onboarding.admin_assignment),
            joinedload(Onboarding.validation_feedbacks),
            joinedload(Onboarding.cost_estimation),
            joinedload(Onboarding.recommendations),
            joinedload(Onboarding.interaction_events),
            joinedload(Onboarding.user),
        )
        .filter(Onboarding.id == onboarding_id)
        .first()
    )
    return ob


def _is_assigned_to_admin(ob: Onboarding, admin: User) -> bool:
    """Check whether the onboarding is assigned to this admin."""
    if admin.role == "superadmin":
        return True
    return ob.admin_assignment is not None and ob.admin_assignment.admin_id == admin.id


# ── Dashboard ────────────────────────────────────────────────────────────────

def get_dashboard(
    db: Session,
    admin: User,
    status: str | None = None,
    search: str | None = None,
) -> dict:
    """Return dashboard data: stats + onboardings assigned to this admin."""
    query = (
        db.query(Onboarding)
        .join(AdminAssignment, AdminAssignment.onboarding_id == Onboarding.id)
        .options(
            joinedload(Onboarding.account_details),
            joinedload(Onboarding.requirement_assessment),
            joinedload(Onboarding.admin_assignment),
            joinedload(Onboarding.user),
        )
        .filter(AdminAssignment.admin_id == admin.id)
        .filter(AdminAssignment.status == "active")
    )

    all_onboardings = query.order_by(Onboarding.created_at.desc()).all()

    # Count by admin_status
    total = len(all_onboardings)
    pending_review = sum(1 for o in all_onboardings if o.admin_status in ("assigned", "under_review", "approvals_under_review"))
    approved = sum(1 for o in all_onboardings if o.admin_status in ("approved", "approvals_approved"))
    sent_back = sum(1 for o in all_onboardings if o.admin_status in ("sent_back", "approvals_sent_back"))
    cost_pending = sum(1 for o in all_onboardings if o.admin_status == "cost_pending")
    recommendations_pending = sum(1 for o in all_onboardings if o.admin_status in ("cost_done", "approval_checklist_sent"))

    # Apply filters for the returned list
    filtered = all_onboardings
    if status:
        filtered = [o for o in all_onboardings if o.admin_status == status]
    if search:
        filtered = [o for o in filtered if search.lower() in (o.name or "").lower()]

    return {
        "total_assigned": total,
        "pending_review": pending_review,
        "approved": approved,
        "sent_back": sent_back,
        "cost_pending": cost_pending,
        "recommendations_pending": recommendations_pending,
        "onboardings": filtered,
    }


# ── Detail ───────────────────────────────────────────────────────────────────

def get_onboarding_detail(
    db: Session, onboarding_id: str, admin: User,
) -> tuple[Onboarding | None, bool]:
    """Return full onboarding detail for any admin."""
    ob = _load_onboarding(db, onboarding_id)
    if ob is None:
        return None, False
    is_read_only = not _is_assigned_to_admin(ob, admin)
    return ob, is_read_only


# ── Other Onboardings ────────────────────────────────────────────────────────

def get_other_onboardings(
    db: Session,
    admin: User,
    offset: int = 0,
    limit: int = 10,
    search: str | None = None,
) -> dict:
    """Return onboardings NOT assigned to the current admin, paginated."""
    from sqlalchemy import or_, func as sa_func

    query = (
        db.query(Onboarding)
        .outerjoin(AdminAssignment, AdminAssignment.onboarding_id == Onboarding.id)
        .options(
            joinedload(Onboarding.account_details),
            joinedload(Onboarding.requirement_assessment),
            joinedload(Onboarding.admin_assignment),
            joinedload(Onboarding.user),
        )
        .filter(
            or_(
                AdminAssignment.id.is_(None),           # unassigned
                AdminAssignment.admin_id != admin.id,    # assigned to someone else
            )
        )
    )

    if search:
        query = query.filter(
            or_(
                Onboarding.name.ilike(f"%{search}%"),
                Onboarding.id.ilike(f"%{search}%"),
            )
        )

    total_count = query.with_entities(sa_func.count(Onboarding.id)).scalar() or 0
    onboardings = query.order_by(Onboarding.created_at.desc()).offset(offset).limit(limit).all()

    return {
        "total_count": total_count,
        "onboardings": onboardings,
    }


# ── Feedback ─────────────────────────────────────────────────────────────────

def submit_feedback(
    db: Session, onboarding_id: str, admin: User, data: FeedbackCreate,
) -> ValidationFeedback:
    """Create validation feedback for a section."""
    feedback = ValidationFeedback(
        id=str(uuid.uuid4()),
        onboarding_id=onboarding_id,
        admin_id=admin.id,
        section=data.section,
        status=data.status,
        comment=data.comment,
    )
    db.add(feedback)

    ob = db.query(Onboarding).filter(Onboarding.id == onboarding_id).first()
    if ob and ob.admin_status in ("assigned", "under_review"):
        ob.admin_status = "under_review"

    db.commit()
    _log_event(
        db, onboarding_id, "admin", admin.name,
        "decision" if data.status == "approved" else "comment",
        f"{'Approved' if data.status == 'approved' else 'Requested changes for'} {data.section.replace('_', ' ').title()}",
        body=data.comment,
        scope=data.section.replace('_', ' ').title(),
    )
    db.commit()
    db.refresh(feedback)
    return feedback


# ── Approve ──────────────────────────────────────────────────────────────────

def approve_onboarding(db: Session, onboarding_id: str, admin: User) -> bool:
    """Approve the full onboarding — all 4 sections must be approved."""
    ob = _load_onboarding(db, onboarding_id)
    if ob is None:
        return False

    required_sections = {"account_details", "requirements", "cloud_resources", "architecture"}
    approved_sections = set()
    for fb in ob.validation_feedbacks:
        if fb.status == "approved":
            approved_sections.add(fb.section)

    if not required_sections.issubset(approved_sections):
        return False

    ob.admin_status = "cost_pending"
    _log_event(
        db, onboarding_id, "admin", admin.name,
        "decision", "Approved all sections — proceeding to cost budgeting",
    )
    db.commit()
    return True


# ── Send-back ────────────────────────────────────────────────────────────────

def send_back(db: Session, onboarding_id: str, admin: User, comment: str) -> bool:
    """Send onboarding back to user with a comment."""
    ob = (
        db.query(Onboarding)
        .options(joinedload(Onboarding.validation_feedbacks))
        .filter(Onboarding.id == onboarding_id)
        .first()
    )
    if ob is None:
        return False

    ob.admin_status = "sent_back"
    comments = list(ob.admin_comments) if ob.admin_comments else []

    section_labels = {
        "account_details": "Account Details",
        "requirements": "Requirements",
        "cloud_resources": "Cloud Resources",
        "architecture": "Architecture",
    }
    section_comments = []
    for fb in ob.validation_feedbacks:
        if fb.status == "rejected" and fb.comment:
            section_comments.append({
                "section": fb.section,
                "section_label": section_labels.get(fb.section, fb.section),
                "comment": fb.comment,
            })

    comments.append({
        "admin_id": admin.id,
        "admin_name": admin.name,
        "comment": comment,
        "section_comments": section_comments,
        "timestamp": str(uuid.uuid4())[:8],
    })
    ob.admin_comments = comments

    _log_event(
        db, onboarding_id, "admin", admin.name,
        "decision", "Sent back to user for changes",
        body=comment,
    )
    db.commit()
    return True


# ── Resubmit (User) ──────────────────────────────────────────────────────────

def resubmit_onboarding(
    db: Session,
    onboarding_id: str,
    user_name: str | None = None,
    comment: str | None = None,
) -> bool:
    """User resubmits after making changes — reset for admin re-review."""
    ob = (
        db.query(Onboarding)
        .options(
            joinedload(Onboarding.admin_assignment),
            joinedload(Onboarding.validation_feedbacks),
            joinedload(Onboarding.user),
        )
        .filter(Onboarding.id == onboarding_id)
        .first()
    )
    if ob is None:
        return False

    db.query(ValidationFeedback).filter(
        ValidationFeedback.onboarding_id == onboarding_id,
    ).delete()

    if ob.admin_assignment is not None:
        ob.admin_status = "assigned"
    else:
        ob.admin_status = "pending_assignment"

    actor_name = user_name or (ob.user.name if ob.user else "Requestor")
    _log_event(
        db, onboarding_id, "user", actor_name,
        "submission", "Resubmitted onboarding for review",
        body=comment.strip() if comment and comment.strip() else None,
    )
    db.commit()
    return True


# ── Cost Estimation ──────────────────────────────────────────────────────────

def upsert_cost(
    db: Session, onboarding_id: str, admin: User, data: CostEstimationUpsert,
) -> CostEstimation:
    """Create or update cost estimation."""
    existing = (
        db.query(CostEstimation)
        .filter(CostEstimation.onboarding_id == onboarding_id)
        .first()
    )

    cost_data = [item.model_dump() for item in data.resource_costs]

    if existing:
        existing.resource_costs = cost_data
        existing.infra_support_cost = data.infra_support_cost
        existing.total_monthly_cost = data.total_monthly_cost
        existing.total_annual_cost = data.total_annual_cost
        existing.currency = data.currency
        existing.notes = data.notes
        existing.admin_id = admin.id
        cost = existing
    else:
        cost = CostEstimation(
            id=str(uuid.uuid4()),
            onboarding_id=onboarding_id,
            admin_id=admin.id,
            resource_costs=cost_data,
            infra_support_cost=data.infra_support_cost,
            total_monthly_cost=data.total_monthly_cost,
            total_annual_cost=data.total_annual_cost,
            currency=data.currency,
            notes=data.notes,
        )
        db.add(cost)

    ob = db.query(Onboarding).filter(Onboarding.id == onboarding_id).first()
    if ob:
        ob.admin_status = "cost_done"
        _log_event(
            db, onboarding_id, "admin", admin.id,
            "publish", "Cost estimation saved",
            scope="Cost",
        )

    db.commit()
    db.refresh(cost)
    return cost


def get_cost(db: Session, onboarding_id: str) -> CostEstimation | None:
    """Return cost estimation for an onboarding."""
    return (
        db.query(CostEstimation)
        .filter(CostEstimation.onboarding_id == onboarding_id)
        .first()
    )


def seed_cost_from_bucket(db: Session, onboarding_id: str) -> list[dict]:
    """Read cloud resource bucket and return pre-populated cost items."""
    ob = _load_onboarding(db, onboarding_id)
    if ob is None or ob.cloud_resource_bucket is None:
        return []

    items = []
    bucket = ob.cloud_resource_bucket
    for resource in (bucket.resources or []):
        items.append({
            "resource_name": resource.get("service", "Unknown"),
            "unit_cost": 0,
            "quantity": resource.get("count", 1),
            "monthly_cost": 0,
        })
    return items


# ── Recommendations ─────────────────────────────────────────────────────────

def get_recommendations(db: Session, onboarding_id: str) -> list[Recommendation]:
    """Return all recommendations for an onboarding."""
    return (
        db.query(Recommendation)
        .filter(Recommendation.onboarding_id == onboarding_id)
        .order_by(Recommendation.created_at)
        .all()
    )


def update_recommendation(
    db: Session, rec_id: str, data: RecommendationUpdate,
) -> Recommendation | None:
    """Update a single recommendation."""
    rec = db.query(Recommendation).filter(Recommendation.id == rec_id).first()
    if rec is None:
        return None

    update_data = data.model_dump(exclude_unset=True)
    for field, value in update_data.items():
        setattr(rec, field, value)
    rec.status = "edited"

    db.commit()
    db.refresh(rec)
    return rec


def _parse_llm_json(raw: str) -> dict:
    """Extract JSON from LLM response, handling markdown code fences."""
    text = raw.strip()
    if text.startswith("```"):
        lines = text.split("\n")
        lines = [l for l in lines if not l.strip().startswith("```")]
        text = "\n".join(lines)
    return json.loads(text)



def _generate_approval_recommendations(db: Session, onboarding_id: str, reqs) -> list[Recommendation]:
    """Helper to generate approval rules checklist."""
    solution_type = reqs.solution_type.lower() if reqs else ""
    approval_rules = (
        db.query(ApprovalRule)
        .order_by(ApprovalRule.sort_order)
        .all()
    )

    recs = []
    for rule in approval_rules:
        applies_to = (rule.applies_to or "").lower().replace(" ", "-")
        is_gen_ai = solution_type in ("generative-ai", "genai", "generative ai")
        
        if is_gen_ai:
            if applies_to not in ["all", "generative-ai"]:
                continue
        else:
            if applies_to != "all":
                continue

        approval_rec = Recommendation(
            id=str(uuid.uuid4()),
            onboarding_id=onboarding_id,
            category="approval",
            title=f"Approval – {rule.name}",
            summary=rule.description,
            parameters=[
                {"label": "Approver Role", "value": rule.approver_role},
                {"label": "Applies To", "value": rule.applies_to},
            ],
            status="generated",
        )
        db.add(approval_rec)
        recs.append(approval_rec)
    return recs


def generate_recommendations(db: Session, onboarding_id: str) -> list[Recommendation]:
    """Generate approval checklist recommendations."""
    ob = _load_onboarding(db, onboarding_id)
    if ob is None:
        raise ValueError("Onboarding not found")

    reqs = ob.requirement_assessment

    # Delete previous recommendations for a clean regeneration
    db.query(Recommendation).filter(
        Recommendation.onboarding_id == onboarding_id,
    ).delete()
    db.flush()

    results: list[Recommendation] = []

    # Approval Recommendations
    results.extend(_generate_approval_recommendations(db, onboarding_id, reqs))

    db.commit()
    for r in results:
        db.refresh(r)
    return results


# ── Send to User ─────────────────────────────────────────────────────────────

def send_to_user(db: Session, onboarding_id: str) -> bool:
    """Mark onboarding as approval_checklist_sent."""
    ob = db.query(Onboarding).filter(Onboarding.id == onboarding_id).first()
    if ob is None:
        return False

    ob.admin_status = "approval_checklist_sent"

    # Mark all recommendations as 'sent'
    db.query(Recommendation).filter(
        Recommendation.onboarding_id == onboarding_id,
    ).update({"status": "sent"})

    _log_event(
        db, onboarding_id, "system", "System",
        "publish", "Approval Checklist sent to user",
        scope="Approval Checklist",
    )
    db.commit()
    return True


# ── Interaction Events ───────────────────────────────────────────────────────

def get_interaction_events(db: Session, onboarding_id: str) -> list[dict]:
    """Return all interaction events for an onboarding, sorted by timestamp."""
    events = (
        db.query(InteractionEvent)
        .filter(InteractionEvent.onboarding_id == onboarding_id)
        .order_by(InteractionEvent.ts)
        .all()
    )
    return [
        {
            "id": e.id,
            "onboarding_id": e.onboarding_id,
            "ts": e.ts.isoformat() if e.ts else None,
            "actor": e.actor,
            "actor_name": e.actor_name,
            "kind": e.kind,
            "title": e.title,
            "body": e.body,
            "scope": e.scope,
        }
        for e in events
    ]


# ── Admin: Approve/Send-back Approval Screenshots ────────────────────────────

def get_approval_screenshots(db: Session, onboarding_id: str) -> list[dict]:
    """Return all approval screenshots for an onboarding with metadata."""
    from app.models.approval_screenshot import ApprovalScreenshot
    from app.models.recommendation import Recommendation

    screenshots = (
        db.query(ApprovalScreenshot)
        .filter(ApprovalScreenshot.onboarding_id == onboarding_id)
        .all()
    )
    result = []
    for s in screenshots:
        rec = db.query(Recommendation).filter(Recommendation.id == s.rec_id).first()
        result.append({
            "id": s.id,
            "rec_id": s.rec_id,
            "rec_title": rec.title if rec else s.rec_id,
            "filename": s.filename,
            "content_type": s.content_type,
            "admin_status": s.admin_status,
            "admin_comment": s.admin_comment,
            "uploaded_at": s.uploaded_at.isoformat() if s.uploaded_at else None,
            "reviewed_at": s.reviewed_at.isoformat() if s.reviewed_at else None,
        })
    return result


def admin_approve_screenshot(
    db: Session,
    onboarding_id: str,
    rec_id: str,
    admin: User,
) -> bool:
    """Mark all approval screenshots for a recommendation as approved by admin."""
    from app.models.approval_screenshot import ApprovalScreenshot
    from datetime import datetime, timezone

    screenshots = (
        db.query(ApprovalScreenshot)
        .filter(
            ApprovalScreenshot.onboarding_id == onboarding_id,
            ApprovalScreenshot.rec_id == rec_id,
        )
        .all()
    )
    if not screenshots:
        return False

    for s in screenshots:
        s.admin_status = "approved"
        s.admin_comment = None
        s.reviewed_at = datetime.now(timezone.utc)
    db.flush()

    from app.models.recommendation import Recommendation
    rec = db.query(Recommendation).filter(Recommendation.id == rec_id).first()
    title_label = rec.title if rec else rec_id

    _log_event(
        db, onboarding_id, "admin", admin.name,
        "decision",
        f"Approved: {title_label}",
        scope="Approval Screenshot",
    )

    # Check overall approval completion and sync Onboarding record
    approval_recs = (
        db.query(Recommendation)
        .filter(Recommendation.onboarding_id == onboarding_id, Recommendation.category == "approval")
        .all()
    )
    all_screenshots = (
        db.query(ApprovalScreenshot)
        .filter(ApprovalScreenshot.onboarding_id == onboarding_id)
        .all()
    )
    has_sent_back = any(s.admin_status == "sent_back" for s in all_screenshots)
    approved_rec_ids = {s.rec_id for s in all_screenshots if s.admin_status == "approved"}

    is_all_approved = False
    if approval_recs:
        is_all_approved = not has_sent_back and all(r.id in approved_rec_ids for r in approval_recs)
    elif all_screenshots:
        is_all_approved = not has_sent_back and all(s.admin_status == "approved" for s in all_screenshots)

    ob = db.query(Onboarding).filter(Onboarding.id == onboarding_id).first()
    if ob:
        if is_all_approved:
            ob.admin_status = "approvals_approved"
            ob.status = "Provisioning"
            _log_event(
                db, onboarding_id, "system", "System",
                "decision",
                "All approval proofs verified — proceeding to Provisioning",
                scope="Approval Workflow",
            )
        elif has_sent_back:
            ob.admin_status = "approvals_sent_back"
        else:
            ob.admin_status = "approvals_under_review"

        # Sync into remaining_state['approvals'] if present
        if ob.remaining_state and "approvals" in ob.remaining_state:
            rem_state = dict(ob.remaining_state)
            approvals_list = list(rem_state.get("approvals", []))
            found = False
            for item in approvals_list:
                if item.get("id") == rec_id or item.get("title") == title_label:
                    item["adminStatus"] = "approved"
                    item["adminComment"] = None
                    item["status"] = "approved"
                    found = True
            if not found:
                approvals_list.append({
                    "id": rec_id,
                    "title": title_label,
                    "adminStatus": "approved",
                    "adminComment": None,
                    "status": "approved",
                })
            rem_state["approvals"] = approvals_list
            ob.remaining_state = rem_state

    db.commit()
    return True


def admin_send_back_screenshot(
    db: Session,
    onboarding_id: str,
    rec_id: str,
    admin: User,
    comment: str,
) -> bool:
    """Send back all approval screenshots for a recommendation to user for re-upload."""
    from app.models.approval_screenshot import ApprovalScreenshot
    from datetime import datetime, timezone

    screenshots = (
        db.query(ApprovalScreenshot)
        .filter(
            ApprovalScreenshot.onboarding_id == onboarding_id,
            ApprovalScreenshot.rec_id == rec_id,
        )
        .all()
    )
    if not screenshots:
        return False

    for s in screenshots:
        s.admin_status = "sent_back"
        s.admin_comment = comment
        s.reviewed_at = datetime.now(timezone.utc)
    db.flush()

    from app.models.recommendation import Recommendation
    rec = db.query(Recommendation).filter(Recommendation.id == rec_id).first()
    title_label = rec.title if rec else rec_id

    _log_event(
        db, onboarding_id, "admin", admin.name,
        "comment",
        f"Sent back: {title_label}",
        body=comment,
        scope="Approval Screenshot",
    )

    # Sync onboarding table
    all_screenshots = (
        db.query(ApprovalScreenshot)
        .filter(ApprovalScreenshot.onboarding_id == onboarding_id)
        .all()
    )

    ob = db.query(Onboarding).filter(Onboarding.id == onboarding_id).first()
    if ob:
        ob.admin_status = "approvals_sent_back"

        # Sync into remaining_state['approvals'] if present
        if ob.remaining_state and "approvals" in ob.remaining_state:
            rem_state = dict(ob.remaining_state)
            approvals_list = list(rem_state.get("approvals", []))
            found = False
            for item in approvals_list:
                if item.get("id") == rec_id or item.get("title") == title_label:
                    item["adminStatus"] = "sent_back"
                    item["adminComment"] = comment
                    item["status"] = "pending"
                    found = True
            if not found:
                approvals_list.append({
                    "id": rec_id,
                    "title": title_label,
                    "adminStatus": "sent_back",
                    "adminComment": comment,
                    "status": "pending",
                })
            rem_state["approvals"] = approvals_list
            ob.remaining_state = rem_state

    db.commit()
    return True