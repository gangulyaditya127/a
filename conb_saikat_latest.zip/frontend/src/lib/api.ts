const BASE_URL = '/api';

// ─── Eligibility & Disclaimer ────────────────────────────────────────

export interface ApiQuestion {
  section: string;
  title: string;
  note: string | null;
  question_type: 'single' | 'multi';
  options: string[];
  correct_answer: string | string[];
  fail_message: string;
  sort_order: number;
}

export interface ApiClause {
  title: string;
  text: string;
  sort_order: number;
}

// ─── Account Details ─────────────────────────────────────────────────

export interface ApiAccountDetails {
  id: string;
  onboarding_id: string;
  project_name: string;
  isu: string;
  account_name: string;
  owner: string;
  emp_id: string;
  description: string;
  business_unit: string;
}

export interface ApiAccountDetailsPayload {
  project_name: string;
  isu: string;
  account_name: string;
  owner: string;
  emp_id: string;
  description: string;
  business_unit: string;
}

// ─── Requirement Assessment ──────────────────────────────────────────

export interface ApiRequirement {
  id: string;
  onboarding_id: string;
  solution_type: string;
  deployment_environments: string[];
  cloud_provider: string;
  region: string;
}

export interface ApiRequirementPayload {
  solution_type: string;
  deployment_environments: string[];
  cloud_provider: string;
  region: string;
}

// ─── Onboarding ──────────────────────────────────────────────────────

export interface ApiOnboardingListItem {
  id: string;
  name: string;
  status: string;
  current_step: number;
  created_at: string;
  updated_at: string;
  user_id?: string | null;
  user_name?: string | null;
  user_email?: string | null;
}

export interface ApiOnboardingFull {
  id: string;
  name: string;
  status: string;
  current_step: number;
  created_at: string;
  updated_at: string;
  remaining_state: Record<string, unknown> | null;
  user_id?: string | null;
  user_name?: string | null;
  user_email?: string | null;
  admin_status?: string;
  admin_comments?: {
    admin_id: string;
    admin_name: string;
    comment: string;
    timestamp: string;
    section_comments?: { section: string; section_label: string; comment: string }[];
  }[];
  account_details: ApiAccountDetails | null;
  requirement_assessment: ApiRequirement | null;
}

export interface ApiOnboardingCreate {
  name?: string;
}

export interface ApiOnboardingUpdate {
  name?: string;
  status?: string;
  current_step?: number;
  remaining_state?: Record<string, unknown> | null;
}

// ─── API Functions ───────────────────────────────────────────────────

function getUserAuthHeaders(): Record<string, string> {
  const userId = localStorage.getItem('auth_user_id');
  return userId ? { 'X-User-Id': userId } : {};
}

async function request<T>(path: string, options?: RequestInit): Promise<T> {
  const res = await fetch(`${BASE_URL}${path}`, {
    headers: { 'Content-Type': 'application/json', ...getUserAuthHeaders(), ...options?.headers },
    ...options,
  });
  if (!res.ok) {
    const errorBody = await res.text();
    throw new Error(`API Error ${res.status}: ${errorBody}`);
  }
  return res.json();
}

// Eligibility
export const fetchEligibilityQuestions = () =>
  request<ApiQuestion[]>('/onboardings/eligibility/questions');

// Disclaimer
export const fetchDisclaimerClauses = () =>
  request<ApiClause[]>('/onboardings/disclaimer/clauses');

// Onboardings
export const fetchOnboardings = () =>
  request<ApiOnboardingListItem[]>('/onboardings');

export const createOnboarding = (data: ApiOnboardingCreate = {}) =>
  request<ApiOnboardingFull>('/onboardings', {
    method: 'POST',
    body: JSON.stringify(data),
  });

export const getOnboarding = (id: string) =>
  request<ApiOnboardingFull>(`/onboardings/${id}`);

export const updateOnboarding = (id: string, data: ApiOnboardingUpdate) =>
  request<ApiOnboardingFull>(`/onboardings/${id}`, {
    method: 'PUT',
    body: JSON.stringify(data),
  });

export const deleteOnboarding = (id: string) =>
  request<{ ok: boolean }>(`/onboardings/${id}`, { method: 'DELETE' });

export const resubmitOnboarding = (id: string, comment?: string) =>
  request<{ status: string }>(`/onboardings/${id}/resubmit`, {
    method: 'POST',
    body: JSON.stringify(comment ? { comment } : {}),
  });

// Account Details
export const getAccountDetails = (onboardingId: string) =>
  request<ApiAccountDetails>(`/account-details/${onboardingId}`);

export const upsertAccountDetails = (onboardingId: string, data: ApiAccountDetailsPayload) =>
  request<ApiAccountDetails>(`/account-details/${onboardingId}`, {
    method: 'PUT',
    body: JSON.stringify(data),
  });

// Requirements
export const getRequirements = (onboardingId: string) =>
  request<ApiRequirement>(`/requirements/${onboardingId}`);

export const upsertRequirements = (onboardingId: string, data: ApiRequirementPayload) =>
  request<ApiRequirement>(`/requirements/${onboardingId}`, {
    method: 'PUT',
    body: JSON.stringify(data),
  });

// ─── Cloud Resources Chat ─────────────────────────────────────────────

export interface ApiChatMessage {
  role: 'user' | 'model';
  text: string;
}

export interface ApiProposedResource {
  service: string;
  count: number;
  configDetails: string;
}

export interface ApiChatRequest {
  provider: string;
  message: string;
  history: ApiChatMessage[];
}

export interface ApiChatResponse {
  reply: string;
  proposed_resources: ApiProposedResource[];
}

export interface ApiResourceItem {
  service: string;
  count: number;
  configDetails: string;
}

export interface ApiBucketUpsert {
  provider: string;
  resources: ApiResourceItem[];
}

export interface ApiBucketResponse {
  id: string;
  onboarding_id: string;
  provider: string;
  resources: ApiResourceItem[];
}

export const chatCloudResources = (data: ApiChatRequest) =>
  request<ApiChatResponse>('/cloud-resources/chat', {
    method: 'POST',
    body: JSON.stringify(data),
  });

export const getCloudResourceBucket = (onboardingId: string) =>
  request<ApiBucketResponse>(`/cloud-resources/${onboardingId}/bucket`);

export const upsertCloudResourceBucket = (onboardingId: string, data: ApiBucketUpsert) =>
  request<ApiBucketResponse>(`/cloud-resources/${onboardingId}/bucket`, {
    method: 'PUT',
    body: JSON.stringify(data),
  });

// ─── Architecture Validation ──────────────────────────────────────────

export interface ApiValidationViolation {
  category: string;
  rule_text: string;
  severity: string;
  finding: string;
}

export interface ApiUploadResponse {
  id: string;
  onboarding_id: string;
  image_filename: string;
  user_context?: string | null;
  message: string;
}

export interface ApiValidationResponse {
  id: string;
  onboarding_id: string;
  image_filename: string;
  user_context?: string | null;
  verdict: string | null;
  violations: ApiValidationViolation[];
  validated_at: string | null;
}

export async function uploadArchitectureDiagram(
  onboardingId: string,
  file: File,
  userContext?: string,
): Promise<ApiUploadResponse> {
  const formData = new FormData();
  formData.append('file', file);
  if (userContext !== undefined && userContext !== null) {
    formData.append('user_context', userContext);
  }
  const res = await fetch(`${BASE_URL}/architecture-validation/${onboardingId}/upload`, {
    method: 'POST',
    headers: { ...getUserAuthHeaders() },
    body: formData,
    // No Content-Type header — browser sets multipart boundary automatically
  });
  if (!res.ok) {
    const errorBody = await res.text();
    throw new Error(`API Error ${res.status}: ${errorBody}`);
  }
  return res.json();
}

export const validateArchitecture = (onboardingId: string, userContext?: string) =>
  request<ApiValidationResponse>(`/architecture-validation/${onboardingId}/validate`, {
    method: 'POST',
    body: JSON.stringify({ user_context: userContext }),
  });

export const getArchitectureValidation = (onboardingId: string) =>
  request<ApiValidationResponse>(`/architecture-validation/${onboardingId}`);

// ─── Interaction Events (user-facing) ────────────────────────────────

export interface ApiInteractionEvent {
  id: string;
  onboarding_id: string;
  ts: string;
  actor: string;
  actor_name: string;
  kind: string;
  title: string;
  body: string | null;
  scope: string | null;
}

export const fetchUserEvents = (onboardingId: string) =>
  request<ApiInteractionEvent[]>(`/onboardings/${onboardingId}/events`);

// ─── Recommendations (user-facing) ───────────────────────────────────

export interface ApiRecommendationParam {
  label: string;
  value: string;
}

export interface ApiRecommendation {
  id: string;
  category: string;
  title: string;
  summary: string;
  parameters: ApiRecommendationParam[];
  copy_text: string;
  status: string;
}

export interface ApiRecommendationsResponse {
  status: 'pending' | 'published';
  recommendations: ApiRecommendation[];
}

export const fetchUserRecommendations = (onboardingId: string) =>
  request<ApiRecommendationsResponse>(`/onboardings/${onboardingId}/recommendations`);

// ─── Approval Screenshots (user-facing) ──────────────────────────────────────

export interface ApiApprovalScreenshotImage {
  id: string;
  filename: string;
  content_type: string;
  admin_status: 'uploaded' | 'approved' | 'sent_back';
  admin_comment: string | null;
  uploaded_at: string | null;
}

export interface ApiApprovalScreenshotMeta {
  id?: string;
  rec_id: string;
  filename?: string;
  content_type?: string;
  admin_status: 'uploaded' | 'approved' | 'sent_back';
  admin_comment: string | null;
  uploaded_at?: string | null;
  images: ApiApprovalScreenshotImage[];
}

export async function uploadApprovalScreenshot(
  onboardingId: string,
  recId: string,
  file: File,
): Promise<ApiApprovalScreenshotMeta> {
  const formData = new FormData();
  formData.append('file', file);
  const res = await fetch(`${BASE_URL}/approval-screenshots/${onboardingId}/${recId}`, {
    method: 'POST',
    headers: { ...getUserAuthHeaders() },
    body: formData,
  });
  if (!res.ok) {
    const errorBody = await res.text();
    throw new Error(`API Error ${res.status}: ${errorBody}`);
  }
  return res.json();
}

export const getApprovalScreenshots = (onboardingId: string) =>
  request<ApiApprovalScreenshotMeta[]>(`/approval-screenshots/${onboardingId}`);

export const deleteApprovalScreenshot = (onboardingId: string, screenshotId: string) =>
  request<{ ok: boolean }>(`/approval-screenshots/${onboardingId}/${screenshotId}`, {
    method: 'DELETE',
  });

export const submitApprovalScreenshots = (onboardingId: string) =>
  request<{ ok: boolean; admin_status: string }>(`/approval-screenshots/${onboardingId}/submit`, {
    method: 'POST',
  });
