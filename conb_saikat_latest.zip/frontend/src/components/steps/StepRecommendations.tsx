import { useState, useEffect } from "react";
import { type Recommendation } from "@/types/onboarding";
import { Badge } from "@/components/ui/badge";
import { ShieldCheck, Clock, Loader2 } from "lucide-react";
import {
  fetchUserRecommendations,
  type ApiRecommendation,
  type ApiRecommendationsResponse,
} from "@/lib/api";

interface Props {
  data: Recommendation[];
  solutionType: string;
  onChange: (data: Recommendation[]) => void;
  onboardingId?: string;
}

interface DetailedRecommendation {
  id: string;
  category: "gps" | "rfc" | "approval";
  title: string;
  summary: string;
  parameters: { label: string; value: string }[];
  copyText: string;
}

// ── Static fallback recommendations ──────────────────────────────────
// These are shown only when the backend has no admin-generated recommendations.
const generateStaticRecommendations = (solutionType: string): DetailedRecommendation[] => {
  const recs: DetailedRecommendation[] = [
    {
      id: "approval-1", category: "approval",
      title: "Architecture Approval from ISM",
      summary: "Submit the finalized architecture diagram and resource plan to the unit ISM for security and compliance validation.",
      parameters: [
        { label: "Submission To", value: "Unit Information Security Manager (ISM)" },
        { label: "Artifacts Required", value: "Architecture Diagram, Data Flow Diagram, Security Controls Matrix" },
        { label: "Expected Turnaround", value: "3–5 business days" },
      ],
      copyText: `Approval Request: Architecture Validation\nSubmit To: Unit ISM`,
    },
  ];

  if (solutionType === "generative-ai") {
    recs.push({
      id: "approval-2", category: "approval",
      title: "Legal Approval for LLM Usage",
      summary: "Obtain legal clearance for using non-TCS-approved LLM models, including IP and licensing review.",
      parameters: [
        { label: "Submission To", value: "Legal & Compliance Team" },
        { label: "Review Criteria", value: "IP ownership, data residency, model licensing, output liability" },
        { label: "Expected Turnaround", value: "5–7 business days" },
      ],
      copyText: `Approval Request: LLM Legal Clearance\nSubmit To: Legal & Compliance Team`,
    });
  }

  return recs;
};

// ── Convert backend API recommendations to the display format ────────
const apiToDetailed = (recs: ApiRecommendation[]): DetailedRecommendation[] =>
  recs.map((r) => ({
    id: r.id,
    category: r.category as "gps" | "rfc" | "approval",
    title: r.title,
    summary: r.summary,
    parameters: r.parameters ?? [],
    copyText: r.copy_text ?? "",
  }));

// ── Status Banner extracted to remove nested ternary ────────────────
const StatusBanner = ({ isPending, isFromAdmin }: { isPending: boolean; isFromAdmin: boolean }) => {
  if (isPending) {
    return (
      <div className="bg-amber-500/5 border border-amber-500/20 rounded-lg p-5 text-center space-y-2">
        <Clock className="h-8 w-8 text-amber-500 mx-auto" />
        <h3 className="font-semibold text-lg">Approval Checklist Pending</h3>
        <p className="text-sm text-muted-foreground max-w-md mx-auto">
          The DIS Admin is reviewing your submission and preparing the project-specific approval checklist.
          Once generated and sent, they will appear here automatically.
        </p>
        <Badge variant="secondary" className="mt-2">
          Showing default templates below for reference
        </Badge>
      </div>
    );
  }

  if (isFromAdmin) {
    return (
      <div className="bg-green-500/5 border border-green-500/20 rounded-lg p-4 text-sm text-muted-foreground">
        <strong className="text-foreground">Admin-Generated Approval Checklist:</strong>{" "}
        The following approval checklist items have been prepared by the DIS Admin
        based on your specific project requirements.
      </div>
    );
  }

  return (
    <div className="bg-muted/50 border rounded-lg p-4 text-sm text-muted-foreground">
      <strong className="text-foreground">Default Approval Checklist:</strong>{" "}
      Based on your project requirements, the following approval checklist items are required.
    </div>
  );
};

// ── Badge Label logic extracted to remove nested ternary ────────────
const getBadgeLabel = (isFromAdmin: boolean, isPending: boolean) => {
  if (isFromAdmin) return "Admin Prepared";
  if (isPending) return "Template";
  return "AI Recommended";
};


export const StepRecommendations = ({ data, solutionType, onChange, onboardingId }: Props) => {
  const [detailedRecs, setDetailedRecs] = useState<DetailedRecommendation[]>([]);
  const [loading, setLoading] = useState(true);
  const [isPending, setIsPending] = useState(false);
  const [isFromAdmin, setIsFromAdmin] = useState(false);

  useEffect(() => {
    if (!onboardingId) {
      // No onboarding ID — use static fallback
      const staticRecs = generateStaticRecommendations(solutionType);
      setDetailedRecs(staticRecs);
      syncBasicState(staticRecs);
      setLoading(false);
      return;
    }

    setLoading(true);
    fetchUserRecommendations(onboardingId)
      .then((res: ApiRecommendationsResponse) => {
        if (res.status === "published" && res.recommendations.length > 0) {
          // Real admin-generated recommendations
          const detailed = apiToDetailed(res.recommendations);
          setDetailedRecs(detailed);
          setIsFromAdmin(true);
          setIsPending(false);
          syncBasicState(detailed);
        } else {
          // Admin hasn't sent recommendations yet
          setIsPending(true);
          setIsFromAdmin(false);
          // Show static fallback for reference
          const staticRecs = generateStaticRecommendations(solutionType);
          setDetailedRecs(staticRecs);
          syncBasicState(staticRecs);
        }
      })
      .catch(() => {
        // API error — fall back to static
        const staticRecs = generateStaticRecommendations(solutionType);
        setDetailedRecs(staticRecs);
        syncBasicState(staticRecs);
      })
      .finally(() => setLoading(false));
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [onboardingId]);

  const syncBasicState = (recs: DetailedRecommendation[]) => {
    if (data.length === 0) {
      const basic: Recommendation[] = recs.map((r) => ({
        id: r.id,
        category: r.category,
        title: r.title,
        description: r.summary,
        status: "recommended" as const,
      }));
      onChange(basic);
    }
  };


  const filterByCategory = (cat: string) => detailedRecs.filter((r) => r.category === cat);

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-16 gap-3">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
        <p className="text-sm text-muted-foreground">Loading approval checklist…</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Extracted Status Banner */}
      <StatusBanner isPending={isPending} isFromAdmin={isFromAdmin} />

      <div className="space-y-4">
        <h3 className="font-semibold flex items-center gap-2">
          <ShieldCheck className="h-4 w-4" /> Approval Checklist ({filterByCategory("approval").length})
        </h3>
        {filterByCategory("approval").length === 0 ? (
          <div className="text-center py-8 text-sm text-muted-foreground">
            No approval checklist items {isPending ? "yet" : "for this project"}.
          </div>
        ) : (
          filterByCategory("approval").map((rec) => {
            // const displayParams = rec.parameters.filter((p) => p.label.toLowerCase() !== 'mandatory');
            const displayParams = rec.parameters.filter((p) => p.label.toLowerCase() !== 'mandatory' && p.label.toLowerCase() !== 'applies to');
            return (
              <div key={rec.id} className="border rounded-lg overflow-hidden">
                <div className="flex items-center gap-2 p-4 bg-muted/30 border-b">
                  <ShieldCheck className="h-4 w-4" />
                  <span className="font-semibold">{rec.title}</span>
                  <Badge variant="secondary" className="text-xs">
                    {getBadgeLabel(isFromAdmin, isPending)}
                  </Badge>
                </div>
                <div className="p-4 space-y-3">
                  <p className="text-sm text-muted-foreground">{rec.summary}</p>
                  {displayParams.length > 0 && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                      {displayParams.map((param) => (
                        <div key={param.label} className="flex flex-col gap-0.5 p-2 bg-muted/20 rounded text-sm">
                          <span className="text-xs font-medium text-muted-foreground uppercase tracking-wide">{param.label}</span>
                          <span className="text-foreground">{param.value}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>

      {solutionType === "generative-ai" && (
        <div className="bg-warning/5 border border-warning/20 rounded-lg p-4 text-sm">
          <strong>GenAI Note:</strong> Additional approvals from Legal and Data Privacy teams are required for Generative AI projects. These have been included in the Approval Checklist.
        </div>
      )}
    </div>
  );
};