import { useState, useEffect } from "react";
import {
  Loader2,
  Plus,
  Pencil,
  Trash2,
  ArrowLeft,
  Gavel,
} from "lucide-react";
import { SuperAdminLayout } from "@/components/admin/SuperAdminLayout";
import {
  fetchApprovalRules,
  createApprovalRule,
  updateApprovalRule,
  deleteApprovalRule,
  type ApprovalRule,
} from "@/lib/adminApi";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { useNavigate } from "react-router-dom";

const ApprovalRulesConfig = () => {
  const [rules, setRules] = useState<ApprovalRule[]>([]);
  const [loading, setLoading] = useState(true);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [currentRule, setCurrentRule] = useState<Partial<ApprovalRule> | null>(null);
  const { toast } = useToast();
  const navigate = useNavigate();

  const loadRules = () => {
    setLoading(true);
    fetchApprovalRules()
      .then(setRules)
      .catch(() => {
        toast({
          title: "Error",
          description: "Failed to load approval rules.",
          variant: "destructive",
        });
      })
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    loadRules();
  }, []);

  const handleSave = async () => {
    if (!currentRule?.name || !currentRule?.approver_role) {
      toast({ title: "Validation Error", description: "Name and approver role are required.", variant: "destructive" });
      return;
    }

    try {
      const payload = {
        name: currentRule.name,
        description: currentRule.description || "",
        approver_role: currentRule.approver_role,
        is_mandatory: currentRule.is_mandatory ?? true,
        applies_to: currentRule.applies_to || "all",
        sort_order: currentRule.sort_order ?? rules.length + 1,
      };

      if (currentRule.id) {
        await updateApprovalRule(currentRule.id, payload);
        toast({ title: "Updated", description: "Approval rule updated successfully." });
      } else {
        await createApprovalRule(payload);
        toast({ title: "Created", description: "Approval rule created successfully." });
      }

      setIsDialogOpen(false);
      setCurrentRule(null);
      loadRules();
    } catch {
      toast({ title: "Error", description: "Failed to save approval rule.", variant: "destructive" });
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await deleteApprovalRule(id);
      toast({ title: "Deleted", description: "Approval rule removed." });
      loadRules();
    } catch {
      toast({ title: "Error", description: "Failed to delete approval rule.", variant: "destructive" });
    }
  };

  const openCreate = () => {
    setCurrentRule({ is_mandatory: true, applies_to: "all" });
    setIsDialogOpen(true);
  };

  const openEdit = (rule: ApprovalRule) => {
    setCurrentRule({ ...rule });
    setIsDialogOpen(true);
  };

  const appliesToLabel = (value: string) => {
    switch (value) {
      case "all": return "All Projects";
      case "generative-ai": return "GenAI Only";
      case "non-generative-ai": return "Non-GenAI";
      default: return value;
    }
  };

  const appliesToColor = (value: string) => {
    switch (value) {
      case "generative-ai": return "bg-purple-500/10 text-purple-600 border-purple-500/20";
      case "non-generative-ai": return "bg-blue-500/10 text-blue-600 border-blue-500/20";
      default: return "bg-muted text-muted-foreground";
    }
  };

  let content;
  if (loading) {
    content = (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="h-8 w-8 animate-spin text-amber-500" />
      </div>
    );
  } else if (rules.length === 0) {
    content = (
      <Card>
        <CardContent className="p-12 text-center">
          <Gavel className="h-12 w-12 mx-auto text-muted-foreground/30 mb-4" />
          <p className="text-muted-foreground font-medium">No approval rules configured</p>
          <p className="text-sm text-muted-foreground mt-1 mb-4">
            Add approval rules to define which sign-offs are required during onboarding.
          </p>
          <Button onClick={openCreate} className="gap-1.5">
            <Plus className="h-4 w-4" /> Add First Rule
          </Button>
        </CardContent>
      </Card>
    );
  } else {
    content = (
      <div className="space-y-3">
        {rules.map((rule) => (
          <Card key={rule.id} className="shadow-card hover:shadow-card-hover transition-shadow">
            <CardContent className="p-4">
              <div className="flex items-start justify-between gap-4">
                <div className="flex items-start gap-3 flex-1 min-w-0">
                  <div
                    className={`h-9 w-9 rounded-lg flex items-center justify-center shrink-0 mt-0.5 ${
                      rule.is_mandatory
                        ? "bg-amber-500/10 text-amber-600"
                        : "bg-muted text-muted-foreground"
                    }`}
                  >
                    <Gavel className="h-4 w-4" />
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <h3 className="font-semibold text-sm">{rule.name}</h3>
                      {rule.is_mandatory && (
                        <Badge className="bg-amber-500/10 text-amber-600 border-amber-500/20 text-[10px]">
                          Mandatory
                        </Badge>
                      )}
                      <Badge variant="outline" className="text-[10px] capitalize">
                        {rule.approver_role}
                      </Badge>
                      <Badge className={`text-[10px] ${appliesToColor(rule.applies_to)}`}>
                        {appliesToLabel(rule.applies_to)}
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground mt-1 line-clamp-2">
                      {rule.description}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-1 shrink-0">
                  <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => openEdit(rule)}>
                    <Pencil className="h-3.5 w-3.5" />
                  </Button>
                  <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive" onClick={() => handleDelete(rule.id)}>
                    <Trash2 className="h-3.5 w-3.5" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  return (
    <SuperAdminLayout
      title="Approval Rules"
      subtitle="Configure approval workflows, required roles, and mandatory checks"
    >
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => navigate("/superadmin/config")}
          className="gap-1.5"
        >
          <ArrowLeft className="h-3.5 w-3.5" /> Back to Configuration
        </Button>
        <Button onClick={openCreate} className="gap-1.5 gradient-primary text-white">
          <Plus className="h-4 w-4" /> Add Rule
        </Button>
      </div>

      {content}

      {/* Add/Edit Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={(open) => { if (!open) { setIsDialogOpen(false); setCurrentRule(null); } }}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{currentRule?.id ? "Edit Approval Rule" : "Add Approval Rule"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="rule-name">Rule Name *</Label>
              <Input
                id="rule-name"
                placeholder="e.g. ISM Security Approval"
                value={currentRule?.name || ""}
                onChange={(e) => setCurrentRule({ ...currentRule, name: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="rule-description">Description</Label>
              <Textarea
                id="rule-description"
                placeholder="What does this approval step cover?"
                value={currentRule?.description || ""}
                onChange={(e) => setCurrentRule({ ...currentRule, description: e.target.value })}
                rows={3}
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="rule-approver-role">Approver Role *</Label>
                <Input
                  id="rule-approver-role"
                  placeholder="e.g. ISM, Legal, DPO"
                  value={currentRule?.approver_role || ""}
                  onChange={(e) => setCurrentRule({ ...currentRule, approver_role: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="rule-applies-to">Applies To</Label>
                <Select
                  value={currentRule?.applies_to || "all"}
                  onValueChange={(v) => setCurrentRule({ ...currentRule, applies_to: v })}
                >
                  <SelectTrigger id="rule-applies-to"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Projects</SelectItem>
                    <SelectItem value="generative-ai">GenAI Only</SelectItem>
                    <SelectItem value="non-generative-ai">Non-GenAI Only</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="flex items-center justify-between rounded border p-3">
              <div>
                <Label htmlFor="rule-mandatory" className="text-sm font-medium">Mandatory</Label>
                <p className="text-xs text-muted-foreground">This approval step must be completed before provisioning</p>
              </div>
              <Switch
                id="rule-mandatory"
                checked={currentRule?.is_mandatory ?? true}
                onCheckedChange={(v) => setCurrentRule({ ...currentRule, is_mandatory: v })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="rule-sort-order">Sort Order</Label>
              <Input
                id="rule-sort-order"
                type="number"
                min={1}
                value={currentRule?.sort_order ?? rules.length + 1}
                onChange={(e) => setCurrentRule({ ...currentRule, sort_order: Number.parseInt(e.target.value) || 1 })}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => { setIsDialogOpen(false); setCurrentRule(null); }}>
              Cancel
            </Button>
            <Button onClick={handleSave} className="gradient-primary text-white">
              {currentRule?.id ? "Save Changes" : "Create Rule"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </SuperAdminLayout>
  );
};

export default ApprovalRulesConfig;