import { useState, useEffect } from "react";
import {
  Loader2,
  Plus,
  Pencil,
  Trash2,
  ArrowLeft,
  GripVertical,
} from "lucide-react";
import { SuperAdminLayout } from "@/components/admin/SuperAdminLayout";
import {
  fetchEligibilityQuestions,
  createEligibilityQuestion,
  updateEligibilityQuestion,
  deleteEligibilityQuestion,
  type EligibilityQuestion,
} from "@/lib/adminApi";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useNavigate } from "react-router-dom";

const EligibilityConfig = () => {
  const [questions, setQuestions] = useState<EligibilityQuestion[]>([]);
  const [loading, setLoading] = useState(true);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [currentQuestion, setCurrentQuestion] = useState<Partial<EligibilityQuestion> | null>(null);
  const { toast } = useToast();
  const navigate = useNavigate();

  const loadQuestions = () => {
    setLoading(true);
    fetchEligibilityQuestions()
      .then(setQuestions)
      .catch(() => {
        toast({
          title: "Error",
          description: "Failed to load eligibility questions.",
          variant: "destructive",
        });
      })
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    loadQuestions();
  }, []);

  const handleSave = async () => {
    if (!currentQuestion?.title || !currentQuestion?.section) {
      toast({ title: "Validation Error", description: "Title and section are required.", variant: "destructive" });
      return;
    }

    try {
      const payload = {
        ...currentQuestion,
        options: currentQuestion.options || [],
        question_type: currentQuestion.question_type || "single",
        correct_answer: currentQuestion.correct_answer || "",
        fail_message: currentQuestion.fail_message || "",
        sort_order: currentQuestion.sort_order || 0,
      };

      if (currentQuestion.id) {
        await updateEligibilityQuestion(currentQuestion.id, payload);
        toast({ title: "Success", description: "Question updated successfully." });
      } else {
        await createEligibilityQuestion(payload);
        toast({ title: "Success", description: "Question created successfully." });
      }
      setIsDialogOpen(false);
      loadQuestions();
    } catch (e: unknown) {
      const errorMessage = e instanceof Error ? e.message : "An error occurred";
      toast({ title: "Error", description: errorMessage, variant: "destructive" });
    }
  };

  const handleDelete = async (id: string) => {
    if (confirm("Are you sure you want to delete this question?")) {
      try {
        await deleteEligibilityQuestion(id);
        toast({ title: "Success", description: "Question deleted successfully." });
        loadQuestions();
      } catch (e: unknown) {
        const errorMessage = e instanceof Error ? e.message : "An error occurred";
        toast({ title: "Error", description: errorMessage, variant: "destructive" });
      }
    }
  };

  const openDialog = (question?: EligibilityQuestion) => {
    setCurrentQuestion(question || { section: "General", options: [] });
    setIsDialogOpen(true);
  };

  let mainContent;
  if (loading) {
    mainContent = (
      <div className="flex justify-center py-20">
        <Loader2 className="h-8 w-8 animate-spin text-purple-500" />
      </div>
    );
  } else {
    mainContent = (
      <Card className="shadow-sm">
        <CardHeader className="border-b bg-muted/20">
          <CardTitle>Questions ({questions.length})</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {questions.length === 0 ? (
            <div className="p-8 text-center text-muted-foreground">
              No questions found. Click "Add Question" to create one.
            </div>
          ) : (
            <div className="divide-y">
              {questions.map((q) => (
                <div key={q.id} className="flex items-start justify-between p-4 hover:bg-muted/30 transition-colors">
                  <div className="flex gap-3 items-start">
                    <div className="mt-1 cursor-grab text-muted-foreground/50">
                      <GripVertical className="h-5 w-5" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-semibold">{q.title}</span>
                        <Badge variant="outline" className="text-[10px]">{q.section}</Badge>
                        <Badge variant="secondary" className="text-[10px] bg-purple-50 text-purple-700">{q.question_type}</Badge>
                      </div>
                      {q.note && <p className="text-sm text-muted-foreground mb-2">{q.note}</p>}
                      <div className="text-xs space-y-1 mt-2 bg-muted/30 p-2 rounded-md">
                        <div><strong>Options:</strong> {q.options.join(", ") || "None"}</div>
                        <div><strong className="text-emerald-600">Correct:</strong> {JSON.stringify(q.correct_answer)}</div>
                        <div className="text-red-500"><strong>Fail Msg:</strong> {q.fail_message}</div>
                      </div>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button variant="ghost" size="icon" onClick={() => openDialog(q)}>
                      <Pencil className="h-4 w-4 text-blue-500" />
                    </Button>
                    <Button variant="ghost" size="icon" onClick={() => handleDelete(q.id)}>
                      <Trash2 className="h-4 w-4 text-red-500" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    );
  }

  return (
    <SuperAdminLayout
      title="Eligibility Questions"
      subtitle="Manage the questions shown during the eligibility assessment step."
    >
      <div className="mb-6 flex items-center justify-between">
        <Button variant="ghost" onClick={() => navigate("/superadmin/config")} className="pl-0 text-muted-foreground hover:text-foreground">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Configuration
        </Button>
        <Button onClick={() => openDialog()} className="bg-purple-600 hover:bg-purple-700">
          <Plus className="mr-2 h-4 w-4" />
          Add Question
        </Button>
      </div>

      {mainContent}

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{currentQuestion?.id ? "Edit Question" : "Add Question"}</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="eligibility-section">Section</Label>
                <Input
                  id="eligibility-section"
                  value={currentQuestion?.section || ""}
                  onChange={(e) => setCurrentQuestion({ ...currentQuestion, section: e.target.value })}
                  placeholder="e.g. Compliance"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="eligibility-qtype">Question Type</Label>
                <Select
                  value={currentQuestion?.question_type || "single"}
                  onValueChange={(v) => setCurrentQuestion({ ...currentQuestion, question_type: v })}
                >
                  <SelectTrigger id="eligibility-qtype"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="single">Single Choice</SelectItem>
                    <SelectItem value="multi">Multiple Choice</SelectItem>
                    <SelectItem value="text">Text Input</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="eligibility-title">Title (The Question)</Label>
              <Input
                id="eligibility-title"
                value={currentQuestion?.title || ""}
                onChange={(e) => setCurrentQuestion({ ...currentQuestion, title: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="eligibility-note">Note (Optional tooltip/hint)</Label>
              <Textarea
                id="eligibility-note"
                value={currentQuestion?.note || ""}
                onChange={(e) => setCurrentQuestion({ ...currentQuestion, note: e.target.value })}
                rows={2}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="eligibility-options">Options (comma separated)</Label>
              <Input
                id="eligibility-options"
                value={currentQuestion?.options?.join(", ") || ""}
                onChange={(e) => setCurrentQuestion({ ...currentQuestion, options: e.target.value.split(",").map(s => s.trim()).filter(Boolean) })}
                placeholder="Yes, No"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="eligibility-correct-answer">Correct Answer</Label>
                <Input
                  id="eligibility-correct-answer"
                  value={typeof currentQuestion?.correct_answer === "string" ? currentQuestion.correct_answer : JSON.stringify(currentQuestion?.correct_answer || "")}
                  onChange={(e) => {
                    let val: unknown = e.target.value;
                    try { val = JSON.parse(e.target.value); } catch { /* Keep raw string if not JSON */ }
                    setCurrentQuestion({ ...currentQuestion, correct_answer: val });
                  }}
                  placeholder='e.g. "Yes" or ["A", "B"]'
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="eligibility-sort-order">Sort Order</Label>
                <Input
                  id="eligibility-sort-order"
                  type="number"
                  value={currentQuestion?.sort_order || 0}
                  onChange={(e) => setCurrentQuestion({ ...currentQuestion, sort_order: Number.parseInt(e.target.value, 10) || 0 })}
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="eligibility-fail-msg">Fail Message (shown if answer is incorrect)</Label>
              <Textarea
                id="eligibility-fail-msg"
                value={currentQuestion?.fail_message || ""}
                onChange={(e) => setCurrentQuestion({ ...currentQuestion, fail_message: e.target.value })}
                rows={2}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSave} className="bg-purple-600 hover:bg-purple-700">Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </SuperAdminLayout>
  );
};

export default EligibilityConfig;