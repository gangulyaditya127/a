import { useEffect, useState } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import {
  CheckCircle2, XCircle, AlertTriangle, Loader2, ArrowLeft, Send,
  FileText, Settings2, Cloud, Image, MessageSquare, DollarSign,
  Lightbulb, Plus, Trash2, Sparkles, Copy, Edit, Check,
  BookOpen, ShieldCheck, Server, Layers,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger,
} from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { AdminLayout } from "@/components/admin/AdminLayout";
import { InteractionTimeline, type InteractionEvent } from "@/components/InteractionTimeline";
import { toast } from "@/hooks/use-toast";
import {
  fetchAdminOnboarding,
  submitFeedback,
  approveOnboarding,
  sendBackOnboarding,
  upsertCost,
  seedCostFromBucket,
  getCost,
  generateRecommendations,
  getRecommendations,
  sendToUser,
  fetchInteractionEvents,
  type AdminOnboarding,
  type ValidationFeedback,
  type ResourceCostItem,
  type RecommendationItem,
  type InteractionEventItem,
} from "@/lib/adminApi";

const SECTIONS = ['account_details', 'requirements', 'cloud_resources', 'architecture'] as const;
type Section = typeof SECTIONS[number];

const sectionLabels: Record<Section, string> = {
  account_details: 'Account Details',
  requirements: 'Requirements',
  cloud_resources: 'Cloud Resources',
  architecture: 'Architecture',
};

const AdminOnboardingReview = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();

  // ── General state ──
  const [data, setData] = useState<AdminOnboarding | null>(null);
  const [loading, setLoading] = useState(true);
  const [events, setEvents] = useState<InteractionEvent[]>([]);

  // ── Review state ──
  const [feedbackComment, setFeedbackComment] = useState<Record<Section, string>>({
    account_details: '', requirements: '', cloud_resources: '', architecture: '',
  });
  const [submitting, setSubmitting] = useState<string | null>(null);
  const [sendBackComment, setSendBackComment] = useState('');
  const [sendingBack, setSendingBack] = useState(false);
  const [approving, setApproving] = useState(false);

  // ── Cost state ──
  const [resourceCosts, setResourceCosts] = useState<ResourceCostItem[]>([]);
  const [infraSupportCost, setInfraSupportCost] = useState(0);
  const [currency, setCurrency] = useState('INR');
  const [costNotes, setCostNotes] = useState('');
  const [savingCost, setSavingCost] = useState(false);

  // ── Recommendations state ──
  const [recs, setRecs] = useState<RecommendationItem[]>([]);
  const [generating, setGenerating] = useState(false);
  const [sendDialogOpen, setSendDialogOpen] = useState(false);
  const [sending, setSending] = useState(false);
  const [editingRec, setEditingRec] = useState<RecommendationItem | null>(null);

  // ── Data loading ──
  const loadData = () => {
    if (!id) return;
    setLoading(true);
    Promise.all([
      fetchAdminOnboarding(id),
      getRecommendations(id).catch(() => []),
      fetchInteractionEvents(id).catch(() => []),
    ])
      .then(([onb, r, evts]) => {
        setData(onb);
        setRecs(r.length > 0 ? r : onb.recommendations ?? []);
        // Map backend events to InteractionTimeline format
        setEvents((evts as InteractionEventItem[]).map((e) => ({
          id: e.id,
          ts: e.ts,
          actor: e.actor,
          actorName: e.actor_name,
          kind: e.kind as InteractionEvent['kind'],
          title: e.title,
          body: e.body ?? undefined,
          scope: e.scope ?? undefined,
        })));
        // Load cost state
        if (onb.cost_estimation) {
          setResourceCosts(onb.cost_estimation.resource_costs);
          setInfraSupportCost(onb.cost_estimation.infra_support_cost);
          setCurrency(onb.cost_estimation.currency);
          setCostNotes(onb.cost_estimation.notes);
        }
      })
      .catch(() => toast({ title: "Error", description: "Failed to load onboarding.", variant: "destructive" }))
      .finally(() => setLoading(false));
  };

  useEffect(() => { loadData(); }, [id]);

  // ── Review helpers ──
  const feedbacks = data?.validation_feedbacks ?? [];
  const getFeedback = (section: Section): ValidationFeedback | undefined =>
    feedbacks.find((f) => f.section === section);

  const approvedCount = SECTIONS.filter((s) => getFeedback(s)?.status === 'approved').length;
  const rejectedCount = SECTIONS.filter((s) => getFeedback(s)?.status === 'rejected').length;
  const allApproved = approvedCount === 4;
  const isReadOnly = data ? (data.admin_status !== 'assigned' && data.admin_status !== 'under_review') : false;
  const bothValidationsApproved = getFeedback('cloud_resources')?.status === 'approved' &&
    getFeedback('architecture')?.status === 'approved';
  const costReady = data?.admin_status === 'cost_done' || data?.admin_status === 'recommendations_sent';

  // ── Review actions ──
  const handleSectionApprove = async (section: Section) => {
    if (!id) return;
    setSubmitting(section);
    try {
      await submitFeedback(id, { section, status: 'approved' });
      toast({ title: "Section Approved", description: `${sectionLabels[section]} has been approved.` });
      loadData();
    } catch {
      toast({ title: "Error", description: "Failed to submit feedback.", variant: "destructive" });
    } finally {
      setSubmitting(null);
    }
  };

  const handleSectionReject = async (section: Section) => {
    if (!id) return;
    const comment = feedbackComment[section];
    if (!comment.trim()) {
      toast({ title: "Comment Required", description: "Please provide a reason for requesting changes.", variant: "destructive" });
      return;
    }
    setSubmitting(section);
    try {
      await submitFeedback(id, { section, status: 'rejected', comment });
      toast({ title: "Changes Requested", description: `Feedback sent for ${sectionLabels[section]}.` });
      setFeedbackComment((prev) => ({ ...prev, [section]: '' }));
      loadData();
    } catch {
      toast({ title: "Error", description: "Failed to submit feedback.", variant: "destructive" });
    } finally {
      setSubmitting(null);
    }
  };

  const handleApproveAll = async () => {
    if (!id) return;
    setApproving(true);
    try {
      await approveOnboarding(id);
      toast({ title: "Onboarding Approved!", description: "Proceeding to cost budgeting." });
      loadData();
    } catch {
      toast({ title: "Error", description: "Failed to approve.", variant: "destructive" });
    } finally {
      setApproving(false);
    }
  };

  const handleSendBack = async () => {
    if (!id) return;
    if (!sendBackComment.trim()) {
      toast({ title: "Comment Required", description: "Provide feedback for the user.", variant: "destructive" });
      return;
    }
    setSendingBack(true);
    try {
      await sendBackOnboarding(id, { comment: sendBackComment });
      toast({ title: "Sent Back", description: "Onboarding sent back to the user." });
      navigate('/admin');
    } catch {
      toast({ title: "Error", description: "Failed to send back.", variant: "destructive" });
    } finally {
      setSendingBack(false);
    }
  };

  // ── Cost actions ──
  const updateResourceCost = (index: number, field: keyof ResourceCostItem, value: string | number) => {
    setResourceCosts((prev) => {
      const updated = [...prev];
      const item = { ...updated[index], [field]: value };
      if (field === 'unit_cost' || field === 'quantity') {
        item.monthly_cost = (Number(item.unit_cost) || 0) * (Number(item.quantity) || 0);
      }
      updated[index] = item;
      return updated;
    });
  };

  const addCostRow = () => {
    setResourceCosts((prev) => [...prev, { resource_name: '', unit_cost: 0, quantity: 1, monthly_cost: 0 }]);
  };

  const removeCostRow = (index: number) => {
    setResourceCosts((prev) => prev.filter((_, i) => i !== index));
  };

  const handleLoadFromBucket = async () => {
    if (!id) return;
    try {
      const items = await seedCostFromBucket(id);
      setResourceCosts(items);
      toast({ title: "Loaded", description: `${items.length} resource(s) loaded from bucket.` });
    } catch {
      // Fallback: use local data
      if (data?.cloud_resource_bucket?.resources) {
        setResourceCosts(
          data.cloud_resource_bucket.resources.map((r) => ({
            resource_name: r.service,
            unit_cost: 0,
            quantity: r.count,
            monthly_cost: 0,
          }))
        );
        toast({ title: "Loaded from cache", description: "Resources loaded from local data." });
      }
    }
  };

  const resourceSubtotal = resourceCosts.reduce((sum, r) => sum + (r.monthly_cost || 0), 0);
  const totalMonthly = resourceSubtotal + infraSupportCost;
  const totalAnnual = totalMonthly * 12;

  const handleSaveCost = async () => {
    if (!id) return;
    setSavingCost(true);
    try {
      await upsertCost(id, {
        resource_costs: resourceCosts,
        infra_support_cost: infraSupportCost,
        total_monthly_cost: totalMonthly,
        total_annual_cost: totalAnnual,
        currency,
        notes: costNotes,
      });
      toast({ title: "Cost Saved", description: "Cost estimation published to user." });
      loadData();
    } catch {
      toast({ title: "Error", description: "Failed to save cost.", variant: "destructive" });
    } finally {
      setSavingCost(false);
    }
  };

  // ── Recommendations actions ──
  const handleGenerate = async () => {
    if (!id) return;
    setGenerating(true);
    try {
      const generated = await generateRecommendations(id);
      setRecs(generated);
      toast({ title: "Generated", description: `${generated.length} recommendations created.` });
    } catch {
      toast({ title: "Error", description: "Failed to generate.", variant: "destructive" });
    } finally {
      setGenerating(false);
    }
  };

  const handleSendToUser = async () => {
    if (!id) return;
    setSending(true);
    try {
      await sendToUser(id);
      toast({ title: "Sent to User", description: "Recommendations visible to the user." });
      setSendDialogOpen(false);
      loadData();
    } catch {
      toast({ title: "Error", description: "Failed to send.", variant: "destructive" });
    } finally {
      setSending(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({ title: "Copied", description: "Copied to clipboard." });
  };

  const gpsRecs = recs.filter((r) => r.category === 'gps');
  const rfcRecs = recs.filter((r) => r.category === 'rfc');
  const approvalRecs = recs.filter((r) => r.category === 'approval');

  // ── Validation status rendering ──
  const renderValidationStatus = (section: Section) => {
    const fb = getFeedback(section);
    if (!fb) return null;
    if (fb.status === 'approved') {
      return (
        <Badge className="bg-green-500/10 text-green-600 border-green-500/20 gap-1">
          <CheckCircle2 className="h-3 w-3" /> Approved
        </Badge>
      );
    }
    return (
      <div className="space-y-1">
        <Badge className="bg-amber-500/10 text-amber-600 border-amber-500/20 gap-1">
          <AlertTriangle className="h-3 w-3" /> Changes Requested
        </Badge>
        {fb.comment && <p className="text-xs text-muted-foreground italic pl-1">"{fb.comment}"</p>}
      </div>
    );
  };

  const renderSectionActions = (section: Section) => {
    const fb = getFeedback(section);
    if (fb || isReadOnly) return null;
    const isSubmitting = submitting === section;
    return (
      <div className="space-y-3 pt-4 border-t">
        <Textarea
          placeholder="Comment for user (required for Send Back)…"
          value={feedbackComment[section]}
          onChange={(e) => setFeedbackComment((prev) => ({ ...prev, [section]: e.target.value }))}
          rows={2}
          className="text-sm"
        />
        <div className="flex gap-2 justify-end">
          <Button
            size="sm"
            variant="outline"
            onClick={() => handleSectionReject(section)}
            disabled={isSubmitting}
          >
            {isSubmitting ? <Loader2 className="h-3.5 w-3.5 animate-spin mr-1" /> : <AlertTriangle className="h-3.5 w-3.5 mr-1" />}
            Send Back
          </Button>
          <Button
            size="sm"
            onClick={() => handleSectionApprove(section)}
            disabled={isSubmitting}
            className="bg-green-600 hover:bg-green-700 text-white"
          >
            {isSubmitting ? <Loader2 className="h-3.5 w-3.5 animate-spin mr-1" /> : <CheckCircle2 className="h-3.5 w-3.5 mr-1" />}
            Approve
          </Button>
        </div>
      </div>
    );
  };

  // ── Loading / not found ──
  if (loading) {
    return (
      <AdminLayout>
        <div className="flex items-center justify-center py-20">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </AdminLayout>
    );
  }

  if (!data) {
    return (
      <AdminLayout>
        <Card><CardContent className="p-10 text-center space-y-3">
          <p className="text-sm text-muted-foreground">
            Onboarding <span className="font-mono">{id}</span> not found.
          </p>
          <Link to="/admin"><Button variant="outline" size="sm"><ArrowLeft className="h-3 w-3 mr-1" /> Back to dashboard</Button></Link>
        </CardContent></Card>
      </AdminLayout>
    );
  }

  const acct = data.account_details;
  const req = data.requirement_assessment;
  const bucket = data.cloud_resource_bucket;
  const arch = data.architecture_validation;

  const statusTone = (status: string) => {
    if (['approved', 'cost_done', 'recommendations_sent'].includes(status)) return 'bg-green-500/10 text-green-600 border-green-500/20';
    if (status === 'sent_back') return 'bg-amber-500/10 text-amber-600 border-amber-500/20';
    if (status === 'cost_pending') return 'bg-purple-500/10 text-purple-600 border-purple-500/20';
    return 'bg-blue-500/10 text-blue-600 border-blue-500/20';
  };

  return (
    <AdminLayout>
      <div className="grid grid-cols-1 xl:grid-cols-[minmax(0,1fr)_360px] gap-6 max-w-[1500px]">
        {/* ── Main content ── */}
        <div className="space-y-4 min-w-0">
          {/* Back link */}
          <Link to="/admin" className="text-xs text-muted-foreground inline-flex items-center gap-1 hover:text-foreground">
            <ArrowLeft className="h-3 w-3" /> Back to dashboard
          </Link>

          {/* Header card */}
          <Card>
            <CardHeader className="flex-row items-start justify-between space-y-0">
              <div>
                <CardTitle className="text-xl">{data.name}</CardTitle>
                <p className="text-xs text-muted-foreground mt-1 font-mono">{data.id}</p>
                <p className="text-xs text-muted-foreground">
                  Requestor: {acct?.owner || '—'} · BU: {acct?.business_unit || '—'}
                </p>
              </div>
              <Badge className={statusTone(data.admin_status)}>
                {data.admin_status?.replace(/_/g, ' ')}
              </Badge>
            </CardHeader>
          </Card>

          {/* ── 4-Tab Review ── */}
          <Tabs defaultValue="resource">
            <TabsList>
              <TabsTrigger value="resource" className="gap-1.5">
                <Server className="h-3.5 w-3.5" /> Resource Validation
                {getFeedback('cloud_resources')?.status === 'approved' && <CheckCircle2 className="h-3 w-3 text-green-600" />}
              </TabsTrigger>
              <TabsTrigger value="arch" className="gap-1.5">
                <Layers className="h-3.5 w-3.5" /> Architecture
                {getFeedback('architecture')?.status === 'approved' && <CheckCircle2 className="h-3 w-3 text-green-600" />}
              </TabsTrigger>
              <TabsTrigger value="cost" className="gap-1.5">
                <DollarSign className="h-3.5 w-3.5" /> Cost Budgeting
                {costReady && <CheckCircle2 className="h-3 w-3 text-green-600" />}
              </TabsTrigger>
              <TabsTrigger value="recs" className="gap-1.5">
                <Lightbulb className="h-3.5 w-3.5" /> Recommendations
                {data.admin_status === 'recommendations_sent' && <CheckCircle2 className="h-3 w-3 text-green-600" />}
              </TabsTrigger>
            </TabsList>

            {/* ── Resource Validation Tab ── */}
            <TabsContent value="resource">
              <Card><CardContent className="p-5 space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="font-semibold">Cloud Resource Buckets</h3>
                  {renderValidationStatus('cloud_resources')}
                </div>
                {bucket && bucket.resources.length > 0 ? (
                  <div className="rounded-md border">
                    <div className="px-3 py-2 bg-muted/40 text-xs font-semibold uppercase">
                      {bucket.provider} — {bucket.resources.length} resource(s)
                    </div>
                    <Table>
                      <TableHeader><TableRow>
                        <TableHead>Service</TableHead><TableHead>Count</TableHead><TableHead>Config</TableHead>
                      </TableRow></TableHeader>
                      <TableBody>
                        {bucket.resources.map((r, i) => (
                          <TableRow key={i}>
                            <TableCell className="font-medium">{r.service}</TableCell>
                            <TableCell>{r.count}</TableCell>
                            <TableCell className="text-xs text-muted-foreground">{r.configDetails}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                ) : (
                  <p className="text-sm text-muted-foreground">No resources submitted yet by the user.</p>
                )}

                {/* Account Details inline */}
                {acct && (
                  <details className="border rounded p-3">
                    <summary className="text-sm font-medium cursor-pointer flex items-center gap-2">
                      <FileText className="h-3.5 w-3.5 text-primary" /> Account Details
                      {getFeedback('account_details')?.status === 'approved' && <CheckCircle2 className="h-3 w-3 text-green-600 ml-auto" />}
                    </summary>
                    <div className="grid grid-cols-2 gap-3 text-sm mt-3">
                      {[
                        { label: 'Project Name', value: acct.project_name },
                        { label: 'ISU', value: acct.isu },
                        { label: 'Account Name', value: acct.account_name },
                        { label: 'Owner', value: acct.owner },
                        { label: 'Employee ID', value: acct.emp_id },
                        { label: 'Business Unit', value: acct.business_unit },
                      ].map((f) => (
                        <div key={f.label} className="rounded border p-2">
                          <p className="text-xs text-muted-foreground">{f.label}</p>
                          <p className="font-medium">{f.value || '—'}</p>
                        </div>
                      ))}
                    </div>
                    <Separator className="my-3" />
                    {renderSectionActions('account_details')}
                  </details>
                )}

                {/* Requirements inline */}
                {req && (
                  <details className="border rounded p-3">
                    <summary className="text-sm font-medium cursor-pointer flex items-center gap-2">
                      <Settings2 className="h-3.5 w-3.5 text-primary" /> Requirements
                      {getFeedback('requirements')?.status === 'approved' && <CheckCircle2 className="h-3 w-3 text-green-600 ml-auto" />}
                    </summary>
                    <div className="grid grid-cols-2 gap-3 text-sm mt-3">
                      <div className="rounded border p-2">
                        <p className="text-xs text-muted-foreground">Solution Type</p>
                        <Badge variant="secondary">{req.solution_type?.replace(/-/g, ' ') || '—'}</Badge>
                      </div>
                      <div className="rounded border p-2">
                        <p className="text-xs text-muted-foreground">Cloud Provider</p>
                        <Badge variant="outline" className="gap-1"><Cloud className="h-3 w-3" /> {req.cloud_provider || '—'}</Badge>
                      </div>
                      <div className="rounded border p-2">
                        <p className="text-xs text-muted-foreground">Region</p>
                        <p className="font-medium">{req.region || '—'}</p>
                      </div>
                      <div className="rounded border p-2">
                        <p className="text-xs text-muted-foreground">Environments</p>
                        <div className="flex flex-wrap gap-1 mt-1">
                          {(req.deployment_environments ?? []).map((env) => (
                            <Badge key={env} className="bg-blue-500/10 text-blue-600 border-blue-500/20 text-[10px]">{env}</Badge>
                          ))}
                        </div>
                      </div>
                    </div>
                    <Separator className="my-3" />
                    {renderSectionActions('requirements')}
                  </details>
                )}

                {renderSectionActions('cloud_resources')}
              </CardContent></Card>
            </TabsContent>

            {/* ── Architecture Tab ── */}
            <TabsContent value="arch">
              <Card><CardContent className="p-5 space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="font-semibold">Architecture Overview</h3>
                  {renderValidationStatus('architecture')}
                </div>
                {arch ? (
                  <div className="space-y-4">
                    {arch.image_filename && (
                      <div className="border rounded-lg overflow-hidden bg-muted/30">
                        <img
                          src={`/api/architecture-validation/${id}/image`}
                          alt="Architecture diagram"
                          className="max-w-full max-h-96 mx-auto p-4"
                        />
                      </div>
                    )}
                    <div className="grid grid-cols-2 gap-3 text-sm">
                      <div className="rounded border p-3">
                        <p className="text-xs text-muted-foreground">Verdict</p>
                        {arch.verdict ? (
                          <Badge className={arch.verdict === 'PASS' ? 'bg-green-500/10 text-green-600' : 'bg-red-500/10 text-red-600'}>
                            {arch.verdict}
                          </Badge>
                        ) : <Badge variant="secondary">Not validated</Badge>}
                      </div>
                      <div className="rounded border p-3">
                        <p className="text-xs text-muted-foreground">Security Violations</p>
                        <p className="font-medium">{arch.violations.length}</p>
                      </div>
                    </div>
                    {arch.violations.length > 0 && (
                      <ul className="text-xs space-y-1 list-disc pl-5">
                        {arch.violations.map((v, i) => (
                          <li key={i} className="text-red-600">
                            <span className="font-medium">{v.finding}</span> · {v.category} · {v.severity}
                          </li>
                        ))}
                      </ul>
                    )}
                  </div>
                ) : (
                  <p className="text-sm text-muted-foreground">Architecture validation has not been completed.</p>
                )}
                {renderSectionActions('architecture')}
              </CardContent></Card>
            </TabsContent>

            {/* ── Cost Budgeting Tab ── */}
            <TabsContent value="cost">
              {!allApproved && !bothValidationsApproved && !costReady ? (
                <Card><CardContent className="p-8 text-center text-sm text-muted-foreground">
                  Cost budgeting unlocks after all sections are approved.
                </CardContent></Card>
              ) : (
                <Card><CardContent className="p-5 space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="font-semibold">Cost Budgeting</h3>
                    <div className="flex gap-2">
                      {resourceCosts.length === 0 && (
                        <Button size="sm" variant="outline" onClick={handleLoadFromBucket}>
                          Load from resources
                        </Button>
                      )}
                      <Button size="sm" variant="outline" onClick={addCostRow}>
                        <Plus className="h-3.5 w-3.5 mr-1" /> Add Row
                      </Button>
                      <Button
                        size="sm"
                        onClick={handleSaveCost}
                        disabled={savingCost || resourceCosts.length === 0}
                        className="gradient-primary text-white"
                      >
                        {savingCost ? <Loader2 className="h-3.5 w-3.5 animate-spin mr-1" /> : <Send className="h-3.5 w-3.5 mr-1" />}
                        Publish to User
                      </Button>
                    </div>
                  </div>

                  {costReady && (
                    <Badge className="bg-green-500/10 text-green-600 border-green-500/20">
                      Cost published
                    </Badge>
                  )}

                  <Table>
                    <TableHeader><TableRow>
                      <TableHead>Resource</TableHead>
                      <TableHead className="w-32">Unit Cost ({currency})</TableHead>
                      <TableHead className="w-20">Qty</TableHead>
                      <TableHead className="w-32 text-right">Monthly ({currency})</TableHead>
                      <TableHead className="w-10" />
                    </TableRow></TableHeader>
                    <TableBody>
                      {resourceCosts.map((row, i) => (
                        <TableRow key={i}>
                          <TableCell>
                            <Input value={row.resource_name} onChange={(e) => updateResourceCost(i, 'resource_name', e.target.value)} className="h-8 text-xs" />
                          </TableCell>
                          <TableCell>
                            <Input type="number" value={row.unit_cost || ''} onChange={(e) => updateResourceCost(i, 'unit_cost', Number(e.target.value))} className="h-8" />
                          </TableCell>
                          <TableCell>
                            <Input type="number" value={row.quantity || ''} onChange={(e) => updateResourceCost(i, 'quantity', Number(e.target.value))} className="h-8" />
                          </TableCell>
                          <TableCell className="text-right font-mono text-xs">
                            {(row.monthly_cost || 0).toLocaleString('en-IN')}
                          </TableCell>
                          <TableCell>
                            <Button variant="ghost" size="sm" onClick={() => removeCostRow(i)}>
                              <Trash2 className="h-3.5 w-3.5 text-muted-foreground hover:text-destructive" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                      {resourceCosts.length === 0 && (
                        <TableRow>
                          <TableCell colSpan={5} className="text-center text-muted-foreground text-sm py-6">
                            No cost lines yet. Click "Load from resources" to seed from user's bucket.
                          </TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>

                  {/* Summary cards */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-2">
                    <div className="rounded border p-3">
                      <p className="text-xs text-muted-foreground">Infra Support ({currency})</p>
                      <Input
                        type="number"
                        value={infraSupportCost || ''}
                        onChange={(e) => setInfraSupportCost(Number(e.target.value))}
                        className="mt-1"
                      />
                    </div>
                    <div className="rounded border p-3">
                      <p className="text-xs text-muted-foreground">Currency</p>
                      <Select value={currency} onValueChange={setCurrency}>
                        <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="INR">INR (₹)</SelectItem>
                          <SelectItem value="USD">USD ($)</SelectItem>
                          <SelectItem value="EUR">EUR (€)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="rounded border p-3 bg-primary/5">
                      <p className="text-xs text-muted-foreground">Total monthly</p>
                      <p className="text-lg font-bold font-mono text-primary mt-1">
                        {currency} {totalMonthly.toLocaleString('en-IN')}
                      </p>
                    </div>
                  </div>

                  <div>
                    <p className="text-xs text-muted-foreground mb-1">Notes</p>
                    <Textarea value={costNotes} onChange={(e) => setCostNotes(e.target.value)} placeholder="Additional notes…" rows={2} />
                  </div>
                </CardContent></Card>
              )}
            </TabsContent>

            {/* ── Recommendations Tab ── */}
            <TabsContent value="recs">
              {!costReady ? (
                <Card><CardContent className="p-8 text-center text-sm text-muted-foreground">
                  Recommendations unlock after Cost Budgeting is published.
                </CardContent></Card>
              ) : (
                <Card><CardContent className="p-5 space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="font-semibold">Recommendations & Approval Checklist</h3>
                    <div className="flex gap-2">
                      {recs.length === 0 && !generating && (
                        <Button size="sm" onClick={handleGenerate} className="gradient-primary text-white">
                          <Sparkles className="h-3.5 w-3.5 mr-1" /> Generate
                        </Button>
                      )}
                      {recs.length > 0 && (
                        <Dialog open={sendDialogOpen} onOpenChange={setSendDialogOpen}>
                          <DialogTrigger asChild>
                            <Button size="sm" className="gradient-primary text-white">
                              <Send className="h-3.5 w-3.5 mr-1" />
                              {data.admin_status === 'recommendations_sent' ? 'Re-send' : 'Send to User'}
                            </Button>
                          </DialogTrigger>
                          <DialogContent>
                            <DialogHeader>
                              <DialogTitle>Send Recommendations to User</DialogTitle>
                              <DialogDescription>This will make recommendations and cost visible to the user.</DialogDescription>
                            </DialogHeader>
                            <DialogFooter>
                              <Button variant="outline" onClick={() => setSendDialogOpen(false)}>Cancel</Button>
                              <Button onClick={handleSendToUser} disabled={sending} className="gradient-primary text-white">
                                {sending ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <Check className="h-4 w-4 mr-2" />}
                                Confirm & Send
                              </Button>
                            </DialogFooter>
                          </DialogContent>
                        </Dialog>
                      )}
                    </div>
                  </div>

                  {data.admin_status === 'recommendations_sent' && (
                    <Badge className="bg-green-500/10 text-green-600 border-green-500/20">Recommendations sent to user</Badge>
                  )}

                  {generating && (
                    <div className="text-center py-8 space-y-3">
                      <Loader2 className="h-10 w-10 animate-spin text-primary mx-auto" />
                      <p className="text-sm font-medium">Generating recommendations…</p>
                      <p className="text-xs text-muted-foreground">This may take 10-30 seconds.</p>
                    </div>
                  )}

                  {recs.length === 0 && !generating && (
                    <div className="rounded-lg border border-dashed bg-muted/40 p-8 text-center space-y-3">
                      <Sparkles className="h-8 w-8 mx-auto text-muted-foreground" />
                      <p className="text-sm font-medium">No recommendations yet</p>
                      <p className="text-xs text-muted-foreground">Click Generate to create AI-powered recommendations.</p>
                    </div>
                  )}

                  {recs.length > 0 && !generating && (
                    <Tabs defaultValue="gps" className="space-y-3">
                      <TabsList className="grid grid-cols-3">
                        <TabsTrigger value="gps" className="gap-1.5 text-xs"><FileText className="h-3 w-3" /> GPS ({gpsRecs.length})</TabsTrigger>
                        <TabsTrigger value="rfcs" className="gap-1.5 text-xs"><BookOpen className="h-3 w-3" /> RFCs ({rfcRecs.length})</TabsTrigger>
                        <TabsTrigger value="approvals" className="gap-1.5 text-xs"><ShieldCheck className="h-3 w-3" /> Approvals ({approvalRecs.length})</TabsTrigger>
                      </TabsList>

                      <TabsContent value="gps" className="space-y-3">
                        {gpsRecs.map((rec) => (
                          <div key={rec.id} className="rounded border p-3 flex items-start gap-3">
                            <Lightbulb className="h-4 w-4 text-amber-500 mt-0.5 shrink-0" />
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2">
                                <Badge variant="outline" className="text-[10px]">GPS</Badge>
                                <span className="font-medium text-sm">{rec.title}</span>
                                <div className="ml-auto flex gap-1">
                                  <Button variant="ghost" size="sm" className="h-6 w-6 p-0" onClick={() => setEditingRec(rec)}><Edit className="h-3 w-3" /></Button>
                                  <Button variant="ghost" size="sm" className="h-6 w-6 p-0" onClick={() => copyToClipboard(rec.copy_text || rec.summary)}><Copy className="h-3 w-3" /></Button>
                                </div>
                              </div>
                              <p className="text-xs text-muted-foreground mt-0.5">{rec.summary}</p>
                              {rec.parameters?.length > 0 && (
                                <div className="grid grid-cols-2 gap-1.5 mt-2">
                                  {rec.parameters.map((p, i) => (
                                    <div key={i} className="bg-muted/50 rounded p-1.5">
                                      <p className="text-[10px] text-muted-foreground">{p.label}</p>
                                      <p className="text-xs font-medium">{p.value}</p>
                                    </div>
                                  ))}
                                </div>
                              )}
                            </div>
                          </div>
                        ))}
                      </TabsContent>

                      <TabsContent value="rfcs" className="space-y-3">
                        {rfcRecs.map((rec) => (
                          <div key={rec.id} className="rounded border p-3 flex items-start gap-3">
                            <BookOpen className="h-4 w-4 text-blue-500 mt-0.5 shrink-0" />
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2">
                                <Badge variant="outline" className="text-[10px]">RFC</Badge>
                                <span className="font-medium text-sm">{rec.title}</span>
                                <div className="ml-auto flex gap-1">
                                  <Button variant="ghost" size="sm" className="h-6 w-6 p-0" onClick={() => setEditingRec(rec)}><Edit className="h-3 w-3" /></Button>
                                  <Button variant="ghost" size="sm" className="h-6 w-6 p-0" onClick={() => copyToClipboard(rec.copy_text || rec.summary)}><Copy className="h-3 w-3" /></Button>
                                </div>
                              </div>
                              <p className="text-xs text-muted-foreground mt-0.5">{rec.summary}</p>
                              {rec.parameters?.length > 0 && (
                                <div className="grid grid-cols-2 gap-1.5 mt-2">
                                  {rec.parameters.map((p, i) => (
                                    <div key={i} className="bg-muted/50 rounded p-1.5">
                                      <p className="text-[10px] text-muted-foreground">{p.label}</p>
                                      <p className="text-xs font-medium">{p.value}</p>
                                    </div>
                                  ))}
                                </div>
                              )}
                            </div>
                          </div>
                        ))}
                      </TabsContent>

                      <TabsContent value="approvals" className="space-y-3">
                        {approvalRecs.map((rec) => (
                          <div key={rec.id} className="rounded border p-3 flex items-center gap-3">
                            <div className="h-8 w-8 rounded-full bg-purple-500/10 text-purple-600 flex items-center justify-center shrink-0">
                              <ShieldCheck className="h-4 w-4" />
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="text-sm font-medium">{rec.title}</p>
                              <p className="text-xs text-muted-foreground">{rec.summary}</p>
                            </div>
                            {rec.parameters?.find((p) => p.label === 'mandatory')?.value === 'true' && (
                              <Badge className="bg-red-500/10 text-red-600 border-red-500/20 text-[10px]">Mandatory</Badge>
                            )}
                            <Badge variant="outline" className="text-[10px]">
                              {rec.parameters?.find((p) => p.label === 'approver_role')?.value ?? 'Approver'}
                            </Badge>
                          </div>
                        ))}
                      </TabsContent>
                    </Tabs>
                  )}
                </CardContent></Card>
              )}
            </TabsContent>
          </Tabs>

          {/* ── Bottom Action Bar ── */}
          {data.admin_status === 'assigned' || data.admin_status === 'under_review' ? (
            <Card className="border-2">
              <CardContent className="p-5">
                {allApproved ? (
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 text-green-600">
                      <CheckCircle2 className="h-5 w-5" />
                      <span className="font-medium">All sections approved ✓</span>
                    </div>
                    <Button
                      onClick={handleApproveAll}
                      disabled={approving}
                      className="gradient-primary text-white"
                    >
                      {approving ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <CheckCircle2 className="h-4 w-4 mr-2" />}
                      Approve & Proceed to Cost Budgeting
                    </Button>
                  </div>
                ) : rejectedCount > 0 ? (
                  <div className="space-y-3">
                    <p className="text-sm text-amber-600 flex items-center gap-2">
                      <AlertTriangle className="h-4 w-4" />
                      {rejectedCount} section{rejectedCount > 1 ? 's' : ''} flagged for changes. Send back with consolidated feedback.
                    </p>
                    <Textarea
                      placeholder="Add overall comments for the user…"
                      value={sendBackComment}
                      onChange={(e) => setSendBackComment(e.target.value)}
                      rows={2}
                    />
                    <Button variant="destructive" onClick={handleSendBack} disabled={sendingBack}>
                      {sendingBack ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <Send className="h-4 w-4 mr-2" />}
                      Send Back to User
                    </Button>
                  </div>
                ) : (
                  <p className="text-sm text-muted-foreground flex items-center gap-2">
                    <MessageSquare className="h-4 w-4" />
                    Review each section and approve or request changes. All 4 sections must be approved.
                  </p>
                )}
              </CardContent>
            </Card>
          ) : (
            <Card className="border-2 bg-muted/50">
              <CardContent className="p-5 text-sm text-muted-foreground space-y-4">
                <div className="text-center">
                  This onboarding is currently in <strong>{data.admin_status?.replace(/_/g, ' ')}</strong> status.
                  {data.admin_status === 'sent_back' && ' Waiting for user to resubmit.'}
                </div>
                {data.admin_comments && data.admin_comments.length > 0 && (
                  <div className="bg-background rounded-lg border p-4 shadow-sm max-w-3xl mx-auto">
                    <p className="font-semibold text-foreground flex items-center gap-2 mb-1.5">
                      <MessageSquare className="h-4 w-4 text-primary" />
                      Latest Overall Comment Sent
                    </p>
                    <p className="text-foreground">
                      {data.admin_comments[data.admin_comments.length - 1].comment}
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          )}
        </div>

        {/* ── Right Rail: Activity Timeline ── */}
        <aside className="xl:sticky xl:top-6 self-start h-[calc(100vh-7rem)]">
          <Card className="h-full">
            <CardContent className="p-4 h-full">
              <InteractionTimeline
                events={events}
                title="User ↔ Admin Activity"
                emptyHint="No interactions yet. Submissions, comments, decisions and publishes appear here."
              />
            </CardContent>
          </Card>
        </aside>
      </div>

      {/* ── Edit Recommendation Dialog ── */}
      {editingRec && (
        <Dialog open={!!editingRec} onOpenChange={() => setEditingRec(null)}>
          <DialogContent className="max-w-lg">
            <DialogHeader>
              <DialogTitle>Edit Recommendation</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Title</label>
                <Input value={editingRec.title} onChange={(e) => setEditingRec({ ...editingRec, title: e.target.value })} />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">Summary</label>
                <Textarea value={editingRec.summary} onChange={(e) => setEditingRec({ ...editingRec, summary: e.target.value })} rows={3} />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setEditingRec(null)}>Cancel</Button>
              <Button
                onClick={() => {
                  setRecs((prev) => prev.map((r) => r.id === editingRec.id ? editingRec : r));
                  setEditingRec(null);
                  toast({ title: "Updated", description: "Recommendation updated." });
                }}
                className="gradient-primary text-white"
              >
                Save Changes
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </AdminLayout>
  );
};

export default AdminOnboardingReview;
