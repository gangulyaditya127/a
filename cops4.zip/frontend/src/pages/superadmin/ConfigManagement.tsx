import { useEffect, useState } from "react";
import {
  Loader2,
  Settings,
  HelpCircle,
  FileText,
  ShieldCheck,
  Gavel,
  ArrowRight,
  CheckCircle2,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { SuperAdminLayout } from "@/components/admin/SuperAdminLayout";
import {
  fetchConfigSummary,
  fetchApprovalRules,
  type ApprovalRule,
} from "@/lib/adminApi";
import { useNavigate } from "react-router-dom";

interface ConfigSummary {
  eligibility_questions: number;
  disclaimer_clauses: number;
  architecture_rules: number;
  approval_rules: number;
}

const ConfigManagement = () => {
  const [summary, setSummary] = useState<ConfigSummary | null>(null);
  const navigate = useNavigate();
  const [approvalRules, setApprovalRules] = useState<ApprovalRule[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    Promise.all([fetchConfigSummary(), fetchApprovalRules()])
      .then(([sum, rules]) => {
        setSummary(sum);
        setApprovalRules(rules);
      })
      .catch(() => {
        // Use placeholder counts on error
        setSummary({
          eligibility_questions: 8,
          disclaimer_clauses: 5,
          architecture_rules: 12,
          approval_rules: 4,
        });
      })
      .finally(() => setLoading(false));
  }, []);

  const configCards = summary
    ? [
        {
          title: "Eligibility Questions",
          description:
            "Manage the questions shown during the eligibility assessment step.",
          count: summary.eligibility_questions,
          icon: HelpCircle,
          gradient: "from-purple-500 to-violet-600",
          countLabel: "questions",
          path: "/superadmin/config/eligibility",
        },
        {
          title: "Disclaimer Clauses",
          description:
            "Configure disclaimer text and clauses users must acknowledge.",
          count: summary.disclaimer_clauses,
          icon: FileText,
          gradient: "from-blue-500 to-indigo-600",
          countLabel: "clauses",
          path: "/superadmin/config/disclaimers",
        },
        {
          title: "Architecture Rules",
          description:
            "Define validation rules applied during architecture review.",
          count: summary.architecture_rules,
          icon: ShieldCheck,
          gradient: "from-emerald-500 to-green-600",
          countLabel: "rules",
          path: "/superadmin/config/architecture-rules",
        },
        {
          title: "Approval Rules",
          description:
            "Set up approval workflows, required roles, and mandatory checks.",
          count: summary.approval_rules,
          icon: Gavel,
          gradient: "from-amber-500 to-orange-600",
          countLabel: "rules",
          path: null, // No dedicated page yet
        },
      ]
    : [];

  return (
    <SuperAdminLayout
      title="Configuration"
      subtitle="Manage platform settings, rules, and templates"
    >
      {loading ? (
        <div className="flex items-center justify-center py-20">
          <Loader2 className="h-8 w-8 animate-spin text-purple-500" />
        </div>
      ) : (
        <div className="space-y-8">
          {/* Config Category Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {configCards.map((card) => (
              <Card
                key={card.title}
                className="shadow-card hover:shadow-card-hover transition-shadow overflow-hidden"
              >
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <div
                        className={`h-10 w-10 rounded-lg bg-gradient-to-br ${card.gradient} flex items-center justify-center shadow-sm`}
                      >
                        <card.icon className="h-5 w-5 text-white" />
                      </div>
                      <div>
                        <CardTitle className="text-base">
                          {card.title}
                        </CardTitle>
                        <p className="text-xs text-muted-foreground mt-0.5">
                          {card.description}
                        </p>
                      </div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pt-0">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="text-2xl font-bold text-foreground">
                        {card.count}
                      </span>
                      <span className="text-sm text-muted-foreground">
                        {card.countLabel}
                      </span>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      className="text-purple-700 border-purple-200 hover:bg-purple-50"
                      onClick={() => {
                        if (card.path) {
                          navigate(card.path);
                        } else {
                          import("@/hooks/use-toast").then(({ toast }) => {
                            toast({
                              title: "Coming Soon",
                              description: "Configuration editor will be available in a future update.",
                            });
                          });
                        }
                      }}
                    >
                      Manage
                      <ArrowRight className="h-3.5 w-3.5 ml-1" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Approval Rules Preview */}
          {approvalRules.length > 0 && (
            <div className="space-y-4">
              <div>
                <h2 className="text-lg font-semibold text-foreground">
                  Approval Rules
                </h2>
                <p className="text-sm text-muted-foreground">
                  Current approval workflow configuration
                </p>
              </div>
              <Card className="shadow-card overflow-hidden">
                <CardContent className="p-0">
                  <div className="divide-y">
                    {approvalRules.map((rule) => (
                      <div
                        key={rule.id}
                        className="flex items-center gap-4 px-5 py-4 hover:bg-muted/30 transition-colors"
                      >
                        <div
                          className={`h-8 w-8 rounded-full flex items-center justify-center shrink-0 ${
                            rule.mandatory
                              ? "bg-purple-100 text-purple-700"
                              : "bg-gray-100 text-gray-500"
                          }`}
                        >
                          <CheckCircle2 className="h-4 w-4" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium text-foreground">
                            {rule.name}
                          </p>
                          <p className="text-xs text-muted-foreground truncate">
                            {rule.description}
                          </p>
                        </div>
                        <div className="flex items-center gap-2 shrink-0">
                          <Badge
                            variant="outline"
                            className="text-[10px] capitalize"
                          >
                            {rule.approver_role}
                          </Badge>
                          {rule.mandatory && (
                            <Badge className="bg-purple-50 text-purple-700 border-purple-200 text-[10px]">
                              Mandatory
                            </Badge>
                          )}
                          <Badge
                            variant="secondary"
                            className="text-[10px] capitalize"
                          >
                            {rule.applies_to}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Empty state for approval rules */}
          {approvalRules.length === 0 && (
            <Card>
              <CardContent className="p-12 text-center">
                <Settings className="h-12 w-12 mx-auto text-muted-foreground/30 mb-4" />
                <p className="text-muted-foreground font-medium">
                  No approval rules configured
                </p>
                <p className="text-sm text-muted-foreground mt-1">
                  Approval rules will appear here once configured.
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      )}
    </SuperAdminLayout>
  );
};

export default ConfigManagement;
