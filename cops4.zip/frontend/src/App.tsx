import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "@/contexts/AuthContext";
import Index from "./pages/Index.tsx";
import NotFound from "./pages/NotFound.tsx";
import AdminDashboard from "./pages/admin/AdminDashboard";
import AdminOnboardingReview from "./pages/admin/AdminOnboardingReview";
import SuperAdminDashboard from "./pages/superadmin/SuperAdminDashboard";
import OnboardingAssignment from "./pages/superadmin/OnboardingAssignment";
import AdminManagement from "./pages/superadmin/AdminManagement";
import ConfigManagement from "./pages/superadmin/ConfigManagement";
import EligibilityConfig from "./pages/superadmin/config/EligibilityConfig";
import DisclaimerConfig from "./pages/superadmin/config/DisclaimerConfig";
import ArchitectureRulesConfig from "./pages/superadmin/config/ArchitectureRulesConfig";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <AuthProvider>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<Index />} />
            {/* Admin Portal — all review work in one page */}
            <Route path="/admin" element={<AdminDashboard />} />
            <Route path="/admin/review/:id" element={<AdminOnboardingReview />} />
            {/* SuperAdmin Portal */}
            <Route path="/superadmin" element={<SuperAdminDashboard />} />
            <Route path="/superadmin/onboardings" element={<OnboardingAssignment />} />
            <Route path="/superadmin/admins" element={<AdminManagement />} />
            <Route path="/superadmin/config" element={<ConfigManagement />} />
            <Route path="/superadmin/config/eligibility" element={<EligibilityConfig />} />
            <Route path="/superadmin/config/disclaimers" element={<DisclaimerConfig />} />
            <Route path="/superadmin/config/architecture-rules" element={<ArchitectureRulesConfig />} />
            {/* Catch-all */}
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </TooltipProvider>
    </AuthProvider>
  </QueryClientProvider>
);

export default App;
