"""SuperAdmin API router — onboarding oversight and admin management."""

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.domains.auth.dependencies import require_superadmin
from app.models.user import User
from app.admin.superadmin import service
from app.admin.superadmin.schemas import (
    AdminCreate,
    AdminResponse,
    AdminUpdate,
    AssignmentResponse,
    AssignRequest,
    DashboardStats,
    OnboardingListItem,
)

router = APIRouter()


@router.get("/dashboard", response_model=DashboardStats)
def dashboard(
    db: Session = Depends(get_db),
    superadmin: User = Depends(require_superadmin),
) -> DashboardStats:
    """Return aggregate stats and admin workloads."""
    return service.get_dashboard(db)


@router.get("/onboardings", response_model=list[OnboardingListItem])
def list_onboardings(
    unassigned: bool | None = None,
    assigned: bool | None = None,
    admin_status: str | None = None,
    search: str | None = None,
    db: Session = Depends(get_db),
    superadmin: User = Depends(require_superadmin),
) -> list[OnboardingListItem]:
    """List all onboardings with optional filters."""
    return service.list_onboardings(
        db,
        unassigned=unassigned,
        assigned=assigned,
        admin_status=admin_status,
        search=search,
    )


@router.post(
    "/onboardings/{onboarding_id}/assign",
    response_model=AssignmentResponse,
    status_code=201,
)
def assign_admin(
    onboarding_id: str,
    data: AssignRequest,
    db: Session = Depends(get_db),
    superadmin: User = Depends(require_superadmin),
) -> AssignmentResponse:
    """Assign an admin to an onboarding."""
    # Validate admin exists
    admin = db.query(User).filter(User.id == data.admin_id, User.role == "admin").first()
    if admin is None:
        raise HTTPException(status_code=404, detail="Admin user not found")

    return service.assign_admin(db, onboarding_id, data.admin_id, superadmin.id)


@router.post(
    "/onboardings/{onboarding_id}/reassign",
    response_model=AssignmentResponse,
    status_code=201,
)
def reassign_admin(
    onboarding_id: str,
    data: AssignRequest,
    db: Session = Depends(get_db),
    superadmin: User = Depends(require_superadmin),
) -> AssignmentResponse:
    """Reassign an onboarding to a different admin."""
    admin = db.query(User).filter(User.id == data.admin_id, User.role == "admin").first()
    if admin is None:
        raise HTTPException(status_code=404, detail="Admin user not found")

    return service.reassign_admin(db, onboarding_id, data.admin_id, superadmin.id)


@router.get("/admins", response_model=list[AdminResponse])
def list_admins(
    db: Session = Depends(get_db),
    superadmin: User = Depends(require_superadmin),
) -> list[AdminResponse]:
    """List all admin users."""
    return service.list_admins(db)


@router.post("/admins", response_model=AdminResponse, status_code=201)
def create_admin(
    data: AdminCreate,
    db: Session = Depends(get_db),
    superadmin: User = Depends(require_superadmin),
) -> AdminResponse:
    """Register a new admin user."""
    # Check email uniqueness
    existing = db.query(User).filter(User.email == data.email).first()
    if existing:
        raise HTTPException(status_code=400, detail="Email already registered")

    return service.create_admin(db, data)


@router.put("/admins/{admin_id}", response_model=AdminResponse)
def update_admin(
    admin_id: str,
    data: AdminUpdate,
    db: Session = Depends(get_db),
    superadmin: User = Depends(require_superadmin),
) -> AdminResponse:
    """Update an admin user."""
    admin = service.update_admin(db, admin_id, data)
    if admin is None:
        raise HTTPException(status_code=404, detail="Admin not found")
    return admin


@router.delete("/admins/{admin_id}", status_code=204)
def delete_admin(
    admin_id: str,
    db: Session = Depends(get_db),
    superadmin: User = Depends(require_superadmin),
) -> None:
    """Deactivate an admin (soft delete)."""
    deleted = service.deactivate_admin(db, admin_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="Admin not found")
