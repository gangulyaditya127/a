import { useState } from "react";
import { ConsoleLayout } from "@/components/admin/ConsoleLayout";
import { superNav } from "../SuperAdminDashboard";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Plus, Pencil, Trash2, ArrowLeft, GripVertical } from "lucide-react";
import { Link } from "react-router-dom";
import { deleteEligibility, loadEligibility, upsertEligibility, type EligibilityCriterion } from "@/lib/configStorage";
import { toast } from "@/hooks/use-toast";

const EligibilityConfigPage = () => {
  const [items, setItems] = useState<EligibilityCriterion[]>(() => loadEligibility());
  const [open, setOpen] = useState(false);
  const [draft, setDraft] = useState<Partial<EligibilityCriterion> | null>(null);

  const openNew = () => { setDraft({ section: "General", questionType: "single", options: ["Yes", "No"], correctAnswer: "Yes", sortOrder: (items.at(-1)?.sortOrder ?? 0) + 10 }); setOpen(true); };
  const openEdit = (q: EligibilityCriterion) => { setDraft(q); setOpen(true); };

  const save = () => {
    if (!draft?.title?.trim()) { toast({ title: "Title required", variant: "destructive" }); return; }
    const next = upsertEligibility(draft);
    setItems(next);
    setOpen(false);
    toast({ title: draft.id ? "Question updated" : "Question added" });
  };

  const remove = (id: string) => { setItems(deleteEligibility(id)); toast({ title: "Question deleted" }); };

  return (
    <ConsoleLayout role="superadmin" items={superNav}>
      <div className="space-y-4 max-w-[1100px]">
        <div className="flex items-center justify-between">
          <Link to="/superadmin/config" className="text-xs text-muted-foreground hover:text-foreground inline-flex items-center gap-1"><ArrowLeft className="h-3 w-3" /> Back to Configuration</Link>
          <Button onClick={openNew}><Plus className="h-4 w-4 mr-1" /> Add Question</Button>
        </div>
        <div>
          <h2 className="text-2xl font-semibold">Eligibility Criteria</h2>
          <p className="text-sm text-muted-foreground">Questions shown to the user before they can start an onboarding. A wrong answer blocks intake with the configured fail message.</p>
        </div>

        <Card>
          <CardHeader className="border-b py-3"><CardTitle className="text-sm">Questions ({items.length})</CardTitle></CardHeader>
          <CardContent className="p-0">
            {items.length === 0 ? (
              <p className="p-8 text-center text-sm text-muted-foreground">No questions. Add one to gate onboarding intake.</p>
            ) : (
              <div className="divide-y">
                {items.map((q) => (
                  <div key={q.id} className="flex items-start justify-between p-4 hover:bg-muted/30">
                    <div className="flex gap-3">
                      <GripVertical className="h-5 w-5 text-muted-foreground/40 mt-0.5" />
                      <div className="space-y-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-medium text-sm">{q.title}</span>
                          <Badge variant="outline" className="text-[10px]">{q.section}</Badge>
                          <Badge variant="secondary" className="text-[10px]">{q.questionType}</Badge>
                          <Badge variant="outline" className="text-[10px]">order {q.sortOrder}</Badge>
                        </div>
                        {q.note && <p className="text-xs text-muted-foreground">{q.note}</p>}
                        <div className="text-[11px] grid gap-0.5 bg-muted/40 p-2 rounded">
                          <div><span className="text-muted-foreground">Options:</span> {q.options.join(" · ") || "—"}</div>
                          <div><span className="text-success">Correct:</span> {JSON.stringify(q.correctAnswer)}</div>
                          <div className="text-destructive"><span className="font-medium">On fail:</span> {q.failMessage}</div>
                        </div>
                      </div>
                    </div>
                    <div className="flex gap-1">
                      <Button variant="ghost" size="icon" onClick={() => openEdit(q)}><Pencil className="h-3.5 w-3.5" /></Button>
                      <Button variant="ghost" size="icon" onClick={() => remove(q.id)}><Trash2 className="h-3.5 w-3.5 text-destructive" /></Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-xl max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle>{draft?.id ? "Edit Question" : "Add Question"}</DialogTitle></DialogHeader>
          <div className="space-y-3 py-2">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1"><Label>Section</Label><Input value={draft?.section ?? ""} onChange={(e) => setDraft({ ...draft, section: e.target.value })} /></div>
              <div className="space-y-1"><Label>Type</Label>
                <Select value={draft?.questionType ?? "single"} onValueChange={(v: any) => setDraft({ ...draft, questionType: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="single">Single Choice</SelectItem>
                    <SelectItem value="multi">Multiple Choice</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-1"><Label>Question</Label><Input value={draft?.title ?? ""} onChange={(e) => setDraft({ ...draft, title: e.target.value })} /></div>
            <div className="space-y-1"><Label>Hint / Note</Label><Textarea rows={2} value={draft?.note ?? ""} onChange={(e) => setDraft({ ...draft, note: e.target.value })} /></div>
            <div className="space-y-1"><Label>Options (comma separated)</Label>
              <Input value={draft?.options?.join(", ") ?? ""} onChange={(e) => setDraft({ ...draft, options: e.target.value.split(",").map((s) => s.trim()).filter(Boolean) })} />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1"><Label>Correct answer</Label>
                <Input value={Array.isArray(draft?.correctAnswer) ? (draft!.correctAnswer as string[]).join(", ") : (draft?.correctAnswer as string ?? "")}
                  onChange={(e) => {
                    const v = e.target.value;
                    setDraft({ ...draft, correctAnswer: draft?.questionType === "multi" ? v.split(",").map((s) => s.trim()).filter(Boolean) : v });
                  }} />
              </div>
              <div className="space-y-1"><Label>Sort order</Label><Input type="number" value={draft?.sortOrder ?? 0} onChange={(e) => setDraft({ ...draft, sortOrder: Number(e.target.value) || 0 })} /></div>
            </div>
            <div className="space-y-1"><Label>Fail message</Label><Textarea rows={2} value={draft?.failMessage ?? ""} onChange={(e) => setDraft({ ...draft, failMessage: e.target.value })} /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button onClick={save}>Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </ConsoleLayout>
  );
};

export default EligibilityConfigPage;