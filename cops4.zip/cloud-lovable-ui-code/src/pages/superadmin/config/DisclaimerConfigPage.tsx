import { useState } from "react";
import { ConsoleLayout } from "@/components/admin/ConsoleLayout";
import { superNav } from "../SuperAdminDashboard";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Plus, Pencil, Trash2, ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";
import { deleteDisclaimer, loadDisclaimer, upsertDisclaimer, type DisclaimerClause } from "@/lib/configStorage";
import { toast } from "@/hooks/use-toast";

const DisclaimerConfigPage = () => {
  const [items, setItems] = useState<DisclaimerClause[]>(() => loadDisclaimer());
  const [open, setOpen] = useState(false);
  const [draft, setDraft] = useState<Partial<DisclaimerClause> | null>(null);

  const openNew = () => { setDraft({ sortOrder: (items.at(-1)?.sortOrder ?? 0) + 10 }); setOpen(true); };
  const openEdit = (c: DisclaimerClause) => { setDraft(c); setOpen(true); };
  const save = () => {
    if (!draft?.title?.trim() || !draft?.text?.trim()) { toast({ title: "Title and text are required", variant: "destructive" }); return; }
    setItems(upsertDisclaimer(draft));
    setOpen(false);
    toast({ title: draft.id ? "Clause updated" : "Clause added" });
  };
  const remove = (id: string) => { setItems(deleteDisclaimer(id)); toast({ title: "Clause deleted" }); };

  return (
    <ConsoleLayout role="superadmin" items={superNav}>
      <div className="space-y-4 max-w-[1100px]">
        <div className="flex items-center justify-between">
          <Link to="/superadmin/config" className="text-xs text-muted-foreground hover:text-foreground inline-flex items-center gap-1"><ArrowLeft className="h-3 w-3" /> Back to Configuration</Link>
          <Button onClick={openNew}><Plus className="h-4 w-4 mr-1" /> Add Clause</Button>
        </div>
        <div>
          <h2 className="text-2xl font-semibold">Disclaimer Clauses</h2>
          <p className="text-sm text-muted-foreground">Acknowledgement text shown after a user passes eligibility. Both the title and body are displayed verbatim.</p>
        </div>

        <Card>
          <CardHeader className="border-b py-3"><CardTitle className="text-sm">Clauses ({items.length})</CardTitle></CardHeader>
          <CardContent className="p-0">
            {items.length === 0 ? <p className="p-8 text-center text-sm text-muted-foreground">No clauses yet.</p> : (
              <div className="divide-y">
                {items.map((c) => (
                  <div key={c.id} className="flex items-start justify-between p-4 hover:bg-muted/30">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-medium text-sm">{c.title}</span>
                        <span className="text-[10px] text-muted-foreground bg-muted px-1.5 py-0.5 rounded">order {c.sortOrder}</span>
                      </div>
                      <p className="text-xs text-muted-foreground max-w-2xl">{c.text}</p>
                    </div>
                    <div className="flex gap-1">
                      <Button variant="ghost" size="icon" onClick={() => openEdit(c)}><Pencil className="h-3.5 w-3.5" /></Button>
                      <Button variant="ghost" size="icon" onClick={() => remove(c.id)}><Trash2 className="h-3.5 w-3.5 text-destructive" /></Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>{draft?.id ? "Edit Clause" : "Add Clause"}</DialogTitle></DialogHeader>
          <div className="space-y-3 py-2">
            <div className="space-y-1"><Label>Title</Label><Input value={draft?.title ?? ""} onChange={(e) => setDraft({ ...draft, title: e.target.value })} /></div>
            <div className="space-y-1"><Label>Text</Label><Textarea rows={5} value={draft?.text ?? ""} onChange={(e) => setDraft({ ...draft, text: e.target.value })} /></div>
            <div className="space-y-1"><Label>Sort order</Label><Input type="number" value={draft?.sortOrder ?? 0} onChange={(e) => setDraft({ ...draft, sortOrder: Number(e.target.value) || 0 })} /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button onClick={save}>Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </ConsoleLayout>
  );
};

export default DisclaimerConfigPage;