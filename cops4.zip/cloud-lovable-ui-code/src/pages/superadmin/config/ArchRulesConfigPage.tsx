import { useMemo, useState } from "react";
import { ConsoleLayout } from "@/components/admin/ConsoleLayout";
import { superNav } from "../SuperAdminDashboard";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Plus, Pencil, Trash2, ArrowLeft, ShieldAlert } from "lucide-react";
import { Link } from "react-router-dom";
import { deleteArchRule, loadArchRules, upsertArchRule, type ArchRule } from "@/lib/configStorage";
import { toast } from "@/hooks/use-toast";

const sevTone: Record<string, string> = {
  CRITICAL: "bg-destructive/10 text-destructive border-destructive/20",
  HIGH: "bg-warning/10 text-warning border-warning/20",
  MEDIUM: "bg-info/10 text-info border-info/20",
  LOW: "bg-muted text-muted-foreground border-border",
};

const ArchRulesConfigPage = () => {
  const [items, setItems] = useState<ArchRule[]>(() => loadArchRules());
  const [open, setOpen] = useState(false);
  const [draft, setDraft] = useState<Partial<ArchRule> | null>(null);
  const [filter, setFilter] = useState<string>("ALL");

  const openNew = () => { setDraft({ cloudProvider: "AWS", severity: "CRITICAL", category: "" }); setOpen(true); };
  const openEdit = (r: ArchRule) => { setDraft(r); setOpen(true); };
  const save = () => {
    if (!draft?.category?.trim() || !draft?.ruleText?.trim()) { toast({ title: "Category and rule text required", variant: "destructive" }); return; }
    setItems(upsertArchRule(draft));
    setOpen(false);
    toast({ title: draft.id ? "Rule updated" : "Rule added" });
  };
  const remove = (id: string) => { setItems(deleteArchRule(id)); toast({ title: "Rule deleted" }); };

  const filtered = useMemo(() => filter === "ALL" ? items : items.filter((r) => r.cloudProvider === filter), [items, filter]);

  return (
    <ConsoleLayout role="superadmin" items={superNav}>
      <div className="space-y-4 max-w-[1200px]">
        <div className="flex items-center justify-between">
          <Link to="/superadmin/config" className="text-xs text-muted-foreground hover:text-foreground inline-flex items-center gap-1"><ArrowLeft className="h-3 w-3" /> Back to Configuration</Link>
          <div className="flex items-center gap-2">
            <Select value={filter} onValueChange={setFilter}>
              <SelectTrigger className="w-40 h-9"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL">All providers</SelectItem>
                <SelectItem value="AWS">AWS</SelectItem>
                <SelectItem value="Azure">Azure</SelectItem>
                <SelectItem value="GCP">GCP</SelectItem>
                <SelectItem value="On-Prem">On-Prem</SelectItem>
              </SelectContent>
            </Select>
            <Button onClick={openNew}><Plus className="h-4 w-4 mr-1" /> Add Rule</Button>
          </div>
        </div>
        <div>
          <h2 className="text-2xl font-semibold">Architecture Rules</h2>
          <p className="text-sm text-muted-foreground">Validation rules surfaced to DIS Admins during architecture review. A failed CRITICAL rule blocks approval.</p>
        </div>

        <Card>
          <CardHeader className="border-b py-3"><CardTitle className="text-sm">Rules ({filtered.length})</CardTitle></CardHeader>
          <CardContent className="p-0">
            {filtered.length === 0 ? <p className="p-8 text-center text-sm text-muted-foreground">No rules.</p> : (
              <div className="divide-y">
                {filtered.map((r) => (
                  <div key={r.id} className="flex items-start justify-between p-4 hover:bg-muted/30">
                    <div className="flex items-start gap-3">
                      <ShieldAlert className="h-5 w-5 text-primary mt-0.5" />
                      <div className="space-y-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <Badge variant="outline" className="font-mono text-[10px]">{r.cloudProvider}</Badge>
                          <span className="font-medium text-sm">{r.category}</span>
                          <Badge variant="outline" className={sevTone[r.severity] + " text-[10px]"}>{r.severity}</Badge>
                        </div>
                        <p className="text-xs text-muted-foreground max-w-2xl">{r.ruleText}</p>
                      </div>
                    </div>
                    <div className="flex gap-1">
                      <Button variant="ghost" size="icon" onClick={() => openEdit(r)}><Pencil className="h-3.5 w-3.5" /></Button>
                      <Button variant="ghost" size="icon" onClick={() => remove(r.id)}><Trash2 className="h-3.5 w-3.5 text-destructive" /></Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>{draft?.id ? "Edit Rule" : "Add Rule"}</DialogTitle></DialogHeader>
          <div className="space-y-3 py-2">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1"><Label>Cloud Provider</Label>
                <Select value={draft?.cloudProvider ?? "AWS"} onValueChange={(v: any) => setDraft({ ...draft, cloudProvider: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="AWS">AWS</SelectItem>
                    <SelectItem value="Azure">Azure</SelectItem>
                    <SelectItem value="GCP">GCP</SelectItem>
                    <SelectItem value="On-Prem">On-Prem</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1"><Label>Severity</Label>
                <Select value={draft?.severity ?? "CRITICAL"} onValueChange={(v: any) => setDraft({ ...draft, severity: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="CRITICAL">CRITICAL</SelectItem>
                    <SelectItem value="HIGH">HIGH</SelectItem>
                    <SelectItem value="MEDIUM">MEDIUM</SelectItem>
                    <SelectItem value="LOW">LOW</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-1"><Label>Category</Label><Input value={draft?.category ?? ""} placeholder="e.g. Network Security, Identity, Storage" onChange={(e) => setDraft({ ...draft, category: e.target.value })} /></div>
            <div className="space-y-1"><Label>Rule Text</Label><Textarea rows={4} value={draft?.ruleText ?? ""} onChange={(e) => setDraft({ ...draft, ruleText: e.target.value })} /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button onClick={save}>Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </ConsoleLayout>
  );
};

export default ArchRulesConfigPage;