import { ConsoleLayout, NavItem } from "@/components/admin/ConsoleLayout";
import { Inbox, Users, BarChart3, ScrollText, LayoutDashboard, ShieldCheck, Settings } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { DIS_ADMINS, getAllOnboardings, statusTone, toneClass, MOCK_USERS } from "@/lib/adminMockData";
import { Progress } from "@/components/ui/progress";

export const superNav: NavItem[] = [
  { title: "Overview", url: "/superadmin", icon: LayoutDashboard },
  { title: "Assignment Console", url: "/superadmin/assignments", icon: Inbox, badge: "2" },
  { title: "Admin Management", url: "/superadmin/admins", icon: Users },
  { title: "Configuration", url: "/superadmin/config", icon: Settings },
  { title: "Global Oversight", url: "/superadmin/oversight", icon: BarChart3 },
  { title: "Audit & Policy", url: "/superadmin/audit", icon: ScrollText },
];

const Kpi = ({ label, value, tone = "bg-primary/10 text-primary" }: any) => (
  <Card><CardContent className="p-4">
    <p className="text-xs text-muted-foreground">{label}</p>
    <p className={`text-2xl font-semibold mt-1`}>{value}</p>
  </CardContent></Card>
);

const SuperAdminDashboard = () => {
  const all = getAllOnboardings();
  const unassigned = all.filter((o) => !o.assignedAdmin).length;
  const escalated = all.filter((o) => o.escalated).length;
  const completed = all.filter((o) => o.status === "Completed").length;
  return (
    <ConsoleLayout role="superadmin" items={superNav}>
      <div className="space-y-6 max-w-[1500px]">
        <div>
          <h2 className="text-2xl font-semibold">Super Admin Overview</h2>
          <p className="text-sm text-muted-foreground">Hi {MOCK_USERS.superadmin.name.split(" ")[0]} — system-wide view of onboarding orchestration, admin workload, and SLA health.</p>
        </div>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <Kpi label="Total onboardings" value={all.length} />
          <Kpi label="Awaiting assignment" value={unassigned} />
          <Kpi label="Escalated" value={escalated} />
          <Kpi label="Completed (30d)" value={completed} />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <Card><CardContent className="p-4 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold flex items-center gap-2"><Users className="h-4 w-4" /> DIS Admin workload</h3>
              <Badge variant="outline">{DIS_ADMINS.filter((a) => a.status === "Active").length} active</Badge>
            </div>
            <div className="space-y-3">
              {DIS_ADMINS.map((a) => {
                const pct = Math.round((a.active / a.capacity) * 100);
                return (
                  <div key={a.id} className="space-y-1">
                    <div className="flex justify-between text-xs">
                      <span className="font-medium text-foreground">{a.name} <span className="text-muted-foreground">· {a.region}</span></span>
                      <span className="font-mono">{a.active}/{a.capacity}</span>
                    </div>
                    <Progress value={pct} className={pct >= 100 ? "[&>div]:bg-destructive" : pct >= 80 ? "[&>div]:bg-warning" : ""} />
                  </div>
                );
              })}
            </div>
          </CardContent></Card>

          <Card><CardContent className="p-4 space-y-3">
            <h3 className="font-semibold flex items-center gap-2"><ShieldCheck className="h-4 w-4" /> Recent onboardings</h3>
            <div className="overflow-x-auto"><Table>
              <TableHeader><TableRow>
                <TableHead>ID</TableHead><TableHead>Project</TableHead><TableHead>Cloud</TableHead><TableHead>Status</TableHead>
              </TableRow></TableHeader>
              <TableBody>{all.slice(0, 6).map((o) => (
                <TableRow key={o.id}>
                  <TableCell className="font-mono text-xs">{o.id}</TableCell>
                  <TableCell className="text-sm">{o.project}</TableCell>
                  <TableCell><Badge variant="outline">{o.cloud}</Badge></TableCell>
                  <TableCell><Badge className={toneClass(statusTone(o.status))}>{o.status}</Badge></TableCell>
                </TableRow>
              ))}</TableBody>
            </Table></div>
          </CardContent></Card>
        </div>
      </div>
    </ConsoleLayout>
  );
};
export default SuperAdminDashboard;
