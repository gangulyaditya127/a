import { useMemo, useState } from "react";
import { ConsoleLayout } from "@/components/admin/ConsoleLayout";
import { superNav } from "./SuperAdminDashboard";
import { Card, CardContent } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { DIS_ADMINS, getAllOnboardings, adminById, statusTone, toneClass } from "@/lib/adminMockData";
import { toast } from "@/hooks/use-toast";

const SaAssignments = () => {
  const initial = useMemo(() => getAllOnboardings(), []);
  const [items, setItems] = useState(initial);
  const assign = (id: string, adminId: string) => {
    setItems((prev) => prev.map((o) => o.id === id ? { ...o, assignedAdmin: adminId, status: o.status === "Submitted" ? "Under Review" : o.status } : o));
    const a = adminById(adminId);
    toast({ title: "Assigned", description: `${id} → ${a?.name}` });
  };
  const unassigned = items.filter((o) => !o.assignedAdmin);
  const assigned = items.filter((o) => o.assignedAdmin);

  return (
    <ConsoleLayout role="superadmin" items={superNav}>
      <div className="space-y-6 max-w-[1500px]">
        <div>
          <h2 className="text-2xl font-semibold">Assignment Console</h2>
          <p className="text-sm text-muted-foreground">New onboardings auto-routed after cloud selection. Assign to a DIS Admin to begin operational coordination.</p>
        </div>

        <Card><CardContent className="p-4 space-y-3">
          <h3 className="font-semibold">Awaiting assignment ({unassigned.length})</h3>
          <div className="overflow-x-auto"><Table>
            <TableHeader><TableRow>
              <TableHead>ID</TableHead><TableHead>Project</TableHead><TableHead>Requester</TableHead><TableHead>Cloud</TableHead>
              <TableHead>Status</TableHead><TableHead>Assign to</TableHead>
            </TableRow></TableHeader>
            <TableBody>{unassigned.map((o) => (
              <TableRow key={o.id}>
                <TableCell className="font-mono text-xs">{o.id}</TableCell>
                <TableCell className="font-medium">{o.project}</TableCell>
                <TableCell className="text-muted-foreground">{o.requester}</TableCell>
                <TableCell><Badge variant="outline">{o.cloud}</Badge></TableCell>
                <TableCell><Badge className={toneClass(statusTone(o.status))}>{o.status}</Badge></TableCell>
                <TableCell>
                  <Select onValueChange={(v) => assign(o.id, v)}>
                    <SelectTrigger className="w-56 h-8 text-xs"><SelectValue placeholder="Choose DIS Admin..." /></SelectTrigger>
                    <SelectContent>
                      {DIS_ADMINS.filter((a) => a.status === "Active").map((a) => (
                        <SelectItem key={a.id} value={a.id}>{a.name} — {a.active}/{a.capacity} ({a.region})</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </TableCell>
              </TableRow>
            ))}
            {unassigned.length === 0 && <TableRow><TableCell colSpan={6} className="text-center text-sm text-muted-foreground py-6">No pending assignments.</TableCell></TableRow>}
            </TableBody>
          </Table></div>
        </CardContent></Card>

        <Card><CardContent className="p-4 space-y-3">
          <h3 className="font-semibold">Assigned onboardings ({assigned.length})</h3>
          <div className="overflow-x-auto"><Table>
            <TableHeader><TableRow>
              <TableHead>ID</TableHead><TableHead>Project</TableHead><TableHead>DIS Admin</TableHead>
              <TableHead>Status</TableHead><TableHead>SLA</TableHead><TableHead></TableHead>
            </TableRow></TableHeader>
            <TableBody>{assigned.map((o) => {
              const a = adminById(o.assignedAdmin);
              return (
                <TableRow key={o.id}>
                  <TableCell className="font-mono text-xs">{o.id}</TableCell>
                  <TableCell className="font-medium">{o.project}</TableCell>
                  <TableCell className="text-sm">{a?.name ?? "—"}</TableCell>
                  <TableCell><Badge className={toneClass(statusTone(o.status))}>{o.status}</Badge></TableCell>
                  <TableCell className={`text-xs font-mono ${o.ageHours > o.slaHours ? "text-destructive" : "text-muted-foreground"}`}>{o.ageHours}h / {o.slaHours}h</TableCell>
                  <TableCell className="text-right"><Button size="sm" variant="ghost">Reassign</Button></TableCell>
                </TableRow>
              );
            })}</TableBody>
          </Table></div>
        </CardContent></Card>
      </div>
    </ConsoleLayout>
  );
};
export default SaAssignments;
