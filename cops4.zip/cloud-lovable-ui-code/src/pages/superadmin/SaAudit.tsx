import { ConsoleLayout } from "@/components/admin/ConsoleLayout";
import { superNav } from "./SuperAdminDashboard";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { AUDIT_LOG } from "@/lib/adminMockData";

const STATUSES = ["Draft", "Submitted", "Under Review", "Pending Governance", "Pending GPS", "Pending ISM", "Pending RFC", "Service ID In Progress", "RFC In Progress", "Completed", "Rejected", "Escalated"];
const TEAMS = [
  { team: "Governance", lead: "Sanjay Pillai", sla: "48h", contact: "governance@tcs.com" },
  { team: "ISM", lead: "Rohan Bhatt", sla: "72h", contact: "ism@tcs.com" },
  { team: "GPS", lead: "Asha Reddy", sla: "48h", contact: "gps@tcs.com" },
  { team: "Change / RFC", lead: "Kunal Shah", sla: "96h", contact: "change@tcs.com" },
];

const roleTone = (r: string) => r === "Super Admin" ? "bg-warning/10 text-warning" : r === "DIS Admin" ? "bg-accent/15 text-accent" : r === "System" ? "bg-muted text-muted-foreground" : "bg-info/10 text-info";

const SaAudit = () => (
  <ConsoleLayout role="superadmin" items={superNav}>
    <div className="space-y-6 max-w-[1400px]">
      <div>
        <h2 className="text-2xl font-semibold">Audit & Policy</h2>
        <p className="text-sm text-muted-foreground">Audit log of admin actions, configurable status model, and approval team directory.</p>
      </div>

      <Card><CardContent className="p-4 space-y-3">
        <div className="flex items-center justify-between gap-2">
          <h3 className="font-semibold">Audit log</h3>
          <Input placeholder="Filter by actor or target..." className="w-72" />
        </div>
        <div className="overflow-x-auto"><Table>
          <TableHeader><TableRow>
            <TableHead>Timestamp</TableHead><TableHead>Actor</TableHead><TableHead>Role</TableHead>
            <TableHead>Action</TableHead><TableHead>Target</TableHead>
          </TableRow></TableHeader>
          <TableBody>{AUDIT_LOG.map((e) => (
            <TableRow key={e.id}>
              <TableCell className="font-mono text-xs text-muted-foreground">{new Date(e.ts).toLocaleString()}</TableCell>
              <TableCell className="text-sm font-medium">{e.actor}</TableCell>
              <TableCell><Badge className={roleTone(e.role)}>{e.role}</Badge></TableCell>
              <TableCell className="text-sm">{e.action}</TableCell>
              <TableCell className="font-mono text-xs">{e.target}</TableCell>
            </TableRow>
          ))}</TableBody>
        </Table></div>
      </CardContent></Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card><CardContent className="p-4 space-y-3">
          <h3 className="font-semibold">Status model</h3>
          <p className="text-xs text-muted-foreground">Configured statuses available across the orchestration platform.</p>
          <div className="flex flex-wrap gap-1.5">
            {STATUSES.map((s) => <Badge key={s} variant="outline">{s}</Badge>)}
          </div>
          <Button size="sm" variant="outline" className="mt-2">Manage statuses</Button>
        </CardContent></Card>

        <Card><CardContent className="p-4 space-y-3">
          <h3 className="font-semibold">Approval teams</h3>
          <Table>
            <TableHeader><TableRow>
              <TableHead>Team</TableHead><TableHead>Lead</TableHead><TableHead>SLA</TableHead><TableHead>Contact</TableHead>
            </TableRow></TableHeader>
            <TableBody>{TEAMS.map((t) => (
              <TableRow key={t.team}>
                <TableCell className="font-medium">{t.team}</TableCell>
                <TableCell>{t.lead}</TableCell>
                <TableCell className="font-mono text-xs">{t.sla}</TableCell>
                <TableCell className="text-xs text-muted-foreground">{t.contact}</TableCell>
              </TableRow>
            ))}</TableBody>
          </Table>
        </CardContent></Card>
      </div>
    </div>
  </ConsoleLayout>
);
export default SaAudit;
