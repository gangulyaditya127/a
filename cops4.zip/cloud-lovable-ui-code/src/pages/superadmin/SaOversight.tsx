import { ConsoleLayout } from "@/components/admin/ConsoleLayout";
import { superNav } from "./SuperAdminDashboard";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { getAllOnboardings, adminById, statusTone, toneClass, DIS_ADMINS } from "@/lib/adminMockData";

const SaOversight = () => {
  const all = getAllOnboardings();
  const byCloud = ["AWS", "Azure", "GCP"].map((c) => ({ cloud: c, count: all.filter((o) => o.cloud === c).length }));
  const byStatus = Object.entries(all.reduce<Record<string, number>>((m, o) => { m[o.status] = (m[o.status] || 0) + 1; return m; }, {}));
  return (
    <ConsoleLayout role="superadmin" items={superNav}>
      <div className="space-y-6 max-w-[1500px]">
        <div>
          <h2 className="text-2xl font-semibold">Global Oversight</h2>
          <p className="text-sm text-muted-foreground">Org-wide view across all admins, clouds and SLA health.</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <Card><CardContent className="p-4 space-y-3">
            <h3 className="font-semibold text-sm">By cloud provider</h3>
            {byCloud.map((c) => (
              <div key={c.cloud} className="flex items-center gap-3">
                <span className="text-xs w-12 text-muted-foreground">{c.cloud}</span>
                <div className="flex-1 h-2 rounded bg-muted overflow-hidden">
                  <div className="h-full bg-primary" style={{ width: `${(c.count / all.length) * 100}%` }} />
                </div>
                <span className="text-xs font-mono">{c.count}</span>
              </div>
            ))}
          </CardContent></Card>

          <Card><CardContent className="p-4 space-y-2">
            <h3 className="font-semibold text-sm">Status distribution</h3>
            <div className="flex flex-wrap gap-1.5">
              {byStatus.map(([s, n]) => (
                <Badge key={s} className={toneClass(statusTone(s as any))}>{s} · {n}</Badge>
              ))}
            </div>
          </CardContent></Card>

          <Card><CardContent className="p-4 space-y-2">
            <h3 className="font-semibold text-sm">SLA heatmap</h3>
            <div className="grid grid-cols-5 gap-1">
              {DIS_ADMINS.map((a) => {
                const tone = a.slaCompliance >= 95 ? "bg-success" : a.slaCompliance >= 90 ? "bg-warning" : "bg-destructive";
                return (
                  <div key={a.id} className={`aspect-square ${tone} rounded flex items-center justify-center text-[10px] text-primary-foreground font-mono`}>
                    {a.slaCompliance}
                  </div>
                );
              })}
            </div>
            <p className="text-[10px] text-muted-foreground">% SLA compliance per DIS Admin</p>
          </CardContent></Card>
        </div>

        <Card><CardContent className="p-4 space-y-3">
          <h3 className="font-semibold">All onboardings</h3>
          <div className="overflow-x-auto"><Table>
            <TableHeader><TableRow>
              <TableHead>ID</TableHead><TableHead>Project</TableHead><TableHead>Cloud</TableHead>
              <TableHead>Assigned</TableHead><TableHead>Status</TableHead><TableHead>SLA</TableHead>
            </TableRow></TableHeader>
            <TableBody>{all.map((o) => (
              <TableRow key={o.id}>
                <TableCell className="font-mono text-xs">{o.id}</TableCell>
                <TableCell className="font-medium">{o.project}</TableCell>
                <TableCell><Badge variant="outline">{o.cloud}</Badge></TableCell>
                <TableCell className="text-sm">{adminById(o.assignedAdmin)?.name ?? <span className="text-muted-foreground italic">unassigned</span>}</TableCell>
                <TableCell><Badge className={toneClass(statusTone(o.status))}>{o.status}</Badge></TableCell>
                <TableCell className={`text-xs font-mono ${o.ageHours > o.slaHours ? "text-destructive" : "text-muted-foreground"}`}>{o.ageHours}h / {o.slaHours}h</TableCell>
              </TableRow>
            ))}</TableBody>
          </Table></div>
        </CardContent></Card>
      </div>
    </ConsoleLayout>
  );
};
export default SaOversight;
