import { ConsoleLayout } from "@/components/admin/ConsoleLayout";
import { superNav } from "./SuperAdminDashboard";
import { Card, CardContent } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { DIS_ADMINS } from "@/lib/adminMockData";
import { Plus } from "lucide-react";

const SaAdmins = () => (
  <ConsoleLayout role="superadmin" items={superNav}>
    <div className="space-y-4 max-w-[1300px]">
      <div className="flex items-end justify-between">
        <div>
          <h2 className="text-2xl font-semibold">Admin Management</h2>
          <p className="text-sm text-muted-foreground">Manage DIS Admins, their capacity, regions and performance.</p>
        </div>
        <Button><Plus className="h-4 w-4" /> Add DIS Admin</Button>
      </div>
      <Card><CardContent className="p-0"><div className="overflow-x-auto"><Table>
        <TableHeader><TableRow>
          <TableHead>Name</TableHead><TableHead>Email</TableHead><TableHead>Region</TableHead>
          <TableHead>Load</TableHead><TableHead>SLA Compliance</TableHead><TableHead>Status</TableHead><TableHead></TableHead>
        </TableRow></TableHeader>
        <TableBody>{DIS_ADMINS.map((a) => {
          const pct = Math.round((a.active / a.capacity) * 100);
          return (
            <TableRow key={a.id}>
              <TableCell className="font-medium">{a.name}</TableCell>
              <TableCell className="text-xs text-muted-foreground">{a.email}</TableCell>
              <TableCell><Badge variant="outline">{a.region}</Badge></TableCell>
              <TableCell className="w-48">
                <div className="space-y-1">
                  <Progress value={pct} className={pct >= 100 ? "[&>div]:bg-destructive" : pct >= 80 ? "[&>div]:bg-warning" : ""} />
                  <span className="text-[10px] font-mono text-muted-foreground">{a.active}/{a.capacity}</span>
                </div>
              </TableCell>
              <TableCell><span className={`text-sm font-mono ${a.slaCompliance >= 95 ? "text-success" : a.slaCompliance >= 90 ? "text-warning" : "text-destructive"}`}>{a.slaCompliance}%</span></TableCell>
              <TableCell><Badge variant={a.status === "Active" ? "outline" : "secondary"}>{a.status}</Badge></TableCell>
              <TableCell className="text-right"><Button size="sm" variant="ghost">Edit</Button></TableCell>
            </TableRow>
          );
        })}</TableBody>
      </Table></div></CardContent></Card>
    </div>
  </ConsoleLayout>
);
export default SaAdmins;
