import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { ConsoleLayout } from "@/components/admin/ConsoleLayout";
import { superNav } from "./SuperAdminDashboard";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowRight, HelpCircle, FileText, ShieldCheck } from "lucide-react";
import { configSummary } from "@/lib/configStorage";

const cards = [
  { key: "eligibility", title: "Eligibility Criteria", description: "Questions shown during the eligibility assessment a user takes before starting onboarding.", icon: HelpCircle, path: "/superadmin/config/eligibility", count: (s: any) => s.eligibility, label: "questions" },
  { key: "disclaimer",  title: "Disclaimer Clauses",   description: "Governance, security and compliance commitments the user must acknowledge.", icon: FileText, path: "/superadmin/config/disclaimer", count: (s: any) => s.disclaimer, label: "clauses" },
  { key: "arch",        title: "Architecture Rules",   description: "Validation rules applied by DIS Admin during architecture review.", icon: ShieldCheck, path: "/superadmin/config/architecture-rules", count: (s: any) => s.archRules, label: "rules" },
];

const SaConfig = () => {
  const [s, setS] = useState(() => configSummary());
  useEffect(() => { setS(configSummary()); }, []);
  return (
    <ConsoleLayout role="superadmin" items={superNav}>
      <div className="space-y-6 max-w-[1300px]">
        <div>
          <h2 className="text-2xl font-semibold">Platform Configuration</h2>
          <p className="text-sm text-muted-foreground">Manage the registries that drive eligibility, disclaimer and architecture validation for every onboarding.</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {cards.map((c) => (
            <Card key={c.key} className="shadow-card hover:shadow-card-hover transition-shadow">
              <CardHeader className="space-y-2">
                <div className="h-10 w-10 rounded-md bg-primary/10 text-primary flex items-center justify-center">
                  <c.icon className="h-5 w-5" />
                </div>
                <CardTitle className="text-base">{c.title}</CardTitle>
                <p className="text-xs text-muted-foreground">{c.description}</p>
              </CardHeader>
              <CardContent className="flex items-center justify-between">
                <div>
                  <span className="text-2xl font-semibold">{c.count(s)}</span>
                  <span className="text-xs text-muted-foreground ml-1">{c.label}</span>
                </div>
                <Link to={c.path}>
                  <Button variant="outline" size="sm">Manage <ArrowRight className="h-3.5 w-3.5 ml-1" /></Button>
                </Link>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </ConsoleLayout>
  );
};

export default SaConfig;