import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { TopNav } from "@/components/TopNav";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Checkbox } from "@/components/ui/checkbox";
import { AlertTriangle, ArrowLeft, ArrowRight, CheckCircle2, FileCheck2, ShieldAlert, ShieldCheck, XCircle } from "lucide-react";
import { loadDisclaimer, loadEligibility, type EligibilityCriterion } from "@/lib/configStorage";

type Answer = string | string[] | null;
type Phase = "disclaimer" | "questions" | "failed" | "passed";

const passes = (q: EligibilityCriterion, a: Answer) => {
  if (q.questionType === "multi") {
    const c = Array.isArray(q.correctAnswer) ? q.correctAnswer : [q.correctAnswer as string];
    return Array.isArray(a) && a.length === c.length && c.every((x) => a.includes(x));
  }
  return a === q.correctAnswer;
};

const Eligibility = () => {
  const nav = useNavigate();
  const questions = useMemo(() => loadEligibility(), []);
  const clauses = useMemo(() => loadDisclaimer(), []);
  const [phase, setPhase] = useState<Phase>("disclaimer");
  const [idx, setIdx] = useState(0);
  const [answers, setAnswers] = useState<Record<string, Answer>>({});
  const [failMessage, setFailMessage] = useState<string>("");

  useEffect(() => {
    if (phase === "passed") {
      sessionStorage.setItem("dis_eligibility_ok", "1");
      nav("/?new=1");
    }
  }, [phase, nav]);

  if (phase === "disclaimer") {
    return (
      <div className="min-h-screen bg-background flex flex-col">
        <TopNav />
        <main className="flex-1 overflow-auto">
          <div className="max-w-3xl mx-auto p-6">
            <Card className="shadow-card">
              <CardHeader className="space-y-3">
                <Badge variant="outline" className="w-fit gap-1.5"><FileCheck2 className="h-3.5 w-3.5" /> Disclaimer & Acknowledgement</Badge>
                <CardTitle className="text-2xl">DIS Managed Cloud — Governance, Security & Compliance</CardTitle>
                <p className="text-sm text-muted-foreground">Review and acknowledge the operational commitments before starting onboarding.</p>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="rounded-lg border border-warning/20 bg-warning/5 p-3 text-xs flex items-start gap-2">
                  <ShieldAlert className="h-4 w-4 text-warning mt-0.5 shrink-0" />
                  <span>By selecting <strong>I Agree</strong>, you confirm the project will adhere to every policy below. Exceptions require explicit ISM / Security / Compliance approval.</span>
                </div>
                <ul className="space-y-3">
                  {clauses.map((c) => (
                    <li key={c.id} className="rounded-lg border bg-card p-4">
                      <p className="font-medium text-sm">{c.title}</p>
                      <p className="text-sm text-muted-foreground leading-relaxed mt-1">{c.text}</p>
                    </li>
                  ))}
                </ul>
                <div className="flex justify-end gap-2 pt-3 border-t">
                  <Button variant="outline" onClick={() => nav("/")}>
                    <XCircle className="h-4 w-4 mr-1" /> I Disagree
                  </Button>
                  <Button onClick={() => setPhase("questions")} className="gradient-primary text-primary-foreground">
                    <CheckCircle2 className="h-4 w-4 mr-1" /> I Agree — Continue
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    );
  }

  if (phase === "failed") {
    return (
      <div className="min-h-screen bg-background flex flex-col">
        <TopNav />
        <main className="flex-1 flex items-center justify-center p-6">
          <Card className="max-w-2xl w-full shadow-card border-destructive/30">
            <CardHeader className="space-y-3">
              <div className="h-12 w-12 rounded-full bg-destructive/10 text-destructive flex items-center justify-center"><XCircle className="h-7 w-7" /></div>
              <Badge variant="outline" className="w-fit text-destructive border-destructive/30">Eligibility Failed</Badge>
              <CardTitle className="text-2xl">This project is not eligible for DIS Managed Cloud onboarding</CardTitle>
            </CardHeader>
            <CardContent className="space-y-5">
              <div className="rounded-lg border border-destructive/20 bg-destructive/5 p-4 text-sm">
                <p className="font-medium">Reason:</p>
                <p className="text-muted-foreground mt-1">{failMessage}</p>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" onClick={() => nav("/")}><ArrowLeft className="h-4 w-4 mr-1" /> Back to Dashboard</Button>
                <Button onClick={() => { setAnswers({}); setIdx(0); setPhase("questions"); }}>Restart Assessment</Button>
              </div>
            </CardContent>
          </Card>
        </main>
      </div>
    );
  }

  if (questions.length === 0) {
    // No criteria configured — auto-pass.
    if (phase !== "passed") setPhase("passed");
    return null;
  }

  const q = questions[idx];
  const current = answers[q.id];
  const progress = ((idx + (current ? 1 : 0)) / questions.length) * 100;
  const setAnswer = (val: Answer) => setAnswers((p) => ({ ...p, [q.id]: val }));
  const toggleMulti = (opt: string) => {
    const arr = Array.isArray(current) ? [...current] : [];
    const i = arr.indexOf(opt);
    if (i >= 0) arr.splice(i, 1); else arr.push(opt);
    setAnswer(arr);
  };
  const next = () => {
    if (!passes(q, current ?? null)) { setFailMessage(q.failMessage); setPhase("failed"); return; }
    if (idx === questions.length - 1) setPhase("passed"); else setIdx(idx + 1);
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <TopNav />
      <main className="flex-1 flex items-center justify-center p-6">
        <Card className="max-w-2xl w-full shadow-card">
          <CardHeader className="space-y-4">
            <div className="flex items-center gap-2">
              <Badge variant="outline" className="gap-1.5"><ShieldCheck className="h-3.5 w-3.5" /> Eligibility Assessment</Badge>
              <Badge variant="secondary">{idx + 1}/{questions.length}</Badge>
            </div>
            <Progress value={progress} className="h-1.5" />
            <p className="text-xs text-muted-foreground uppercase tracking-wide">{q.section}</p>
            <CardTitle className="text-xl leading-snug">{q.title}</CardTitle>
            {q.note && (
              <div className="flex items-start gap-2 text-xs text-muted-foreground bg-muted/50 rounded-md p-2">
                <AlertTriangle className="h-3.5 w-3.5 mt-0.5 shrink-0" /> {q.note}
              </div>
            )}
          </CardHeader>
          <CardContent className="space-y-6">
            {q.questionType === "single" ? (
              <RadioGroup value={(current as string) ?? ""} onValueChange={setAnswer} className="space-y-2">
                {q.options.map((opt) => (
                  <label key={opt} className={`flex items-center gap-3 p-3 rounded-lg border-2 cursor-pointer transition-all ${current === opt ? "border-primary bg-primary/5" : "border-border hover:border-primary/40"}`}>
                    <RadioGroupItem value={opt} />
                    <span className="text-sm font-medium">{opt}</span>
                  </label>
                ))}
              </RadioGroup>
            ) : (
              <div className="space-y-2">
                {q.options.map((opt) => {
                  const checked = Array.isArray(current) && current.includes(opt);
                  return (
                    <label key={opt} className={`flex items-center gap-3 p-3 rounded-lg border-2 cursor-pointer transition-all ${checked ? "border-primary bg-primary/5" : "border-border hover:border-primary/40"}`}>
                      <Checkbox checked={checked} onCheckedChange={() => toggleMulti(opt)} />
                      <span className="text-sm font-medium">{opt}</span>
                    </label>
                  );
                })}
              </div>
            )}
            <div className="flex items-center justify-between pt-2">
              <Button variant="ghost" onClick={() => idx === 0 ? nav("/") : setIdx(idx - 1)}>
                <ArrowLeft className="h-4 w-4 mr-1" /> {idx === 0 ? "Cancel" : "Back"}
              </Button>
              <Button onClick={next} disabled={current == null || current === "" || (Array.isArray(current) && current.length === 0)} className="gradient-primary text-primary-foreground">
                {idx === questions.length - 1 ? <>Submit <CheckCircle2 className="h-4 w-4 ml-1" /></> : <>Next <ArrowRight className="h-4 w-4 ml-1" /></>}
              </Button>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
};

export default Eligibility;