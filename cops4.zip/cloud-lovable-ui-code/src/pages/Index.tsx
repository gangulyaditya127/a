import { useEffect, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { Dashboard } from "@/components/Dashboard";
import { OnboardingWizard } from "@/components/OnboardingWizard";
import { type PopularOnboardingTemplate } from "@/data/onboardingTemplates";
import type { SavedOnboarding } from "@/lib/onboardingStorage";

type Mode = "dashboard" | "wizard";

const Index = () => {
  const [mode, setMode] = useState<Mode>("dashboard");
  const [template, setTemplate] = useState<PopularOnboardingTemplate | null>(null);
  const [existing, setExisting] = useState<SavedOnboarding | null>(null);
  const nav = useNavigate();
  const [params, setParams] = useSearchParams();

  // Returning from /eligibility with ?new=1 — auto-start the wizard.
  useEffect(() => {
    if (params.get("new") === "1" && sessionStorage.getItem("dis_eligibility_ok") === "1") {
      sessionStorage.removeItem("dis_eligibility_ok");
      setTemplate(null); setExisting(null); setMode("wizard");
      setParams({}, { replace: true });
    }
  }, [params, setParams]);

  const startBlank = () => nav("/eligibility");

  if (mode === "dashboard") {
    return (
      <Dashboard
        onStartBlank={startBlank}
        onUseTemplate={(t) => { setTemplate(t); setExisting(null); setMode("wizard"); }}
        onResume={(item) => { setTemplate(null); setExisting(item); setMode("wizard"); }}
      />
    );
  }

  return (
    <OnboardingWizard
      initialTemplate={template?.state}
      existing={existing}
      onBackToDashboard={() => setMode("dashboard")}
    />
  );
};

export default Index;
