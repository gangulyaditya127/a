import { ConsoleLayout } from "@/components/admin/ConsoleLayout";
import { adminNav } from "./AdminDashboard";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { AlertTriangle, ChevronRight } from "lucide-react";
import { getAllOnboardings, statusTone, toneClass } from "@/lib/adminMockData";

const AdminEscalations = () => {
  const items = getAllOnboardings().filter((o) => o.escalated || o.ageHours > o.slaHours);
  return (
    <ConsoleLayout role="admin" items={adminNav}>
      <div className="space-y-4 max-w-[1200px]">
        <div>
          <h2 className="text-2xl font-semibold">Escalations</h2>
          <p className="text-sm text-muted-foreground">SLA breaches and blockers requiring escalation to Super Admin or approval teams.</p>
        </div>
        <div className="space-y-3">
          {items.map((o) => (
            <Card key={o.id}><CardContent className="p-4 flex items-center gap-4">
              <div className="h-10 w-10 rounded-md bg-warning/15 text-warning flex items-center justify-center"><AlertTriangle className="h-5 w-5" /></div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-medium text-foreground">{o.project}</span>
                  <span className="font-mono text-xs text-muted-foreground">{o.id}</span>
                  <Badge className={toneClass(statusTone(o.status))}>{o.status}</Badge>
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  SLA: <span className="font-mono">{o.ageHours}h / {o.slaHours}h</span> · Pending: {o.pendingApprovals.join(", ") || "—"} · Requester: {o.requester}
                </p>
              </div>
              <Button size="sm" variant="outline">Escalate <ChevronRight className="h-3.5 w-3.5" /></Button>
            </CardContent></Card>
          ))}
          {items.length === 0 && <Card><CardContent className="p-8 text-center text-sm text-muted-foreground">No active escalations.</CardContent></Card>}
        </div>
      </div>
    </ConsoleLayout>
  );
};
export default AdminEscalations;
