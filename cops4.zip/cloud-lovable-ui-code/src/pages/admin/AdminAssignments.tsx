import { ConsoleLayout } from "@/components/admin/ConsoleLayout";
import { adminNav } from "./AdminDashboard";
import { Card, CardContent } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { getAllOnboardings, statusTone, toneClass } from "@/lib/adminMockData";

const AdminAssignments = () => {
  const all = getAllOnboardings().filter((o) => o.assignedAdmin === "a1");
  return (
    <ConsoleLayout role="admin" items={adminNav}>
      <div className="space-y-4 max-w-[1400px]">
        <div>
          <h2 className="text-2xl font-semibold">Assignments</h2>
          <p className="text-sm text-muted-foreground">All onboardings currently assigned to you as SPOC.</p>
        </div>
        <Card><CardContent className="p-0">
          <div className="overflow-x-auto"><Table>
            <TableHeader><TableRow>
              <TableHead>ID</TableHead><TableHead>Project</TableHead><TableHead>Requester</TableHead><TableHead>Cloud</TableHead>
              <TableHead>Status</TableHead><TableHead>Pending</TableHead><TableHead>SLA</TableHead><TableHead>Updated</TableHead><TableHead></TableHead>
            </TableRow></TableHeader>
            <TableBody>{all.map((o) => (
              <TableRow key={o.id}>
                <TableCell className="font-mono text-xs">{o.id}</TableCell>
                <TableCell className="font-medium">{o.project}</TableCell>
                <TableCell className="text-muted-foreground">{o.requester}</TableCell>
                <TableCell><Badge variant="outline">{o.cloud}</Badge></TableCell>
                <TableCell><Badge className={toneClass(statusTone(o.status))}>{o.status}</Badge></TableCell>
                <TableCell className="text-xs">{o.pendingApprovals.join(", ") || "—"}</TableCell>
                <TableCell className={`text-xs font-mono ${o.ageHours > o.slaHours ? "text-destructive" : "text-muted-foreground"}`}>{o.ageHours}h / {o.slaHours}h</TableCell>
                <TableCell className="text-xs text-muted-foreground">{new Date(o.updatedAt).toLocaleString()}</TableCell>
                <TableCell className="text-right">
                  <Link to={`/admin/onboardings/${o.id.toLowerCase()}`}>
                    <Button size="sm" variant="outline">Open</Button>
                  </Link>
                </TableCell>
              </TableRow>
            ))}</TableBody>
          </Table></div>
        </CardContent></Card>
      </div>
    </ConsoleLayout>
  );
};
export default AdminAssignments;
