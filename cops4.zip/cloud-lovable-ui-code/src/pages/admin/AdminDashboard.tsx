import { useMemo, useState } from "react";
import { ConsoleLayout, NavItem } from "@/components/admin/ConsoleLayout";
import { LayoutDashboard, Inbox, ShieldAlert, MessageSquare, FileText, Activity, AlertTriangle, Clock, CheckCircle2 } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { adminById, getAllOnboardings, statusTone, toneClass, MOCK_USERS } from "@/lib/adminMockData";
import { Link } from "react-router-dom";

export const adminNav: NavItem[] = [
  { title: "Dashboard", url: "/admin", icon: LayoutDashboard },
  { title: "Assignments", url: "/admin/assignments", icon: Inbox, badge: "8" },
  { title: "Escalations", url: "/admin/escalations", icon: ShieldAlert, badge: "2" },
  { title: "Comments", url: "/admin/comments", icon: MessageSquare, badge: "4" },
  { title: "RFC Tracking", url: "/admin/rfcs", icon: FileText },
  { title: "SLA Monitor", url: "/admin/sla", icon: Activity },
];

const Kpi = ({ label, value, icon: Icon, tone = "" }: any) => (
  <Card><CardContent className="p-4 flex items-center gap-3">
    <div className={`h-10 w-10 rounded-md flex items-center justify-center ${tone || "bg-primary/10 text-primary"}`}><Icon className="h-5 w-5" /></div>
    <div><p className="text-xs text-muted-foreground">{label}</p><p className="text-lg font-semibold text-foreground">{value}</p></div>
  </CardContent></Card>
);

const AdminDashboard = () => {
  const all = useMemo(() => getAllOnboardings().filter((o) => o.assignedAdmin === "a1"), []);
  const [q, setQ] = useState("");
  const [status, setStatus] = useState<string>("all");

  const filtered = all.filter((o) =>
    (status === "all" || o.status === status) &&
    (q === "" || o.project.toLowerCase().includes(q.toLowerCase()) || o.id.toLowerCase().includes(q.toLowerCase()))
  );

  const stats = {
    assigned: all.length,
    pending: all.filter((o) => o.status.toString().startsWith("Pending") || o.status === "In Approval").length,
    escalated: all.filter((o) => o.escalated).length,
    completed: all.filter((o) => o.status === "Completed").length,
  };

  return (
    <ConsoleLayout role="admin" items={adminNav}>
      <div className="space-y-6 max-w-[1400px]">
        <div>
          <h2 className="text-2xl font-semibold text-foreground">Welcome back, {MOCK_USERS.admin.name.split(" ")[0]}</h2>
          <p className="text-sm text-muted-foreground">Operational SPOC view for assigned onboardings. Monitor progress, coordinate with users, and escalate blockers.</p>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <Kpi label="Assigned to me" value={stats.assigned} icon={Inbox} />
          <Kpi label="Pending approvals" value={stats.pending} icon={Clock} tone="bg-info/10 text-info" />
          <Kpi label="Escalated" value={stats.escalated} icon={AlertTriangle} tone="bg-warning/10 text-warning" />
          <Kpi label="Completed (7d)" value={stats.completed} icon={CheckCircle2} tone="bg-success/10 text-success" />
        </div>

        <Card>
          <CardContent className="p-4 space-y-4">
            <div className="flex flex-wrap items-center gap-2 justify-between">
              <div>
                <h3 className="font-semibold text-foreground">My assigned onboardings</h3>
                <p className="text-xs text-muted-foreground">Click a row to open the detail drawer.</p>
              </div>
              <div className="flex gap-2">
                <Input placeholder="Search project or ID..." value={q} onChange={(e) => setQ(e.target.value)} className="w-64" />
                <Select value={status} onValueChange={setStatus}>
                  <SelectTrigger className="w-44"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All statuses</SelectItem>
                    <SelectItem value="Pending Governance">Pending Governance</SelectItem>
                    <SelectItem value="Pending GPS">Pending GPS</SelectItem>
                    <SelectItem value="Pending ISM">Pending ISM</SelectItem>
                    <SelectItem value="Service ID In Progress">Service ID In Progress</SelectItem>
                    <SelectItem value="RFC In Progress">RFC In Progress</SelectItem>
                    <SelectItem value="Architecture Issue">Architecture Issue</SelectItem>
                    <SelectItem value="Completed">Completed</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="rounded-md border overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>ID</TableHead>
                    <TableHead>Project</TableHead>
                    <TableHead>Requester</TableHead>
                    <TableHead>Cloud</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Step</TableHead>
                    <TableHead>SLA</TableHead>
                    <TableHead>Comments</TableHead>
                    <TableHead className="text-right">Action</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filtered.map((o) => {
                    const breach = o.ageHours > o.slaHours;
                    return (
                      <TableRow key={o.id} className="cursor-pointer">
                        <TableCell className="font-mono text-xs">{o.id}</TableCell>
                        <TableCell className="font-medium">{o.project}</TableCell>
                        <TableCell className="text-muted-foreground">{o.requester}</TableCell>
                        <TableCell><Badge variant="outline">{o.cloud}</Badge></TableCell>
                        <TableCell><Badge className={toneClass(statusTone(o.status))}>{o.status}</Badge></TableCell>
                        <TableCell className="text-xs text-muted-foreground">{o.step}</TableCell>
                        <TableCell>
                          <span className={`text-xs font-mono ${breach ? "text-destructive font-semibold" : "text-muted-foreground"}`}>
                            {o.ageHours}h / {o.slaHours}h{breach && " ⚠"}
                          </span>
                        </TableCell>
                        <TableCell>{o.unreadComments > 0 ? <Badge variant="secondary">{o.unreadComments}</Badge> : <span className="text-xs text-muted-foreground">—</span>}</TableCell>
                        <TableCell className="text-right">
                          <Link to={`/admin/onboardings/${o.id.toLowerCase()}`}>
                            <Button size="sm" variant="outline">Open</Button>
                          </Link>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                  {filtered.length === 0 && (
                    <TableRow><TableCell colSpan={9} className="text-center text-sm text-muted-foreground py-8">No onboardings match the filter.</TableCell></TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </div>
    </ConsoleLayout>
  );
};

export default AdminDashboard;
