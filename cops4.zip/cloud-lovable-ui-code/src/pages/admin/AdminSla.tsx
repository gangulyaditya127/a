import { ConsoleLayout } from "@/components/admin/ConsoleLayout";
import { adminNav } from "./AdminDashboard";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { getAllOnboardings, statusTone, toneClass } from "@/lib/adminMockData";

const AdminSla = () => {
  const items = getAllOnboardings().filter((o) => o.assignedAdmin === "a1" && o.status !== "Completed");
  return (
    <ConsoleLayout role="admin" items={adminNav}>
      <div className="space-y-4 max-w-[1100px]">
        <div>
          <h2 className="text-2xl font-semibold">SLA Monitor</h2>
          <p className="text-sm text-muted-foreground">Track elapsed time vs SLA target for each active onboarding.</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {items.map((o) => {
            const pct = Math.min(100, Math.round((o.ageHours / o.slaHours) * 100));
            const breach = pct >= 100;
            return (
              <Card key={o.id}><CardContent className="p-4 space-y-2">
                <div className="flex items-center justify-between gap-2">
                  <div className="min-w-0">
                    <p className="font-medium text-sm truncate">{o.project}</p>
                    <p className="font-mono text-[10px] text-muted-foreground">{o.id}</p>
                  </div>
                  <Badge className={toneClass(statusTone(o.status))}>{o.status}</Badge>
                </div>
                <Progress value={pct} className={breach ? "[&>div]:bg-destructive" : pct > 75 ? "[&>div]:bg-warning" : ""} />
                <div className="flex justify-between text-xs">
                  <span className="text-muted-foreground">{o.ageHours}h elapsed</span>
                  <span className={breach ? "text-destructive font-semibold" : "text-muted-foreground"}>SLA {o.slaHours}h{breach && " — breached"}</span>
                </div>
              </CardContent></Card>
            );
          })}
        </div>
      </div>
    </ConsoleLayout>
  );
};
export default AdminSla;
