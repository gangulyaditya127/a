import { ConsoleLayout } from "@/components/admin/ConsoleLayout";
import { adminNav } from "./AdminDashboard";
import { Card, CardContent } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";

const RFCS = [
  { id: "RFC-771", onboarding: "ONB-2044", title: "Enable VPC peering to shared services", type: "Normal", risk: "Medium", status: "In Implementation", window: "Sat 02:00-04:00" },
  { id: "RFC-772", onboarding: "ONB-2044", title: "Apply WAF rule set v3", type: "Standard", risk: "Low", status: "Submitted", window: "Sun 01:00-02:00" },
  { id: "RFC-769", onboarding: "ONB-2043", title: "Provision BigQuery dataset", type: "Standard", risk: "Low", status: "Approved", window: "Today" },
  { id: "RFC-764", onboarding: "ONB-2041", title: "Add Azure OpenAI quota", type: "Normal", risk: "Medium", status: "Pending RFC", window: "TBD" },
];
const tone = (s: string) => s === "In Implementation" ? "bg-info/10 text-info" : s === "Approved" ? "bg-success/10 text-success" : s === "Submitted" ? "bg-muted text-muted-foreground" : "bg-warning/10 text-warning";

const AdminRfcs = () => (
  <ConsoleLayout role="admin" items={adminNav}>
    <div className="space-y-4 max-w-[1300px]">
      <div>
        <h2 className="text-2xl font-semibold">RFC Tracking</h2>
        <p className="text-sm text-muted-foreground">All RFCs across your assigned onboardings.</p>
      </div>
      <Card><CardContent className="p-0">
        <Table>
          <TableHeader><TableRow>
            <TableHead>RFC</TableHead><TableHead>Onboarding</TableHead><TableHead>Title</TableHead>
            <TableHead>Type</TableHead><TableHead>Risk</TableHead><TableHead>Window</TableHead><TableHead>Status</TableHead>
          </TableRow></TableHeader>
          <TableBody>{RFCS.map((r) => (
            <TableRow key={r.id}>
              <TableCell className="font-mono text-xs">{r.id}</TableCell>
              <TableCell className="font-mono text-xs text-muted-foreground">{r.onboarding}</TableCell>
              <TableCell className="font-medium">{r.title}</TableCell>
              <TableCell><Badge variant="outline">{r.type}</Badge></TableCell>
              <TableCell><Badge variant="outline">{r.risk}</Badge></TableCell>
              <TableCell className="text-xs text-muted-foreground">{r.window}</TableCell>
              <TableCell><Badge className={tone(r.status)}>{r.status}</Badge></TableCell>
            </TableRow>
          ))}</TableBody>
        </Table>
      </CardContent></Card>
    </div>
  </ConsoleLayout>
);
export default AdminRfcs;
