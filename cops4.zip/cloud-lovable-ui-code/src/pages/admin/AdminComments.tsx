import { ConsoleLayout } from "@/components/admin/ConsoleLayout";
import { adminNav } from "./AdminDashboard";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { COMMENTS } from "@/lib/adminMockData";
import { Send } from "lucide-react";

const AdminComments = () => (
  <ConsoleLayout role="admin" items={adminNav}>
    <div className="space-y-4 max-w-[1000px]">
      <div>
        <h2 className="text-2xl font-semibold">Comments Feed</h2>
        <p className="text-sm text-muted-foreground">All clarification threads across your assigned onboardings.</p>
      </div>
      <Card><CardContent className="p-0 divide-y">
        {COMMENTS.map((c) => (
          <div key={c.id} className="p-4 flex gap-3">
            <Avatar className="h-9 w-9"><AvatarFallback>{c.from.split(" ").map((x) => x[0]).join("")}</AvatarFallback></Avatar>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="font-medium text-sm">{c.from}</span>
                <span className="font-mono text-[10px] text-muted-foreground">{c.onboardingId}</span>
                <span className="text-xs text-muted-foreground">· {c.project}</span>
                {c.unread && <Badge variant="secondary" className="h-4 px-1.5 text-[10px]">new</Badge>}
                <span className="text-[10px] text-muted-foreground ml-auto">{new Date(c.ts).toLocaleString()}</span>
              </div>
              <p className="text-sm text-foreground mt-1">{c.message}</p>
              <div className="flex gap-2 mt-2">
                <Input placeholder="Reply..." className="h-8 text-xs" />
                <Button size="sm" variant="outline"><Send className="h-3.5 w-3.5" /></Button>
              </div>
            </div>
          </div>
        ))}
      </CardContent></Card>
    </div>
  </ConsoleLayout>
);
export default AdminComments;
