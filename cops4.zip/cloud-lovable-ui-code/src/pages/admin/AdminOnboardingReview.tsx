import { useEffect, useMemo, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { ConsoleLayout } from "@/components/admin/ConsoleLayout";
import { adminNav } from "./AdminDashboard";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { ArrowLeft, CheckCircle2, AlertTriangle, DollarSign, Lightbulb, Server, Layers, Send, MessageSquare } from "lucide-react";
import { MOCK_USERS, statusTone, toneClass } from "@/lib/adminMockData";
import {
  adminPublishCost,
  adminPublishRecommendations,
  adminSeedCostFromResources,
  adminSetStatus,
  adminUpdateCostBudget,
  computeCostTotal,
  getReviewItem,
} from "@/lib/adminReview";
import { toast } from "@/hooks/use-toast";
import type { SavedOnboarding } from "@/lib/onboardingStorage";
import type { ReviewSection } from "@/types/onboarding";
import { InteractionTimeline } from "@/components/InteractionTimeline";

const AdminOnboardingReview = () => {
  const { id = "" } = useParams<{ id: string }>();
  const [item, setItem] = useState<SavedOnboarding | null>(null);
  const reload = () => setItem(getReviewItem(id));
  useEffect(() => { reload(); }, [id]);

  if (!item) {
    return (
      <ConsoleLayout role="admin" items={adminNav}>
        <Card><CardContent className="p-10 text-center space-y-3">
          <p className="text-sm text-muted-foreground">
            Onboarding <span className="font-mono">{id}</span> is not in your local workspace (it may be a sample row). Create or resume a real onboarding in the user portal first.
          </p>
          <Link to="/admin/assignments"><Button variant="outline" size="sm"><ArrowLeft className="h-3 w-3 mr-1" /> Back to assignments</Button></Link>
        </CardContent></Card>
      </ConsoleLayout>
    );
  }

  const ar = item.state.adminReview!;
  const admin = MOCK_USERS.admin.name;

  return (
    <ConsoleLayout role="admin" items={adminNav}>
      <div className="grid grid-cols-1 xl:grid-cols-[minmax(0,1fr)_360px] gap-6 max-w-[1500px]">
        <div className="space-y-4 min-w-0">
        <Link to="/admin/assignments" className="text-xs text-muted-foreground inline-flex items-center gap-1 hover:text-foreground">
          <ArrowLeft className="h-3 w-3" /> Back to assignments
        </Link>
        <Card>
          <CardHeader className="flex-row items-start justify-between space-y-0">
            <div>
              <CardTitle className="text-xl">{item.name}</CardTitle>
              <p className="text-xs text-muted-foreground mt-1 font-mono">{item.id}</p>
              <p className="text-xs text-muted-foreground">Requestor: {item.state.accountDetails.owner || "—"} · BU: {item.state.accountDetails.businessUnit || "—"}</p>
            </div>
            <Badge className={toneClass(statusTone(item.status as any))}>{item.status}</Badge>
          </CardHeader>
        </Card>

        <Tabs defaultValue="resource">
          <TabsList>
            <TabsTrigger value="resource" className="gap-1.5"><Server className="h-3.5 w-3.5" /> Resource Validation</TabsTrigger>
            <TabsTrigger value="arch" className="gap-1.5"><Layers className="h-3.5 w-3.5" /> Architecture Validation</TabsTrigger>
            <TabsTrigger value="cost" className="gap-1.5"><DollarSign className="h-3.5 w-3.5" /> Cost Budgeting</TabsTrigger>
            <TabsTrigger value="recs" className="gap-1.5"><Lightbulb className="h-3.5 w-3.5" /> Recommendations</TabsTrigger>
          </TabsList>

          <TabsContent value="resource">
            <ResourceTab item={item} section={ar.resourceValidation} admin={admin} reload={reload} />
          </TabsContent>
          <TabsContent value="arch">
            <ArchTab item={item} section={ar.archValidation} admin={admin} reload={reload} />
          </TabsContent>
          <TabsContent value="cost">
            <CostTab item={item} reload={reload} />
          </TabsContent>
          <TabsContent value="recs">
            <RecsTab item={item} reload={reload} />
          </TabsContent>
        </Tabs>
        </div>

        {/* Right rail: Interaction Timeline */}
        <aside className="xl:sticky xl:top-6 self-start h-[calc(100vh-7rem)]">
          <Card className="h-full">
            <CardContent className="p-4 h-full">
              <InteractionTimeline
                events={item.state.events ?? []}
                title="User ↔ Admin Activity"
                emptyHint="No interactions yet. Submissions, comments, decisions and publishes appear here in chronological order."
              />
            </CardContent>
          </Card>
        </aside>
      </div>
    </ConsoleLayout>
  );
};

// ---- Resource tab ----
const SectionActions = ({ id, target, section, admin, reload }: { id: string; target: "resource" | "arch"; section: ReviewSection; admin: string; reload: () => void }) => {
  const [comment, setComment] = useState("");
  const act = (status: "approved" | "changes_requested") => {
    adminSetStatus(id, target, status, comment, admin);
    setComment("");
    reload();
    toast({ title: status === "approved" ? "Approved" : "Changes Requested", description: "User has been notified." });
  };
  return (
    <div className="space-y-3">
      <div className="rounded-md border bg-muted/30 p-3 space-y-2 max-h-56 overflow-auto">
        {section.comments.length === 0 && <p className="text-xs text-muted-foreground">No comments yet.</p>}
        {section.comments.map((c) => (
          <div key={c.id} className="text-xs">
            <div className="flex items-center gap-2">
              <Badge variant={c.role === "admin" ? "default" : "secondary"} className="text-[10px] h-4 px-1.5">{c.role === "admin" ? "DIS Admin" : "Requestor"}</Badge>
              <span className="font-medium">{c.author}</span>
              <span className="text-muted-foreground">{new Date(c.ts).toLocaleString()}</span>
            </div>
            <p className="mt-1 pl-1">{c.message}</p>
          </div>
        ))}
      </div>
      <Textarea rows={2} placeholder="Add review comment (required for Send Back)…" value={comment} onChange={(e) => setComment(e.target.value)} />
      <div className="flex gap-2 justify-end">
        <Button size="sm" variant="outline" onClick={() => act("changes_requested")} disabled={!comment.trim()}>
          <AlertTriangle className="h-3.5 w-3.5 mr-1" /> Send Back
        </Button>
        <Button size="sm" onClick={() => act("approved")} className="bg-success text-success-foreground hover:bg-success/90">
          <CheckCircle2 className="h-3.5 w-3.5 mr-1" /> Approve
        </Button>
      </div>
    </div>
  );
};

const ResourceTab = ({ item, section, admin, reload }: any) => (
  <Card><CardContent className="p-5 space-y-4">
    <div className="flex items-center justify-between">
      <h3 className="font-semibold">Cloud Resource Buckets</h3>
      <Badge variant="outline">Status: {section.status.replace("_", " ")}</Badge>
    </div>
    {item.state.cloudResources.length === 0 ? (
      <p className="text-sm text-muted-foreground">No resources submitted yet by the user.</p>
    ) : item.state.cloudResources.map((b: any) => (
      <div key={b.provider} className="rounded-md border">
        <div className="px-3 py-2 bg-muted/40 text-xs font-semibold uppercase">{b.provider} — {b.resources.length} resource(s)</div>
        <Table>
          <TableHeader><TableRow><TableHead>Service</TableHead><TableHead>Count</TableHead><TableHead>Config</TableHead></TableRow></TableHeader>
          <TableBody>{b.resources.map((r: any) => (
            <TableRow key={r.id}><TableCell className="font-medium">{r.service}</TableCell><TableCell>{r.count}</TableCell><TableCell className="text-xs text-muted-foreground">{r.configDetails}</TableCell></TableRow>
          ))}</TableBody>
        </Table>
      </div>
    ))}
    <SectionActions id={item.id} target="resource" section={section} admin={admin} reload={reload} />
  </CardContent></Card>
);

const ArchTab = ({ item, section, admin, reload }: any) => {
  const ao = item.state.architectureOverview;
  return (
    <Card><CardContent className="p-5 space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="font-semibold">Architecture Overview</h3>
        <Badge variant="outline">Status: {section.status.replace("_", " ")}</Badge>
      </div>
      <div className="grid grid-cols-2 gap-3 text-sm">
        <div className="rounded border p-3"><p className="text-xs text-muted-foreground">Diagram</p><p className="font-medium">{ao.uploadedDiagram || "—"}</p></div>
        <div className="rounded border p-3"><p className="text-xs text-muted-foreground">Generated</p><p className="font-medium">{ao.generatedFromBucket ? "Yes" : "No"}</p></div>
        <div className="rounded border p-3"><p className="text-xs text-muted-foreground">Analysis complete</p><p className="font-medium">{ao.analysisComplete ? "Yes" : "No"}</p></div>
        <div className="rounded border p-3"><p className="text-xs text-muted-foreground">Security violations</p><p className="font-medium">{ao.securityViolations.length}</p></div>
      </div>
      {ao.securityViolations.length > 0 && (
        <ul className="text-xs space-y-1 list-disc pl-5">
          {ao.securityViolations.map((v: string, i: number) => <li key={i}>{v}</li>)}
        </ul>
      )}
      <SectionActions id={item.id} target="arch" section={section} admin={admin} reload={reload} />
    </CardContent></Card>
  );
};

// ---- Cost tab ----
const CostTab = ({ item, reload }: any) => {
  const ar = item.state.adminReview;
  const cb = ar.costBudget;
  const bothApproved = ar.resourceValidation.status === "approved" && ar.archValidation.status === "approved";

  if (!bothApproved) {
    return <Card><CardContent className="p-8 text-center text-sm text-muted-foreground">
      Cost budgeting unlocks after both Resource Validation and Architecture Validation are approved.
    </CardContent></Card>;
  }

  const totals = computeCostTotal(cb);
  const fmt = (n: number) => `${cb.currency} ${n.toLocaleString(undefined, { maximumFractionDigits: 2 })}`;

  const updateItem = (id: string, field: "qty" | "unitCost" | "notes", value: any) => {
    adminUpdateCostBudget(item.id, (c) => ({ ...c, items: c.items.map((i) => i.id === id ? { ...i, [field]: field === "notes" ? value : Number(value) || 0 } : i) }));
    reload();
  };

  const onSeed = () => { adminSeedCostFromResources(item.id); reload(); };
  const onPublish = () => { adminPublishCost(item.id); reload(); toast({ title: "Cost Published", description: "Cost page is now visible to the user." }); };

  return (
    <Card><CardContent className="p-5 space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="font-semibold">Cost Budgeting</h3>
        <div className="flex gap-2">
          {cb.items.length === 0 && <Button size="sm" variant="outline" onClick={onSeed}>Load from resources</Button>}
          <Button size="sm" onClick={onPublish} disabled={cb.items.length === 0} className="gradient-primary text-primary-foreground">
            <Send className="h-3.5 w-3.5 mr-1" /> {cb.publishedAt ? "Re-publish" : "Publish to User"}
          </Button>
        </div>
      </div>
      {cb.publishedAt && <Badge className="bg-success/10 text-success border-success/20">Published {new Date(cb.publishedAt).toLocaleString()}</Badge>}

      <Table>
        <TableHeader><TableRow>
          <TableHead>Provider</TableHead><TableHead>Service</TableHead><TableHead>Notes</TableHead>
          <TableHead className="w-20">Qty</TableHead><TableHead className="w-32">Unit / mo</TableHead><TableHead className="w-32 text-right">Monthly</TableHead>
        </TableRow></TableHeader>
        <TableBody>
          {cb.items.map((i: any) => (
            <TableRow key={i.id}>
              <TableCell><Badge variant="outline">{i.provider}</Badge></TableCell>
              <TableCell className="font-medium">{i.service}</TableCell>
              <TableCell><Input value={i.notes} onChange={(e) => updateItem(i.id, "notes", e.target.value)} className="h-8 text-xs" /></TableCell>
              <TableCell><Input type="number" value={i.qty} onChange={(e) => updateItem(i.id, "qty", e.target.value)} className="h-8" /></TableCell>
              <TableCell><Input type="number" value={i.unitCost} onChange={(e) => updateItem(i.id, "unitCost", e.target.value)} className="h-8" /></TableCell>
              <TableCell className="text-right font-mono text-xs">{fmt(i.qty * i.unitCost)}</TableCell>
            </TableRow>
          ))}
          {cb.items.length === 0 && (
            <TableRow><TableCell colSpan={6} className="text-center text-muted-foreground text-sm py-6">No cost lines yet. Click "Load from resources" to seed from user's bucket.</TableCell></TableRow>
          )}
        </TableBody>
      </Table>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-2">
        <div className="rounded border p-3">
          <p className="text-xs text-muted-foreground">Infra Support — one-off</p>
          <Input type="number" value={cb.infraSupportOneOff} onChange={(e) => { adminUpdateCostBudget(item.id, (c) => ({ ...c, infraSupportOneOff: Number(e.target.value) || 0 })); reload(); }} className="mt-1" />
        </div>
        <div className="rounded border p-3">
          <p className="text-xs text-muted-foreground">Infra Support — monthly</p>
          <Input type="number" value={cb.infraSupportMonthly} onChange={(e) => { adminUpdateCostBudget(item.id, (c) => ({ ...c, infraSupportMonthly: Number(e.target.value) || 0 })); reload(); }} className="mt-1" />
        </div>
        <div className="rounded border p-3 bg-primary/5">
          <p className="text-xs text-muted-foreground">Total monthly</p>
          <p className="text-lg font-bold font-mono text-primary mt-1">{fmt(totals.totalMonthly)}</p>
        </div>
      </div>
    </CardContent></Card>
  );
};

// ---- Recommendations tab ----
const RecsTab = ({ item, reload }: any) => {
  const ar = item.state.adminReview;
  const costReady = !!ar.costBudget.publishedAt;

  if (!costReady) {
    return <Card><CardContent className="p-8 text-center text-sm text-muted-foreground">
      Recommendations unlock after Cost Budgeting is published.
    </CardContent></Card>;
  }

  const dummy = [
    { cat: "Architecture", title: "Move RDS to private subnet", detail: "Restrict DB exposure; pair with VPC endpoints." },
    { cat: "Security", title: "Enable WAF on internet-facing ALB", detail: "OWASP top-10 managed rule set." },
    { cat: "Cost", title: "Reserved Instances for steady-state EC2", detail: "Estimated 32% savings vs on-demand for 1-year term." },
    { cat: "Governance", title: "Tagging policy enforcement", detail: "Required: CostCenter, Project, Owner." },
    { cat: "Resilience", title: "Multi-AZ for primary database", detail: "RPO < 1 min, RTO < 5 min." },
  ];
  const checklist = [
    { type: "Governance", item: "Architecture Approval (ISM)" },
    { type: "Governance", item: "Data Privacy clearance" },
    { type: "GPS", item: "Cloud Infrastructure Provisioning" },
    { type: "GPS", item: "SSL/TLS Certificate Procurement" },
    { type: "RFC", item: "AD Group creation (post Service ID)" },
    { type: "RFC", item: "Firewall rule update" },
  ];

  const onPublish = () => { adminPublishRecommendations(item.id); reload(); toast({ title: "Recommendations Sent", description: "User can now initiate Governance Approvals." }); };

  return (
    <Card><CardContent className="p-5 space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="font-semibold">Recommendations & Approval Checklist</h3>
        <Button size="sm" onClick={onPublish} className="gradient-primary text-primary-foreground">
          <Send className="h-3.5 w-3.5 mr-1" /> {ar.recommendationsPublishedAt ? "Re-send" : "Send to User"}
        </Button>
      </div>
      {ar.recommendationsPublishedAt && <Badge className="bg-success/10 text-success border-success/20">Sent {new Date(ar.recommendationsPublishedAt).toLocaleString()}</Badge>}

      <div>
        <p className="text-xs font-semibold text-muted-foreground uppercase mb-2">Generated Recommendations (dummy)</p>
        <div className="grid gap-2">
          {dummy.map((d) => (
            <div key={d.title} className="rounded border p-3 flex items-start gap-3">
              <Lightbulb className="h-4 w-4 text-warning mt-0.5" />
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className="text-[10px]">{d.cat}</Badge>
                  <span className="font-medium text-sm">{d.title}</span>
                </div>
                <p className="text-xs text-muted-foreground mt-0.5">{d.detail}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div>
        <p className="text-xs font-semibold text-muted-foreground uppercase mb-2">Approval Checklist</p>
        <Table>
          <TableHeader><TableRow><TableHead className="w-32">Type</TableHead><TableHead>Item</TableHead></TableRow></TableHeader>
          <TableBody>{checklist.map((c) => (
            <TableRow key={c.item}><TableCell><Badge variant="secondary" className="text-[10px]">{c.type}</Badge></TableCell><TableCell>{c.item}</TableCell></TableRow>
          ))}</TableBody>
        </Table>
      </div>
    </CardContent></Card>
  );
};

export default AdminOnboardingReview;