import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Index from "./pages/Index.tsx";
import NotFound from "./pages/NotFound.tsx";
import AdminDashboard from "./pages/admin/AdminDashboard";
import AdminAssignments from "./pages/admin/AdminAssignments";
import AdminOnboardingReview from "./pages/admin/AdminOnboardingReview";
import AdminEscalations from "./pages/admin/AdminEscalations";
import AdminComments from "./pages/admin/AdminComments";
import AdminRfcs from "./pages/admin/AdminRfcs";
import AdminSla from "./pages/admin/AdminSla";
import SuperAdminDashboard from "./pages/superadmin/SuperAdminDashboard";
import SaAssignments from "./pages/superadmin/SaAssignments";
import SaAdmins from "./pages/superadmin/SaAdmins";
import SaOversight from "./pages/superadmin/SaOversight";
import SaAudit from "./pages/superadmin/SaAudit";
import SaConfig from "./pages/superadmin/SaConfig";
import EligibilityConfigPage from "./pages/superadmin/config/EligibilityConfigPage";
import DisclaimerConfigPage from "./pages/superadmin/config/DisclaimerConfigPage";
import ArchRulesConfigPage from "./pages/superadmin/config/ArchRulesConfigPage";
import Eligibility from "./pages/Eligibility";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/eligibility" element={<Eligibility />} />
          <Route path="/admin" element={<AdminDashboard />} />
          <Route path="/admin/assignments" element={<AdminAssignments />} />
          <Route path="/admin/onboardings/:id" element={<AdminOnboardingReview />} />
          <Route path="/admin/escalations" element={<AdminEscalations />} />
          <Route path="/admin/comments" element={<AdminComments />} />
          <Route path="/admin/rfcs" element={<AdminRfcs />} />
          <Route path="/admin/sla" element={<AdminSla />} />
          <Route path="/superadmin" element={<SuperAdminDashboard />} />
          <Route path="/superadmin/assignments" element={<SaAssignments />} />
          <Route path="/superadmin/admins" element={<SaAdmins />} />
          <Route path="/superadmin/oversight" element={<SaOversight />} />
          <Route path="/superadmin/audit" element={<SaAudit />} />
          <Route path="/superadmin/config" element={<SaConfig />} />
          <Route path="/superadmin/config/eligibility" element={<EligibilityConfigPage />} />
          <Route path="/superadmin/config/disclaimer" element={<DisclaimerConfigPage />} />
          <Route path="/superadmin/config/architecture-rules" element={<ArchRulesConfigPage />} />
          {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
