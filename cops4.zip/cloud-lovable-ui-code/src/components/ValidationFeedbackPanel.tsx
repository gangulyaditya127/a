import { useState } from "react";
import type { ReviewSection } from "@/types/onboarding";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { MessageSquare, Send, CheckCircle2, AlertTriangle, Clock, Lock, Inbox } from "lucide-react";

interface Props {
  title: string;
  section: ReviewSection;
  canSubmit: boolean;
  onSubmit: () => void;
  onReply: (message: string) => void;
}

const statusMeta: Record<ReviewSection["status"], { label: string; tone: string; icon: any; hint: string }> = {
  not_submitted: { label: "Not submitted", tone: "bg-muted text-muted-foreground border-border", icon: Inbox, hint: "Fill in the details and submit for admin review when ready." },
  in_review: { label: "Awaiting admin review", tone: "bg-info/10 text-info border-info/20", icon: Clock, hint: "Locked while the assigned DIS Admin reviews your submission." },
  changes_requested: { label: "Changes requested", tone: "bg-warning/10 text-warning border-warning/20", icon: AlertTriangle, hint: "Admin has requested changes. Update the details and resubmit." },
  approved: { label: "Approved by admin", tone: "bg-success/10 text-success border-success/20", icon: CheckCircle2, hint: "Approved. No further edits needed for this step." },
};

export const ValidationFeedbackPanel = ({ title, section, canSubmit, onSubmit, onReply }: Props) => {
  const meta = statusMeta[section.status];
  const Icon = meta.icon;
  const [draft, setDraft] = useState("");
  const locked = section.status === "in_review" || section.status === "approved";

  return (
    <div className="rounded-lg border bg-muted/30 p-4 space-y-3">
      <div className="flex flex-wrap items-center gap-2 justify-between">
        <div className="flex items-center gap-2">
          <MessageSquare className="h-4 w-4 text-primary" />
          <span className="text-sm font-semibold text-foreground">Admin Validation & Feedback — {title}</span>
        </div>
        <Badge variant="outline" className={meta.tone + " gap-1"}>
          <Icon className="h-3 w-3" /> {meta.label}
        </Badge>
      </div>
      <p className="text-xs text-muted-foreground flex items-center gap-1">
        {locked && <Lock className="h-3 w-3" />} {meta.hint}
      </p>

      {section.comments.length > 0 && (
        <div className="space-y-2 max-h-48 overflow-auto rounded-md border bg-background p-3">
          {section.comments.map((c) => (
            <div key={c.id} className="text-xs">
              <div className="flex items-center gap-2">
                <Badge variant={c.role === "admin" ? "default" : "secondary"} className="text-[10px] h-4 px-1.5">
                  {c.role === "admin" ? "DIS Admin" : "Requestor"}
                </Badge>
                <span className="font-medium text-foreground">{c.author}</span>
                <span className="text-muted-foreground">{new Date(c.ts).toLocaleString()}</span>
              </div>
              <p className="mt-1 text-foreground leading-relaxed pl-1">{c.message}</p>
            </div>
          ))}
        </div>
      )}

      {section.status === "changes_requested" && (
        <div className="space-y-2">
          <Textarea
            placeholder="Reply to admin and describe your changes…"
            rows={2}
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
          />
          <div className="flex gap-2 justify-end">
            <Button
              size="sm"
              variant="outline"
              disabled={!draft.trim()}
              onClick={() => { onReply(draft.trim()); setDraft(""); }}
            >
              <MessageSquare className="h-3.5 w-3.5 mr-1" /> Send Comment
            </Button>
            <Button size="sm" onClick={onSubmit} disabled={!canSubmit} className="gradient-primary text-primary-foreground">
              <Send className="h-3.5 w-3.5 mr-1" /> Resubmit for Review
            </Button>
          </div>
        </div>
      )}

      {(section.status === "not_submitted") && (
        <div className="flex justify-end">
          <Button size="sm" onClick={onSubmit} disabled={!canSubmit} className="gradient-primary text-primary-foreground">
            <Send className="h-3.5 w-3.5 mr-1" /> Submit for Admin Review
          </Button>
        </div>
      )}
    </div>
  );
};