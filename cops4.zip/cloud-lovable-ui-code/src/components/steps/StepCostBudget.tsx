import type { AdminReview } from "@/types/onboarding";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Clock, DollarSign, CheckCircle2 } from "lucide-react";
import { computeCostTotal } from "@/lib/adminReview";

interface Props { review: AdminReview | undefined; }

export const StepCostBudget = ({ review }: Props) => {
  const cb = review?.costBudget;

  if (!cb || !cb.publishedAt) {
    return (
      <div className="space-y-4">
        <div className="rounded-lg border border-dashed bg-muted/40 p-8 text-center space-y-2">
          <Clock className="h-8 w-8 mx-auto text-muted-foreground" />
          <p className="text-sm font-medium text-foreground">Waiting for admin cost budgeting…</p>
          <p className="text-xs text-muted-foreground max-w-md mx-auto">
            Once the DIS Admin has approved your cloud resources and architecture, they will publish the resource-level and infra support cost here.
          </p>
          {review && (
            <div className="flex justify-center gap-2 pt-1 text-[11px]">
              <Badge variant="outline">Resource: {review.resourceValidation.status.replace("_", " ")}</Badge>
              <Badge variant="outline">Architecture: {review.archValidation.status.replace("_", " ")}</Badge>
            </div>
          )}
        </div>
      </div>
    );
  }

  const totals = computeCostTotal(cb);
  const fmt = (n: number) => `${cb.currency} ${n.toLocaleString(undefined, { maximumFractionDigits: 2 })}`;

  return (
    <div className="space-y-5">
      <div className="flex items-center gap-2 text-sm">
        <Badge className="bg-success/10 text-success border-success/20 gap-1"><CheckCircle2 className="h-3 w-3" /> Cost published</Badge>
        <span className="text-xs text-muted-foreground">Published {new Date(cb.publishedAt).toLocaleString()}</span>
      </div>

      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Provider</TableHead>
                <TableHead>Service</TableHead>
                <TableHead>Notes</TableHead>
                <TableHead className="text-right">Qty</TableHead>
                <TableHead className="text-right">Unit / mo</TableHead>
                <TableHead className="text-right">Monthly</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {cb.items.map((i) => (
                <TableRow key={i.id}>
                  <TableCell><Badge variant="outline">{i.provider}</Badge></TableCell>
                  <TableCell className="font-medium">{i.service}</TableCell>
                  <TableCell className="text-xs text-muted-foreground max-w-xs truncate">{i.notes}</TableCell>
                  <TableCell className="text-right">{i.qty}</TableCell>
                  <TableCell className="text-right font-mono text-xs">{fmt(i.unitCost)}</TableCell>
                  <TableCell className="text-right font-mono text-xs">{fmt(i.qty * i.unitCost)}</TableCell>
                </TableRow>
              ))}
              {cb.items.length === 0 && (
                <TableRow><TableCell colSpan={6} className="text-center text-muted-foreground text-sm py-6">No resource costs.</TableCell></TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        <Card><CardContent className="p-4">
          <p className="text-xs text-muted-foreground">Resources monthly</p>
          <p className="text-lg font-semibold font-mono">{fmt(totals.itemsMonthly)}</p>
        </CardContent></Card>
        <Card><CardContent className="p-4">
          <p className="text-xs text-muted-foreground">Infra support — one-off</p>
          <p className="text-lg font-semibold font-mono">{fmt(totals.infraOneOff)}</p>
        </CardContent></Card>
        <Card><CardContent className="p-4">
          <p className="text-xs text-muted-foreground">Infra support — monthly</p>
          <p className="text-lg font-semibold font-mono">{fmt(totals.infraMonthly)}</p>
        </CardContent></Card>
      </div>

      <div className="rounded-lg border bg-primary/5 p-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <DollarSign className="h-5 w-5 text-primary" />
          <span className="font-semibold text-foreground">Total monthly run-rate</span>
        </div>
        <span className="text-xl font-bold font-mono text-primary">{fmt(totals.totalMonthly)}</span>
      </div>
    </div>
  );
};