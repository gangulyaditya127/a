import { useMemo, useState } from "react";
import type { InteractionEvent, InteractionActor, InteractionKind } from "@/types/onboarding";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  MessageSquare, CheckCircle2, AlertTriangle, UserPlus, Send,
  Inbox, Settings, Activity, History, Filter, Sparkles,
} from "lucide-react";

const kindMeta: Record<InteractionKind, { icon: any; tone: string; label: string }> = {
  submission:    { icon: Inbox,         tone: "bg-info/10 text-info border-info/20",                 label: "Submission" },
  assignment:    { icon: UserPlus,      tone: "bg-accent/15 text-accent border-accent/30",           label: "Assignment" },
  comment:       { icon: MessageSquare, tone: "bg-muted text-muted-foreground border-border",        label: "Comment" },
  decision:      { icon: CheckCircle2,  tone: "bg-success/10 text-success border-success/20",        label: "Decision" },
  publish:       { icon: Send,          tone: "bg-primary/10 text-primary border-primary/20",       label: "Publish" },
  status_change: { icon: Activity,      tone: "bg-warning/10 text-warning border-warning/20",        label: "Status" },
  config_change: { icon: Settings,      tone: "bg-secondary text-secondary-foreground border-border", label: "Config" },
  note:          { icon: Sparkles,      tone: "bg-muted text-muted-foreground border-border",        label: "Note" },
};

const actorLabel: Record<InteractionActor, string> = {
  user: "Requestor",
  admin: "DIS Admin",
  superadmin: "Super Admin",
  system: "System",
};

const actorColor: Record<InteractionActor, string> = {
  user:       "bg-accent/15 text-accent border-accent/30",
  admin:      "bg-info/10 text-info border-info/20",
  superadmin: "bg-warning/10 text-warning border-warning/20",
  system:     "bg-muted text-muted-foreground border-border",
};

type FilterKey = "all" | "comments" | "decisions" | "publishes";

interface Props {
  events: InteractionEvent[];
  title?: string;
  emptyHint?: string;
  /** Compact mode hides the filter row — useful in drawers. */
  compact?: boolean;
}

/**
 * Standard enterprise "audit / activity" view of all user↔admin interactions
 * on an onboarding. Vertical timeline with actor avatar, role badge, kind chip
 * and (placeholder) timestamp. One canonical log everyone shares.
 */
export const InteractionTimeline = ({ events, title = "Activity", emptyHint, compact }: Props) => {
  const [filter, setFilter] = useState<FilterKey>("all");

  const filtered = useMemo(() => {
    const list = [...events].sort((a, b) => new Date(b.ts).getTime() - new Date(a.ts).getTime());
    switch (filter) {
      case "comments":   return list.filter((e) => e.kind === "comment");
      case "decisions":  return list.filter((e) => e.kind === "decision");
      case "publishes":  return list.filter((e) => e.kind === "publish");
      default:           return list;
    }
  }, [events, filter]);

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center justify-between pb-3 border-b">
        <div className="flex items-center gap-2">
          <History className="h-4 w-4 text-muted-foreground" />
          <h3 className="font-semibold text-sm">{title}</h3>
          <Badge variant="secondary" className="text-[10px] h-5">{events.length}</Badge>
        </div>
        {!compact && (
          <div className="flex items-center gap-1">
            <Filter className="h-3 w-3 text-muted-foreground mr-1" />
            {(["all", "comments", "decisions", "publishes"] as FilterKey[]).map((k) => (
              <Button
                key={k}
                size="sm"
                variant={filter === k ? "secondary" : "ghost"}
                className="h-6 px-2 text-[11px] capitalize"
                onClick={() => setFilter(k)}
              >{k}</Button>
            ))}
          </div>
        )}
      </div>

      <div className="flex-1 overflow-auto pt-4">
        {filtered.length === 0 ? (
          <p className="text-xs text-muted-foreground text-center py-6">
            {emptyHint ?? "No activity yet. Comments, approvals and publishes will appear here."}
          </p>
        ) : (
          <ol className="relative ml-3 border-l border-border space-y-4 pb-2">
            {filtered.map((e) => {
              const k = kindMeta[e.kind];
              const Icon = k.icon;
              return (
                <li key={e.id} className="pl-4 relative">
                  <span className={`absolute -left-[11px] top-0 h-5 w-5 rounded-full border flex items-center justify-center bg-background ${k.tone}`}>
                    <Icon className="h-2.5 w-2.5" />
                  </span>
                  <div className="flex flex-wrap items-center gap-1.5 text-[11px]">
                    <Badge variant="outline" className={actorColor[e.actor] + " h-4 px-1.5 text-[10px]"}>
                      {actorLabel[e.actor]}
                    </Badge>
                    <span className="font-medium text-foreground">{e.actorName}</span>
                    {e.scope && (
                      <Badge variant="secondary" className="h-4 px-1.5 text-[10px]">{e.scope}</Badge>
                    )}
                    <span className="text-muted-foreground ml-auto whitespace-nowrap">
                      {new Date(e.ts).toLocaleString(undefined, { dateStyle: "short", timeStyle: "short" })}
                    </span>
                  </div>
                  <p className="text-xs font-medium text-foreground mt-1">{e.title}</p>
                  {e.body && (
                    <p className="text-xs text-muted-foreground mt-1 leading-relaxed whitespace-pre-wrap">{e.body}</p>
                  )}
                </li>
              );
            })}
          </ol>
        )}
      </div>
    </div>
  );
};