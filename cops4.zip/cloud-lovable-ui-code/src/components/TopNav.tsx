import { Cloud, Bell, User, HelpCircle, ChevronDown, Shield, ShieldCheck } from "lucide-react";
import { Button } from "./ui/button";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from "./ui/dropdown-menu";
import { useNavigate } from "react-router-dom";

export const TopNav = () => {
  const navigate = useNavigate();
  return (
    <header className="gradient-nav h-14 flex items-center px-6 justify-between shrink-0">
      <div className="flex items-center gap-3">
        <Cloud className="h-6 w-6 text-nav-foreground" />
        <div>
          <h1 className="text-sm font-semibold text-nav-foreground leading-tight">
            DIS Cloud Onboarding
          </h1>
          <p className="text-[10px] text-nav-foreground/60">
            Digital Infrastructure Services — Automation Platform
          </p>
        </div>
      </div>
      <div className="flex items-center gap-1">
        <Button variant="ghost" size="icon" className="text-nav-foreground/70 hover:text-nav-foreground hover:bg-nav-foreground/10">
          <HelpCircle className="h-4 w-4" />
        </Button>
        <Button variant="ghost" size="icon" className="text-nav-foreground/70 hover:text-nav-foreground hover:bg-nav-foreground/10 relative">
          <Bell className="h-4 w-4" />
          <span className="absolute top-1.5 right-1.5 h-2 w-2 rounded-full bg-destructive" />
        </Button>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm" className="text-nav-foreground/70 hover:text-nav-foreground hover:bg-nav-foreground/10 ml-2 gap-2">
              <User className="h-4 w-4" />
              <span className="text-xs">John D. — Requestor</span>
              <ChevronDown className="h-3 w-3 opacity-60" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-56">
            <DropdownMenuLabel>Switch role view</DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={() => navigate("/")}><User className="h-4 w-4" /> Requestor (current)</DropdownMenuItem>
            <DropdownMenuItem onClick={() => navigate("/admin")}><Shield className="h-4 w-4" /> DIS Admin console</DropdownMenuItem>
            <DropdownMenuItem onClick={() => navigate("/superadmin")}><ShieldCheck className="h-4 w-4" /> Super Admin console</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  );
};
