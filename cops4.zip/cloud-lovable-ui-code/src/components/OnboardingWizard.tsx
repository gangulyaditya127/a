import { useEffect, useRef, useState } from "react";
import { STEPS, type OnboardingState, emptyAdminReview } from "@/types/onboarding";
import { StepIndicator } from "./StepIndicator";
import { TopNav } from "./TopNav";
import { StepAccountDetails } from "./steps/StepAccountDetails";
import { StepRequirementAssessment } from "./steps/StepRequirementAssessment";
import { StepCloudResources } from "./steps/StepCloudResources";
import { StepArchitectureOverview } from "./steps/StepArchitectureOverview";
import { StepCostBudget } from "./steps/StepCostBudget";
import { StepRecommendations } from "./steps/StepRecommendations";
import { StepApprovalTracker } from "./steps/StepApprovalTracker";
import { StepServiceIdCreation } from "./steps/StepServiceIdCreation";
import { StepRfcTracking } from "./steps/StepRfcTracking";
import { Button } from "./ui/button";
import { ChevronLeft, ChevronRight, LayoutDashboard, Save } from "lucide-react";
import { History } from "lucide-react";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "./ui/sheet";
import { InteractionTimeline } from "./InteractionTimeline";
import { toast } from "@/hooks/use-toast";
import { computeStatus, newId, saveOne, type SavedOnboarding } from "@/lib/onboardingStorage";
import { ValidationFeedbackPanel } from "./ValidationFeedbackPanel";
import { userReplyComment, userSubmitForReview } from "@/lib/adminReview";

const initialState: OnboardingState = {
  currentStep: 1,
  accountDetails: {
    projectName: "", isu: "", accountName: "", owner: "", empId: "", description: "", businessUnit: "",
  },
  requirementAssessment: {
    solutionType: "", deploymentEnvironments: [], cloudProviders: [], region: "",
  },
  cloudResources: [],
  architectureOverview: {
    uploadedDiagram: null, generatedFromBucket: false, securityViolations: [], revisedDiagram: null, analysisComplete: false,
  },
  recommendations: [],
  approvals: [],
  serviceId: {
    serviceId: "", status: "not-started", disTeamAssigned: "", createdDate: null,
  },
  rfcs: [],
  adminReview: emptyAdminReview(),
};

interface Props {
  initialTemplate?: Partial<OnboardingState> | null;
  existing?: SavedOnboarding | null;
  onBackToDashboard?: () => void;
}

const TOTAL = STEPS.length;

export const OnboardingWizard = ({ initialTemplate, existing, onBackToDashboard }: Props) => {
  const [state, setState] = useState<OnboardingState>(() => {
    if (existing) return { ...existing.state, adminReview: existing.state.adminReview ?? emptyAdminReview() };
    return { ...initialState, ...initialTemplate, currentStep: 1, adminReview: emptyAdminReview() };
  });
  const idRef = useRef<string>(existing?.id ?? newId());
  const createdRef = useRef<string>(existing?.createdAt ?? new Date().toISOString());

  const persist = (next: OnboardingState) => {
    const name = next.accountDetails.projectName?.trim() || "Untitled Onboarding";
    const item: SavedOnboarding = {
      id: idRef.current,
      name,
      createdAt: createdRef.current,
      updatedAt: new Date().toISOString(),
      status: computeStatus(next),
      state: next,
    };
    saveOne(item);
  };

  // auto-persist on any state change
  useEffect(() => {
    persist(state);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state]);

  const updateState = <K extends keyof OnboardingState>(key: K, value: OnboardingState[K]) => {
    setState((prev) => ({ ...prev, [key]: value }));
  };

  const goNext = () => state.currentStep < TOTAL && setState((p) => ({ ...p, currentStep: p.currentStep + 1 }));
  const goPrev = () => state.currentStep > 1 && setState((p) => ({ ...p, currentStep: p.currentStep - 1 }));
  const goToStep = (step: number) => setState((p) => ({ ...p, currentStep: step }));

  const handleSave = () => {
    persist(state);
    toast({ title: "Progress Saved", description: "Onboarding saved to your dashboard." });
  };

  // Pull latest adminReview after admin-side changes
  const reload = () => {
    const raw = JSON.parse(localStorage.getItem("dis_onboardings_v1") || "[]");
    const latest = raw.find((o: SavedOnboarding) => o.id === idRef.current);
    if (latest?.state.adminReview) setState((p) => ({ ...p, adminReview: latest.state.adminReview }));
  };

  const requestor = state.accountDetails.owner || "Requestor";

  const renderFeedback = (target: "resource" | "arch", title: string, canSubmit: boolean) => {
    const section = target === "resource"
      ? state.adminReview!.resourceValidation
      : state.adminReview!.archValidation;
    return (
      <ValidationFeedbackPanel
        title={title}
        section={section}
        canSubmit={canSubmit}
        onSubmit={() => {
          userSubmitForReview(idRef.current, target);
          reload();
          toast({ title: "Submitted for Review", description: `${title} sent to your DIS Admin.` });
        }}
        onReply={(msg) => {
          userReplyComment(idRef.current, target, msg, requestor);
          reload();
        }}
      />
    );
  };

  const renderStep = () => {
    switch (state.currentStep) {
      case 1: return <StepAccountDetails data={state.accountDetails} onChange={(d) => updateState("accountDetails", d)} />;
      case 2: return <StepRequirementAssessment data={state.requirementAssessment} onChange={(d) => updateState("requirementAssessment", d)} />;
      case 3: return (
        <div className="space-y-6">
          <StepCloudResources data={state.cloudResources} providers={state.requirementAssessment.cloudProviders} onChange={(d) => updateState("cloudResources", d)} />
          {renderFeedback("resource", "Cloud Resources", state.cloudResources.some((b) => b.resources.length > 0))}
        </div>
      );
      case 4: return (
        <div className="space-y-6">
          <StepArchitectureOverview data={state.architectureOverview} onChange={(d) => updateState("architectureOverview", d)} />
          {renderFeedback("arch", "Architecture Overview", !!state.architectureOverview.uploadedDiagram)}
        </div>
      );
      case 5: return <StepCostBudget review={state.adminReview} />;
      case 6: {
        const ready = !!state.adminReview?.recommendationsPublishedAt;
        if (!ready) {
          return (
            <div className="rounded-lg border border-dashed bg-muted/40 p-8 text-center text-sm text-muted-foreground">
              Waiting for admin to generate and publish recommendations. You will see GPS, RFC and approval items here once ready.
            </div>
          );
        }
        return <StepRecommendations data={state.recommendations} solutionType={state.requirementAssessment.solutionType} onChange={(d) => updateState("recommendations", d)} />;
      }
      case 7: return <StepApprovalTracker data={state.approvals} solutionType={state.requirementAssessment.solutionType} onChange={(d) => updateState("approvals", d)} />;
      case 8: return <StepServiceIdCreation data={state.serviceId} onChange={(d) => updateState("serviceId", d)} />;
      case 9: return <StepRfcTracking data={state.rfcs} serviceIdReady={state.serviceId.status === "completed"} onChange={(d) => updateState("rfcs", d)} />;
      default: return null;
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <TopNav />
      <div className="flex-1 flex flex-col">
        <div className="border-b bg-card px-6 py-4">
          <div className="flex items-center gap-4">
            <div className="flex-1 min-w-0">
              <StepIndicator steps={STEPS} currentStep={state.currentStep} onStepClick={goToStep} />
            </div>
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="outline" size="sm" className="shrink-0 gap-1.5">
                  <History className="h-3.5 w-3.5" />
                  Activity
                  {(state.events?.length ?? 0) > 0 && (
                    <span className="ml-1 inline-flex items-center justify-center text-[10px] h-4 px-1.5 rounded-full bg-primary text-primary-foreground">
                      {state.events!.length}
                    </span>
                  )}
                </Button>
              </SheetTrigger>
              <SheetContent className="w-[420px] sm:max-w-[420px] flex flex-col">
                <SheetHeader>
                  <SheetTitle>User ↔ Admin Activity</SheetTitle>
                </SheetHeader>
                <div className="flex-1 mt-4 overflow-hidden">
                  <InteractionTimeline
                    events={state.events ?? []}
                    title="Timeline"
                    emptyHint="No interactions yet. Submit a section for admin review to start the conversation."
                  />
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
        <div className="flex-1 overflow-auto">
          <div className="max-w-6xl mx-auto px-6 py-8">
            <div className="mb-6">
              <h2 className="text-2xl font-semibold text-foreground">{STEPS[state.currentStep - 1].title}</h2>
              <p className="text-muted-foreground text-sm mt-1">
                Step {state.currentStep} of {TOTAL} — {STEPS[state.currentStep - 1].description}
              </p>
            </div>
            <div className="bg-card rounded-lg border shadow-card p-6">{renderStep()}</div>
          </div>
        </div>
        <div className="border-t bg-card px-6 py-4">
          <div className="max-w-6xl mx-auto flex items-center justify-between">
            <div className="flex items-center gap-2">
              {onBackToDashboard && (
                <Button variant="ghost" onClick={onBackToDashboard}>
                  <LayoutDashboard className="h-4 w-4 mr-1" /> Dashboard
                </Button>
              )}
              <Button variant="outline" onClick={goPrev} disabled={state.currentStep === 1}>
                <ChevronLeft className="h-4 w-4 mr-1" /> Previous
              </Button>
            </div>
            <Button variant="ghost" onClick={handleSave}>
              <Save className="h-4 w-4 mr-1" /> Save Draft
            </Button>
            {state.currentStep < TOTAL ? (
              <Button onClick={goNext} className="gradient-primary text-primary-foreground">
                Next <ChevronRight className="h-4 w-4 ml-1" />
              </Button>
            ) : (
              <Button onClick={() => toast({ title: "Onboarding Submitted", description: "All RFCs tracked. Dashboard updated." })} className="gradient-accent text-accent-foreground">
                Finish
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
