import type { InteractionEvent, OnboardingState } from "@/types/onboarding";
import { emptyAdminReview } from "@/types/onboarding";

const KEY = "dis_onboardings_v1";

export type OnboardingStatus =
  | "Draft"
  | "Awaiting Admin Review"
  | "Changes Requested"
  | "Costing in Progress"
  | "Recommendations Ready"
  | "In Approval"
  | "Provisioning"
  | "RFC Pending"
  | "Complete";

export interface SavedOnboarding {
  id: string;
  name: string;
  createdAt: string;
  updatedAt: string;
  status: OnboardingStatus;
  state: OnboardingState;
}

export const computeStatus = (s: OnboardingState): OnboardingStatus => {
  const allRfcsClosed = s.rfcs.length > 0 && s.rfcs.every((r) => r.status === "implemented" || r.status === "closed");
  if (s.serviceId.status === "completed" && allRfcsClosed) return "Complete";
  if (s.serviceId.status === "completed") return "RFC Pending";
  if (s.serviceId.status !== "not-started") return "Provisioning";
  if (s.approvals.length > 0) return "In Approval";
  const ar = s.adminReview;
  if (ar) {
    if (ar.recommendationsPublishedAt) return "Recommendations Ready";
    if (ar.costBudget.publishedAt) return "Recommendations Ready";
    if (ar.resourceValidation.status === "approved" && ar.archValidation.status === "approved") return "Costing in Progress";
    if (ar.resourceValidation.status === "changes_requested" || ar.archValidation.status === "changes_requested") return "Changes Requested";
    if (ar.resourceValidation.status === "in_review" || ar.archValidation.status === "in_review") return "Awaiting Admin Review";
  }
  return "Draft";
};

export const ensureAdminReview = (s: OnboardingState): OnboardingState => ({
  ...s,
  adminReview: s.adminReview ?? emptyAdminReview(),
});

export const loadAll = (): SavedOnboarding[] => {
  try {
    return JSON.parse(localStorage.getItem(KEY) || "[]");
  } catch {
    return [];
  }
};

export const loadOne = (id: string): SavedOnboarding | null =>
  loadAll().find((o) => o.id === id || o.id.toUpperCase() === id.toUpperCase()) ?? null;

export const saveOne = (item: SavedOnboarding) => {
  const all = loadAll();
  const idx = all.findIndex((o) => o.id === item.id);
  if (idx >= 0) all[idx] = item;
  else all.unshift(item);
  localStorage.setItem(KEY, JSON.stringify(all));
};

export const updateOne = (id: string, mutator: (item: SavedOnboarding) => SavedOnboarding): SavedOnboarding | null => {
  const existing = loadOne(id);
  if (!existing) return null;
  const next = mutator(existing);
  next.updatedAt = new Date().toISOString();
  next.status = computeStatus(next.state);
  saveOne(next);
  return next;
};

export const deleteOne = (id: string) => {
  localStorage.setItem(KEY, JSON.stringify(loadAll().filter((o) => o.id !== id)));
};

export const newId = () => "onb_" + Math.random().toString(36).slice(2, 10);

export const appendEvent = (
  id: string,
  event: Omit<InteractionEvent, "id" | "ts"> & Partial<Pick<InteractionEvent, "ts">>
) =>
  updateOne(id, (item) => {
    const events = item.state.events ?? [];
    const next: InteractionEvent = {
      id: "ev_" + Math.random().toString(36).slice(2, 9),
      ts: event.ts ?? new Date().toISOString(),
      ...event,
    } as InteractionEvent;
    return { ...item, state: { ...item.state, events: [...events, next] } };
  });
