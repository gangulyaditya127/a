// Local-storage registries for Super Admin platform configuration.
// Replaceable with real backend later — keep shape stable.

export interface EligibilityCriterion {
  id: string;
  section: string;
  title: string;
  note?: string;
  questionType: "single" | "multi";
  options: string[];
  correctAnswer: string | string[];
  failMessage: string;
  sortOrder: number;
}

export interface DisclaimerClause {
  id: string;
  title: string;
  text: string;
  sortOrder: number;
}

export interface ArchRule {
  id: string;
  cloudProvider: "AWS" | "Azure" | "GCP" | "On-Prem";
  category: string;
  ruleText: string;
  severity: "CRITICAL" | "HIGH" | "MEDIUM" | "LOW";
}

const KEYS = {
  elig: "dis_cfg_eligibility_v1",
  disc: "dis_cfg_disclaimer_v1",
  rules: "dis_cfg_arch_rules_v1",
} as const;

const seedEligibility: EligibilityCriterion[] = [
  {
    id: "e1", section: "Compliance", sortOrder: 10,
    title: "Will the workload process customer PII or regulated data?",
    note: "If yes, ISM + Data Privacy clearance is mandatory.",
    questionType: "single", options: ["No", "Yes — with approvals", "Yes — no approvals yet"],
    correctAnswer: "Yes — with approvals",
    failMessage: "PII workloads without ISM / Data Privacy approvals cannot proceed on DIS Managed Cloud.",
  },
  {
    id: "e2", section: "Solution", sortOrder: 20,
    title: "Which solution type are you onboarding?",
    questionType: "single", options: ["Generative AI", "Non-Generative AI", "Traditional Workload"],
    correctAnswer: "Generative AI",
    failMessage: "This intake currently supports DIS-approved GenAI patterns. Use the standard onboarding portal for other workloads.",
  },
  {
    id: "e3", section: "Governance", sortOrder: 30,
    title: "Have you identified Project Owner, ISM SPOC, and Cost Center?",
    questionType: "single", options: ["Yes — all three", "Partial", "No"],
    correctAnswer: "Yes — all three",
    failMessage: "Owner, ISM SPOC and Cost Center are mandatory before requesting cloud capacity.",
  },
];

const seedDisclaimer: DisclaimerClause[] = [
  { id: "d1", sortOrder: 10, title: "Data Residency", text: "All customer data must remain in the approved DIS region. Cross-region replication requires written ISM approval." },
  { id: "d2", sortOrder: 20, title: "Tagging & Cost Allocation", text: "Every resource must carry CostCenter, Project and Owner tags. Untagged resources will be reclaimed weekly." },
  { id: "d3", sortOrder: 30, title: "Shared Responsibility", text: "DIS manages platform, network and baseline security. Application-level vulnerabilities, secrets and IAM hygiene remain with the project team." },
  { id: "d4", sortOrder: 40, title: "Change Management", text: "Post Service-ID creation, all production changes flow through the RFC pipeline. Direct console changes are auditable and may trigger rollback." },
];

const seedRules: ArchRule[] = [
  { id: "r1", cloudProvider: "AWS", category: "Network Security", severity: "CRITICAL", ruleText: "No RDS / database instance may be placed in a public subnet." },
  { id: "r2", cloudProvider: "AWS", category: "Identity", severity: "HIGH", ruleText: "Workload IAM roles must use scoped policies — wildcard '*' actions are blocked." },
  { id: "r3", cloudProvider: "Azure", category: "Storage", severity: "CRITICAL", ruleText: "Blob containers default to Private. Public anonymous access requires explicit ISM exception." },
  { id: "r4", cloudProvider: "GCP", category: "Network Security", severity: "HIGH", ruleText: "GKE clusters must use private nodes and authorized networks for the control plane." },
];

const read = <T,>(key: string, seed: T[]): T[] => {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) {
      localStorage.setItem(key, JSON.stringify(seed));
      return [...seed];
    }
    return JSON.parse(raw) as T[];
  } catch {
    return [...seed];
  }
};
const write = <T,>(key: string, items: T[]) => localStorage.setItem(key, JSON.stringify(items));
const rid = (p: string) => p + Math.random().toString(36).slice(2, 8);

// Eligibility
export const loadEligibility = () => read(KEYS.elig, seedEligibility).sort((a, b) => a.sortOrder - b.sortOrder);
export const saveEligibility = (items: EligibilityCriterion[]) => write(KEYS.elig, items);
export const upsertEligibility = (item: Partial<EligibilityCriterion>) => {
  const all = loadEligibility();
  if (item.id) {
    const idx = all.findIndex((x) => x.id === item.id);
    if (idx >= 0) all[idx] = { ...all[idx], ...item } as EligibilityCriterion;
  } else {
    all.push({ ...(item as EligibilityCriterion), id: rid("e") });
  }
  saveEligibility(all);
  return all;
};
export const deleteEligibility = (id: string) => { const next = loadEligibility().filter((x) => x.id !== id); saveEligibility(next); return next; };

// Disclaimer
export const loadDisclaimer = () => read(KEYS.disc, seedDisclaimer).sort((a, b) => a.sortOrder - b.sortOrder);
export const saveDisclaimer = (items: DisclaimerClause[]) => write(KEYS.disc, items);
export const upsertDisclaimer = (item: Partial<DisclaimerClause>) => {
  const all = loadDisclaimer();
  if (item.id) {
    const idx = all.findIndex((x) => x.id === item.id);
    if (idx >= 0) all[idx] = { ...all[idx], ...item } as DisclaimerClause;
  } else {
    all.push({ ...(item as DisclaimerClause), id: rid("d") });
  }
  saveDisclaimer(all);
  return all;
};
export const deleteDisclaimer = (id: string) => { const next = loadDisclaimer().filter((x) => x.id !== id); saveDisclaimer(next); return next; };

// Architecture rules
export const loadArchRules = () => read(KEYS.rules, seedRules);
export const saveArchRules = (items: ArchRule[]) => write(KEYS.rules, items);
export const upsertArchRule = (item: Partial<ArchRule>) => {
  const all = loadArchRules();
  if (item.id) {
    const idx = all.findIndex((x) => x.id === item.id);
    if (idx >= 0) all[idx] = { ...all[idx], ...item } as ArchRule;
  } else {
    all.push({ ...(item as ArchRule), id: rid("r") });
  }
  saveArchRules(all);
  return all;
};
export const deleteArchRule = (id: string) => { const next = loadArchRules().filter((x) => x.id !== id); saveArchRules(next); return next; };

export const configSummary = () => ({
  eligibility: loadEligibility().length,
  disclaimer: loadDisclaimer().length,
  archRules: loadArchRules().length,
});