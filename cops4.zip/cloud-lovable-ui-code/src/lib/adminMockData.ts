import { loadAll, type SavedOnboarding } from "@/lib/onboardingStorage";

export type AdminStatus =
  | "Draft"
  | "Submitted"
  | "Under Review"
  | "In Approval"
  | "Pending Governance"
  | "Pending GPS"
  | "Pending ISM"
  | "Pending RFC"
  | "Architecture Issue"
  | "User Action Required"
  | "On Hold"
  | "Provisioning"
  | "Service ID In Progress"
  | "RFC Pending"
  | "RFC In Progress"
  | "Completed"
  | "Complete"
  | "Rejected"
  | "Escalated";

export interface AdminOnboarding {
  id: string;
  project: string;
  requester: string;
  cloud: string;
  assignedAdmin: string | null;
  status: AdminStatus;
  step: string;
  slaHours: number;
  ageHours: number;
  pendingApprovals: string[];
  unreadComments: number;
  rfcsOpen: number;
  updatedAt: string;
  escalated?: boolean;
}

export interface DisAdmin {
  id: string;
  name: string;
  email: string;
  region: string;
  capacity: number;
  active: number;
  slaCompliance: number;
  status: "Active" | "On Leave" | "Inactive";
}

export interface AuditEvent {
  id: string;
  ts: string;
  actor: string;
  role: "Super Admin" | "DIS Admin" | "System" | "Requester";
  action: string;
  target: string;
}

export interface CommentThread {
  id: string;
  onboardingId: string;
  project: string;
  from: string;
  message: string;
  ts: string;
  unread: boolean;
}

export const DIS_ADMINS: DisAdmin[] = [
  { id: "a1", name: "Priya Sharma", email: "priya.s@tcs.com", region: "APAC", capacity: 12, active: 8, slaCompliance: 96, status: "Active" },
  { id: "a2", name: "Rahul Verma", email: "rahul.v@tcs.com", region: "EMEA", capacity: 10, active: 10, slaCompliance: 88, status: "Active" },
  { id: "a3", name: "Anita Desai", email: "anita.d@tcs.com", region: "NAM", capacity: 12, active: 5, slaCompliance: 99, status: "Active" },
  { id: "a4", name: "Vikram Iyer", email: "vikram.i@tcs.com", region: "APAC", capacity: 10, active: 7, slaCompliance: 92, status: "Active" },
  { id: "a5", name: "Meera Joshi", email: "meera.j@tcs.com", region: "EMEA", capacity: 8, active: 0, slaCompliance: 100, status: "On Leave" },
];

const MOCK_ONBOARDINGS: AdminOnboarding[] = [
  { id: "ONB-2041", project: "Atlas GenAI Copilot", requester: "John Doe", cloud: "Azure", assignedAdmin: "a1", status: "Pending Governance", step: "Approval Tracker", slaHours: 48, ageHours: 36, pendingApprovals: ["Governance"], unreadComments: 2, rfcsOpen: 0, updatedAt: "2026-06-10T09:21:00Z" },
  { id: "ONB-2042", project: "Helios Risk Engine", requester: "Sarah Kim", cloud: "AWS", assignedAdmin: "a2", status: "Pending GPS", step: "Approval Tracker", slaHours: 48, ageHours: 52, pendingApprovals: ["GPS"], unreadComments: 0, rfcsOpen: 0, updatedAt: "2026-06-09T14:02:00Z", escalated: true },
  { id: "ONB-2043", project: "Nimbus Data Lake", requester: "Arvind Rao", cloud: "GCP", assignedAdmin: "a1", status: "Service ID In Progress", step: "Service ID Creation", slaHours: 72, ageHours: 18, pendingApprovals: [], unreadComments: 1, rfcsOpen: 0, updatedAt: "2026-06-11T07:10:00Z" },
  { id: "ONB-2044", project: "Orion Trading API", requester: "Linda Wu", cloud: "AWS", assignedAdmin: "a3", status: "RFC In Progress", step: "RFC Tracking", slaHours: 96, ageHours: 60, pendingApprovals: ["RFC"], unreadComments: 0, rfcsOpen: 2, updatedAt: "2026-06-10T22:40:00Z" },
  { id: "ONB-2045", project: "Pulse Marketing CDP", requester: "Marco Bianchi", cloud: "Azure", assignedAdmin: null, status: "Submitted", step: "Awaiting Assignment", slaHours: 24, ageHours: 6, pendingApprovals: [], unreadComments: 0, rfcsOpen: 0, updatedAt: "2026-06-11T03:55:00Z" },
  { id: "ONB-2046", project: "Vega ML Platform", requester: "Chen Wei", cloud: "GCP", assignedAdmin: null, status: "Submitted", step: "Awaiting Assignment", slaHours: 24, ageHours: 2, pendingApprovals: [], unreadComments: 0, rfcsOpen: 0, updatedAt: "2026-06-11T11:18:00Z" },
  { id: "ONB-2047", project: "Quantum HR Suite", requester: "Olivia Park", cloud: "Azure", assignedAdmin: "a4", status: "Architecture Issue", step: "Architecture Overview", slaHours: 48, ageHours: 30, pendingApprovals: [], unreadComments: 4, rfcsOpen: 0, updatedAt: "2026-06-10T17:00:00Z" },
  { id: "ONB-2048", project: "Sentinel SOC Hub", requester: "Daniel Cohen", cloud: "AWS", assignedAdmin: "a2", status: "Pending ISM", step: "Approval Tracker", slaHours: 72, ageHours: 80, pendingApprovals: ["ISM"], unreadComments: 1, rfcsOpen: 0, updatedAt: "2026-06-08T12:00:00Z", escalated: true },
  { id: "ONB-2049", project: "Lumen Edge IoT", requester: "Ravi Menon", cloud: "Azure", assignedAdmin: "a3", status: "Completed", step: "Closed", slaHours: 72, ageHours: 0, pendingApprovals: [], unreadComments: 0, rfcsOpen: 0, updatedAt: "2026-06-07T09:00:00Z" },
];

export const COMMENTS: CommentThread[] = [
  { id: "c1", onboardingId: "ONB-2041", project: "Atlas GenAI Copilot", from: "John Doe", message: "Updated the architecture diagram, please re-validate.", ts: "2026-06-11T08:14:00Z", unread: true },
  { id: "c2", onboardingId: "ONB-2041", project: "Atlas GenAI Copilot", from: "Priya Sharma", message: "Governance has flagged region. Awaiting clarification.", ts: "2026-06-11T09:21:00Z", unread: true },
  { id: "c3", onboardingId: "ONB-2047", project: "Quantum HR Suite", from: "Olivia Park", message: "Why was the EKS cluster recommendation removed?", ts: "2026-06-10T17:00:00Z", unread: true },
  { id: "c4", onboardingId: "ONB-2048", project: "Sentinel SOC Hub", from: "Daniel Cohen", message: "Escalating - ISM SLA breached.", ts: "2026-06-10T20:11:00Z", unread: true },
  { id: "c5", onboardingId: "ONB-2043", project: "Nimbus Data Lake", from: "System", message: "Service ID NIMBUS-9821 provisioned.", ts: "2026-06-11T07:10:00Z", unread: true },
];

export const AUDIT_LOG: AuditEvent[] = [
  { id: "e1", ts: "2026-06-11T11:20:00Z", actor: "Arjun Mehta", role: "Super Admin", action: "Assigned onboarding", target: "ONB-2046 → Priya Sharma" },
  { id: "e2", ts: "2026-06-11T10:02:00Z", actor: "System", role: "System", action: "SLA breach detected", target: "ONB-2042" },
  { id: "e3", ts: "2026-06-11T09:21:00Z", actor: "Priya Sharma", role: "DIS Admin", action: "Comment added", target: "ONB-2041" },
  { id: "e4", ts: "2026-06-10T22:40:00Z", actor: "System", role: "System", action: "RFC submitted", target: "ONB-2044 / RFC-771" },
  { id: "e5", ts: "2026-06-10T18:11:00Z", actor: "Arjun Mehta", role: "Super Admin", action: "Updated SLA policy", target: "Governance SLA: 48h" },
  { id: "e6", ts: "2026-06-10T12:00:00Z", actor: "Rahul Verma", role: "DIS Admin", action: "Escalated request", target: "ONB-2048" },
];

const localToAdmin = (s: SavedOnboarding): AdminOnboarding => ({
  id: s.id.toUpperCase(),
  project: s.name,
  requester: "John D.",
  cloud: s.state.requirementAssessment.cloudProviders[0] || "—",
  assignedAdmin: "a1",
  status: (s.status as AdminStatus) ?? "Draft",
  step: `Step ${s.state.currentStep}`,
  slaHours: 48,
  ageHours: Math.max(0, Math.floor((Date.now() - new Date(s.updatedAt).getTime()) / 3600000)),
  pendingApprovals: s.status === "In Approval" ? ["Governance"] : [],
  unreadComments: 0,
  rfcsOpen: s.state.rfcs.filter((r) => r.status !== "implemented" && r.status !== "closed").length,
  updatedAt: s.updatedAt,
});

export const getAllOnboardings = (): AdminOnboarding[] => {
  const local = loadAll().map(localToAdmin);
  return [...local, ...MOCK_ONBOARDINGS];
};

export const adminById = (id: string | null) => DIS_ADMINS.find((a) => a.id === id);

export const statusTone = (s: AdminStatus): "muted" | "info" | "warning" | "success" | "destructive" => {
  if (s === "Completed") return "success";
  if (s === "Rejected") return "destructive";
  if (s === "Escalated" || s === "Architecture Issue" || s === "On Hold" || s === "User Action Required") return "warning";
  if (s === "Draft") return "muted";
  if (s.startsWith("Pending") || s.includes("In Progress") || s === "In Approval" || s === "Provisioning" || s === "RFC Pending" || s === "Under Review" || s === "Submitted") return "info";
  return "muted";
};

export const toneClass = (tone: ReturnType<typeof statusTone>) => {
  switch (tone) {
    case "success": return "bg-success/10 text-success border-success/20";
    case "destructive": return "bg-destructive/10 text-destructive border-destructive/20";
    case "warning": return "bg-warning/10 text-warning border-warning/20";
    case "info": return "bg-info/10 text-info border-info/20";
    default: return "bg-muted text-muted-foreground border-border";
  }
};

export const MOCK_USERS = {
  admin: { name: "Priya Sharma", role: "DIS Admin", region: "APAC" },
  superadmin: { name: "Arjun Mehta", role: "Super Admin", region: "Global" },
} as const;
