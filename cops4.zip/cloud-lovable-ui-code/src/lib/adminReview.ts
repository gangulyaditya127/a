import { appendEvent, updateOne, loadOne, type SavedOnboarding } from "@/lib/onboardingStorage";
import {
  emptyAdminReview,
  type AdminReview,
  type CostBudget,
  type CostLineItem,
  type ReviewComment,
  type ReviewSection,
  type ReviewStatus,
} from "@/types/onboarding";

const ensure = (item: SavedOnboarding): SavedOnboarding => ({
  ...item,
  state: { ...item.state, adminReview: item.state.adminReview ?? emptyAdminReview() },
});

const now = () => new Date().toISOString();

const addComment = (
  section: ReviewSection,
  message: string,
  author: string,
  role: ReviewComment["role"]
): ReviewSection => ({
  ...section,
  comments: [
    ...section.comments,
    { id: "c_" + Math.random().toString(36).slice(2, 9), author, role, message, ts: now() },
  ],
  lastActionAt: now(),
});

// ---- User-side actions ----

export const userSubmitForReview = (id: string, target: "resource" | "arch") =>
  {
  const r = updateOne(id, (item) => {
    const it = ensure(item);
    const ar = it.state.adminReview!;
    const key = target === "resource" ? "resourceValidation" : "archValidation";
    ar[key] = { ...ar[key], status: "in_review", lastActionAt: now() };
    return { ...it, state: { ...it.state, adminReview: { ...ar } } };
  });
  appendEvent(id, {
    actor: "user", actorName: "Requestor", kind: "submission",
    title: `Submitted ${target === "resource" ? "Cloud Resources" : "Architecture"} for review`,
    scope: target === "resource" ? "Resource Validation" : "Architecture Validation",
  });
  return r;
  };

export const userReplyComment = (id: string, target: "resource" | "arch", message: string, author: string) =>
  {
  const r = updateOne(id, (item) => {
    const it = ensure(item);
    const ar = it.state.adminReview!;
    const key = target === "resource" ? "resourceValidation" : "archValidation";
    ar[key] = addComment(ar[key], message, author, "user");
    return { ...it, state: { ...it.state, adminReview: { ...ar } } };
  });
  appendEvent(id, {
    actor: "user", actorName: author, kind: "comment",
    title: "Replied to admin", body: message,
    scope: target === "resource" ? "Resource Validation" : "Architecture Validation",
  });
  return r;
  };

// ---- Admin-side actions ----

export const adminAssign = (id: string, adminId: string, adminName: string) =>
  {
  const r = updateOne(id, (item) => {
    const it = ensure(item);
    return { ...it, state: { ...it.state, adminReview: { ...it.state.adminReview!, assignedAdminId: adminId, assignedAdminName: adminName } } };
  });
  appendEvent(id, {
    actor: "superadmin", actorName: "Super Admin", kind: "assignment",
    title: `Assigned to ${adminName}`,
  });
  return r;
  };

export const adminSetStatus = (
  id: string,
  target: "resource" | "arch",
  status: ReviewStatus,
  comment: string | null,
  author: string
) =>
  {
  const r = updateOne(id, (item) => {
    const it = ensure(item);
    const ar = it.state.adminReview!;
    const key = target === "resource" ? "resourceValidation" : "archValidation";
    let next: ReviewSection = { ...ar[key], status, lastActionAt: now() };
    if (comment && comment.trim()) {
      next = addComment(next, comment.trim(), author, "admin");
    }
    ar[key] = next;
    return { ...it, state: { ...it.state, adminReview: { ...ar } } };
  });
  const scope = target === "resource" ? "Resource Validation" : "Architecture Validation";
  appendEvent(id, {
    actor: "admin", actorName: author, kind: "decision",
    title: status === "approved" ? `Approved ${scope}` : `Requested changes on ${scope}`,
    body: comment?.trim() || undefined, scope,
  });
  return r;
  };

// ---- Cost budgeting ----

export const adminSeedCostFromResources = (id: string) =>
  updateOne(id, (item) => {
    const it = ensure(item);
    if (it.state.adminReview!.costBudget.items.length > 0) return it;
    const items: CostLineItem[] = [];
    it.state.cloudResources.forEach((bucket) => {
      bucket.resources.forEach((r) => {
        items.push({
          id: "ci_" + Math.random().toString(36).slice(2, 9),
          provider: bucket.provider,
          service: r.service,
          qty: r.count,
          unitCost: 0,
          notes: r.configDetails,
        });
      });
    });
    return { ...it, state: { ...it.state, adminReview: { ...it.state.adminReview!, costBudget: { ...it.state.adminReview!.costBudget, items } } } };
  });

export const adminUpdateCostBudget = (id: string, mutator: (cb: CostBudget) => CostBudget) =>
  updateOne(id, (item) => {
    const it = ensure(item);
    return { ...it, state: { ...it.state, adminReview: { ...it.state.adminReview!, costBudget: mutator(it.state.adminReview!.costBudget) } } };
  });

export const adminPublishCost = (id: string) =>
  {
  const r = adminUpdateCostBudget(id, (cb) => ({ ...cb, publishedAt: now() }));
  appendEvent(id, { actor: "admin", actorName: "DIS Admin", kind: "publish", title: "Published cost estimate to user", scope: "Cost" });
  return r;
  };

// ---- Recommendations ----

export const adminPublishRecommendations = (id: string) =>
  {
  const r = updateOne(id, (item) => {
    const it = ensure(item);
    return { ...it, state: { ...it.state, adminReview: { ...it.state.adminReview!, recommendationsPublishedAt: now() } } };
  });
  appendEvent(id, { actor: "admin", actorName: "DIS Admin", kind: "publish", title: "Sent recommendations to user", scope: "Recommendations" });
  return r;
  };

export const computeCostTotal = (cb: CostBudget) => {
  const items = cb.items.reduce((sum, i) => sum + i.qty * i.unitCost, 0);
  return { itemsMonthly: items, infraOneOff: cb.infraSupportOneOff, infraMonthly: cb.infraSupportMonthly, totalMonthly: items + cb.infraSupportMonthly };
};

export const getReviewItem = (id: string) => {
  const it = loadOne(id);
  return it ? ensure(it) : null;
};