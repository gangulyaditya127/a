## Goal

Keep the current Lovable UI system (sidebar `ConsoleLayout`, dense tables, design tokens, tabbed `AdminOnboardingReview`) and bring in the richer **feature set** from your `cops2` codebase. Frontend-only — no backend port; we'll keep using `localStorage` mock data so the preview stays self-contained. You can wire the FastAPI backend later by swapping `onboardingStorage` / `adminApi`.

## What I'm porting from cops2 (features, not UI)

**User portal**
- `EligibilityDisclaimer` + `EligibilityAssessment` as a pre-wizard gate (drives `superadmin` Eligibility/Disclaimer config)
- A **Validation & Feedback** surface unified into the new Interaction Timeline (below)

**Admin portal** (`/admin`)
- Dashboard inbox (already present — enrich with stage chips from cops2)
- `AdminOnboardingReview` — extend existing tabs with cops2's deeper validation fields
- `AdminCostBudgeting` — per-resource unit cost + infra support, drafts vs. published (already partial; align fields with cops2)
- `AdminRecommendations` — category-grouped recs editor + approval checklist (Governance / GPS / RFC)

**Super Admin portal** (`/superadmin`)
- `OnboardingAssignment` — assign DIS admin to new submissions
- `AdminManagement` — workload/capacity (already partial; align)
- `ConfigManagement` with three sub-pages:
  - `EligibilityConfig` (criteria registry)
  - `DisclaimerConfig` (versioned disclaimer text)
  - `ArchitectureRulesConfig` (rules registry)

All rendered inside the existing `ConsoleLayout` sidebar shell (same theme, role badge) — no second design language.

## New: Interaction Timeline (the "how to portray user↔admin history" question)

Standard pattern for this in enterprise tools is a **left-rail vertical timeline + right-pane detail**, scoped per onboarding. I'll add it as:

- A reusable `InteractionTimeline.tsx` component
- One filterable, chronological log per onboarding, with typed events:
  - `submission` (user submits step), `assignment` (SA assigns admin), `comment` (admin/user), `decision` (approve / changes_requested), `publish` (cost / recommendations), `status_change`, `config_change`
- Visual: avatar + role badge + action verb + diff snippet + (placeholder) timestamp
- Filters: All / Comments / Decisions / Publishes; chips for actor (User / DIS Admin / Super Admin)
- Surfaces in three places:
  1. **User wizard** — collapsible right-side drawer "Activity" button on every step (replaces today's per-step `ValidationFeedbackPanel` clutter; the panel becomes the "Take action" footer only)
  2. **Admin review workspace** — full-height right rail next to the tabs
  3. **Super Admin onboarding detail** — read-only audit view

Data: an `events: InteractionEvent[]` array added to `SavedOnboarding.state`, appended by every existing mutation in `adminReview.ts` (and new user actions). Timestamps use `Date.now()` for now — you said you'll handle real ones backend-side later.

This gives one canonical "what happened" log everyone shares, instead of comments scattered across step panels.

## Technical notes

- Types: extend `src/types/onboarding.ts` with `InteractionEvent`, `EligibilityResponse`, `DisclaimerAck`, `ArchRule`, `EligibilityCriterion`, `DisclaimerDoc`.
- Storage: extend `onboardingStorage.ts` with `appendEvent(id, event)` and a separate `src/lib/configStorage.ts` for SA registries (eligibility / disclaimer / arch rules).
- Routes added to `App.tsx`:
  - `/eligibility` (user pre-wizard)
  - `/superadmin/config`, `/superadmin/config/eligibility`, `/superadmin/config/disclaimer`, `/superadmin/config/architecture-rules`
  - `/superadmin/assignments` already exists — replace impl with cops2's richer one
- Reuse existing tokens (`gradient-primary`, status `tone` helpers). No hardcoded colors.
- Mock data: seed a few eligibility criteria, a disclaimer v1, and 3 arch rules so SA pages are not empty.

## Out of scope this round

- Real auth, real backend wiring (kept as `localStorage` mocks)
- Email/SLA breach automation
- Real timestamps / server clock
- Audit export to CSV (easy follow-up)

## Deliverables

~14 files touched, ~6 new components/pages. After this, the Admin and SuperAdmin consoles in your Lovable preview will match the feature scope of cops2 while keeping the cleaner UI shell, and every user↔admin exchange will be visible in one timeline.

Reply "go" and I'll build it.
