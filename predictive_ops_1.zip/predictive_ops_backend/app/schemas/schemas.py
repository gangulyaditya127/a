from pydantic import BaseModel
from typing import List, Optional

class SubjourneyOut(BaseModel):
    id: str
    name: str
    journey_id: str
    mapping_name: str
    
    # UI expected mock fields
    status: str = "ok"
    resp: int = 120
    avail: float = 99.9
    errRate: float = 0.1
    happy: int = 90
    alerts: int = 0
    
    class Config:
        from_attributes = True

class JourneyOut(BaseModel):
    id: str
    name: str
    
    # UI expected mock fields
    segment: str = "enterprise"
    status: str = "ok"
    users: int = 1000
    happy: int = 80
    unhappy: int = 10
    frustrated: int = 10
    avail: float = 99.5
    alerts: int = 0
    subJourneysCount: int = 0
    
    class Config:
        from_attributes = True
