from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.routers import journey_router
from app.routers import correlation_router

app = FastAPI(title="Predictive Ops API", version="1.0.0")

# Configure CORS
origins = [
    "http://localhost:5173", # Vite dev server
    "http://127.0.0.1:5173",
    "http://localhost:5174",
    "http://127.0.0.1:5174",
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(journey_router.router)
app.include_router(correlation_router.router)

@app.get("/")
def read_root():
    return {"message": "Welcome to Predictive Ops API"}
