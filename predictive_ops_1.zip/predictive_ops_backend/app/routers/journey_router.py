from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List

from app.database import get_db
from app.schemas import schemas
from app.services import journey_service

router = APIRouter(prefix="/api/journeys", tags=["journeys"])

@router.get("", response_model=List[schemas.JourneyOut])
def read_journeys(db: Session = Depends(get_db)):
    return journey_service.get_journeys(db)

@router.get("/{journey_id}/subjourneys", response_model=List[schemas.SubjourneyOut])
def read_subjourneys(journey_id: str, db: Session = Depends(get_db)):
    subjourneys = journey_service.get_subjourneys_by_journey_id(db, journey_id)
    if not subjourneys:
        # Returning empty list is fine, or raise 404
        return []
    return subjourneys
