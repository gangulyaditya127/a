from sqlalchemy import Column, String, Integer, BigInteger, Float, DateTime, ForeignKey, Text
from sqlalchemy.orm import declarative_base, relationship

Base = declarative_base()

class Journey(Base):
    __tablename__ = 'journeys'
    
    id = Column(String(50), primary_key=True, index=True)
    name = Column(String(255))
    
    subjourneys = relationship("Subjourney", back_populates="journey")

class Subjourney(Base):
    __tablename__ = 'subjourneys'
    
    id = Column(String(50), primary_key=True, index=True)
    journey_id = Column(String(50), ForeignKey('journeys.id'))
    name = Column(String(255))
    mapping_name = Column(String(255))
    
    journey = relationship("Journey", back_populates="subjourneys")
    incidents = relationship("Incident", back_populates="subjourney")
    pattern_families = relationship("PatternFamily", back_populates="subjourney")

class PatternFamily(Base):
    __tablename__ = 'pattern_families'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    subjourney_id = Column(String(50), ForeignKey('subjourneys.id'))
    pattern_name = Column(Text)
    example_description = Column(Text)
    incident_count = Column(Integer)
    
    subjourney = relationship("Subjourney", back_populates="pattern_families")

class Incident(Base):
    __tablename__ = 'incidents'
    
    # We use 'number' as the primary key since it contains unique identifiers like 'INC2103046'
    number = Column(Text, primary_key=True)
    opened = Column(DateTime)
    caller = Column(Text)
    short_description = Column(Text)
    priority = Column(Text)
    state = Column(Text)
    assignment_group = Column(Text)
    updated = Column(DateTime)
    additional_comments = Column(Text)
    child_incidents = Column(BigInteger)
    business_duration = Column(Float)
    business_impact = Column(Text)
    business_resolve_time = Column(Float)
    caused_by_change = Column(Text)
    change_request = Column(Text)
    channel = Column(Text)
    closed = Column(DateTime)
    comments_and_work_notes = Column(Text)
    date = Column(Float)
    configuration_item = Column(Text)
    correlation_id = Column(Text)
    correlation_display = Column(Text)
    created = Column(DateTime)
    description = Column(Text)
    due_date = Column(Float)
    duration = Column(Float)
    first_assignment_group = Column(Text)
    impact = Column(Text)
    incident_state = Column(Text)
    major_incident_state = Column(Text)
    overview = Column(Text)
    parent_incident = Column(Text)
    probable_cause = Column(Text)
    problem = Column(Text)
    reassignment_count = Column(BigInteger)
    reopen_count = Column(BigInteger)
    resolution_code = Column(Text)
    resolution_notes = Column(Text)
    resolve_time = Column(Float)
    resolved = Column(DateTime)
    service = Column(Text)
    severity = Column(Text)
    technician_notes = Column(Float)
    urgency = Column(Text)
    work_notes = Column(Text)
    csat_overall_overall_how_satisfied_are_you_with_the_support_exp = Column(Float)
    ces_ease_how_easy_was_it_to_get_your_issue_resolved = Column(Float)
    communication_how_satisfied_are_you_with_the_clarity_and_timeli = Column(Float)
    resolution_quality_how_satisfied_are_you_that_the_issue_was_res = Column(Float)
    fcr_confirm_was_your_issue_resolved_without_needing_to_contact_ = Column(Float)
    comment_please_share_any_additional_feedback = Column(Float)
    hop_level = Column(Float)
    
    subjourney_id = Column(String(50), ForeignKey('subjourneys.id'))
    
    subjourney = relationship("Subjourney", back_populates="incidents")
