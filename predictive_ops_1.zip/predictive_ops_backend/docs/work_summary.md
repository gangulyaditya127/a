# Project Evolution & Work Summary

This document serves as an elaborate record of all the architectural decisions, logic updates, and full-stack integrations we have implemented throughout our conversation to evolve the Canada Life ARE Observability Platform.

## 1. Correlation Engine: Sub-journey Resolution
* **Rejected "Progressive Intersection"**: We removed the initial progressive intersection algorithm because it wasn't strict enough for business requirements.
* **Implemented "Superset-Check" Logic**: We updated `_resolve_affected_sub_journeys` so that a sub-journey is only associated with an incident if it contains **all** the components associated with the incident's root-cause and downstream alerts.
* **Role Filtering**: During sub-journey identification, the engine now strictly ignores contributing/suppressed alerts and focuses entirely on the root cause and downstream alert roles.

## 2. Incident Topology & Database Schema
* **Schema Migration**: We removed the singular `affected_sub_journey_id` column from the `incidents` table and introduced a many-to-many junction table (`incident_sub_journeys`) to allow a single incident to impact multiple sub-journeys simultaneously.
* **Dynamic Health State Generation (`IncidentTopologyState`)**:
  * Root cause & downstream components are flagged as `'crit'`.
  * Contributing components are flagged as `'deg'`.
  * All other components in the affected sub-journey(s) are marked as `'ok'`.
  * The precise component linked to the root cause alert is explicitly marked with `is_rc_at_time = True`.
* **Critical Edge Calculation (`IncidentCriticalEdge`)**: Instead of scanning base dependencies for severity, the engine now builds incident-specific critical edges by looking at the `incident_topology_state`. An edge is considered critical *only* if both its source and destination components are marked as `'crit'`.
* **Observability Logs**: Added rich print statements throughout `correlation_engine.py` to make the backend execution steps visible and debuggable in the terminal.

## 3. UI Optimization & Lazy Loading
* **Performance Overhaul**: We removed the eager loading of heavy analysis APIs (`/tiers`, `/alerts`, `/corr-data`, `/rules`) from the initial application load (`observabilityService.getAll()`). The home page now only fetches `/journeys`, making it incredibly fast.
* **Dynamic Drill-Down**: The `App.jsx` state manager (`openAnalysis`) was rewritten to execute `Promise.all()` and dynamically fetch all analysis data *only* when a user clicks on a specific sub-journey step.
* **Component Cleanup**: We gutted redundant, complex `useEffect` fetching logic and internal state from `AnalysisView.jsx`. It now acts as a pure presentation component that renders the clean props handed down by `App.jsx`.

## 4. Sub-Journey Dynamic Resolution (`latest` ID)
* **Frontend Parameter**: We updated the `observabilityService` so that clicking a sub-journey passes `incident=latest` along with a `subjourney_id` parameter to the API.
* **Backend Resolution**: The `GET /corr-data` endpoint was modified to intercept the `latest` keyword. It now performs a SQL JOIN against `incident_sub_journeys` to locate the most recent (by `detected_at`) incident specifically tied to the requested sub-journey, and returns its data.

## 5. Correlation API Hardening
* **Time-Windowed Alert Polling**: We introduced a `CORRELATION_WINDOW_MINUTES` environment variable (default: 60) in `.env` and `config.py`. The correlation engine now strictly filters for alerts where `is_correlated = False` AND `detected_at` is within the last 60 minutes.
* **Timestamped Incident Generation**: When the engine is triggered via `POST /correlate` with `incident_id=latest`, instead of deleting a hardcoded incident, it now dynamically generates a unique identifier formatted as `INC-{YYYYMMDDHHMMSS}` and persists a brand new incident record.

## 6. Live Correlation Metrics in UI
* **Backend Payload Expansion**: We updated `AnalysisService.get_corr_data` to serialize and return the actual `Incident` database row in its JSON response.
* **Data Binding**: We stripped out the hardcoded HTML text in the "Alert Correlation" UI card and wired it up to the dynamic `incident` object.
* **Dynamic Fields Displayed**:
  * Title & Root Cause 
  * Root Cause Description
  * Raw Alerts Grouped (`raw_alerts_grouped`)
  * Tools Contributing (`tools_contributing`)
  * Correlation Confidence (`correlation_confidence_pct`)
  * Frustrated Users & Incident ID (Sidebar metrics)

***

*All changes have been successfully compiled, tested, and integrated across the frontend React application, backend FastAPI endpoints, and SQLAlchemy database models.*
