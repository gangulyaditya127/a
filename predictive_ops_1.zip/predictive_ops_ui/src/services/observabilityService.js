import { journeys as mockJourneys, subJourneys as mockSubJourneys, correlationCluster, ruleDiscoveryData } from '../data/mockData';

const API_BASE = 'http://localhost:8000/api';

export const observabilityService = {
  getAll: async () => {
    try {
      const res = await fetch(`${API_BASE}/journeys`);
      if (!res.ok) throw new Error("Failed to fetch journeys");
      const fetchedJourneys = await res.json();
      return {
        journeys: fetchedJourneys,
        subJourneys: mockSubJourneys,
        corrData: correlationCluster,
        rules: ruleDiscoveryData
      };
    } catch (e) {
      console.error("API failed, falling back to mock data", e);
      return {
        journeys: mockJourneys,
        subJourneys: mockSubJourneys,
        corrData: correlationCluster,
        rules: ruleDiscoveryData
      };
    }
  },
  getSubJourneys: async (jid) => {
    try {
      const res = await fetch(`${API_BASE}/journeys/${jid}/subjourneys`);
      if (!res.ok) throw new Error("Failed to fetch subjourneys");
      const fetchedSubJourneys = await res.json();
      
      const journeyRes = await fetch(`${API_BASE}/journeys`);
      const allJourneys = await journeyRes.json();
      const parentJourney = allJourneys.find(j => j.id === jid) || { name: 'Journey' };
      
      return {
        [jid]: {
          title: parentJourney.name,
          steps: fetchedSubJourneys
        }
      };
    } catch (e) {
      console.error("API failed, falling back to mock data", e);
      return { [jid]: mockSubJourneys[jid] };
    }
  },
  getCorrData: async (subjourneyId) => {
    try {
      const res = await fetch(`${API_BASE}/correlation/top_cluster?subjourney_id=${subjourneyId}&opened_datetime=2026-06-15T12:00:00`);
      
      if (!res.ok) throw new Error("Failed to fetch correlation data");
      
      const data = await res.json();
      
      if (data.error) {
        console.warn("API returned error:", data.error);
        return correlationCluster; // fallback to mock if no clusters found
      }
      
      return data;
    } catch (e) {
      console.error("API failed for getCorrData, falling back to mock data", e);
      return correlationCluster;
    }
  },
  getRules: async () => {
    return ruleDiscoveryData;
  },
  minePatterns: async () => { return true; },
  listPatterns: async () => { return []; },
  synthesizePattern: async () => { return {}; },
  listProposals: async () => { return []; },
  approveProposal: async () => { return true; },
  rejectProposal: async () => { return true; }
};