import { Routes, Route } from "react-router-dom";
import { Toaster } from "@/components/ui/sonner";
import CalculatorPage from "./routes/index";
import DeveloperPage from "./routes/developer";
import PricingPage from "./routes/pricing";

export default function App() {
  return (
    <>
      <Routes>
        <Route path="/" element={<CalculatorPage />} />
        <Route path="/developer" element={<DeveloperPage />} />
        <Route path="/pricing" element={<PricingPage />} />
      </Routes>
      <Toaster richColors theme="dark" position="top-right" />
    </>
  );
}
