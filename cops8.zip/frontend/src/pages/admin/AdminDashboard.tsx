import { useCallback, useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  LayoutDashboard,
  Clock,
  AlertTriangle,
  CheckCircle2,
  ChevronDown,
  ChevronRight,
  Eye,
  Loader2,
  Search,
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { AdminLayout } from "@/components/admin/AdminLayout";
import {
  fetchAdminDashboard,
  fetchOtherOnboardings,
  type AdminDashboardData,
  type AdminOnboarding,
} from "@/lib/adminApi";
import { useAuth } from "@/contexts/AuthContext";

// ─── Status badge colours (bg-{color}-500/10 pattern) ────────────────

const statusBadgeStyle: Record<string, string> = {
  pending_assignment:
    "bg-gray-500/10 text-gray-600 border-gray-500/20",
  assigned:
    "bg-yellow-500/10 text-yellow-600 border-yellow-500/20",
  under_review:
    "bg-yellow-500/10 text-yellow-600 border-yellow-500/20",
  approved:
    "bg-emerald-500/10 text-emerald-600 border-emerald-500/20",
  sent_back:
    "bg-red-500/10 text-red-600 border-red-500/20",
  cost_pending:
    "bg-blue-500/10 text-blue-600 border-blue-500/20",
  recommendations_pending:
    "bg-purple-500/10 text-purple-600 border-purple-500/20",
  recommendations_sent:
    "bg-teal-500/10 text-teal-600 border-teal-500/20",
  completed:
    "bg-green-500/10 text-green-600 border-green-500/20",
};

// ─── KPI card ────────────────────────────────────────────────────────

const Kpi = ({
  label,
  value,
  icon: Icon,
  tone = "bg-primary/10 text-primary",
}: {
  label: string;
  value: number;
  icon: React.ComponentType<{ className?: string }>;
  tone?: string;
}) => (
  <Card>
    <CardContent className="p-4 flex items-center gap-3">
      <div
        className={`h-10 w-10 rounded-md flex items-center justify-center ${tone}`}
      >
        <Icon className="h-5 w-5" />
      </div>
      <div>
        <p className="text-xs text-muted-foreground">{label}</p>
        <p className="text-lg font-semibold text-foreground">{value}</p>
      </div>
    </CardContent>
  </Card>
);

// ─── Cloud provider badge helper ─────────────────────────────────────

const cloudProviderBadge = (provider: string | undefined) => {
  if (!provider) return null;
  return <Badge variant="outline">{provider}</Badge>;
};

// ─── Main component ──────────────────────────────────────────────────

const AdminDashboard = () => {
  const navigate = useNavigate();
  const { user } = useAuth();

  const [data, setData] = useState<AdminDashboardData | null>(null);
  const [loading, setLoading] = useState(true);

  // Filter state
  const [q, setQ] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");

  useEffect(() => {
    setLoading(true);
    fetchAdminDashboard()
      .then(setData)
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  // Derive KPI stats
  const onboardings = data?.onboardings ?? [];

  const stats = {
    assigned: data?.total_assigned ?? 0,
    pending: data?.pending_review ?? 0,
    escalated: data?.sent_back ?? 0,
    completed: onboardings.filter(
      (o) => o.admin_status === "completed"
    ).length,
  };

  // Filtering
  const filtered = onboardings.filter((o) => {
    // Status filter
    if (statusFilter !== "all") {
      if (statusFilter === "pending_review") {
        if (
          o.admin_status !== "assigned" &&
          o.admin_status !== "under_review"
        )
          return false;
      } else if (o.admin_status !== statusFilter) {
        return false;
      }
    }
    // Search filter
    if (q) {
      const search = q.toLowerCase();
      const matchName = o.name?.toLowerCase().includes(search);
      const matchId = o.id?.toLowerCase().includes(search);
      const matchProject = o.account_details?.project_name
        ?.toLowerCase()
        .includes(search);
      if (!matchName && !matchId && !matchProject) return false;
    }
    return true;
  });

  // ── Other Onboardings (lazy loaded) ──
  const [othersOpen, setOthersOpen] = useState(false);
  const [othersList, setOthersList] = useState<AdminOnboarding[]>([]);
  const [othersTotal, setOthersTotal] = useState(0);
  const [othersLoading, setOthersLoading] = useState(false);

  const loadOthers = useCallback((offset: number) => {
    setOthersLoading(true);
    fetchOtherOnboardings(offset, 10)
      .then((res) => {
        setOthersTotal(res.total);
        if (offset === 0) {
          setOthersList(res.onboardings);
        } else {
          setOthersList((prev) => [...prev, ...res.onboardings]);
        }
      })
      .catch(() => {})
      .finally(() => setOthersLoading(false));
  }, []);

  return (
    <AdminLayout>
      {loading ? (
        <div className="flex items-center justify-center py-20">
          <Loader2 className="h-8 w-8 animate-spin text-teal-500" />
        </div>
      ) : (
        <div className="space-y-6 max-w-[1400px]">
          {/* Welcome */}
          <div>
            <h2 className="text-2xl font-semibold text-foreground">
              Welcome back, {user?.name?.split(" ")[0] ?? "Admin"}
            </h2>
            <p className="text-sm text-muted-foreground">
              Operational SPOC view for assigned onboardings. Monitor
              progress, coordinate with users, and escalate blockers.
            </p>
          </div>

          {/* KPI row — 4 cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <Kpi
              label="Total Assigned"
              value={stats.assigned}
              icon={LayoutDashboard}
            />
            <Kpi
              label="Pending Review"
              value={stats.pending}
              icon={Clock}
              tone="bg-blue-500/10 text-blue-600"
            />
            <Kpi
              label="Escalated / Sent Back"
              value={stats.escalated}
              icon={AlertTriangle}
              tone="bg-amber-500/10 text-amber-600"
            />
            <Kpi
              label="Completed"
              value={stats.completed}
              icon={CheckCircle2}
              tone="bg-emerald-500/10 text-emerald-600"
            />
          </div>

          {/* Table card */}
          <Card>
            <CardContent className="p-4 space-y-4">
              {/* Header + filters */}
              <div className="flex flex-wrap items-center gap-2 justify-between">
                <div>
                  <h3 className="font-semibold text-foreground">
                    My assigned onboardings
                  </h3>
                  <p className="text-xs text-muted-foreground">
                    {filtered.length} onboarding
                    {filtered.length !== 1 ? "s" : ""} found
                  </p>
                </div>
                <div className="flex gap-2">
                  <div className="relative">
                    <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Search project or ID..."
                      value={q}
                      onChange={(e) => setQ(e.target.value)}
                      className="w-64 pl-8"
                    />
                  </div>
                  <Select
                    value={statusFilter}
                    onValueChange={setStatusFilter}
                  >
                    <SelectTrigger className="w-44">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All statuses</SelectItem>
                      <SelectItem value="pending_review">
                        Pending Review
                      </SelectItem>
                      <SelectItem value="approved">Approved</SelectItem>
                      <SelectItem value="sent_back">Sent Back</SelectItem>
                      <SelectItem value="cost_pending">
                        Cost Pending
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Table */}
              <div className="rounded-md border overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>ID</TableHead>
                      <TableHead>Project</TableHead>
                      <TableHead>Requestor</TableHead>
                      <TableHead>Cloud Provider</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Step</TableHead>
                      <TableHead className="text-right">Action</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filtered.map((o: AdminOnboarding) => (
                      <TableRow key={o.id} className="cursor-pointer">
                        <TableCell className="font-mono text-xs max-w-[100px] truncate">
                          {o.id}
                        </TableCell>
                        <TableCell className="font-medium">
                          {o.account_details?.project_name ?? o.name}
                        </TableCell>
                        <TableCell className="text-muted-foreground">
                          {o.user_name ?? o.account_details?.owner ?? "—"}
                        </TableCell>
                        <TableCell>
                          {cloudProviderBadge(
                            o.requirement_assessment?.cloud_provider
                          )}
                        </TableCell>
                        <TableCell>
                          <Badge
                            className={`text-[10px] ${
                              statusBadgeStyle[o.admin_status] ??
                              "bg-muted text-muted-foreground"
                            }`}
                          >
                            {o.admin_status?.replace(/_/g, " ")}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-xs text-muted-foreground">
                          {o.current_step}/8
                        </TableCell>
                        <TableCell className="text-right">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() =>
                              navigate(`/admin/review/${o.id}`)
                            }
                          >
                            Open
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                    {filtered.length === 0 && (
                      <TableRow>
                        <TableCell
                          colSpan={7}
                          className="text-center text-sm text-muted-foreground py-8"
                        >
                          No onboardings match the filter.
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>

          {/* ── Other Onboardings (lazy-loaded) ───────────────── */}
          <Card>
            <CardContent className="p-4 space-y-4">
              <button
                onClick={() => {
                  if (!othersOpen) loadOthers(0);
                  setOthersOpen((v) => !v);
                }}
                className="flex items-center gap-2 w-full text-left"
              >
                {othersOpen ? (
                  <ChevronDown className="h-4 w-4 text-muted-foreground" />
                ) : (
                  <ChevronRight className="h-4 w-4 text-muted-foreground" />
                )}
                <h3 className="font-semibold text-foreground">Other Onboardings</h3>
                {othersTotal > 0 && (
                  <Badge className="bg-muted text-muted-foreground text-[10px] ml-1">
                    {othersTotal}
                  </Badge>
                )}
                <span className="text-xs text-muted-foreground ml-auto">
                  View-only
                </span>
              </button>

              {othersOpen && (
                <>
                  {othersLoading && othersList.length === 0 ? (
                    <div className="flex items-center justify-center py-8">
                      <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
                    </div>
                  ) : othersList.length === 0 ? (
                    <p className="text-sm text-muted-foreground text-center py-6">
                      No other onboardings found.
                    </p>
                  ) : (
                    <>
                      <div className="rounded-md border overflow-x-auto">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>ID</TableHead>
                              <TableHead>Project</TableHead>
                              <TableHead>Requestor</TableHead>
                              <TableHead>Assigned Admin</TableHead>
                              <TableHead>Status</TableHead>
                              <TableHead>Step</TableHead>
                              <TableHead className="text-right">Action</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {othersList.map((o: AdminOnboarding) => (
                              <TableRow key={o.id}>
                                <TableCell className="font-mono text-xs max-w-[100px] truncate">
                                  {o.id}
                                </TableCell>
                                <TableCell className="font-medium">
                                  {o.account_details?.project_name ?? o.name}
                                </TableCell>
                                <TableCell className="text-muted-foreground">
                                  {o.user_name ?? o.account_details?.owner ?? "—"}
                                </TableCell>
                                <TableCell className="text-muted-foreground text-xs">
                                  {o.admin_assignment?.admin_id ? (
                                    <Badge variant="outline" className="text-[10px]">
                                      {o.admin_assignment.admin_id}
                                    </Badge>
                                  ) : (
                                    <span className="text-muted-foreground/60">Unassigned</span>
                                  )}
                                </TableCell>
                                <TableCell>
                                  <Badge
                                    className={`text-[10px] ${
                                      statusBadgeStyle[o.admin_status] ??
                                      "bg-muted text-muted-foreground"
                                    }`}
                                  >
                                    {o.admin_status?.replace(/_/g, " ")}
                                  </Badge>
                                </TableCell>
                                <TableCell className="text-xs text-muted-foreground">
                                  {o.current_step}/8
                                </TableCell>
                                <TableCell className="text-right">
                                  <Button
                                    size="sm"
                                    variant="ghost"
                                    onClick={() =>
                                      navigate(`/admin/review/${o.id}?readonly=1`)
                                    }
                                  >
                                    <Eye className="h-4 w-4 mr-1" /> View
                                  </Button>
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>

                      {/* Load More */}
                      {othersList.length < othersTotal && (
                        <div className="flex justify-center pt-2">
                          <Button
                            size="sm"
                            variant="outline"
                            disabled={othersLoading}
                            onClick={() => loadOthers(othersList.length)}
                          >
                            {othersLoading ? (
                              <><Loader2 className="h-3 w-3 mr-1 animate-spin" /> Loading...</>
                            ) : (
                              `Load More (${othersList.length} of ${othersTotal})`
                            )}
                          </Button>
                        </div>
                      )}
                    </>
                  )}
                </>
              )}
            </CardContent>
          </Card>
        </div>
      )}
    </AdminLayout>
  );
};

export default AdminDashboard;
