"""add user_id to onboardings

Revision ID: a1b2c3d4e5f6
Revises: 6f66bdca8333
Create Date: 2026-07-06 15:42:00.000000
"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

# revision identifiers, used by Alembic.
revision: str = "a1b2c3d4e5f6"
down_revision: Union[str, None] = "6f66bdca8333"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # Add nullable user_id column
    op.add_column("onboardings", sa.Column("user_id", sa.String(), nullable=True))
    op.create_index(op.f("ix_onboardings_user_id"), "onboardings", ["user_id"])

    # Backfill existing onboardings with first 'user' role user
    conn = op.get_bind()
    first_user = conn.execute(
        sa.text("SELECT id FROM users WHERE role = 'user' LIMIT 1")
    ).scalar()
    if first_user:
        conn.execute(
            sa.text("UPDATE onboardings SET user_id = :uid WHERE user_id IS NULL"),
            {"uid": first_user},
        )

    # Add foreign key constraint
    op.create_foreign_key(
        "fk_onboardings_user_id",
        "onboardings",
        "users",
        ["user_id"],
        ["id"],
    )


def downgrade() -> None:
    op.drop_constraint("fk_onboardings_user_id", "onboardings", type_="foreignkey")
    op.drop_index(op.f("ix_onboardings_user_id"), table_name="onboardings")
    op.drop_column("onboardings", "user_id")
