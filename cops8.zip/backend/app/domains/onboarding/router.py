"""API router for the onboarding domain."""

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.domains.auth.dependencies import get_optional_user
from app.models.user import User
from app.domains.onboarding import service
from app.domains.onboarding.schemas import (
    ClauseOut,
    OnboardingCreate,
    OnboardingListItem,
    OnboardingResponse,
    OnboardingUpdate,
    QuestionOut,
)

router = APIRouter()


@router.get("/", response_model=list[OnboardingListItem])
def list_onboardings(
    db: Session = Depends(get_db),
    user: User | None = Depends(get_optional_user),
) -> list[OnboardingListItem]:
    """Return onboardings. If a user is authenticated, only their own."""
    user_id = user.id if user and user.role == "user" else None
    return service.get_all_onboardings(db, user_id=user_id)


@router.post("/", response_model=OnboardingResponse, status_code=201)
def create_onboarding(
    data: OnboardingCreate,
    db: Session = Depends(get_db),
    user: User | None = Depends(get_optional_user),
) -> OnboardingResponse:
    """Create a new onboarding workflow."""
    user_id = user.id if user else None
    return service.create_onboarding(db, data, user_id=user_id)


# ── Static routes MUST appear before the /{onboarding_id} param route ──


@router.get("/eligibility/questions", response_model=list[QuestionOut])
def get_eligibility_questions(
    db: Session = Depends(get_db),
) -> list[QuestionOut]:
    """Return all eligibility check questions in order."""
    return service.get_eligibility_questions(db)


@router.get("/disclaimer/clauses", response_model=list[ClauseOut])
def get_disclaimer_clauses(
    db: Session = Depends(get_db),
) -> list[ClauseOut]:
    """Return all disclaimer clauses in order."""
    return service.get_disclaimer_clauses(db)


@router.get("/{onboarding_id}/cost")
def get_onboarding_cost(
    onboarding_id: str,
    db: Session = Depends(get_db),
) -> dict:
    """Return cost estimation for user view (no admin auth required)."""
    from app.admin.disadmin.service import get_cost
    cost = get_cost(db, onboarding_id)
    if cost is None:
        return {"status": "pending"}
    return {
        "status": "published",
        "resource_costs": cost.resource_costs,
        "infra_support_cost": cost.infra_support_cost,
        "total_monthly_cost": cost.total_monthly_cost,
        "total_annual_cost": cost.total_annual_cost,
        "currency": cost.currency,
        "notes": cost.notes,
    }


@router.get("/{onboarding_id}/events")
def get_onboarding_events(
    onboarding_id: str,
    db: Session = Depends(get_db),
) -> list[dict]:
    """Return interaction events for user-facing activity timeline."""
    from app.admin.disadmin.service import get_interaction_events
    return get_interaction_events(db, onboarding_id)


@router.get("/{onboarding_id}/recommendations")
def get_onboarding_recommendations(
    onboarding_id: str,
    db: Session = Depends(get_db),
) -> dict:
    """Return admin-generated recommendations for the user view."""
    from app.admin.disadmin.service import get_recommendations
    from app.models.onboarding import Onboarding

    ob = db.query(Onboarding).filter(Onboarding.id == onboarding_id).first()
    if ob is None:
        raise HTTPException(status_code=404, detail="Onboarding not found")

    # Only show recommendations once admin has sent them
    if ob.admin_status not in ("recommendations_sent",):
        return {"status": "pending", "recommendations": []}

    recs = get_recommendations(db, onboarding_id)
    return {
        "status": "published",
        "recommendations": [
            {
                "id": r.id,
                "category": r.category,
                "title": r.title,
                "summary": r.summary,
                "parameters": r.parameters or [],
                "copy_text": r.copy_text or "",
                "status": r.status,
            }
            for r in recs
        ],
    }


# ── Dynamic routes with path parameter ──


@router.get("/{onboarding_id}", response_model=OnboardingResponse)
def get_onboarding(
    onboarding_id: str,
    db: Session = Depends(get_db),
) -> OnboardingResponse:
    """Return a single onboarding with nested account_details and requirement_assessment."""
    onboarding = service.get_onboarding(db, onboarding_id)
    if onboarding is None:
        raise HTTPException(status_code=404, detail="Onboarding not found")
    return onboarding


@router.put("/{onboarding_id}", response_model=OnboardingResponse)
def update_onboarding(
    onboarding_id: str,
    data: OnboardingUpdate,
    db: Session = Depends(get_db),
) -> OnboardingResponse:
    """Update an existing onboarding's fields."""
    onboarding = service.update_onboarding(db, onboarding_id, data)
    if onboarding is None:
        raise HTTPException(status_code=404, detail="Onboarding not found")
    return onboarding


@router.post("/{onboarding_id}/resubmit", status_code=200)
def resubmit_onboarding(
    onboarding_id: str,
    body: dict | None = None,
    db: Session = Depends(get_db),
    user: User | None = Depends(get_optional_user),
) -> dict:
    """Resubmit an onboarding after making changes requested by admin."""
    from app.admin.disadmin.service import resubmit_onboarding as do_resubmit

    user_name = user.name if user else None
    comment = (body or {}).get("comment")
    success = do_resubmit(db, onboarding_id, user_name=user_name, comment=comment)
    if not success:
        raise HTTPException(status_code=404, detail="Onboarding not found")
    return {"status": "resubmitted"}


@router.delete("/{onboarding_id}", status_code=204)
def delete_onboarding(
    onboarding_id: str,
    db: Session = Depends(get_db),
) -> None:
    """Delete an onboarding and all associated data (cascading)."""
    deleted = service.delete_onboarding(db, onboarding_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="Onboarding not found")
