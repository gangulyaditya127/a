"""Pydantic schemas for the onboarding domain."""

from datetime import datetime
from typing import Any, Optional

from pydantic import BaseModel, ConfigDict, model_validator

from app.domains.account_details.schemas import AccountDetailsResponse
from app.domains.requirements.schemas import RequirementResponse


class OnboardingCreate(BaseModel):
    """Payload for creating a new onboarding."""

    name: str = "Untitled Onboarding"
    user_id: Optional[str] = None


class OnboardingUpdate(BaseModel):
    """Payload for updating an existing onboarding — all fields optional."""

    name: Optional[str] = None
    status: Optional[str] = None
    current_step: Optional[int] = None
    remaining_state: Optional[dict[str, Any]] = None


class OnboardingResponse(BaseModel):
    """Full onboarding representation including nested child resources."""

    id: str
    name: str
    status: str
    current_step: int
    created_at: datetime
    updated_at: datetime
    remaining_state: Optional[dict[str, Any]] = None
    user_id: Optional[str] = None
    user_name: Optional[str] = None
    user_email: Optional[str] = None
    admin_status: Optional[str] = None
    admin_comments: Optional[list[Any]] = None
    account_details: Optional[AccountDetailsResponse] = None
    requirement_assessment: Optional[RequirementResponse] = None

    model_config = ConfigDict(from_attributes=True)

    @model_validator(mode="before")
    @classmethod
    def _populate_user_fields(cls, data: Any) -> Any:
        """Extract user_name and user_email from the ORM relationship."""
        if hasattr(data, "user") and data.user is not None:
            data.user_name = data.user.name  # type: ignore[attr-defined]
            data.user_email = data.user.email  # type: ignore[attr-defined]
        return data


class OnboardingListItem(BaseModel):
    """Lightweight onboarding representation for list views."""

    id: str
    name: str
    status: str
    current_step: int
    created_at: datetime
    updated_at: datetime
    user_id: Optional[str] = None
    user_name: Optional[str] = None
    user_email: Optional[str] = None

    model_config = ConfigDict(from_attributes=True)

    @model_validator(mode="before")
    @classmethod
    def _populate_user_fields(cls, data: Any) -> Any:
        if hasattr(data, "user") and data.user is not None:
            data.user_name = data.user.name  # type: ignore[attr-defined]
            data.user_email = data.user.email  # type: ignore[attr-defined]
        return data


class QuestionOut(BaseModel):
    """Response schema for an eligibility question."""

    section: str
    title: str
    note: Optional[str] = None
    question_type: str
    options: list[str]
    correct_answer: Any  # str for single, list[str] for multi
    fail_message: str
    sort_order: int

    model_config = ConfigDict(from_attributes=True)


class ClauseOut(BaseModel):
    """Response schema for a disclaimer clause."""

    title: str
    text: str
    sort_order: int

    model_config = ConfigDict(from_attributes=True)
