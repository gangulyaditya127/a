"""Migrate the existing database to match the current models.

Adds missing columns to existing tables.
"""
import sys, os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from app.core.database import engine
from sqlalchemy import text, inspect

def migrate():
    insp = inspect(engine)

    with engine.begin() as conn:
        # --- users table ---
        user_cols = {c["name"] for c in insp.get_columns("users")}

        if "emp_id" not in user_cols:
            print("[MIGRATE] Adding users.emp_id ...")
            conn.execute(text("ALTER TABLE users ADD COLUMN emp_id VARCHAR NOT NULL DEFAULT ''"))

        if "is_active" not in user_cols:
            print("[MIGRATE] Adding users.is_active ...")
            conn.execute(text("ALTER TABLE users ADD COLUMN is_active BOOLEAN NOT NULL DEFAULT TRUE"))

        # --- onboardings table ---
        ob_cols = {c["name"] for c in insp.get_columns("onboardings")}

        if "admin_status" not in ob_cols:
            print("[MIGRATE] Adding onboardings.admin_status ...")
            conn.execute(text("ALTER TABLE onboardings ADD COLUMN admin_status VARCHAR NOT NULL DEFAULT 'pending_assignment'"))

        if "admin_comments" not in ob_cols:
            print("[MIGRATE] Adding onboardings.admin_comments ...")
            conn.execute(text("ALTER TABLE onboardings ADD COLUMN admin_comments JSON"))

        if "user_comments" not in ob_cols:
            print("[MIGRATE] Adding onboardings.user_comments ...")
            conn.execute(text("ALTER TABLE onboardings ADD COLUMN user_comments JSON"))

        if "user_id" not in ob_cols:
            print("[MIGRATE] Adding onboardings.user_id ...")
            conn.execute(text("ALTER TABLE onboardings ADD COLUMN user_id VARCHAR"))
            # Backfill existing onboardings with the first 'user' role user
            result = conn.execute(text("SELECT id FROM users WHERE role = 'user' LIMIT 1"))
            first_user = result.scalar()
            if first_user:
                conn.execute(
                    text("UPDATE onboardings SET user_id = :uid WHERE user_id IS NULL"),
                    {"uid": first_user},
                )
                print(f"  [BACKFILL] Set user_id = '{first_user}' on existing onboardings")
            # Add index
            conn.execute(text("CREATE INDEX IF NOT EXISTS ix_onboardings_user_id ON onboardings (user_id)"))

    print("[OK] Migration complete.")


if __name__ == "__main__":
    migrate()
