import { createFileRoute } from "@tanstack/react-router"
import { lazy, Suspense, useEffect, useState } from "react"
import { Provider } from "react-redux"
import { HashRouter, Routes, Route as RRoute, Outlet } from "react-router-dom"
import { store } from "@/lib/store"

const S5Catalog = lazy(() => import("@/pages/S5Catalog"))
const S5Home = lazy(() => import("@/pages/S5Home"))
const S5Details = lazy(() => import("@/pages/S5Details"))
const S5Timeline = lazy(() => import("@/pages/S5Timeline"))
const S5Dashboard = lazy(() => import("@/pages/S5Dashboard"))
const S5DependencyGraph = lazy(() => import("@/pages/S5DependencyGraph"))

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "S5 Ops — Event Correlation Engine" },
      { name: "description", content: "AIOps event correlation with CI dependency layer view: topological + temporal root-cause analysis across the technology stack." },
      { property: "og:title", content: "S5 Ops — Event Correlation Engine" },
      { property: "og:description", content: "AIOps event correlation with CI dependency layer view." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
})

const Loader = () => (
  <div className="flex items-center justify-center min-h-screen">
    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-brand" />
  </div>
)

function Shell() {
  return (
    <div className="min-h-screen w-full bg-background">
      <Outlet />
    </div>
  )
}

function Index() {
  const [mounted, setMounted] = useState(false)
  useEffect(() => setMounted(true), [])
  if (!mounted) return <Loader />
  return (
    <Provider store={store}>
      <HashRouter>
        <Suspense fallback={<Loader />}>
          <Routes>
            <RRoute path="/" element={<Shell />}>
              <RRoute index element={<S5Catalog />} />
              <RRoute path=":appId" element={<S5Home />} />
              <RRoute path=":appId/:journey" element={<S5Details />} />
              <RRoute path=":appId/:journey/timeline" element={<S5Timeline />} />
              <RRoute path=":appId/:journey/detail" element={<S5Dashboard />} />
              <RRoute path=":appId/:journey/dependency" element={<S5DependencyGraph />} />
            </RRoute>
          </Routes>
        </Suspense>
      </HashRouter>
    </Provider>
  )
}
