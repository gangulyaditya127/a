import { createSlice, type PayloadAction } from "@reduxjs/toolkit"
import type { ThunkAction, Action } from "@reduxjs/toolkit"
import type { RootState } from "@/lib/store"

export type StepStatus = "idle" | "running" | "completed" | "error"

type Step = {
  key: string; title: string; description: string; agent: string; status: StepStatus
  details?: string; startedAt?: number; completedAt?: number
}
type Agent = { name: string; role: string; status: "idle" | "running" | "completed"; firstSeenAt?: number; completedAt?: number }
type LogItem = { ts: number; scope: string; message: string }

type AgentFlowState = {
  running: boolean; fixed: boolean; startedAt?: number; completedAt?: number
  steps: Step[]; activeAgents: Agent[]; activity: LogItem[]
}

const initialState: AgentFlowState = {
  running: false, fixed: false,
  steps: [
    { key: "analyze", title: "Analyze the issue", description: "Collect metrics and identify anomaly patterns.", agent: "System Agent", status: "idle" },
    { key: "categorize", title: "Issue Categorization", description: "Classify the incident for faster triage.", agent: "Categorization Agent", status: "idle" },
    { key: "correlate", title: "Event Correlation", description: "Correlate alerts across services and applications.", agent: "Correlation Agent", status: "idle" },
    { key: "rca", title: "Root Cause Analysis", description: "Identify the root cause using cross-app evidence.", agent: "RCA Agent", status: "idle" },
    { key: "recommendation", title: "Recommendation", description: "Suggest resolution steps based on RCA.", agent: "Resolution Agent", status: "idle" },
    { key: "auto_resolve", title: "Self-Healing", description: "Execute automated remediation actions.", agent: "Self-Healing Agent", status: "idle" },
    { key: "verify", title: "Verify Resolution", description: "Confirm the fix restored normal operations.", agent: "Verification Agent", status: "idle" },
    { key: "record", title: "Create Problem Record", description: "Generate PRB with evidence and timeline.", agent: "Documentation Agent", status: "idle" },
  ],
  activeAgents: [],
  activity: [],
}

const slice = createSlice({
  name: "agentFlow",
  initialState,
  reducers: {
    startRun(state) { state.running = true; state.startedAt = Date.now(); state.activity.push({ ts: Date.now(), scope: "System", message: "Auto-fix workflow started." }) },
    stepStarted(state, action: PayloadAction<{ index: number }>) {
      const step = state.steps[action.payload.index]; step.status = "running"; step.startedAt = Date.now()
      if (!state.activeAgents.find(a => a.name === step.agent)) { state.activeAgents.push({ name: step.agent, role: step.agent, status: "running", firstSeenAt: Date.now() }) }
      else { const a = state.activeAgents.find(a => a.name === step.agent)!; a.status = "running" }
      state.activity.push({ ts: Date.now(), scope: step.agent, message: `Starting: ${step.title}` })
    },
    stepCompleted(state, action: PayloadAction<{ index: number; details?: string }>) {
      const step = state.steps[action.payload.index]; step.status = "completed"; step.completedAt = Date.now(); step.details = action.payload.details
      const agent = state.activeAgents.find(a => a.name === step.agent); if (agent) { agent.status = "completed"; agent.completedAt = Date.now() }
      state.activity.push({ ts: Date.now(), scope: step.agent, message: `Completed: ${step.title}` })
    },
    addLog(state, action: PayloadAction<LogItem>) { state.activity.push(action.payload) },
    markFixed(state) { state.running = false; state.fixed = true; state.completedAt = Date.now(); state.activity.push({ ts: Date.now(), scope: "System", message: "Issue resolved." }) },
    resetSteps(state) { Object.assign(state, initialState) },
  },
})

export const { startRun, stepStarted, stepCompleted, addLog, markFixed, resetSteps } = slice.actions
export default slice.reducer

export type AppThunk = ThunkAction<void, RootState, unknown, Action<string>>
const delay = (ms: number) => new Promise(res => setTimeout(res, ms))

export const runAutoFixFlow = (): AppThunk => async (dispatch, getState) => {
  const { agentFlow } = getState()
  if (agentFlow?.fixed || agentFlow?.running) return
  dispatch(startRun())
  const run = async (idx: number, logs: string[], det: string) => {
    dispatch(stepStarted({ index: idx }))
    for (const m of logs) { dispatch(addLog({ ts: Date.now(), scope: agentFlow.steps[idx].agent, message: m })); await delay(600) }
    dispatch(stepCompleted({ index: idx, details: det })); await delay(400)
  }
  await run(0, ["Collecting service metrics...", "Analyzing error rate and response time patterns..."], "Anomaly confirmed: error rate 18%, p95 latency 5.5s.")
  await run(1, ["Parsing error signatures...", "Classifying incident: performance / resource-exhaustion..."], "Categorized as performance degradation (confidence 91%).")
  await run(2, ["Grouping related alerts from Splunk, AppDynamics, Oracle...", "Identifying cross-application impact..."], "Correlated 7 alerts across 3 applications into 1 incident cluster.")
  await run(3, ["Scoring root-cause candidates...", "Analyzing dependency path and evidence strength..."], "Root cause: Database connection pool exhaustion (confidence 94%).")
  await run(4, ["Generating resolution candidates...", "Scoring by risk, effort and expected impact..."], "Recommended: Increase connection pool + rolling restart of affected services.")
  await run(5, ["Executing playbook: scale connection pool...", "Performing rolling restart on 2 nodes...", "Monitoring post-action metrics..."], "Self-healing executed. Error rate dropped from 18% to 2%.")
  await run(6, ["Validating service health post-fix...", "Confirming response times within SLA..."], "All services operational. p95 latency back to 200ms.")
  await run(7, ["Compiling problem record with evidence...", "Linking related incidents and resolution steps..."], "PRB created with root cause, resolution, and audit trail.")
  dispatch(markFixed())
}
