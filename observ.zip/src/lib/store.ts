import { configureStore } from "@reduxjs/toolkit"
import agentFlowReducer from "../features/agent-flow-slice"

export const store = configureStore({
  reducer: {
    agentFlow: agentFlowReducer,
  },
})

export type RootState = ReturnType<typeof store.getState>
export type AppDispatch = typeof store.dispatch
