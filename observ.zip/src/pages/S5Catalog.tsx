import { APPLICATIONS, type Application } from "@/data/applications"
import { Link } from "react-router-dom"
import { cn } from "@/lib/utils"
import {
  ClipboardList, HeartPulse, UserCircle, TrendingUp, Briefcase,
  ChevronRight, Activity, ShieldCheck, Sparkles,
} from "lucide-react"

const ICON_MAP: Record<string, React.ElementType> = {
  "policy-admin": ClipboardList,
  "claims-mgmt": HeartPulse,
  "underwriting": ShieldCheck,
  "customer-portal": UserCircle,
  "agent-portal": Briefcase,
}

function avgAvailability(app: Application): number {
  if (app.journeys.length === 0) return 0
  return +(app.journeys.reduce((s, j) => s + j.availability, 0) / app.journeys.length).toFixed(2)
}

export default function S5Catalog() {
  return (
    <div className="max-w-7xl mx-auto px-6 mt-16 pb-16">
      {/* Breadcrumb */}
      <nav className="flex w-fit items-center gap-1.5 rounded-md border border-brand/20 bg-brand-soft/55 px-2.5 py-1.5 text-[11.5px] text-muted-foreground mb-6">
        <span className="font-medium hover:text-foreground cursor-pointer transition-colors">Home</span>
        <ChevronRight className="h-3 w-3 text-brand/45" />
        <span className="rounded-sm bg-card px-1.5 py-0.5 font-semibold text-foreground shadow-sm ring-1 ring-border/70">S5 Proactive Monitoring</span>
      </nav>

      {/* Hero Banner */}
      <div className="relative rounded-2xl overflow-hidden mb-10 shadow-card">
        <div className="absolute inset-0 bg-gradient-to-br from-brand/90 via-brand-strong to-brand-strong" />
        <div className="absolute top-1/2 left-1/4 -translate-y-1/2 w-96 h-96 bg-white/10 rounded-full blur-3xl" />
        <div className="absolute bottom-0 right-1/4 w-64 h-64 bg-white/10 rounded-full blur-3xl" />
        <div className="relative z-10 px-8 py-10">
          <div className="flex items-center gap-2 mb-3">
            <Sparkles className="h-5 w-5 text-white/90" />
            <span className="text-[11px] font-semibold tracking-widest uppercase text-white/90">
              AI-Powered Observability Platform
            </span>
          </div>
          <h1 className="text-3xl font-bold text-white mb-2 flex items-center gap-3">
            <span className="h-2.5 w-2.5 rounded-[3px] bg-white shrink-0" />
            Proactive & Predictive Ops Monitoring
          </h1>
          <p className="text-[13px] text-white/80 max-w-2xl mb-8">
            Intelligent noise reduction, cross-application event correlation, automated root cause analysis,
            self-healing, and predictive risk detection for <span className="text-white font-semibold">Canara Life Insurance</span>.
          </p>

          <div className="grid grid-cols-4 gap-4">
            {[
              { label: "Noise Reduced", value: "95.7%" },
              { label: "Prediction Accuracy", value: "91%" },
              { label: "MTTR", value: "4.2 min" },
              { label: "Monthly Savings", value: "₹1.54 Cr" },
            ].map(stat => (
              <div
                key={stat.label}
                className="rounded-xl border bg-white/15 border-white/20 backdrop-blur-sm p-4 text-center"
              >
                <p className="text-2xl font-bold text-white">{stat.value}</p>
                <p className="text-[10.5px] text-white/80 mt-0.5 uppercase tracking-wider font-medium">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Section Title */}
      <div className="flex items-center gap-2 mb-5">
        <span className="h-2.5 w-2.5 rounded-[3px] bg-brand" />
        <h2 className="text-lg font-semibold text-foreground">Applications</h2>
        <span className="text-[11px] px-2 py-0.5 rounded-full bg-brand-soft text-brand font-medium">
          {APPLICATIONS.length}
        </span>
      </div>

      {/* Application Grid */}
      <div className="grid grid-cols-3 gap-4">
        {APPLICATIONS.map((app) => {
          const Icon = ICON_MAP[app.id] ?? Activity
          const avail = avgAvailability(app)
          const hasIssue = avail < 92

          return (
            <Link
              to={`/${app.id}`}
              key={app.id}
              className={cn(
                "group relative rounded-xl border border-border bg-card p-5",
                "shadow-card transition-all duration-300 hover:border-brand/50",
                "hover:shadow-md hover:-translate-y-0.5"
              )}
            >
              {/* Animated left bar */}
              <div className="absolute left-0 top-4 bottom-4 w-1 rounded-full bg-border transition-all duration-300 group-hover:bg-brand group-hover:shadow-lg group-hover:shadow-brand/40" />

              <div className="flex items-start gap-4 pl-3">
                <div className="h-11 w-11 rounded-lg bg-brand-soft grid place-items-center shrink-0">
                  <Icon className="h-5 w-5 text-brand" />
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="text-[13px] font-semibold text-foreground group-hover:text-brand transition-colors">
                    {app.name}
                  </h3>
                  <p className="text-[11px] text-muted-foreground mt-1 line-clamp-2 leading-relaxed">
                    {app.description}
                  </p>

                  <div className="flex items-center gap-3 mt-3">
                    <span className="text-[10.5px] px-2 py-0.5 rounded bg-secondary text-secondary-foreground font-medium">
                      {app.journeys.length} journeys
                    </span>
                    <span className="flex items-center gap-1.5 text-[11px]">
                      <span className={cn(
                        "h-2 w-2 rounded-full",
                        avail >= 95 ? "bg-emerald-500" : avail >= 85 ? "bg-amber-500" : "bg-red-500"
                      )} />
                      <span className={cn(
                        "font-medium",
                        avail >= 95 ? "text-emerald-600 dark:text-emerald-500" : avail >= 85 ? "text-amber-600 dark:text-amber-500" : "text-red-600 dark:text-red-500"
                      )}>
                        {avail}%
                      </span>
                      <span className="text-muted-foreground">availability</span>
                    </span>
                  </div>
                </div>

                <ChevronRight className="h-4 w-4 text-muted-foreground group-hover:text-brand transition-colors shrink-0 mt-1" />
              </div>

              {hasIssue && (
                <div className="absolute top-2 right-2">
                  <span className="relative flex h-2.5 w-2.5">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75" />
                    <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-red-500" />
                  </span>
                </div>
              )}
            </Link>
          )
        })}
      </div>
    </div>
  )
}
