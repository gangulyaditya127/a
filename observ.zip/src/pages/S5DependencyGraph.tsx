import { useParams, Link } from "react-router-dom"
import { useMemo, useRef, useState, useEffect } from "react"
import { getApp } from "@/data/applications"
import { getActionLayers, type TechLayer, type Connector } from "@/data/layers"
import { cn } from "@/lib/utils"
import {
  ArrowLeft, ChevronRight, Target, Clock, Play, Pause, RotateCcw,
  Activity, AlertTriangle, Zap, Network, GitBranch,
} from "lucide-react"

/* ═══════════════════════════════════════════════════════════════
   CI Dependency Layer View — Event Correlation Engine
   ------------------------------------------------------------
   Topological correlation: dependency edges across tiers
     (Presentation → Application → Integration → Data → Infrastructure)
   Temporal correlation: replay of alert timestamps to show the
     cascade order, with the earliest event flagged as ROOT CAUSE.
   ═══════════════════════════════════════════════════════════════ */

type CINode = {
  id: string           // tierId::layerId
  tierId: string
  tierName: string
  tierIndex: number
  layer: TechLayer
  alertCount: number
  status: "healthy" | "degraded" | "critical"
  firstAlertTs?: string  // "HH:MM:SS"
  firstAlertMs?: number
  sources: Connector[]
}

type CIEdge = {
  from: string
  to: string
  weight: number  // 0..1 correlation strength
  critical: boolean
}

const TIER_ORDER = ["pres", "app", "integ", "data", "infra"]

const STATUS_COLOR: Record<CINode["status"], { fill: string; stroke: string; text: string; badge: string }> = {
  healthy: {
    fill: "hsl(var(--card))",
    stroke: "hsl(160 60% 45%)",
    text: "hsl(160 60% 35%)",
    badge: "bg-emerald-500/10 text-emerald-600 border-emerald-500/20",
  },
  degraded: {
    fill: "hsl(40 100% 96%)",
    stroke: "hsl(35 90% 55%)",
    text: "hsl(30 80% 40%)",
    badge: "bg-amber-500/10 text-amber-600 border-amber-500/20",
  },
  critical: {
    fill: "hsl(354 100% 97%)",
    stroke: "hsl(354 90% 55%)",
    text: "hsl(354 85% 42%)",
    badge: "bg-red-500/10 text-red-600 border-red-500/20",
  },
}

function tsToMs(ts?: string): number | undefined {
  if (!ts) return undefined
  const parts = ts.split(":").map(Number)
  if (parts.some(isNaN)) return undefined
  const [h = 0, m = 0, s = 0] = parts
  return h * 3600_000 + m * 60_000 + s * 1000
}

/* ─────────────────────────────────────────────────────────────
   Main Page
   ───────────────────────────────────────────────────────────── */
export default function S5DependencyGraph() {
  const { appId, journey } = useParams()
  const app = getApp(appId ?? "")
  const journeyName = decodeURIComponent(journey ?? "")
  const data = getActionLayers(appId ?? "", journeyName)

  const [selected, setSelected] = useState<string | null>(null)
  const [playing, setPlaying] = useState(false)
  const [playCursor, setPlayCursor] = useState<number>(0) // index into timeline events

  /* Build node list */
  const nodes: CINode[] = useMemo(() => {
    const out: CINode[] = []
    data.tiers.forEach((tier) => {
      const tierIndex = TIER_ORDER.indexOf(tier.id) === -1 ? out.length : TIER_ORDER.indexOf(tier.id)
      tier.layers.forEach((layer) => {
        const alerts = layer.connectors.flatMap((c) => c.alerts)
        const firstAlert = alerts
          .filter((a) => a.timestamp)
          .sort((a, b) => (tsToMs(a.timestamp)! - tsToMs(b.timestamp)!))[0]
        out.push({
          id: `${tier.id}::${layer.id}`,
          tierId: tier.id,
          tierName: tier.name,
          tierIndex,
          layer,
          alertCount: alerts.length,
          status: layer.status,
          firstAlertTs: firstAlert?.timestamp,
          firstAlertMs: tsToMs(firstAlert?.timestamp),
          sources: layer.connectors,
        })
      })
    })
    return out
  }, [data])

  /* Build edges — topological: within a tier and across adjacent tiers,
     stronger weight when both nodes are non-healthy (correlated).       */
  const edges: CIEdge[] = useMemo(() => {
    const out: CIEdge[] = []
    // Group nodes by tier
    const byTier = new Map<string, CINode[]>()
    nodes.forEach((n) => {
      if (!byTier.has(n.tierId)) byTier.set(n.tierId, [])
      byTier.get(n.tierId)!.push(n)
    })
    // Cross-tier: every layer in tier N depends on every layer in tier N+1
    for (let i = 0; i < data.tiers.length - 1; i++) {
      const a = byTier.get(data.tiers[i].id) ?? []
      const b = byTier.get(data.tiers[i + 1].id) ?? []
      a.forEach((na) => {
        b.forEach((nb) => {
          const bothBad = na.status !== "healthy" && nb.status !== "healthy"
          out.push({
            from: na.id,
            to: nb.id,
            weight: bothBad ? 0.9 : 0.25,
            critical: na.status === "critical" && nb.status === "critical",
          })
        })
      })
    }
    return out
  }, [nodes, data])

  /* Timeline of critical/high events */
  const timeline = useMemo(() => {
    type TL = {
      ms: number
      ts: string
      nodeId: string
      layerName: string
      tierName: string
      severity: string
      message: string
      source: string
      alertId: string
    }
    const events: TL[] = []
    data.tiers.forEach((tier) => {
      tier.layers.forEach((layer) => {
        layer.connectors.forEach((conn) => {
          conn.alerts.forEach((a) => {
            const ms = tsToMs(a.timestamp)
            if (ms == null) return
            events.push({
              ms,
              ts: a.timestamp,
              nodeId: `${tier.id}::${layer.id}`,
              layerName: layer.name,
              tierName: tier.name,
              severity: a.severity,
              message: a.message,
              source: conn.name,
              alertId: a.id,
            })
          })
        })
      })
    })
    return events.sort((a, b) => a.ms - b.ms)
  }, [data])

  const rootCauseNodeId = timeline.find((e) => e.severity === "critical")?.nodeId
    ?? timeline[0]?.nodeId
  const rootCauseEvent = timeline.find((e) => e.nodeId === rootCauseNodeId)

  /* Auto-advance during playback */
  useEffect(() => {
    if (!playing) return
    if (playCursor >= timeline.length - 1) {
      setPlaying(false)
      return
    }
    const t = setTimeout(() => setPlayCursor((c) => c + 1), 900)
    return () => clearTimeout(t)
  }, [playing, playCursor, timeline.length])

  /* Layout: 5 columns, nodes stacked vertically */
  const COL_W = 250
  const NODE_W = 210
  const NODE_H = 82
  const V_GAP = 22
  const PAD_X = 24
  const PAD_Y = 32
  const nodesByTier = useMemo(() => {
    const map = new Map<string, CINode[]>()
    data.tiers.forEach((t, i) => {
      map.set(t.id, nodes.filter((n) => n.tierId === t.id).map((n) => ({ ...n, tierIndex: i })))
    })
    return map
  }, [nodes, data])

  const maxRows = Math.max(...Array.from(nodesByTier.values()).map((ns) => ns.length), 1)
  const svgW = data.tiers.length * COL_W + PAD_X * 2
  const svgH = maxRows * (NODE_H + V_GAP) + PAD_Y * 2 + 60

  const nodePos = new Map<string, { x: number; y: number }>()
  data.tiers.forEach((tier, ci) => {
    const list = nodesByTier.get(tier.id) ?? []
    const colX = PAD_X + ci * COL_W + (COL_W - NODE_W) / 2
    const colTotalH = list.length * NODE_H + (list.length - 1) * V_GAP
    const startY = PAD_Y + 40 + (maxRows * (NODE_H + V_GAP) - colTotalH) / 2
    list.forEach((n, ri) => {
      nodePos.set(n.id, { x: colX, y: startY + ri * (NODE_H + V_GAP) })
    })
  })

  /* Which nodes are "active" in the temporal playback (their earliest
     alert has fired at/before the cursor) */
  const activeNodes = useMemo(() => {
    if (!playing && playCursor === 0) {
      // Static view: everything with alerts is active
      return new Set(nodes.filter((n) => n.alertCount > 0).map((n) => n.id))
    }
    const cutMs = timeline[Math.min(playCursor, timeline.length - 1)]?.ms ?? Infinity
    const s = new Set<string>()
    nodes.forEach((n) => { if (n.firstAlertMs != null && n.firstAlertMs <= cutMs) s.add(n.id) })
    return s
  }, [playing, playCursor, timeline, nodes])

  const selectedNode = nodes.find((n) => n.id === selected) ?? null
  const svgWrapRef = useRef<HTMLDivElement>(null)

  return (
    <div className="w-full px-6 my-6 mb-16">
      {/* Back */}
      <Link
        to={`/${appId}/${journey}/timeline`}
        className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-brand mb-4 transition-colors"
      >
        <ArrowLeft className="h-4 w-4" /> Back to Technical Layers
      </Link>

      {/* Breadcrumb */}
      <nav className="flex items-center gap-1.5 mb-4 rounded-md border border-brand/20 bg-brand-soft/55 px-2.5 py-1.5 text-[11.5px] w-fit text-muted-foreground">
        <Link to="/" className="hover:text-brand transition-colors">Home</Link>
        <ChevronRight className="h-3 w-3 text-brand/45" />
        <Link to={`/${appId}`} className="hover:text-brand transition-colors">{app?.name}</Link>
        <ChevronRight className="h-3 w-3 text-brand/45" />
        <Link to={`/${appId}/${journey}`} className="hover:text-brand transition-colors">{journeyName}</Link>
        <ChevronRight className="h-3 w-3 text-brand/45" />
        <Link to={`/${appId}/${journey}/timeline`} className="hover:text-brand transition-colors">Technical Layers</Link>
        <ChevronRight className="h-3 w-3 text-brand/45" />
        <span className="rounded-sm bg-card px-1.5 py-0.5 font-semibold text-foreground shadow-sm ring-1 ring-border/70">CI Dependency Graph</span>
      </nav>

      {/* Header */}
      <div className="flex items-start justify-between gap-4 mb-4">
        <div>
          <h4 className="text-sm font-medium uppercase text-muted-foreground flex items-center gap-2">
            <Network className="h-4 w-4 text-brand" /> Event Correlation Engine — CI Dependency Layer
          </h4>
          <div className="flex items-center gap-3 mt-1">
            <div className="h-2.5 w-2.5 rounded-[3px] bg-brand" />
            <h3 className="text-2xl font-semibold text-foreground">{journeyName}</h3>
          </div>
          <p className="text-sm text-muted-foreground mt-1 max-w-3xl">
            Topological + temporal view of Configuration Items impacted by the correlated event.
            Edges show upstream/downstream dependencies; the pulsing node marks the earliest fault
            (root cause). Use the timeline scrubber to replay the fault cascade.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => { setPlayCursor(0); setPlaying(true) }}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium border border-brand/30 bg-brand-soft text-brand hover:bg-brand hover:text-white transition-colors"
          >
            <Play className="h-3.5 w-3.5" /> Replay cascade
          </button>
          <button
            onClick={() => setPlaying((p) => !p)}
            disabled={timeline.length === 0}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium border border-border bg-card hover:bg-accent transition-colors"
          >
            {playing ? <Pause className="h-3.5 w-3.5" /> : <Play className="h-3.5 w-3.5" />}
            {playing ? "Pause" : "Play"}
          </button>
          <button
            onClick={() => { setPlaying(false); setPlayCursor(0) }}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium border border-border bg-card hover:bg-accent transition-colors"
          >
            <RotateCcw className="h-3.5 w-3.5" /> Reset
          </button>
        </div>
      </div>

      {/* Root Cause banner */}
      {rootCauseEvent && (
        <div className="mb-4 rounded-xl border border-red-500/30 bg-red-500/[0.04] p-4 flex items-start gap-3">
          <div className="h-8 w-8 rounded-full grid place-items-center bg-red-500/15 shrink-0">
            <Target className="h-4 w-4 text-red-600" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-xs font-bold uppercase tracking-wider text-red-600">Root Cause (earliest event)</span>
              <span className="text-[10px] font-mono text-muted-foreground">{rootCauseEvent.alertId}</span>
              <span className="text-xs text-muted-foreground flex items-center gap-1">
                <Clock className="h-3 w-3" /> {rootCauseEvent.ts}
              </span>
              <span className="text-xs px-2 py-0.5 rounded-md border border-brand/20 bg-brand-soft text-brand font-medium">
                {rootCauseEvent.tierName} → {rootCauseEvent.layerName}
              </span>
              <span className="text-xs text-muted-foreground">Source: <span className="text-foreground font-medium">{rootCauseEvent.source}</span></span>
            </div>
            <p className="text-sm text-foreground mt-1.5">{rootCauseEvent.message}</p>
            <p className="text-xs text-muted-foreground mt-1 italic">{data.summary.rootCauseHint}</p>
          </div>
        </div>
      )}

      {/* Summary chips */}
      <div className="mb-4 flex flex-wrap gap-2">
        <StatChip icon={<AlertTriangle className="h-3.5 w-3.5" />} label="Total alerts" value={data.summary.totalAlerts} />
        <StatChip icon={<Activity className="h-3.5 w-3.5" />} label="CIs impacted" value={data.summary.affectedLayers} />
        <StatChip icon={<GitBranch className="h-3.5 w-3.5" />} label="Sources correlated" value={data.summary.connectors} />
        <StatChip icon={<Clock className="h-3.5 w-3.5" />} label="Cascade span" value={timeline.length > 0 ? formatSpan(timeline[timeline.length - 1].ms - timeline[0].ms) : "—"} />
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-[1fr_360px] gap-4">
        {/* GRAPH */}
        <div className="rounded-xl border border-border bg-card shadow-card overflow-hidden">
          <div className="flex items-center justify-between px-4 py-3 border-b border-border">
            <div className="flex items-center gap-2">
              <Network className="h-4 w-4 text-brand" />
              <span className="text-sm font-semibold text-foreground">Topology — CI dependency graph</span>
            </div>
            <div className="flex items-center gap-3 text-[11px] text-muted-foreground">
              <LegendDot color="hsl(354 90% 55%)" label="Critical" />
              <LegendDot color="hsl(35 90% 55%)" label="Degraded" />
              <LegendDot color="hsl(160 60% 45%)" label="Healthy" />
              <span className="ml-2">Edges: <span className="text-red-600 font-medium">red</span> = correlated fault path</span>
            </div>
          </div>
          <div ref={svgWrapRef} className="overflow-auto scrollbar-thin" style={{ maxHeight: 640 }}>
            <svg width={svgW} height={svgH} className="block">
              {/* Tier column headers */}
              {data.tiers.map((t, i) => (
                <g key={t.id}>
                  <rect
                    x={PAD_X + i * COL_W + 6}
                    y={8}
                    width={COL_W - 12}
                    height={26}
                    rx={6}
                    fill="hsl(var(--secondary))"
                  />
                  <text
                    x={PAD_X + i * COL_W + COL_W / 2}
                    y={25}
                    textAnchor="middle"
                    className="fill-foreground"
                    style={{ fontSize: 11, fontWeight: 600, letterSpacing: 0.5 }}
                  >
                    {t.name.toUpperCase()}
                  </text>
                </g>
              ))}

              {/* Edges */}
              {edges.map((e, i) => {
                const a = nodePos.get(e.from); const b = nodePos.get(e.to)
                if (!a || !b) return null
                const activeA = activeNodes.has(e.from)
                const activeB = activeNodes.has(e.to)
                const bothActive = activeA && activeB
                const stroke = e.critical && bothActive ? "hsl(354 90% 55%)"
                  : bothActive ? "hsl(35 90% 55%)"
                  : "hsl(var(--border))"
                const width = e.critical && bothActive ? 2.2 : bothActive ? 1.4 : 1
                const opacity = bothActive ? 0.9 : 0.4
                const x1 = a.x + NODE_W, y1 = a.y + NODE_H / 2
                const x2 = b.x, y2 = b.y + NODE_H / 2
                const cx = (x1 + x2) / 2
                const path = `M ${x1} ${y1} C ${cx} ${y1}, ${cx} ${y2}, ${x2} ${y2}`
                return (
                  <g key={i}>
                    <path d={path} fill="none" stroke={stroke} strokeWidth={width} opacity={opacity} />
                    {e.critical && bothActive && (
                      <circle r={2.5} fill="hsl(354 90% 55%)">
                        <animateMotion dur="2.4s" repeatCount="indefinite" path={path} />
                      </circle>
                    )}
                  </g>
                )
              })}

              {/* Nodes */}
              {nodes.map((n) => {
                const p = nodePos.get(n.id)!
                const c = STATUS_COLOR[n.status]
                const active = activeNodes.has(n.id)
                const isRoot = n.id === rootCauseNodeId
                const isSel = n.id === selected
                return (
                  <g
                    key={n.id}
                    transform={`translate(${p.x}, ${p.y})`}
                    style={{ cursor: "pointer" }}
                    onClick={() => setSelected(n.id === selected ? null : n.id)}
                  >
                    {isRoot && (
                      <rect
                        x={-6} y={-6} width={NODE_W + 12} height={NODE_H + 12}
                        rx={12} fill="none" stroke="hsl(354 90% 55%)" strokeWidth={2}
                        strokeDasharray="4 4"
                      >
                        <animate attributeName="stroke-dashoffset" from="0" to="16" dur="1.2s" repeatCount="indefinite" />
                      </rect>
                    )}
                    <rect
                      width={NODE_W}
                      height={NODE_H}
                      rx={10}
                      fill={active ? c.fill : "hsl(var(--card))"}
                      stroke={isSel ? "hsl(var(--brand))" : c.stroke}
                      strokeWidth={isSel ? 2.5 : 1.5}
                      opacity={active ? 1 : 0.55}
                    />
                    <text x={12} y={22} style={{ fontSize: 12, fontWeight: 600 }} className="fill-foreground">
                      {truncate(n.layer.name, 26)}
                    </text>
                    <text x={12} y={38} style={{ fontSize: 10.5 }} className="fill-muted-foreground">
                      {truncate(n.layer.technology, 34)}
                    </text>
                    <rect x={12} y={NODE_H - 26} width={54} height={18} rx={4} fill={c.stroke} opacity={0.14} />
                    <text x={39} y={NODE_H - 13} textAnchor="middle" style={{ fontSize: 10, fontWeight: 700 }} fill={c.stroke}>
                      {n.status.toUpperCase()}
                    </text>
                    {n.alertCount > 0 && (
                      <>
                        <rect x={72} y={NODE_H - 26} width={64} height={18} rx={4} fill="hsl(354 90% 55%)" opacity={0.14} />
                        <text x={104} y={NODE_H - 13} textAnchor="middle" style={{ fontSize: 10, fontWeight: 700 }} fill="hsl(354 90% 42%)">
                          {n.alertCount} alert{n.alertCount === 1 ? "" : "s"}
                        </text>
                      </>
                    )}
                    {n.firstAlertTs && (
                      <text x={NODE_W - 12} y={NODE_H - 13} textAnchor="end" style={{ fontSize: 10, fontFamily: "monospace" }} className="fill-muted-foreground">
                        {n.firstAlertTs}
                      </text>
                    )}
                  </g>
                )
              })}
            </svg>
          </div>

          {/* Temporal correlation strip */}
          <div className="border-t border-border p-4">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <Clock className="h-4 w-4 text-brand" />
                <span className="text-sm font-semibold text-foreground">Temporal correlation — event cascade</span>
              </div>
              <span className="text-[11px] text-muted-foreground">
                {timeline.length} events · replay position {playCursor + 1}/{timeline.length || 1}
              </span>
            </div>
            {timeline.length > 0 ? (
              <>
                <div className="relative h-14 rounded-md bg-secondary/50 border border-border">
                  {/* baseline */}
                  <div className="absolute left-4 right-4 top-1/2 h-px bg-border" />
                  {timeline.map((e, i) => {
                    const span = (timeline[timeline.length - 1].ms - timeline[0].ms) || 1
                    const pct = ((e.ms - timeline[0].ms) / span) * 100
                    const color = e.severity === "critical" ? "bg-red-500"
                      : e.severity === "high" ? "bg-orange-500"
                      : e.severity === "medium" ? "bg-amber-500" : "bg-emerald-500"
                    const passed = i <= playCursor
                    return (
                      <button
                        key={i}
                        onClick={() => { setPlaying(false); setPlayCursor(i); setSelected(e.nodeId) }}
                        title={`${e.ts} — ${e.layerName}: ${e.message}`}
                        className={cn(
                          "absolute -translate-x-1/2 -translate-y-1/2 top-1/2 h-3 w-3 rounded-full border-2 border-card transition-all",
                          color,
                          passed ? "opacity-100 scale-100" : "opacity-40 scale-75",
                          i === playCursor && "ring-2 ring-brand ring-offset-1 ring-offset-card scale-125",
                        )}
                        style={{ left: `calc(1rem + ${pct}% * (100% - 2rem) / 100%)` }}
                      />
                    )
                  })}
                  {/* Cursor label */}
                  {timeline[playCursor] && (
                    <div
                      className="absolute -translate-x-1/2 top-full mt-1 text-[10px] font-mono text-muted-foreground whitespace-nowrap"
                      style={{
                        left: `calc(1rem + ${((timeline[playCursor].ms - timeline[0].ms) / ((timeline[timeline.length - 1].ms - timeline[0].ms) || 1)) * 100}% * (100% - 2rem) / 100%)`,
                      }}
                    >
                      {timeline[playCursor].ts}
                    </div>
                  )}
                </div>
                <div className="mt-4 rounded-md border border-border bg-secondary/30 p-2.5 text-xs">
                  <span className="text-[10px] font-mono text-muted-foreground mr-2">{timeline[playCursor]?.ts}</span>
                  <span className="font-medium text-foreground">{timeline[playCursor]?.layerName}</span>
                  <span className="text-muted-foreground"> · {timeline[playCursor]?.source}</span>
                  <p className="text-muted-foreground mt-1">{timeline[playCursor]?.message}</p>
                </div>
              </>
            ) : (
              <p className="text-xs text-muted-foreground">No timestamped alerts for this journey.</p>
            )}
          </div>
        </div>

        {/* SIDE PANEL */}
        <div className="rounded-xl border border-border bg-card shadow-card overflow-hidden">
          <div className="px-4 py-3 border-b border-border flex items-center gap-2">
            <Zap className="h-4 w-4 text-brand" />
            <span className="text-sm font-semibold text-foreground">
              {selectedNode ? "Selected CI" : "Fault propagation path"}
            </span>
          </div>
          {selectedNode ? (
            <div className="p-4 space-y-3">
              <div>
                <p className="text-[10px] uppercase tracking-wider text-muted-foreground">{selectedNode.tierName}</p>
                <p className="text-base font-semibold text-foreground">{selectedNode.layer.name}</p>
                <p className="text-xs text-muted-foreground">{selectedNode.layer.technology}</p>
              </div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className={cn("text-[10px] font-bold px-2 py-0.5 rounded uppercase border", STATUS_COLOR[selectedNode.status].badge)}>
                  {selectedNode.status}
                </span>
                {selectedNode.alertCount > 0 && (
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded border bg-red-500/10 text-red-600 border-red-500/20">
                    {selectedNode.alertCount} alerts
                  </span>
                )}
                {selectedNode.firstAlertTs && (
                  <span className="text-[10px] font-mono text-muted-foreground flex items-center gap-1">
                    <Clock className="h-3 w-3" /> first at {selectedNode.firstAlertTs}
                  </span>
                )}
              </div>

              <div>
                <p className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1.5">Monitoring sources</p>
                <div className="flex flex-wrap gap-1.5">
                  {selectedNode.sources.map((c) => (
                    <span
                      key={c.id}
                      className={cn(
                        "inline-flex items-center gap-1 text-[10.5px] px-2 py-1 rounded border font-medium",
                        c.status === "healthy"
                          ? "bg-secondary text-secondary-foreground border-border"
                          : STATUS_COLOR[c.status === "alerting" ? "degraded" : c.status].badge,
                      )}
                    >
                      <span className={cn("h-1.5 w-1.5 rounded-full",
                        c.status === "healthy" ? "bg-emerald-500"
                          : c.status === "alerting" ? "bg-amber-500" : "bg-red-500")} />
                      {c.name}{c.alerts.length > 0 && ` [${c.alerts.length}]`}
                    </span>
                  ))}
                </div>
              </div>

              <div>
                <p className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1.5">Events on this CI</p>
                <div className="space-y-1.5 max-h-72 overflow-y-auto pr-1">
                  {selectedNode.sources.flatMap((c) =>
                    c.alerts.map((a) => (
                      <div key={a.id} className="rounded-md border border-border bg-secondary/30 p-2">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className={cn("text-[9px] font-bold px-1.5 py-0.5 rounded uppercase",
                            a.severity === "critical" ? "bg-red-500/15 text-red-600"
                              : a.severity === "high" ? "bg-orange-500/15 text-orange-600"
                              : a.severity === "medium" ? "bg-amber-500/15 text-amber-600"
                              : "bg-emerald-500/15 text-emerald-600"
                          )}>{a.severity}</span>
                          <span className="text-[10px] font-mono text-muted-foreground">{a.id}</span>
                          <span className="text-[10px] text-muted-foreground">· {c.name}</span>
                          <span className="text-[10px] font-mono text-muted-foreground ml-auto">{a.timestamp}</span>
                        </div>
                        {a.eventname && <p className="text-xs font-semibold text-foreground mt-1">{a.eventname}</p>}
                        <p className="text-xs text-muted-foreground mt-0.5 leading-snug">{a.message}</p>
                      </div>
                    )),
                  )}
                  {selectedNode.alertCount === 0 && (
                    <p className="text-xs text-muted-foreground italic">No open events on this CI.</p>
                  )}
                </div>
              </div>

              <button
                onClick={() => setSelected(null)}
                className="w-full text-xs font-medium px-3 py-1.5 rounded-md border border-border bg-card hover:bg-accent transition-colors"
              >
                Clear selection
              </button>
            </div>
          ) : (
            <div className="p-4 space-y-3">
              <p className="text-xs text-muted-foreground">
                The correlation engine linked <span className="text-foreground font-semibold">{data.summary.totalAlerts} alerts</span>
                {" "}from <span className="text-foreground font-semibold">{data.summary.connectors} sources</span> across
                {" "}<span className="text-foreground font-semibold">{data.summary.affectedLayers} CIs</span> into a single incident.
              </p>
              <div>
                <p className="text-[10px] uppercase tracking-wider text-muted-foreground mb-2">Inferred cascade</p>
                <ol className="space-y-2">
                  {inferCascade(nodes, timeline).map((step, i, arr) => (
                    <li key={step.id} className="flex items-start gap-2.5">
                      <span className={cn(
                        "h-5 w-5 shrink-0 rounded-full grid place-items-center text-[10px] font-bold text-white",
                        i === 0 ? "bg-red-500" : i === arr.length - 1 ? "bg-brand" : "bg-amber-500",
                      )}>{i + 1}</span>
                      <div className="min-w-0">
                        <p className="text-xs font-semibold text-foreground truncate">{step.layer.name}</p>
                        <p className="text-[10px] text-muted-foreground">
                          {step.tierName} · {step.firstAlertTs ?? "—"}
                        </p>
                      </div>
                    </li>
                  ))}
                </ol>
              </div>
              <p className="text-[11px] text-muted-foreground italic">Click any node to inspect its events and sources.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

/* ─────────────────────────────────────────────────────────────
   Helpers
   ───────────────────────────────────────────────────────────── */

function StatChip({ icon, label, value }: { icon: React.ReactNode; label: string; value: React.ReactNode }) {
  return (
    <div className="inline-flex items-center gap-2 rounded-md border border-border bg-card px-2.5 py-1.5">
      <span className="text-brand">{icon}</span>
      <span className="text-[11px] text-muted-foreground">{label}</span>
      <span className="text-xs font-semibold text-foreground">{value}</span>
    </div>
  )
}

function LegendDot({ color, label }: { color: string; label: string }) {
  return (
    <span className="inline-flex items-center gap-1.5">
      <span className="h-2 w-2 rounded-full" style={{ background: color }} />
      {label}
    </span>
  )
}

function truncate(s: string, n: number) {
  return s.length > n ? s.slice(0, n - 1) + "…" : s
}

function formatSpan(ms: number) {
  if (ms < 0 || !isFinite(ms)) return "—"
  const s = Math.round(ms / 1000)
  if (s < 60) return `${s}s`
  const m = Math.floor(s / 60), r = s % 60
  return `${m}m ${r}s`
}

function inferCascade(nodes: CINode[], timeline: { nodeId: string; ms: number }[]) {
  const firstSeen = new Map<string, number>()
  timeline.forEach((e) => { if (!firstSeen.has(e.nodeId)) firstSeen.set(e.nodeId, e.ms) })
  return nodes
    .filter((n) => firstSeen.has(n.id))
    .sort((a, b) => firstSeen.get(a.id)! - firstSeen.get(b.id)!)
    .slice(0, 6)
}
