import { getApp } from '@/data/applications'
import { useParams, Link } from 'react-router-dom'
import { cn } from '@/lib/utils'
import { ArrowLeft, ChevronRight } from 'lucide-react'

/* ------------------------------------------------------------------ */
/*  Helpers                                                            */
/* ------------------------------------------------------------------ */
function formatDate(): string {
  return new Date().toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  })
}

/* ------------------------------------------------------------------ */
/*  Component                                                          */
/* ------------------------------------------------------------------ */
export default function S5Home() {
  const { appId } = useParams<{ appId: string }>()
  const app = getApp(appId ?? '')

  /* ── Not-found guard ─────────────────────────────────────── */
  if (!app) {
    return (
      <div className="max-w-7xl mx-auto px-6 my-6 mb-12">
        <Link
          to="/"
          className="inline-flex items-center gap-1.5 text-[13px] text-muted-foreground hover:text-brand transition-colors"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to catalog
        </Link>
        <p className="mt-10 text-center text-muted-foreground text-[13px]">
          Application not found.
        </p>
      </div>
    )
  }

  /* ── Column config ───────────────────────────────────────── */
  const columns = [
    { key: 'name', label: 'Journey Name', align: 'left' as const },
    { key: 'activeUsers', label: 'Active Users', align: 'right' as const },
    { key: 'happy', label: 'Happy %', align: 'right' as const },
    { key: 'unhappy', label: 'Unhappy %', align: 'right' as const },
    { key: 'frustrated', label: 'Frustrated %', align: 'right' as const },
    { key: 'availability', label: 'Availability %', align: 'right' as const },
  ] as const

  return (
    <div className="max-w-7xl mx-auto px-6 my-6 mb-12">
      {/* ── Back button ──────────────────────────────────────── */}
      <Link
        to="/"
        className="inline-flex items-center gap-1.5 text-[11.5px] font-medium text-muted-foreground hover:text-brand transition-colors mb-4"
      >
        <ArrowLeft className="h-3.5 w-3.5" />
        Back to catalog
      </Link>

      {/* ── Breadcrumb ───────────────────────────────────────── */}
      <nav className="flex w-fit items-center gap-1.5 rounded-md border border-brand/20 bg-brand-soft/55 px-2.5 py-1.5 text-[11.5px] text-muted-foreground mb-5">
        <Link to="/" className="font-medium hover:text-foreground transition-colors">
          Home
        </Link>
        <ChevronRight className="h-3 w-3 text-brand/45" />
        <Link to="/" className="font-medium hover:text-foreground transition-colors">
          Canara Life
        </Link>
        <ChevronRight className="h-3 w-3 text-brand/45" />
        <span className="rounded-sm bg-card px-1.5 py-0.5 font-semibold text-foreground shadow-sm ring-1 ring-border/70">{app.name}</span>
      </nav>

      {/* ── Title ────────────────────────────────────────────── */}
      <div className="mb-6">
        <div className="flex items-center gap-2">
          <span className="h-2.5 w-2.5 rounded-[3px] bg-brand" />
          <h1 className="text-2xl font-semibold tracking-tight text-foreground">
            {app.name}
          </h1>
        </div>
        <p className="mt-1 flex items-center gap-2 text-[13px] text-muted-foreground pl-4">
          <span>Canara Life — Observability Dashboard</span>
          <span className="text-muted-foreground/40">·</span>
          <span>{formatDate()}</span>
        </p>
      </div>

      {/* ── Journey table card ───────────────────────────────── */}
      <div className="rounded-xl border border-border/60 bg-card overflow-hidden shadow-card">
        <table className="w-full text-[13px]">
          {/* Header */}
          <thead>
            <tr className="border-b border-border/60 bg-secondary/55">
              {columns.map((col) => (
                <th
                  key={col.key}
                  className={cn(
                    'px-5 py-3 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground',
                    col.align === 'right' ? 'text-right' : 'text-left',
                  )}
                >
                  {col.label}
                </th>
              ))}
            </tr>
          </thead>

          {/* Body */}
          <tbody>
            {app.journeys.map((j, idx) => {
              const isLowAvail = j.availability < 80
              const isLast = idx === app.journeys.length - 1

              return (
                <tr
                  key={j.name}
                  className={cn(
                    'group transition-colors duration-150',
                    !isLast && 'border-b border-border/40',
                    isLowAvail
                      ? 'bg-destructive/[0.06] hover:bg-destructive/[0.10]'
                      : 'hover:bg-secondary/55',
                  )}
                >
                  {/* Journey Name */}
                  <td className="px-5 py-3.5">
                    <Link
                      to={`/${app.id}/${encodeURIComponent(j.name)}`}
                      className={cn(
                        'font-medium text-foreground hover:text-brand transition-colors',
                        'inline-flex items-center gap-1.5',
                      )}
                    >
                      {j.name}
                      <ChevronRight className="h-3.5 w-3.5 opacity-0 -translate-x-1 group-hover:opacity-100 group-hover:translate-x-0 transition-all duration-150 text-brand" />
                    </Link>
                  </td>

                  {/* Active Users */}
                  <td className="px-5 py-3.5 text-right tabular-nums text-muted-foreground">
                    {j.activeUsers.toLocaleString()}
                  </td>

                  {/* Happy % */}
                  <td className="px-5 py-3.5 text-right tabular-nums">
                    <span className="text-emerald-600 dark:text-emerald-500 font-medium">
                      {j.happy}%
                    </span>
                  </td>

                  {/* Unhappy % */}
                  <td className="px-5 py-3.5 text-right tabular-nums">
                    <span className="text-amber-600 dark:text-amber-500 font-medium">
                      {j.unhappy}%
                    </span>
                  </td>

                  {/* Frustrated % */}
                  <td className="px-5 py-3.5 text-right tabular-nums">
                    <span className="text-red-600 dark:text-red-500 font-medium">
                      {j.frustrated}%
                    </span>
                  </td>

                  {/* Availability % */}
                  <td className="px-5 py-3.5 text-right tabular-nums">
                    <span
                      className={cn(
                        'inline-flex items-center gap-1.5 font-semibold',
                        j.availability >= 80
                          ? 'text-emerald-600 dark:text-emerald-500'
                          : 'text-red-600 dark:text-red-500',
                      )}
                    >
                      <span
                        className={cn(
                          'inline-block h-1.5 w-1.5 rounded-full',
                          j.availability >= 80
                            ? 'bg-emerald-500'
                            : 'bg-red-500',
                        )}
                      />
                      {j.availability.toFixed(2)}%
                    </span>
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>
    </div>
  )
}
