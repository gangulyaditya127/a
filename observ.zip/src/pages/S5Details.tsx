import { useParams, Link } from "react-router-dom"
import { getApp } from "@/data/applications"
import { getPerformance } from "@/data/journeys"
import { cn } from "@/lib/utils"
import { ArrowLeft, AlertTriangle, ChevronRight } from "lucide-react"

export default function S5Details() {
  const { appId, journey } = useParams()
  const app = getApp(appId ?? "")
  const journeyName = decodeURIComponent(journey ?? "")
  const performance = getPerformance(appId ?? "", journeyName)

  return (
    <div className="max-w-7xl mx-auto px-6 my-6 mb-12">
      {/* Back button */}
      <Link
        to={`/${appId}`}
        className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-brand mb-4 transition-colors"
      >
        <ArrowLeft className="h-4 w-4" />
        Back
      </Link>

      {/* Breadcrumb */}
      <nav className="flex items-center gap-1.5 mb-4 rounded-md border border-brand/20 bg-brand-soft/55 px-2.5 py-1.5 text-[11.5px] w-fit text-muted-foreground">
        <Link to="/" className="hover:text-brand transition-colors">Home</Link>
        <ChevronRight className="h-3 w-3 text-brand/45" />
        <Link to="/" className="hover:text-brand transition-colors">Canara Life</Link>
        <ChevronRight className="h-3 w-3 text-brand/45" />
        <Link to={`/${appId}`} className="hover:text-brand transition-colors">{app?.name}</Link>
        <ChevronRight className="h-3 w-3 text-brand/45" />
        <span className="rounded-sm bg-card px-1.5 py-0.5 font-semibold text-foreground shadow-sm ring-1 ring-border/70">{journeyName}</span>
      </nav>

      {/* Header */}
      <h4 className="text-sm font-medium uppercase text-muted-foreground">
        Journey Execution Experience
      </h4>
      <div className="flex items-center gap-3">
        <div className="h-2.5 w-2.5 rounded-[3px] bg-brand" />
        <h3 className="text-2xl font-semibold text-foreground">{journeyName}</h3>
      </div>
      <p className="text-sm text-muted-foreground mt-1 mb-6">
        {new Date().toLocaleDateString("en-US", { weekday: "long", year: "numeric", month: "long", day: "numeric" })}
      </p>

      {/* Performance Table */}
      {performance.length > 0 ? (
        <div className="rounded-xl border border-border bg-card overflow-hidden shadow-card">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border bg-secondary/55">
                <th className="text-left text-sm font-medium text-muted-foreground px-4 py-3 w-[180px]">Steps</th>
                <th className="text-center text-sm font-medium text-muted-foreground px-3 py-3 border-x border-border" colSpan={3}>
                  Happy + Unhappy + Frustrated
                </th>
                <th className="text-left text-sm font-medium text-muted-foreground px-4 py-3">Actions / API</th>
                <th className="text-right text-sm font-medium text-muted-foreground px-4 py-3 border-l border-border">Avg Resp</th>
                <th className="text-right text-sm font-medium text-muted-foreground px-4 py-3">P(95)</th>
                <th className="text-center text-sm font-medium text-muted-foreground px-4 py-3 border-x border-border">Error Rate</th>
                <th className="text-right text-sm font-medium text-muted-foreground px-4 py-3">Availability</th>
              </tr>
            </thead>
            <tbody>
              {performance.map((step, idx) => (
                <PerformanceRow
                  key={idx}
                  step={step}
                  appId={appId ?? ""}
                  journey={journey ?? ""}
                  isLast={idx === performance.length - 1}
                />
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <div className="rounded-xl border border-border p-12 text-center">
          <p className="text-muted-foreground">No sub-journey data available for this journey.</p>
          <Link
            to={`/${appId}/${journey}/timeline`}
            className="mt-4 inline-flex items-center gap-2 text-primary hover:underline"
          >
            View Technical Layer <ChevronRight className="h-4 w-4" />
          </Link>
        </div>
      )}
    </div>
  )
}

function PerformanceRow({
  step,
  appId,
  journey,
  isLast,
}: {
  step: { step: string; actions: any[]; metrics: { happy: number; unhappy: number; frustrated: number } }
  appId: string
  journey: string
  isLast: boolean
}) {
  return (
    <>
      {step.actions.map((action, actionIdx) => (
        <tr
          key={`${step.step}-${actionIdx}`}
          className={cn(
            "group transition-colors hover:bg-secondary/55",
            action.warning && "bg-red-500/10",
            !isLast && actionIdx === step.actions.length - 1 && "border-b border-border"
          )}
        >
          {actionIdx === 0 && (
            <>
              <td
                className="px-4 py-3 font-medium text-sm text-foreground border-r border-border align-top"
                rowSpan={step.actions.length}
              >
                {step.step}
              </td>
              <td
                className="text-center text-emerald-600 font-medium text-base px-3 py-3 align-top"
                rowSpan={step.actions.length}
              >
                {step.metrics.happy}%
              </td>
              <td
                className="text-center text-amber-600 font-medium text-base px-3 py-3 align-top"
                rowSpan={step.actions.length}
              >
                {step.metrics.unhappy}%
              </td>
              <td
                className="text-center text-red-600 font-medium text-base px-3 py-3 border-r border-border align-top"
                rowSpan={step.actions.length}
              >
                {step.metrics.frustrated}%
              </td>
            </>
          )}
          <td className="px-4 py-2.5">
            <Link
              to={`/${appId}/${journey}/timeline`}
              className={cn(
                "text-sm hover:text-brand transition-colors flex items-center gap-1.5",
                action.warning ? "text-red-600 font-medium" : "text-foreground"
              )}
            >
              {action.warning && <AlertTriangle className="h-3.5 w-3.5 text-red-600 shrink-0" />}
              {action.name}
            </Link>
          </td>
          <td className={cn("text-right px-4 py-2.5 text-sm border-l border-border", action.warning && "text-red-600 font-medium")}>
            {action.avgResp} ms
          </td>
          <td className={cn("text-right px-4 py-2.5 text-sm", action.warning && "text-red-600 font-medium")}>
            {action.p95} ms
          </td>
          <td className={cn("text-center px-4 py-2.5 text-sm border-x border-border", action.warning && "text-red-600 font-medium")}>
            {action.errorRate}%
          </td>
          <td className={cn(
            "text-right px-4 py-2.5 text-sm font-medium",
            parseFloat(action.availability) < 80 ? "text-red-600" : parseFloat(action.availability) < 95 ? "text-amber-600" : "text-emerald-600"
          )}>
            {action.availability}%
          </td>
        </tr>
      ))}
    </>
  )
}
