import { useParams, Link } from "react-router-dom"
import { getApp } from "@/data/applications"
import { getActionLayers, type TechTier, type TechLayer, type Connector, type ConnectorAlert } from "@/data/layers"
import {
  CORRELATION_INCIDENTS, HEALING_LOGS, PREDICTIVE_RISKS,
  NOISE_REDUCTION, generateChartData,
} from "@/data/dashboard"
import DependencyGraphInline from "@/components/DependencyGraphInline"
import { useAppSelector, useAppDispatch } from "@/lib/hooks"
import { runAutoFixFlow } from "@/features/agent-flow-slice"
import { cn } from "@/lib/utils"

import { useState, useMemo } from "react"
import {
  AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer,
} from "recharts"
import {
  ArrowLeft, ChevronRight, MoveRight, AlertTriangle,
  Monitor, Cpu, Cable, Database, HardDrive, Globe, Server,
  Shuffle, Workflow, Layers as LayersIcon, GitBranch, Box, FileText,
  Zap, Shield, Search, Wifi, Activity, CheckCircle2,
  Loader2, Circle, Brain, Sparkles, ArrowRight, Target, Users,
  TrendingUp, TrendingDown, Minus, Clock,
} from "lucide-react"

/* ═══════════════════════════════════════════════════════
   Icon & Status maps
   ═══════════════════════════════════════════════════════ */
const ICON_MAP: Record<string, React.ComponentType<any>> = {
  monitor: Monitor, cpu: Cpu, cable: Cable, database: Database,
  "hard-drive": HardDrive, globe: Globe, server: Server,
  shuffle: Shuffle, workflow: Workflow, layers: LayersIcon,
  "git-branch": GitBranch, box: Box, "file-text": FileText,
  zap: Zap, shield: Shield, search: Search, wifi: Wifi,
}

const TIER_COLORS = {
  healthy: { bg: "bg-emerald-500", ring: "ring-emerald-500/30", text: "text-emerald-600" },
  degraded: { bg: "bg-amber-500", ring: "ring-amber-500/30", text: "text-amber-600" },
  critical: { bg: "bg-red-500", ring: "ring-red-500/30", text: "text-red-600" },
}

const STATUS = {
  healthy: { dot: "bg-emerald-500", text: "text-emerald-600", badge: "bg-emerald-500/10 text-emerald-600 border-emerald-500/20" },
  degraded: { dot: "bg-amber-500", text: "text-amber-600", badge: "bg-amber-500/10 text-amber-600 border-amber-500/20" },
  critical: { dot: "bg-red-500", text: "text-red-600", badge: "bg-red-500/10 text-red-600 border-red-500/20" },
  alerting: { dot: "bg-amber-500", text: "text-amber-600", badge: "bg-amber-500/10 text-amber-600 border-amber-500/20" },
}

const SEVERITY: Record<string, string> = {
  critical: "bg-red-500/10 text-red-600 border-red-500/20",
  high: "bg-orange-500/10 text-orange-600 border-orange-500/20",
  medium: "bg-amber-500/10 text-amber-600 border-amber-500/20",
  low: "bg-emerald-500/10 text-emerald-600 border-emerald-500/20",
  info: "bg-brand-soft text-brand border-brand/20",
}

/* ═══════════════════════════════════════════════════════
   Sub-components: Layer detail box
   ═══════════════════════════════════════════════════════ */
function ConnectorChip({ connector }: { connector: Connector }) {
  const s = STATUS[connector.status] ?? STATUS.healthy
  return (
    <span className={cn(
      "inline-flex items-center gap-1.5 text-[11px] px-2 py-1 rounded-md border font-medium", 
      connector.status === "healthy" ? "bg-secondary text-secondary-foreground border-border" : s.badge
    )}>
      <span className={cn("h-1.5 w-1.5 rounded-full", s.dot)} />
      {connector.name}
      {connector.alerts.length > 0 && <span className="font-bold">[{connector.alerts.length}]</span>}
    </span>
  )
}

function AlertRow({ alert }: { alert: ConnectorAlert }) {
  return (
    <div className="flex items-start gap-2 pl-3 py-2 border-l-2 border-border ml-1 mb-2">
      <span className={cn("text-[10px] font-bold px-1.5 py-0.5 rounded border shrink-0 uppercase mt-0.5", SEVERITY[alert.severity])}>
        {alert.severity}
      </span>
      <div className="flex-1 min-w-0">
        {alert.eventname && (
          <p className="text-xs font-bold text-foreground mb-0.5 mt-0.5">{alert.eventname}</p>
        )}
        <p className="text-xs text-muted-foreground leading-relaxed">{alert.message}</p>
        <div className="flex items-start gap-4 mt-2">
          <span className="text-[10px] text-muted-foreground font-mono pt-0.5">{alert.id}</span>
          <span className="text-[10px] text-muted-foreground pt-0.5">{alert.timestamp}</span>
          {alert.metric && (
            <span className="text-[10px] text-red-500 font-medium leading-tight ml-auto text-right">
              {alert.metric}:<br/>{alert.value}
            </span>
          )}
        </div>
      </div>
    </div>
  )
}


/* ═══════════════════════════════════════════════════════
   Chart sub-component (from Dashboard)
   ═══════════════════════════════════════════════════════ */
function MetricChart({ title, description, data, color }: {
  title: string; description: string; data: { time: string; value: number }[]; color: string
}) {
  return (
    <div className="rounded-xl border border-border bg-card p-4 shadow-card">
      <p className="text-sm font-semibold text-foreground">{title}</p>
      <p className="text-xs text-muted-foreground mb-3">{description}</p>
      <ResponsiveContainer width="100%" height={150}>
        <AreaChart data={data}>
          <defs>
            <linearGradient id={`g-${title.replace(/\s/g, "")}`} x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor={color} stopOpacity={0.3} />
              <stop offset="95%" stopColor={color} stopOpacity={0} />
            </linearGradient>
          </defs>
          <XAxis dataKey="time" tick={{ fontSize: 10, fill: "#888" }} axisLine={false} tickLine={false} />
          <YAxis tick={{ fontSize: 10, fill: "#888" }} axisLine={false} tickLine={false} width={40} />
          <Tooltip contentStyle={{ background: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', color: 'hsl(var(--foreground))', borderRadius: "8px", fontSize: 12 }} />
          <Area type="monotone" dataKey="value" stroke={color} fill={`url(#g-${title.replace(/\s/g, "")})`} strokeWidth={2} />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  )
}


/* ═══════════════════════════════════════════════════════
   MAIN PAGE
   ═══════════════════════════════════════════════════════ */
export default function S5Timeline() {
  const { appId, journey } = useParams()
  const app = getApp(appId ?? "")
  const journeyName = decodeURIComponent(journey ?? "")
  const data = getActionLayers(appId ?? "", journeyName)
  const hasCritical = data.tiers.some(t => t.status === "critical")



  const dispatch = useAppDispatch()
  const agentFlow = useAppSelector(s => s.agentFlow)



  const charts = useMemo(() => ({
    errorRate: generateChartData(30, 5, 3),
    responseTime: generateChartData(30, 800, 400),
    cpu: generateChartData(30, 55, 15),
    memory: generateChartData(30, 68, 10),
    connections: generateChartData(30, 150, 50),
    latency: generateChartData(30, 45, 20),
  }), [])

  return (
    <div className="w-full px-6 my-6 mb-16">
      {/* Back */}
      <Link to={`/${appId}/${journey}`} className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-brand mb-4 transition-colors">
        <ArrowLeft className="h-4 w-4" /> Back
      </Link>

      {/* Breadcrumb */}
      <nav className="flex items-center gap-1.5 mb-4 rounded-md border border-brand/20 bg-brand-soft/55 px-2.5 py-1.5 text-[11.5px] w-fit text-muted-foreground">
        <Link to="/" className="hover:text-brand transition-colors">Home</Link>
        <ChevronRight className="h-3 w-3 text-brand/45" />
        <Link to="/" className="hover:text-brand transition-colors">Canara Life</Link>
        <ChevronRight className="h-3 w-3 text-brand/45" />
        <Link to={`/${appId}`} className="hover:text-brand transition-colors">{app?.name}</Link>
        <ChevronRight className="h-3 w-3 text-brand/45" />
        <Link to={`/${appId}/${journey}`} className="hover:text-brand transition-colors">{journeyName}</Link>
        <ChevronRight className="h-3 w-3 text-brand/45" />
        <span className="rounded-sm bg-card px-1.5 py-0.5 font-semibold text-foreground shadow-sm ring-1 ring-border/70">Technical Layers</span>
      </nav>

      {/* Header */}
      <div className="flex items-start justify-between gap-4 mb-2">
        <div>
          <h4 className="text-sm font-medium uppercase text-muted-foreground">Technical Layer Breakdown</h4>
          <div className="flex items-center gap-3 mt-1">
            <div className="h-2.5 w-2.5 rounded-[3px] bg-brand" />
            <h3 className="text-2xl font-semibold text-foreground">{journeyName}</h3>
          </div>
          <p className="text-sm text-muted-foreground mt-1">
            Action: <span className="text-foreground font-medium">{data.action}</span>
          </p>
        </div>
        <div className="flex items-center gap-2 shrink-0">

          {hasCritical && (
            <button
              onClick={() => dispatch(runAutoFixFlow())}
              disabled={agentFlow.running || agentFlow.fixed}
              className={cn(
                "px-5 py-2.5 rounded-lg text-sm font-semibold flex items-center gap-2 transition-all shadow-sm",
                agentFlow.fixed ? "bg-emerald-500/10 text-emerald-600 border border-emerald-500/20 cursor-default"
                  : agentFlow.running ? "bg-brand/20 text-brand border border-brand/20 cursor-wait"
                  : "bg-brand hover:bg-brand-strong text-white"
              )}
            >
              {agentFlow.fixed ? <><CheckCircle2 className="h-4 w-4" /> Resolved</>
                : agentFlow.running ? <><Loader2 className="h-4 w-4 animate-spin" /> Running...</>
                : <><Zap className="h-4 w-4" /> Auto-Fix</>}
            </button>
          )}
        </div>

      </div>



      {/* Agent Flow Progress */}
      {(agentFlow.running || agentFlow.fixed) && (
        <div className="rounded-xl border border-border bg-card p-5 mb-6">
          <h4 className="text-sm font-semibold text-foreground mb-4 flex items-center gap-2">
            <Brain className="h-4 w-4 text-purple-400" /> AI Agent Execution Flow
          </h4>
          <div className="flex items-center gap-1 overflow-x-auto pb-2">
            {agentFlow.steps.map((step, i) => (
              <div key={step.key} className="flex items-center gap-1">
                <div className="flex flex-col items-center min-w-[90px]">
                  <div className={cn(
                    "h-8 w-8 rounded-full grid place-items-center text-xs font-bold",
                    step.status === "completed" && "bg-green-500/20 text-green-400",
                    step.status === "running" && "bg-blue-500/20 text-blue-400",
                    step.status === "idle" && "bg-border text-muted-foreground",
                  )}>
                    {step.status === "completed" ? <CheckCircle2 className="h-4 w-4" />
                      : step.status === "running" ? <Loader2 className="h-4 w-4 animate-spin" />
                      : <Circle className="h-3 w-3" />}
                  </div>
                  <p className="text-[10px] text-center mt-1 text-foreground leading-tight w-20">{step.title}</p>
                  <p className="text-[9px] text-muted-foreground text-center">{step.agent}</p>
                </div>
                {i < agentFlow.steps.length - 1 && (
                  <div className={cn("h-0.5 w-6 shrink-0 mb-8", step.status === "completed" ? "bg-green-500" : "bg-border")} />
                )}
              </div>
            ))}
          </div>
          {agentFlow.activity.length > 0 && (
            <div className="mt-4 max-h-32 overflow-y-auto rounded-lg bg-background/50 p-3 space-y-1">
              {agentFlow.activity.slice(-8).map((log, i) => (
                <p key={i} className="text-xs text-muted-foreground">
                  <span className="text-primary font-medium">[{log.scope}]</span> {log.message}
                </p>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ══════════════════════════════════════════════════
         SECTION 1 & 2: Side-by-Side Tier View
         ══════════════════════════════════════════════════ */}
      <div className="mb-6">
        <h4 className="text-sm font-semibold text-foreground mb-4 flex items-center gap-2">
          <div className="h-2.5 w-2.5 rounded-[3px] bg-brand" /> Technical Tiers
        </h4>
        <div className="flex gap-4 items-stretch w-full overflow-hidden">
          {data.tiers.map((tier, idx) => {
            const colors = TIER_COLORS[tier.status]
            const Icon = ICON_MAP[tier.icon] ?? Activity
            const totalAlerts = tier.layers.reduce((s, l) => s + l.connectors.reduce((s2, c) => s2 + c.alerts.length, 0), 0)
            const rawConnectors = tier.layers.flatMap(l => l.connectors)
            const allConnectors = Array.from(rawConnectors.reduce((acc, curr) => {
              if (acc.has(curr.name)) {
                const existing = acc.get(curr.name)!
                existing.alerts = [...existing.alerts, ...curr.alerts]
                const statuses = ["healthy", "degraded", "alerting", "critical"]
                if (statuses.indexOf(curr.status) > statuses.indexOf(existing.status)) {
                  existing.status = curr.status
                }
              } else {
                acc.set(curr.name, { ...curr, alerts: [...curr.alerts] })
              }
              return acc
            }, new Map<string, typeof rawConnectors[0]>()).values())

            return (
              <div key={tier.id} className="flex-1 min-w-0 flex flex-col gap-6">
                {/* Topology Circle Header */}
                <div className="relative flex justify-center">
                  <div className="flex flex-col items-center gap-2">
                    <div className={cn(
                      "relative h-20 w-20 rounded-full grid place-items-center transition-all duration-300",
                      colors.bg,
                      tier.status === "critical" && "animate-pulse ring-4 ring-red-500/30",
                    )}>
                      <Icon className="h-8 w-8 text-white" />
                      {tier.status !== "healthy" && (
                        <div className="absolute -top-1 -right-1">
                          <AlertTriangle className={cn("h-5 w-5", tier.status === "critical" ? "text-red-500" : "text-amber-500")} />
                        </div>
                      )}
                    </div>
                    <div className="text-center">
                      <p className="text-sm font-bold text-foreground">
                        {tier.name.replace(" / Middleware Tier", "").replace(" Tier", "")}
                      </p>
                      <span className={cn(
                        "text-[10px] font-bold px-2 py-0.5 rounded-full mt-1 inline-block uppercase tracking-wider",
                        tier.status === "healthy" && "bg-emerald-500/10 text-emerald-600",
                        tier.status === "degraded" && "bg-amber-500/10 text-amber-600",
                        tier.status === "critical" && "bg-red-500/10 text-red-600",
                      )}>
                        {tier.status} {totalAlerts > 0 && `(${totalAlerts})`}
                      </span>
                    </div>
                  </div>
                  {/* Arrow bridging to the next tier */}
                  {idx < data.tiers.length - 1 && (
                    <div className="absolute top-10 left-full ml-2 -translate-x-1/2 -translate-y-1/2 z-10">
                      <MoveRight className={cn(
                        "h-6 w-6",
                        data.tiers[idx + 1].status === "critical" ? "text-red-500"
                          : data.tiers[idx + 1].status === "degraded" ? "text-amber-500"
                          : "text-emerald-500/50"
                      )} />
                    </div>
                  )}
                </div>

                {/* Tier Card */}
                <div className="flex-1 rounded-xl shadow-card border border-border bg-card flex flex-col overflow-hidden">
                <div className={cn("p-4 border-b border-border bg-secondary/30", tier.status === "critical" && "bg-red-500/5")}>
                  <div className="flex items-center gap-3">
                    <div className={cn("h-10 w-10 rounded-lg grid place-items-center shrink-0", colors.bg)}>
                      <Icon className="h-5 w-5 text-white" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-bold text-foreground truncate">{tier.name.replace(" / Middleware Tier", "").replace(" Tier", "")}</p>
                      <span className={cn(
                        "text-[10px] font-bold px-2 py-0.5 rounded-full mt-1 inline-block uppercase tracking-wider",
                        tier.status === "healthy" && "bg-emerald-500/10 text-emerald-600",
                        tier.status === "degraded" && "bg-amber-500/10 text-amber-600",
                        tier.status === "critical" && "bg-red-500/10 text-red-600"
                      )}>
                        {tier.status} {totalAlerts > 0 && `(${totalAlerts})`}
                      </span>
                    </div>
                  </div>
                </div>
                <div className="p-4 flex-1 overflow-y-auto max-h-[500px] flex flex-col gap-4 bg-secondary/10">
                  {/* Summarized View */}
                  <div>
                    <h5 className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider mb-2">Event Summary</h5>
                    <div className="flex flex-wrap gap-1.5">
                      {allConnectors.map(c => <ConnectorChip key={c.id} connector={c} />)}
                    </div>
                  </div>

                  {/* Raw Alerts */}
                  <div className="pt-2">
                    <h5 className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider mb-3">Raw Alerts</h5>
                    <div className="space-y-4">
                      {allConnectors.every(c => c.alerts.length === 0) ? (
                        <p className="text-xs text-emerald-600 flex items-center gap-1.5 py-1 bg-background/50 rounded-lg p-2">
                          <CheckCircle2 className="h-3.5 w-3.5" /> All systems healthy
                        </p>
                      ) : (
                        allConnectors.filter(c => c.alerts.length > 0).map(connector => (
                          <div key={connector.id} className="space-y-1.5">
                            <p className="text-xs font-semibold text-foreground flex items-center gap-1.5">
                              <span className={cn("h-1.5 w-1.5 rounded-full", STATUS[connector.status]?.dot ?? "bg-emerald-500")} />
                              {connector.name}
                            </p>
                            <div className="space-y-1">
                              {connector.alerts.map(a => <AlertRow key={a.id} alert={a} />)}
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
            )
          })}
        </div>
      </div>

      {/* ══════════════════════════════════════════════════
         SECTION 3: Event Correlation Engine
         ══════════════════════════════════════════════════ */}
      {hasCritical && (
        <>
          <div className="rounded-xl border border-border overflow-hidden mb-6">
            <div className="bg-card px-5 py-4 border-b border-border flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="relative">
                  <div className="h-2.5 w-2.5 rounded-full bg-emerald-500" />
                  <div className="absolute inset-0 h-2.5 w-2.5 rounded-full bg-emerald-500 animate-ping opacity-75" />
                </div>
                <h3 className="text-base font-semibold text-foreground">Event Correlation Engine</h3>
                <span className="text-xs font-medium px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-600">Active</span>
              </div>
              <div className="flex items-center gap-4 text-xs text-muted-foreground">
                <span>Interval: <span className="text-foreground">30s</span></span>
                <span>Last Run: <span className="text-foreground">12s ago</span></span>
                <span>Incidents: <span className="text-foreground font-semibold">{CORRELATION_INCIDENTS.length}</span></span>
              </div>
            </div>

            {/* Inline correlation content — single incident view */}
            {CORRELATION_INCIDENTS.length > 0 && (() => {
              const incident = CORRELATION_INCIDENTS[0]
              return (
                <div className="p-6 space-y-6">
                  {/* CI Dependency Graph & Root Cause */}
                  <div>
                    <DependencyGraphInline data={data} incident={incident} />
                  </div>

                  {/* Recommendations */}
                  <div>
                    <h5 className="text-sm font-semibold text-foreground flex items-center gap-2 mb-2">
                      <Sparkles className="h-4 w-4 text-yellow-400" /> Recommendations
                    </h5>
                    <ul className="space-y-1.5">
                      {incident.recommendations.map((rec, i) => (
                        <li key={i} className="flex items-start gap-2 text-sm text-foreground">
                          <CheckCircle2 className="h-4 w-4 text-green-400 mt-0.5 shrink-0" />{rec}
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Executive Narrative */}
                  <div className="rounded-lg border border-border bg-card p-4">
                    <h5 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">Executive Narrative</h5>
                    <p className="text-sm text-foreground leading-relaxed">{incident.narrative}</p>
                  </div>
                </div>
              )
            })()}
          </div>


          {/* ══════════════════════════════════════════════════
             SECTION 4: Noise Reduction Funnel
             ══════════════════════════════════════════════════ */}
          <div className="rounded-xl shadow-card border border-border bg-card p-5 mb-6">
            <h3 className="text-base font-semibold text-foreground mb-1">Intelligent Noise Reduction</h3>
            <p className="text-xs text-muted-foreground mb-4">{NOISE_REDUCTION.reductionPercent}% noise reduction — from {NOISE_REDUCTION.raw.toLocaleString()} raw alerts to {NOISE_REDUCTION.actionable} actionable</p>
            <div className="space-y-3">
              {[
                { label: "Raw Alerts", value: NOISE_REDUCTION.raw, pct: 100, color: "from-red-500 to-red-600" },
                { label: "Deduplicated", value: NOISE_REDUCTION.deduplicated, pct: (NOISE_REDUCTION.deduplicated / NOISE_REDUCTION.raw) * 100, color: "from-orange-500 to-orange-600" },
                { label: "Correlated", value: NOISE_REDUCTION.correlated, pct: (NOISE_REDUCTION.correlated / NOISE_REDUCTION.raw) * 100, color: "from-amber-500 to-amber-600" },
                { label: "Actionable", value: NOISE_REDUCTION.actionable, pct: (NOISE_REDUCTION.actionable / NOISE_REDUCTION.raw) * 100, color: "from-emerald-500 to-emerald-600" },
              ].map(item => (
                <div key={item.label} className="flex items-center gap-4">
                  <span className="text-xs text-muted-foreground w-24 text-right">{item.label}</span>
                  <div className="flex-1 h-7 bg-secondary/50 rounded-full overflow-hidden">
                    <div
                      className={cn("h-full rounded-full bg-gradient-to-r flex items-center justify-end pr-3 transition-all duration-700", item.color)}
                      style={{ width: `${Math.max(item.pct, 6)}%` }}
                    >
                      <span className="text-xs font-bold text-white">{item.value.toLocaleString()}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* ══════════════════════════════════════════════════
             SECTION 5: Self-Healing Logs
             ══════════════════════════════════════════════════ */}
          <div className="rounded-xl border border-border overflow-hidden mb-6">
            <div className="bg-card px-5 py-4 border-b border-border">
              <h3 className="text-base font-semibold text-foreground flex items-center gap-2">
                <Zap className="h-4 w-4 text-yellow-400" /> Self-Healing Automation
              </h3>
              <p className="text-xs text-muted-foreground mt-0.5">Automated remediation actions triggered by the correlation engine</p>
            </div>
            <table className="w-full">
              <thead>
                <tr className="border-b border-border bg-secondary/55">
                  <th className="text-left text-xs font-medium text-muted-foreground px-4 py-2.5">Action</th>
                  <th className="text-left text-xs font-medium text-muted-foreground px-4 py-2.5">Target</th>
                  <th className="text-center text-xs font-medium text-muted-foreground px-4 py-2.5">Status</th>
                  <th className="text-left text-xs font-medium text-muted-foreground px-4 py-2.5">Triggered</th>
                  <th className="text-right text-xs font-medium text-muted-foreground px-4 py-2.5">Duration</th>
                  <th className="text-left text-xs font-medium text-muted-foreground px-4 py-2.5">Result</th>
                </tr>
              </thead>
              <tbody>
                {HEALING_LOGS.map(log => (
                  <tr key={log.id} className="border-b border-border last:border-0 hover:bg-accent/20 transition-colors">
                    <td className="px-4 py-3 text-sm font-medium text-foreground">{log.action}</td>
                    <td className="px-4 py-3 text-sm text-muted-foreground">{log.target}</td>
                    <td className="px-4 py-3 text-center">
                      <span className={cn("text-xs font-medium px-2 py-0.5 rounded-full",
                        log.status === "success" && "bg-green-500/10 text-green-400",
                        log.status === "failed" && "bg-red-500/10 text-red-400",
                        log.status === "in-progress" && "bg-yellow-500/10 text-yellow-400",
                      )}>
                        {log.status === "in-progress" ? "In Progress" : log.status.charAt(0).toUpperCase() + log.status.slice(1)}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-xs text-muted-foreground">{log.triggeredAt}</td>
                    <td className="px-4 py-3 text-xs text-right text-foreground">{log.duration}</td>
                    <td className="px-4 py-3 text-xs text-foreground max-w-xs">{log.result}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* ══════════════════════════════════════════════════
             SECTION 6: Predictive Risks
             ══════════════════════════════════════════════════ */}
          <div className="mb-6">
            <h3 className="text-base font-semibold text-foreground flex items-center gap-2 mb-4">
              <Brain className="h-4 w-4 text-purple-400" /> Predictive Risk Detection
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {PREDICTIVE_RISKS.map(risk => (
                <div key={risk.id} className="rounded-xl border border-border bg-card p-4 shadow-card hover:border-brand/30 transition-colors">
                  <div className="flex items-start justify-between mb-3">
                    <h4 className="text-sm font-semibold text-foreground pr-2">{risk.title}</h4>
                    <div className="relative h-12 w-12 shrink-0">
                      <svg viewBox="0 0 36 36" className="h-12 w-12 -rotate-90">
                        <circle cx="18" cy="18" r="15.5" fill="none" strokeWidth="3" className="stroke-border" />
                        <circle cx="18" cy="18" r="15.5" fill="none" strokeWidth="3"
                          className={cn(risk.probability >= 70 ? "stroke-red-500" : risk.probability >= 50 ? "stroke-yellow-500" : "stroke-green-500")}
                          strokeDasharray={`${risk.probability} ${100 - risk.probability}`}
                          strokeLinecap="round" />
                      </svg>
                      <span className="absolute inset-0 flex items-center justify-center text-xs font-bold text-foreground">{risk.probability}%</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-xs px-2 py-0.5 rounded bg-card border border-border text-muted-foreground flex items-center gap-1">
                      <Clock className="h-3 w-3" /> ETA: {risk.eta}
                    </span>
                    <span className="text-xs px-2 py-0.5 rounded bg-card border border-border flex items-center gap-1">
                      {risk.trend === "rising" ? <TrendingUp className="h-3 w-3 text-red-400" />
                        : risk.trend === "falling" ? <TrendingDown className="h-3 w-3 text-green-400" />
                        : <Minus className="h-3 w-3 text-yellow-400" />}
                      <span className={cn("text-xs",
                        risk.trend === "rising" && "text-red-400",
                        risk.trend === "falling" && "text-green-400",
                        risk.trend === "stable" && "text-yellow-400",
                      )}>{risk.trend}</span>
                    </span>
                  </div>
                  <p className="text-xs text-muted-foreground">{risk.indicator}</p>
                  <p className="text-[10px] text-primary mt-2">{risk.affectedApp}</p>
                </div>
              ))}
            </div>
          </div>
        </>
      )}

      {/* ══════════════════════════════════════════════════
         SECTION 7: Charts
         ══════════════════════════════════════════════════ */}
      <div className="grid grid-cols-3 gap-4">
        <MetricChart title="Error Rate" description="Errors per minute across services" data={charts.errorRate} color="#ef4444" />
        <MetricChart title="Response Time" description="Average response time (ms)" data={charts.responseTime} color="#3b82f6" />
        <MetricChart title="CPU Usage" description="Server CPU utilization (%)" data={charts.cpu} color="#f59e0b" />
        <MetricChart title="Memory Usage" description="Heap / RSS memory (%)" data={charts.memory} color="#8b5cf6" />
        <MetricChart title="Active Connections" description="Database & service connections" data={charts.connections} color="#06b6d4" />
        <MetricChart title="Network Latency" description="Inter-service latency (ms)" data={charts.latency} color="#10b981" />
      </div>
    </div>
  )
}
