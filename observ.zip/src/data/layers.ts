/* ═══════════════════════════════════════════════════════════════
   Hierarchical Technical Layers with Monitoring Connectors
   ═══════════════════════════════════════════════════════════════
   Structure:
     Tier (Presentation / Application / Integration / Data / Infra)
       └── Layer (concrete technology)
             └── Connector (monitoring tool)
                   └── Alert (event from that connector)
   ═══════════════════════════════════════════════════════════════ */

export type ConnectorAlert = {
  id: string
  severity: "critical" | "high" | "medium" | "low" | "info"
  eventname?: string
  message: string
  timestamp: string
  metric?: string
  value?: string
}

export type Connector = {
  id: string
  name: string
  type: string // "APM" | "Log Analytics" | "Infrastructure" | "Database" | "Middleware" | "Synthetic"
  status: "healthy" | "alerting" | "critical"
  alerts: ConnectorAlert[]
}

export type TechLayer = {
  id: string
  name: string
  technology: string
  icon: string
  status: "healthy" | "degraded" | "critical"
  connectors: Connector[]
  metrics?: { latency?: string; errorRate?: string; throughput?: string; cpu?: string; memory?: string }
}

export type TechTier = {
  id: string
  name: string
  icon: string
  status: "healthy" | "degraded" | "critical"
  layers: TechLayer[]
}

export type ActionLayerData = {
  action: string
  tiers: TechTier[]
  summary: { totalAlerts: number; connectors: number; affectedLayers: number; rootCauseHint: string }
}

/* ── Helper: derive tier status from its layers ──────────── */
function tierStatus(layers: TechLayer[]): "healthy" | "degraded" | "critical" {
  if (layers.some(l => l.status === "critical")) return "critical"
  if (layers.some(l => l.status === "degraded")) return "degraded"
  return "healthy"
}

/* ═══════════════════════════════════════════════════════════════
   1) POLICY ADMIN → ENDORSEMENT PROCESSING
      Problematic action: "Benefit Recalculation Service"
   ═══════════════════════════════════════════════════════════════ */
const ENDORSEMENT_LAYERS: ActionLayerData = {
  action: "Benefit Recalculation Service",
  summary: {
    totalAlerts: 16,
    connectors: 9,
    affectedLayers: 7,
    rootCauseHint: "Oracle RAC Node-2 failover → Connection pool exhaustion → TIBCO ESB stall → WebLogic thread exhaustion",
  },
  tiers: [
    {
      id: "pres", name: "Presentation Tier", icon: "monitor", status: "critical",
      layers: [
        {
          id: "dem", name: "Digital Experience Monitor", technology: "Dynatrace SaaS", icon: "monitor", status: "critical",
          connectors: [
            {
              id: "dynatrace-dem", name: "Dynatrace", type: "APM / Synthetic", status: "critical",
              alerts: [
                { id: "DYN-001", severity: "critical", eventname: "BackendCallResponseTimeHigh", message: "PolicyRecalcAdapter response time degraded to 6200ms (baseline 400ms) — end-user impact on Benefit Recalculation Service", timestamp: "14:00:06", metric: "Service Response Time", value: "6200ms" },
                { id: "DYN-002", severity: "high", eventname: "UserActionFailureRate", message: "Endorsement submission failure rate 18% across 4,580 active sessions", timestamp: "14:00:22", metric: "Failure Rate", value: "18%" },
              ],
            },
            {
              id: "splunk-dem", name: "Splunk", type: "Log Analytics", status: "alerting",
              alerts: [
                { id: "SPL-DEM-1", severity: "high", eventname: "GatewayTimeoutSpike", message: "504 Gateway Timeout responses spiked to 340/min at /api/endorsement/recalc", timestamp: "14:00:30" },
              ],
            },
          ],
          metrics: { latency: "6200ms", errorRate: "18%", throughput: "45/s" },
        },
        {
          id: "lb", name: "Load Balancer", technology: "F5 BIG-IP LTM", icon: "shuffle", status: "healthy",
          connectors: [
            { id: "f5-ihealth", name: "F5 iHealth", type: "Load Balancer", status: "healthy", alerts: [] },
          ],
          metrics: { latency: "2ms", errorRate: "0%", throughput: "3.8K/s" },
        },
      ],
    },

    {
      id: "app", name: "Application Tier", icon: "cpu", status: "critical",
      layers: [
        {
          id: "weblogic", name: "Application Server", technology: "Oracle WebLogic 14c", icon: "server", status: "critical",
          connectors: [
            {
              id: "appd-weblogic", name: "AppDynamics", type: "APM", status: "critical",
              alerts: [
                { id: "APD-001", severity: "critical", eventname: "ThreadPoolExhaustion", message: "Thread pool exhaustion: 198/200 threads busy on managed server 'PAS_MS1'", timestamp: "14:23:18", metric: "Thread Pool Active", value: "198/200" },
                { id: "APD-002", severity: "high", eventname: "HighResponseTimeDeviation", message: "Average response time 5.2s exceeds baseline 400ms (13x deviation)", timestamp: "14:23:45", metric: "Avg Response Time", value: "5200ms" },
              ],
            },
            {
              id: "splunk-weblogic", name: "Splunk", type: "Log Analytics", status: "alerting",
              alerts: [
                { id: "SPL-001", severity: "high", eventname: "RejectedExecutionException", message: "SEVERE: java.util.concurrent.RejectedExecutionException — 342 occurrences in 5 min", timestamp: "14:24:02", metric: "Error Count", value: "342" },
                { id: "SPL-002", severity: "medium", eventname: "PoolWaitTimeout", message: "WARN: JDBC connection pool 'CanaraPolicyDS' wait timeout exceeded", timestamp: "14:23:55" },
              ],
            },

          ],
          metrics: { latency: "5200ms", errorRate: "18%", throughput: "45/s", cpu: "94%", memory: "87%" },
        },
        {
          id: "rules", name: "Business Rules Engine", technology: "Drools 8.x (Red Hat Decision Manager)", icon: "git-branch", status: "critical",
          connectors: [
            {
              id: "appd-drools", name: "AppDynamics", type: "APM", status: "critical",
              alerts: [
                { id: "APD-003", severity: "critical", eventname: "RuleExecutionTimeout", message: "Rule execution timeout: 4.8s per invocation (threshold: 500ms), rule set: 'EndorsementBenefitRules'", timestamp: "14:24:10", metric: "Rule Exec Time", value: "4800ms" },
              ],
            },
            {
              id: "splunk-drools", name: "Splunk", type: "Log Analytics", status: "alerting",
              alerts: [
                { id: "SPL-003", severity: "medium", eventname: "WorkingMemoryExceeded", message: "WARN: Working memory exceeded 512MB threshold — rule session leak suspected", timestamp: "14:24:15", metric: "Heap Usage", value: "623MB" },
              ],
            },
          ],
          metrics: { latency: "4800ms", errorRate: "22%", throughput: "32/s", cpu: "98%", memory: "92%" },
        },
      ],
    },
    {
      id: "integ", name: "Integration / Middleware Tier", icon: "cable", status: "critical",
      layers: [
        {
          id: "tibco", name: "Enterprise Service Bus", technology: "TIBCO BusinessWorks 6.x", icon: "workflow", status: "critical",
          connectors: [
            {
              id: "hawk-tibco", name: "TIBCO Hawk", type: "Middleware Monitor", status: "critical",
              alerts: [
                { id: "HWK-001", severity: "critical", eventname: "ProcessEngineStuckThrea", message: "Process engine stuck thread count: 47/50 — process 'PolicyEndorsement.bwp' backlogged", timestamp: "14:23:22", metric: "Stuck Threads", value: "47/50" },
                { id: "HWK-002", severity: "high", eventname: "HighQueueDepth", message: "Queue depth 'PAS.ENDORSEMENT.REQ': 2,340 messages (threshold: 500)", timestamp: "14:23:35", metric: "Queue Depth", value: "2340" },
              ],
            },
            {
              id: "splunk-tibco", name: "Splunk", type: "Log Analytics", status: "alerting",
              alerts: [
                { id: "SPL-004", severity: "high", eventname: "BWProcessTimeout", message: "ERROR: [BW-PROCESS-TIMEOUT] Process 'PolicyEndorsement.bwp' activity 'InvokeOracleDB' timed out after 30s", timestamp: "14:23:40" },
              ],
            },
            {
              id: "appd-tibco", name: "AppDynamics", type: "APM", status: "alerting",
              alerts: [
                { id: "APD-004", severity: "medium", eventname: "ESBBackendCallLatency", message: "ESB backend call latency to Oracle DB: 3,200ms (baseline: 45ms)", timestamp: "14:24:00", metric: "Backend Latency", value: "3200ms" },
              ],
            },
          ],
          metrics: { latency: "3200ms", errorRate: "14%", throughput: "85/s" },
        },

      ],
    },
    {
      id: "data", name: "Data Tier", icon: "database", status: "critical",
      layers: [
        {
          id: "oracle", name: "Primary Database", technology: "Oracle RAC 19c (2-node)", icon: "database", status: "critical",
          connectors: [
            {
              id: "oem", name: "Oracle Enterprise Manager", type: "Database Monitor", status: "critical",
              alerts: [
                { id: "OEM-001", severity: "critical", eventname: "RACNodeInstanceFailover", message: "RAC Node-2 instance failover detected at 14:23:05 — unplanned (CHG0045231 maintenance overrun)", timestamp: "14:23:05", metric: "RAC Node Status", value: "Node-2 DOWN" },
                { id: "OEM-002", severity: "critical", eventname: "ActiveSessionsSpike", message: "Active sessions spike: 340→890 on Node-1 (absorbing Node-2 load)", timestamp: "14:23:12", metric: "Active Sessions", value: "890/1000" },
              ],
            },
            {
              id: "splunk-oracle", name: "Splunk", type: "Log Analytics", status: "critical",
              alerts: [
                { id: "SPL-006", severity: "critical", eventname: "TNSListenerNoHandler", message: "ORA-12516: TNS listener could not find available handler with matching protocol stack", timestamp: "14:23:08" },
                { id: "SPL-007", severity: "high", eventname: "TNSConnectionRejections", message: "ORA-12519: TNS no appropriate service handler found — 230 connection rejections in 2 min", timestamp: "14:23:45" },
              ],
            },
            {
              id: "appd-oracle", name: "AppDynamics Database", type: "Database APM", status: "alerting",
              alerts: [
                { id: "APD-005", severity: "high", eventname: "HighPoolWaitTime", message: "Connection pool wait time: 4,200ms (baseline: 15ms) — pool 'CanaraPolicyDS' exhausted at maxActive=200", timestamp: "14:23:50", metric: "Pool Wait", value: "4200ms" },
              ],
            },
          ],
          metrics: { latency: "4200ms", errorRate: "12%", throughput: "120/s", cpu: "96%", memory: "89%" },
        },
        {
          id: "filenet", name: "Document Management", technology: "IBM FileNet P8 5.5", icon: "file-text", status: "healthy",
          connectors: [
            { id: "filenet-admin", name: "FileNet Admin Console", type: "ECM Monitor", status: "healthy", alerts: [] },
          ],
          metrics: { latency: "120ms", errorRate: "1%", throughput: "340/s" },
        },
        {
          id: "redis", name: "Cache Layer", technology: "Redis Cluster 7.2", icon: "zap", status: "degraded",
          connectors: [
            {
              id: "redis-insight", name: "Redis Insight", type: "Cache Monitor", status: "alerting",
              alerts: [
                { id: "RDS-001", severity: "medium", eventname: "HighCacheMissRate", message: "Cache miss rate: 67% (baseline: 12%) — stale policy data after DB failover", timestamp: "14:24:30", metric: "Cache Miss Rate", value: "67%" },
              ],
            },
            {
              id: "grafana-redis", name: "Grafana", type: "Metrics Dashboard", status: "alerting",
              alerts: [
                { id: "GRF-001", severity: "low", eventname: "HighMemoryFragmentation", message: "Memory fragmentation ratio: 1.8 (threshold: 1.5)", timestamp: "14:24:35", metric: "Frag Ratio", value: "1.8" },
              ],
            },
          ],
          metrics: { latency: "45ms", errorRate: "3%", throughput: "2.1K/s", memory: "78%" },
        },
      ],
    },
    {
      id: "infra", name: "Infrastructure Tier", icon: "hard-drive", status: "degraded",
      layers: [
        {
          id: "vmware", name: "Compute / Virtualization", technology: "VMware vSphere 8.0", icon: "box", status: "degraded",
          connectors: [
            {
              id: "solarwinds-vm", name: "SolarWinds Server & Application Monitor", type: "Infrastructure", status: "alerting",
              alerts: [
                { id: "SW-001", severity: "medium", message: "CPU ready time: 12ms (threshold: 5ms) on ESXi host 'esxi-prod-03'", timestamp: "14:25:00", metric: "CPU Ready", value: "12ms" },
              ],
            },
            {
              id: "vcenter", name: "VMware vCenter", type: "Hypervisor Monitor", status: "alerting",
              alerts: [
                { id: "VC-001", severity: "medium", message: "VM memory balloon active: 'weblogic-pas-03' at 92% — host memory contention", timestamp: "14:25:10", metric: "VM Memory", value: "92%" },
              ],
            },
          ],
          metrics: { cpu: "88%", memory: "92%" },
        },
        {
          id: "storage", name: "Storage", technology: "NetApp ONTAP 9.14 (SAN)", icon: "hard-drive", status: "healthy",
          connectors: [
            { id: "netapp", name: "NetApp OnCommand", type: "Storage Monitor", status: "healthy", alerts: [] },
          ],
          metrics: { throughput: "1.2 GB/s" },
        },
        {
          id: "network", name: "Network", technology: "Cisco Nexus 9300", icon: "wifi", status: "healthy",
          connectors: [
            { id: "solarwinds-net", name: "SolarWinds NPM", type: "Network Monitor", status: "healthy", alerts: [] },
          ],
        },
      ],
    },
  ],
}
// Fix tier statuses
ENDORSEMENT_LAYERS.tiers.forEach(t => { t.status = tierStatus(t.layers) })

/* ═══════════════════════════════════════════════════════════════
   2) CLAIMS MGMT → CLAIMS ASSESSMENT
      Problematic action: "Hospital Network Verification (TPA)"
   ═══════════════════════════════════════════════════════════════ */
const CLAIMS_ASSESSMENT_LAYERS: ActionLayerData = {
  action: "Hospital Network Verification (TPA)",
  summary: {
    totalAlerts: 12,
    connectors: 7,
    affectedLayers: 5,
    rootCauseHint: "Third-party TPA gateway SSL cert expired → Connection failures → MuleSoft retry storm → Claims DB lock contention",
  },
  tiers: [
    {
      id: "pres", name: "Presentation Tier", icon: "monitor", status: "healthy",
      layers: [
        {
          id: "cdn", name: "CDN & Edge", technology: "Akamai Ion", icon: "globe", status: "healthy",
          connectors: [{ id: "akamai", name: "Akamai Luna", type: "CDN Analytics", status: "healthy", alerts: [] }],
          metrics: { latency: "6ms", errorRate: "0%", throughput: "2.8K/s" },
        },
        {
          id: "lb", name: "Load Balancer", technology: "F5 BIG-IP LTM", icon: "shuffle", status: "healthy",
          connectors: [{ id: "f5", name: "F5 iHealth", type: "Load Balancer", status: "healthy", alerts: [] }],
          metrics: { latency: "3ms", errorRate: "0%", throughput: "2.6K/s" },
        },
      ],
    },
    {
      id: "app", name: "Application Tier", icon: "cpu", status: "degraded",
      layers: [
        {
          id: "jboss", name: "Application Server", technology: "JBoss EAP 8.0", icon: "server", status: "degraded",
          connectors: [
            {
              id: "appd-jboss", name: "AppDynamics", type: "APM", status: "alerting",
              alerts: [
                { id: "APD-101", severity: "high", message: "HTTP connection pool to TPA gateway saturated — 50/50 connections busy, 120 requests queued", timestamp: "15:10:22", metric: "Connection Pool", value: "50/50" },
              ],
            },
            {
              id: "splunk-jboss", name: "Splunk", type: "Log Analytics", status: "alerting",
              alerts: [
                { id: "SPL-101", severity: "high", message: "javax.net.ssl.SSLHandshakeException: PKIX path building failed — TPA gateway certificate expired", timestamp: "15:10:05" },
              ],
            },
          ],
          metrics: { latency: "4800ms", errorRate: "16%", throughput: "65/s", cpu: "78%", memory: "72%" },
        },
        {
          id: "fraud", name: "Fraud Detection Engine", technology: "SAS Viya 4.0", icon: "shield", status: "healthy",
          connectors: [
            { id: "appd-sas", name: "AppDynamics", type: "APM", status: "healthy", alerts: [] },
          ],
          metrics: { latency: "890ms", errorRate: "2%", throughput: "210/s" },
        },
      ],
    },
    {
      id: "integ", name: "Integration / Middleware Tier", icon: "cable", status: "critical",
      layers: [
        {
          id: "mulesoft", name: "API Gateway / ESB", technology: "MuleSoft Anypoint (CloudHub)", icon: "workflow", status: "critical",
          connectors: [
            {
              id: "mule-monitor", name: "MuleSoft Anypoint Monitoring", type: "API Gateway", status: "critical",
              alerts: [
                { id: "MULE-001", severity: "critical", message: "API 'hospital-network-v2' circuit breaker OPEN — 340 consecutive failures to TPA endpoint", timestamp: "15:10:15", metric: "Circuit Breaker", value: "OPEN" },
                { id: "MULE-002", severity: "high", message: "Retry storm: 1,200 retry attempts/min to TPA gateway (max-retries=3 per request)", timestamp: "15:10:30", metric: "Retry Rate", value: "1200/min" },
              ],
            },
            {
              id: "splunk-mule", name: "Splunk", type: "Log Analytics", status: "alerting",
              alerts: [
                { id: "SPL-102", severity: "high", message: "ERROR: [MULE-CONNECTOR-SSL] Unable to establish TLS handshake with tpa-gateway.healthnet.co.in:443", timestamp: "15:10:08" },
              ],
            },
          ],
          metrics: { latency: "4200ms", errorRate: "42%", throughput: "28/s" },
        },
        {
          id: "kafka", name: "Event Streaming", technology: "Apache Kafka 3.7 (Confluent)", icon: "layers", status: "degraded",
          connectors: [
            {
              id: "confluent", name: "Confluent Control Center", type: "Streaming Monitor", status: "alerting",
              alerts: [
                { id: "KFK-001", severity: "medium", message: "Consumer lag on topic 'claims.assessment.events': 8,400 messages behind", timestamp: "15:11:00", metric: "Consumer Lag", value: "8400 msgs" },
              ],
            },
          ],
          metrics: { latency: "340ms", errorRate: "0.5%", throughput: "1.2K/s" },
        },
      ],
    },
    {
      id: "data", name: "Data Tier", icon: "database", status: "degraded",
      layers: [
        {
          id: "postgres", name: "Claims Database", technology: "PostgreSQL 16 (Azure Managed)", icon: "database", status: "degraded",
          connectors: [
            {
              id: "azure-pg", name: "Azure Monitor for PostgreSQL", type: "Database Monitor", status: "alerting",
              alerts: [
                { id: "AZ-001", severity: "high", message: "Lock contention: 45 queries waiting on table 'claim_assessments' — long-running transactions from retry storm", timestamp: "15:11:20", metric: "Lock Waits", value: "45 queries" },
                { id: "AZ-002", severity: "medium", message: "Active connections: 180/200 — approaching pool limit", timestamp: "15:11:30", metric: "Active Connections", value: "180/200" },
              ],
            },
            {
              id: "grafana-pg", name: "Grafana", type: "Metrics Dashboard", status: "alerting",
              alerts: [
                { id: "GRF-101", severity: "medium", message: "Query p95 latency: 2,100ms (baseline: 120ms) on 'claim_assessments' table", timestamp: "15:11:35", metric: "Query p95", value: "2100ms" },
              ],
            },
          ],
          metrics: { latency: "2100ms", errorRate: "8%", throughput: "180/s", cpu: "82%", memory: "75%" },
        },
        {
          id: "elastic", name: "Search Index", technology: "Elasticsearch 8.14", icon: "search", status: "healthy",
          connectors: [
            { id: "kibana", name: "Kibana", type: "Search Analytics", status: "healthy", alerts: [] },
          ],
          metrics: { latency: "35ms", errorRate: "0.2%", throughput: "900/s" },
        },
      ],
    },
    {
      id: "infra", name: "Infrastructure Tier", icon: "hard-drive", status: "healthy",
      layers: [
        {
          id: "aks", name: "Container Orchestration", technology: "Azure Kubernetes Service (AKS)", icon: "box", status: "healthy",
          connectors: [
            {
              id: "prometheus", name: "Prometheus + Grafana", type: "Container Monitor", status: "healthy",
              alerts: [
                { id: "PRO-101", severity: "info", message: "Pod 'claims-assessment-7f4d8b' restarted 2x in last 10 min (CrashLoopBackOff recovered)", timestamp: "15:12:00" },
              ],
            },
          ],
          metrics: { cpu: "65%", memory: "70%" },
        },
        {
          id: "network", name: "Network", technology: "Azure Virtual Network + NSG", icon: "wifi", status: "healthy",
          connectors: [
            { id: "azure-net", name: "Azure Network Watcher", type: "Network Monitor", status: "healthy", alerts: [] },
          ],
        },
      ],
    },
  ],
}
CLAIMS_ASSESSMENT_LAYERS.tiers.forEach(t => { t.status = tierStatus(t.layers) })

/* ═══════════════════════════════════════════════════════════════
   3) UNDERWRITING → MEDICAL UNDERWRITING
      Problematic action: "Medical History API (MIB/CIBIL Health)"
   ═══════════════════════════════════════════════════════════════ */
const MEDICAL_UW_LAYERS: ActionLayerData = {
  action: "Medical History API (MIB/CIBIL Health)",
  summary: {
    totalAlerts: 10,
    connectors: 6,
    affectedLayers: 4,
    rootCauseHint: "MIB external API rate limit exceeded → Kong API Gateway throttling → Response queue backlog → Underwriter UI timeout",
  },
  tiers: [
    {
      id: "pres", name: "Presentation Tier", icon: "monitor", status: "healthy",
      layers: [
        {
          id: "nginx", name: "Web Server", technology: "Nginx Ingress Controller", icon: "globe", status: "healthy",
          connectors: [
            { id: "datadog-nginx", name: "Datadog", type: "APM", status: "healthy", alerts: [] },
          ],
          metrics: { latency: "12ms", errorRate: "0.1%", throughput: "1.8K/s" },
        },
      ],
    },
    {
      id: "app", name: "Application Tier", icon: "cpu", status: "degraded",
      layers: [
        {
          id: "springboot", name: "Microservices", technology: "Spring Boot 3.2 (Kubernetes)", icon: "server", status: "degraded",
          connectors: [
            {
              id: "datadog-spring", name: "Datadog APM", type: "APM", status: "alerting",
              alerts: [
                { id: "DD-201", severity: "high", message: "Service 'medical-history-svc' p95 latency: 3,500ms (SLO: 800ms) — upstream MIB API slow", timestamp: "11:45:10", metric: "p95 Latency", value: "3500ms" },
                { id: "DD-202", severity: "medium", message: "Thread pool 'mib-executor' at 48/50 threads — near saturation", timestamp: "11:45:25", metric: "Thread Pool", value: "48/50" },
              ],
            },
            {
              id: "splunk-spring", name: "Splunk", type: "Log Analytics", status: "alerting",
              alerts: [
                { id: "SPL-201", severity: "medium", message: "WARN: Hystrix circuit breaker 'MIBFetchCommand' at 60% failure rate (threshold: 50%)", timestamp: "11:45:30" },
              ],
            },
          ],
          metrics: { latency: "3500ms", errorRate: "14%", throughput: "85/s", cpu: "72%", memory: "68%" },
        },
      ],
    },
    {
      id: "integ", name: "Integration / Middleware Tier", icon: "cable", status: "critical",
      layers: [
        {
          id: "kong", name: "API Gateway", technology: "Kong Gateway Enterprise", icon: "workflow", status: "critical",
          connectors: [
            {
              id: "kong-vitals", name: "Kong Vitals", type: "API Gateway", status: "critical",
              alerts: [
                { id: "KONG-001", severity: "critical", message: "Rate limit plugin triggered: MIB external API quota 500 req/min exceeded — 340 requests rejected (HTTP 429)", timestamp: "11:44:55", metric: "Rate Limit", value: "429 errors" },
                { id: "KONG-002", severity: "high", message: "Upstream health check FAILING for 'mib-api.insurancebureau.org' — 3 consecutive failures", timestamp: "11:45:00", metric: "Health Check", value: "UNHEALTHY" },
              ],
            },
            {
              id: "splunk-kong", name: "Splunk", type: "Log Analytics", status: "alerting",
              alerts: [
                { id: "SPL-202", severity: "high", message: "ERROR: [rate-limiting] API key 'canara-uw-prod' exceeded quota. Next reset in 42s", timestamp: "11:45:05" },
              ],
            },
          ],
          metrics: { latency: "2800ms", errorRate: "32%", throughput: "45/s" },
        },
        {
          id: "rabbitmq", name: "Message Broker", technology: "RabbitMQ 3.13", icon: "layers", status: "degraded",
          connectors: [
            {
              id: "rabbit-mgmt", name: "RabbitMQ Management", type: "Queue Monitor", status: "alerting",
              alerts: [
                { id: "RMQ-001", severity: "medium", message: "Queue 'uw.medical.response' depth: 2,100 (threshold: 500) — consumers not keeping up", timestamp: "11:46:00", metric: "Queue Depth", value: "2100" },
              ],
            },
          ],
          metrics: { latency: "450ms", errorRate: "2%", throughput: "320/s" },
        },
      ],
    },
    {
      id: "data", name: "Data Tier", icon: "database", status: "healthy",
      layers: [
        {
          id: "mongodb", name: "Underwriting Database", technology: "MongoDB Atlas 7.0", icon: "database", status: "healthy",
          connectors: [
            {
              id: "atlas", name: "MongoDB Atlas Monitoring", type: "Database Monitor", status: "healthy",
              alerts: [
                { id: "MDB-201", severity: "info", message: "Slow query detected on collection 'medical_records': 340ms (threshold: 200ms)", timestamp: "11:46:30" },
              ],
            },
          ],
          metrics: { latency: "85ms", errorRate: "0.5%", throughput: "640/s" },
        },
      ],
    },
    {
      id: "infra", name: "Infrastructure Tier", icon: "hard-drive", status: "healthy",
      layers: [
        {
          id: "eks", name: "Container Orchestration", technology: "Amazon EKS 1.30", icon: "box", status: "healthy",
          connectors: [
            { id: "cloudwatch", name: "AWS CloudWatch", type: "Infrastructure", status: "healthy", alerts: [] },
          ],
          metrics: { cpu: "55%", memory: "62%" },
        },
      ],
    },
  ],
}
MEDICAL_UW_LAYERS.tiers.forEach(t => { t.status = tierStatus(t.layers) })

/* ═══════════════════════════════════════════════════════════════
   DEFAULT — Healthy technical stack for non-problematic journeys
   ═══════════════════════════════════════════════════════════════ */
const DEFAULT_LAYERS: ActionLayerData = {
  action: "(All Actions)",
  summary: { totalAlerts: 0, connectors: 6, affectedLayers: 0, rootCauseHint: "All systems operating within normal parameters" },
  tiers: [
    {
      id: "pres", name: "Presentation Tier", icon: "monitor", status: "healthy",
      layers: [
        {
          id: "cdn", name: "CDN & Edge", technology: "Akamai Ion", icon: "globe", status: "healthy",
          connectors: [{ id: "akamai", name: "Akamai Luna", type: "CDN Analytics", status: "healthy", alerts: [] }],
          metrics: { latency: "8ms", errorRate: "0%", throughput: "3.5K/s" },
        },
        {
          id: "lb", name: "Load Balancer", technology: "F5 BIG-IP LTM", icon: "shuffle", status: "healthy",
          connectors: [{ id: "f5", name: "F5 iHealth", type: "Load Balancer", status: "healthy", alerts: [] }],
          metrics: { latency: "2ms", errorRate: "0%", throughput: "3.2K/s" },
        },
      ],
    },
    {
      id: "app", name: "Application Tier", icon: "cpu", status: "healthy",
      layers: [
        {
          id: "appserver", name: "Application Server", technology: "Oracle WebLogic 14c", icon: "server", status: "healthy",
          connectors: [
            { id: "appd", name: "AppDynamics", type: "APM", status: "healthy", alerts: [] },
            { id: "splunk", name: "Splunk", type: "Log Analytics", status: "healthy", alerts: [] },
          ],
          metrics: { latency: "180ms", errorRate: "1.5%", throughput: "450/s", cpu: "45%", memory: "58%" },
        },
      ],
    },
    {
      id: "integ", name: "Integration / Middleware Tier", icon: "cable", status: "healthy",
      layers: [
        {
          id: "esb", name: "Enterprise Service Bus", technology: "TIBCO BusinessWorks 6.x", icon: "workflow", status: "healthy",
          connectors: [
            { id: "hawk", name: "TIBCO Hawk", type: "Middleware Monitor", status: "healthy", alerts: [] },
            { id: "splunk-esb", name: "Splunk", type: "Log Analytics", status: "healthy", alerts: [] },
          ],
          metrics: { latency: "45ms", errorRate: "0.5%", throughput: "800/s" },
        },
      ],
    },
    {
      id: "data", name: "Data Tier", icon: "database", status: "healthy",
      layers: [
        {
          id: "db", name: "Primary Database", technology: "Oracle RAC 19c", icon: "database", status: "healthy",
          connectors: [
            { id: "oem", name: "Oracle Enterprise Manager", type: "Database Monitor", status: "healthy", alerts: [] },
          ],
          metrics: { latency: "35ms", errorRate: "0.3%", throughput: "1.8K/s" },
        },
      ],
    },
    {
      id: "infra", name: "Infrastructure Tier", icon: "hard-drive", status: "healthy",
      layers: [
        {
          id: "compute", name: "Compute", technology: "VMware vSphere 8.0", icon: "box", status: "healthy",
          connectors: [
            { id: "solar", name: "SolarWinds SAM", type: "Infrastructure", status: "healthy", alerts: [] },
          ],
          metrics: { cpu: "42%", memory: "55%" },
        },
      ],
    },
  ],
}

/* ═══════════════════════════════════════════════════════════════
   Lookup
   ═══════════════════════════════════════════════════════════════ */
const LAYER_MAP: Record<string, Record<string, ActionLayerData>> = {
  "policy-admin": { "Endorsement Processing": ENDORSEMENT_LAYERS },
  "claims-mgmt": { "Claims Assessment": CLAIMS_ASSESSMENT_LAYERS },
  "underwriting": { "Medical Underwriting": MEDICAL_UW_LAYERS },
}

export function getActionLayers(appId: string, journey: string): ActionLayerData {
  return LAYER_MAP[appId]?.[journey] ?? DEFAULT_LAYERS
}
