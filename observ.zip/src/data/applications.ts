export type Journey = {
  name: string
  activeUsers: number
  happy: number
  unhappy: number
  frustrated: number
  availability: number
}

export type Application = {
  id: string
  name: string
  icon: string
  description: string
  journeys: Journey[]
}

export const APPLICATIONS: Application[] = [
  {
    id: "policy-admin",
    name: "Policy Administration System",
    icon: "clipboard-list",
    description: "End-to-end policy lifecycle — new business submission, issuance, endorsements, renewals, surrender, and premium collection for life & health products.",
    journeys: [
      { name: "New Business Submission", activeUsers: 2340, happy: 87, unhappy: 8, frustrated: 5, availability: 93.45 },
      { name: "Policy Issuance", activeUsers: 1890, happy: 92, unhappy: 5, frustrated: 3, availability: 97.12 },
      { name: "Endorsement Processing", activeUsers: 1120, happy: 74, unhappy: 17, frustrated: 9, availability: 68.90 },
      { name: "Policy Renewal", activeUsers: 1650, happy: 95, unhappy: 3, frustrated: 2, availability: 98.34 },
      { name: "Premium Collection", activeUsers: 3200, happy: 91, unhappy: 6, frustrated: 3, availability: 96.78 },
    ],
  },
  {
    id: "claims-mgmt",
    name: "Claims Management System",
    icon: "heart-pulse",
    description: "Claims lifecycle from first notice of loss through investigation, adjudication, and settlement for life, health, and critical illness claims.",
    journeys: [
      { name: "Claims Intimation (FNOL)", activeUsers: 1450, happy: 90, unhappy: 7, frustrated: 3, availability: 97.56 },
      { name: "Claims Assessment", activeUsers: 980, happy: 76, unhappy: 15, frustrated: 9, availability: 71.20 },
      { name: "Claims Adjudication", activeUsers: 870, happy: 88, unhappy: 8, frustrated: 4, availability: 94.12 },
      { name: "Claims Settlement", activeUsers: 1230, happy: 93, unhappy: 4, frustrated: 3, availability: 97.89 },
    ],
  },
  {
    id: "underwriting",
    name: "Underwriting Workbench",
    icon: "shield-check",
    description: "Risk assessment, medical & financial underwriting, and reinsurance placement for individual and group life & health proposals.",
    journeys: [
      { name: "Risk Assessment", activeUsers: 560, happy: 89, unhappy: 7, frustrated: 4, availability: 95.34 },
      { name: "Medical Underwriting", activeUsers: 420, happy: 82, unhappy: 12, frustrated: 6, availability: 87.45 },
      { name: "Financial Underwriting", activeUsers: 340, happy: 94, unhappy: 4, frustrated: 2, availability: 97.56 },
      { name: "Reinsurance Placement", activeUsers: 180, happy: 96, unhappy: 3, frustrated: 1, availability: 98.90 },
    ],
  },
  {
    id: "customer-portal",
    name: "Customer Self-Service Portal",
    icon: "user-circle",
    description: "Policyholder self-service — login, policy servicing, premium payments, claims filing, and ULIP fund switches.",
    journeys: [
      { name: "Login & Registration", activeUsers: 5600, happy: 97, unhappy: 2, frustrated: 1, availability: 99.87 },
      { name: "Policy Servicing", activeUsers: 3400, happy: 94, unhappy: 4, frustrated: 2, availability: 98.12 },
      { name: "Premium Payment", activeUsers: 4200, happy: 92, unhappy: 5, frustrated: 3, availability: 96.45 },
      { name: "Claims Filing", activeUsers: 890, happy: 86, unhappy: 9, frustrated: 5, availability: 93.21 },
      { name: "Fund Switch (ULIP)", activeUsers: 620, happy: 90, unhappy: 7, frustrated: 3, availability: 95.67 },
    ],
  },
  {
    id: "agent-portal",
    name: "Agent & Distributor Portal",
    icon: "briefcase",
    description: "Agent tools for proposal submission, commission tracking, persistency monitoring, lead management, and renewal follow-ups.",
    journeys: [
      { name: "Proposal Submission", activeUsers: 1890, happy: 91, unhappy: 6, frustrated: 3, availability: 96.34 },
      { name: "Commission Statement", activeUsers: 2340, happy: 95, unhappy: 3, frustrated: 2, availability: 98.56 },
      { name: "Persistency Tracking", activeUsers: 1100, happy: 93, unhappy: 5, frustrated: 2, availability: 97.12 },
      { name: "Lead Management", activeUsers: 780, happy: 89, unhappy: 7, frustrated: 4, availability: 94.78 },
      { name: "Renewal Follow-up", activeUsers: 1450, happy: 92, unhappy: 5, frustrated: 3, availability: 96.89 },
    ],
  },
]

export function getApp(id: string): Application | undefined {
  return APPLICATIONS.find(a => a.id === id)
}
