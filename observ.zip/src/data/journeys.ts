export type PerformanceAction = {
  name: string
  avgResp: string
  p95: string
  errorRate: string
  availability: string
  warning?: boolean
}

export type PerformanceStep = {
  step: string
  actions: PerformanceAction[]
  metrics: { happy: number; unhappy: number; frustrated: number }
}

export const JOURNEY_PERFORMANCE: Record<string, Record<string, PerformanceStep[]>> = {
  /* ════════════════════════════════════════════════════════════
     POLICY ADMINISTRATION SYSTEM
     ════════════════════════════════════════════════════════════ */
  "policy-admin": {
    "New Business Submission": [
      {
        step: "Proposal Capture",
        actions: [
          { name: "Proposal Form Validation API", avgResp: "180", p95: "320", errorRate: "2", availability: "98.90" },
          { name: "Nominee & Beneficiary Registration", avgResp: "120", p95: "210", errorRate: "1", availability: "99.34" },
          { name: "Product Recommendation Engine", avgResp: "340", p95: "560", errorRate: "3", availability: "97.12" },
        ],
        metrics: { happy: 91, unhappy: 6, frustrated: 3 },
      },
      {
        step: "KYC & AML Verification",
        actions: [
          { name: "CKYC Registry Lookup", avgResp: "450", p95: "780", errorRate: "4", availability: "95.67" },
          { name: "PAN / Aadhaar Validation (UIDAI)", avgResp: "890", p95: "1200", errorRate: "5", availability: "94.32" },
          { name: "FATCA / CRS Compliance Check", avgResp: "210", p95: "380", errorRate: "2", availability: "98.56" },
        ],
        metrics: { happy: 85, unhappy: 10, frustrated: 5 },
      },
      {
        step: "Premium Quotation",
        actions: [
          { name: "Actuarial Rate Engine", avgResp: "280", p95: "450", errorRate: "2", availability: "98.12" },
          { name: "Rider Benefit Calculator", avgResp: "150", p95: "260", errorRate: "1", availability: "99.45" },
          { name: "GST Computation Service", avgResp: "90", p95: "160", errorRate: "1", availability: "99.78" },
        ],
        metrics: { happy: 94, unhappy: 4, frustrated: 2 },
      },
      {
        step: "Payment & Binding",
        actions: [
          { name: "Payment Gateway (Razorpay)", avgResp: "520", p95: "890", errorRate: "3", availability: "97.56" },
          { name: "First Premium Receipt Generation", avgResp: "340", p95: "560", errorRate: "2", availability: "98.34" },
        ],
        metrics: { happy: 90, unhappy: 7, frustrated: 3 },
      },
    ],
    "Endorsement Processing": [
      {
        step: "Change Request Intake",
        actions: [
          { name: "Policy Status Verification API", avgResp: "150", p95: "280", errorRate: "2", availability: "98.90" },
          { name: "Document Upload Service (FileNet)", avgResp: "320", p95: "540", errorRate: "3", availability: "97.12" },
          { name: "Customer 360 Lookup", avgResp: "230", p95: "410", errorRate: "2", availability: "98.34" },
        ],
        metrics: { happy: 88, unhappy: 8, frustrated: 4 },
      },
      {
        step: "Eligibility & Compliance",
        actions: [
          { name: "Policy Eligibility Check", avgResp: "180", p95: "310", errorRate: "2", availability: "97.89" },
          { name: "IRDAI Regulatory Compliance Engine", avgResp: "340", p95: "520", errorRate: "3", availability: "96.45" },
          { name: "Benefit Recalculation Service", avgResp: "5200", p95: "7800", errorRate: "18", availability: "68.90", warning: true },
        ],
        metrics: { happy: 68, unhappy: 20, frustrated: 12 },
      },
      {
        step: "Premium Adjustment",
        actions: [
          { name: "Pro-rata Premium Calculator", avgResp: "180", p95: "310", errorRate: "2", availability: "98.34" },
          { name: "Tax Recalculation (80C/80D)", avgResp: "120", p95: "210", errorRate: "1", availability: "99.12" },
        ],
        metrics: { happy: 92, unhappy: 5, frustrated: 3 },
      },
      {
        step: "Approval & Issuance",
        actions: [
          { name: "Underwriter Approval Workflow", avgResp: "450", p95: "720", errorRate: "3", availability: "96.78" },
          { name: "Endorsement Schedule Generator", avgResp: "670", p95: "980", errorRate: "4", availability: "95.23" },
          { name: "Policyholder SMS/Email Notification", avgResp: "80", p95: "150", errorRate: "1", availability: "99.67" },
        ],
        metrics: { happy: 89, unhappy: 7, frustrated: 4 },
      },
    ],
    "Policy Issuance": [
      {
        step: "Underwriting Decision",
        actions: [
          { name: "Auto-Underwriting Rules Engine", avgResp: "320", p95: "520", errorRate: "2", availability: "97.89" },
          { name: "Risk Classification API", avgResp: "280", p95: "450", errorRate: "2", availability: "98.12" },
        ],
        metrics: { happy: 93, unhappy: 5, frustrated: 2 },
      },
      {
        step: "Policy Document Generation",
        actions: [
          { name: "Policy Schedule Generator", avgResp: "450", p95: "720", errorRate: "3", availability: "96.78" },
          { name: "E-Stamp / E-Sign Service", avgResp: "340", p95: "560", errorRate: "2", availability: "97.56" },
          { name: "Welcome Kit Dispatch (Courier API)", avgResp: "120", p95: "210", errorRate: "1", availability: "99.12" },
        ],
        metrics: { happy: 92, unhappy: 5, frustrated: 3 },
      },
    ],
    "Policy Renewal": [
      {
        step: "Renewal Processing",
        actions: [
          { name: "Renewal Eligibility Check", avgResp: "110", p95: "200", errorRate: "1", availability: "99.23" },
          { name: "Lapse & Grace Period Validator", avgResp: "150", p95: "270", errorRate: "1", availability: "98.89" },
          { name: "Renewal Premium Calculator", avgResp: "180", p95: "310", errorRate: "2", availability: "98.56" },
        ],
        metrics: { happy: 95, unhappy: 3, frustrated: 2 },
      },
    ],
    "Premium Collection": [
      {
        step: "Payment Processing",
        actions: [
          { name: "NACH / ECS Mandate Processing", avgResp: "340", p95: "560", errorRate: "3", availability: "97.12" },
          { name: "UPI Collect (NPCI)", avgResp: "210", p95: "380", errorRate: "2", availability: "98.34" },
          { name: "Premium Allocation Engine", avgResp: "150", p95: "260", errorRate: "1", availability: "99.45" },
        ],
        metrics: { happy: 91, unhappy: 6, frustrated: 3 },
      },
    ],
  },

  /* ════════════════════════════════════════════════════════════
     CLAIMS MANAGEMENT SYSTEM
     ════════════════════════════════════════════════════════════ */
  "claims-mgmt": {
    "Claims Intimation (FNOL)": [
      {
        step: "First Notice Registration",
        actions: [
          { name: "FNOL Intake API", avgResp: "200", p95: "350", errorRate: "2", availability: "98.90" },
          { name: "Policy Coverage Verification", avgResp: "280", p95: "450", errorRate: "2", availability: "98.12" },
          { name: "Document Upload (Medical Reports)", avgResp: "450", p95: "780", errorRate: "3", availability: "97.23" },
          { name: "Claimant Notification Service", avgResp: "80", p95: "150", errorRate: "1", availability: "99.78" },
        ],
        metrics: { happy: 90, unhappy: 7, frustrated: 3 },
      },
    ],
    "Claims Assessment": [
      {
        step: "Investigation Initiation",
        actions: [
          { name: "Case Assignment Engine", avgResp: "210", p95: "380", errorRate: "2", availability: "98.12" },
          { name: "Surveyor / TPA Dispatch Service", avgResp: "340", p95: "560", errorRate: "3", availability: "96.78" },
          { name: "Document Collection API (FileNet)", avgResp: "280", p95: "450", errorRate: "2", availability: "97.45" },
        ],
        metrics: { happy: 85, unhappy: 10, frustrated: 5 },
      },
      {
        step: "Medical / Loss Assessment",
        actions: [
          { name: "Hospital Network Verification (TPA)", avgResp: "4800", p95: "7200", errorRate: "16", availability: "71.20", warning: true },
          { name: "ICD-10 Code Validation Service", avgResp: "120", p95: "210", errorRate: "2", availability: "98.56" },
          { name: "Loss Estimation Engine", avgResp: "560", p95: "890", errorRate: "4", availability: "95.12" },
        ],
        metrics: { happy: 72, unhappy: 18, frustrated: 10 },
      },
      {
        step: "Fraud Screening",
        actions: [
          { name: "Fraud Analytics Engine (SAS)", avgResp: "890", p95: "1300", errorRate: "4", availability: "94.56" },
          { name: "OFAC / Sanctions Watchlist Screening", avgResp: "340", p95: "520", errorRate: "2", availability: "97.89" },
          { name: "Behavioral Pattern Analyzer (ML)", avgResp: "450", p95: "780", errorRate: "3", availability: "96.34" },
        ],
        metrics: { happy: 88, unhappy: 8, frustrated: 4 },
      },
    ],
    "Claims Adjudication": [
      {
        step: "Decision Processing",
        actions: [
          { name: "Adjudication Rules Engine (Drools)", avgResp: "560", p95: "890", errorRate: "4", availability: "95.12" },
          { name: "Reserve Calculation API", avgResp: "340", p95: "520", errorRate: "3", availability: "96.78" },
          { name: "Authority Matrix / Approval Workflow", avgResp: "210", p95: "380", errorRate: "2", availability: "98.12" },
        ],
        metrics: { happy: 88, unhappy: 8, frustrated: 4 },
      },
    ],
    "Claims Settlement": [
      {
        step: "Payment Processing",
        actions: [
          { name: "Bank Account Validation (Penny Drop)", avgResp: "320", p95: "520", errorRate: "2", availability: "98.34" },
          { name: "NEFT / RTGS Payment Gateway", avgResp: "450", p95: "780", errorRate: "3", availability: "97.56" },
          { name: "TDS Deduction Calculator (IT Act)", avgResp: "120", p95: "210", errorRate: "1", availability: "99.12" },
        ],
        metrics: { happy: 93, unhappy: 4, frustrated: 3 },
      },
    ],
  },

  /* ════════════════════════════════════════════════════════════
     UNDERWRITING WORKBENCH
     ════════════════════════════════════════════════════════════ */
  "underwriting": {
    "Risk Assessment": [
      {
        step: "Risk Evaluation",
        actions: [
          { name: "Mortality Risk Scoring Engine", avgResp: "450", p95: "720", errorRate: "3", availability: "96.78" },
          { name: "Occupation Hazard Classifier", avgResp: "180", p95: "310", errorRate: "2", availability: "98.34" },
          { name: "Sum Assured Capacity Check", avgResp: "120", p95: "210", errorRate: "1", availability: "99.12" },
        ],
        metrics: { happy: 89, unhappy: 7, frustrated: 4 },
      },
    ],
    "Medical Underwriting": [
      {
        step: "Medical Data Collection",
        actions: [
          { name: "Tele-MER Integration (Video KYC)", avgResp: "890", p95: "1200", errorRate: "5", availability: "94.32" },
          { name: "Lab Report Aggregator (Pathology)", avgResp: "560", p95: "890", errorRate: "4", availability: "95.67" },
          { name: "Medical History API (MIB/CIBIL Health)", avgResp: "3500", p95: "5800", errorRate: "14", availability: "87.45", warning: true },
        ],
        metrics: { happy: 78, unhappy: 14, frustrated: 8 },
      },
      {
        step: "Risk Classification",
        actions: [
          { name: "Morbidity Assessment Engine", avgResp: "340", p95: "560", errorRate: "3", availability: "96.78" },
          { name: "Preferred Life Qualifier", avgResp: "180", p95: "310", errorRate: "2", availability: "98.12" },
          { name: "Extra Mortality Loading Calculator", avgResp: "120", p95: "210", errorRate: "1", availability: "99.34" },
        ],
        metrics: { happy: 90, unhappy: 7, frustrated: 3 },
      },
    ],
    "Financial Underwriting": [
      {
        step: "Financial Assessment",
        actions: [
          { name: "Income Verification (ITR/Form 16 OCR)", avgResp: "450", p95: "720", errorRate: "3", availability: "97.12" },
          { name: "Net Worth Estimation Engine", avgResp: "280", p95: "450", errorRate: "2", availability: "98.34" },
        ],
        metrics: { happy: 94, unhappy: 4, frustrated: 2 },
      },
    ],
    "Reinsurance Placement": [
      {
        step: "Treaty Matching",
        actions: [
          { name: "Reinsurance Treaty Lookup", avgResp: "210", p95: "380", errorRate: "2", availability: "98.56" },
          { name: "Facultative Quote Engine", avgResp: "340", p95: "560", errorRate: "2", availability: "98.12" },
        ],
        metrics: { happy: 96, unhappy: 3, frustrated: 1 },
      },
    ],
  },

  /* ════════════════════════════════════════════════════════════
     CUSTOMER SELF-SERVICE PORTAL
     ════════════════════════════════════════════════════════════ */
  "customer-portal": {
    "Login & Registration": [
      {
        step: "Authentication",
        actions: [
          { name: "SSO Gateway (Okta)", avgResp: "110", p95: "200", errorRate: "1", availability: "99.92" },
          { name: "OTP Service (MSG91)", avgResp: "180", p95: "320", errorRate: "2", availability: "99.67" },
          { name: "Session Token Manager", avgResp: "50", p95: "90", errorRate: "0.5", availability: "99.98" },
        ],
        metrics: { happy: 97, unhappy: 2, frustrated: 1 },
      },
    ],
    "Policy Servicing": [
      {
        step: "Self-Service Operations",
        actions: [
          { name: "Policy Dashboard API", avgResp: "180", p95: "310", errorRate: "2", availability: "98.56" },
          { name: "Nominee Change Service", avgResp: "280", p95: "450", errorRate: "2", availability: "97.89" },
          { name: "Address Update (DigiLocker)", avgResp: "340", p95: "560", errorRate: "3", availability: "97.12" },
        ],
        metrics: { happy: 94, unhappy: 4, frustrated: 2 },
      },
    ],
    "Premium Payment": [
      {
        step: "Online Payment",
        actions: [
          { name: "UPI / NetBanking Gateway", avgResp: "320", p95: "520", errorRate: "3", availability: "97.12" },
          { name: "Auto-Debit Mandate (NACH)", avgResp: "210", p95: "380", errorRate: "2", availability: "98.34" },
          { name: "Premium Receipt Generator", avgResp: "120", p95: "210", errorRate: "1", availability: "99.23" },
        ],
        metrics: { happy: 92, unhappy: 5, frustrated: 3 },
      },
    ],
    "Claims Filing": [
      {
        step: "Online Claim Submission",
        actions: [
          { name: "Claim Form Wizard API", avgResp: "210", p95: "380", errorRate: "3", availability: "96.78" },
          { name: "Medical Document OCR Service", avgResp: "890", p95: "1200", errorRate: "5", availability: "94.32" },
          { name: "Claim Status Tracker", avgResp: "120", p95: "210", errorRate: "1", availability: "99.12" },
        ],
        metrics: { happy: 86, unhappy: 9, frustrated: 5 },
      },
    ],
    "Fund Switch (ULIP)": [
      {
        step: "Fund Transfer",
        actions: [
          { name: "NAV Fetch Service (AMFI)", avgResp: "180", p95: "310", errorRate: "2", availability: "97.89" },
          { name: "Fund Switch Execution Engine", avgResp: "450", p95: "720", errorRate: "3", availability: "96.34" },
          { name: "Unit Allocation Calculator", avgResp: "120", p95: "210", errorRate: "1", availability: "99.12" },
        ],
        metrics: { happy: 90, unhappy: 7, frustrated: 3 },
      },
    ],
  },

  /* ════════════════════════════════════════════════════════════
     AGENT & DISTRIBUTOR PORTAL
     ════════════════════════════════════════════════════════════ */
  "agent-portal": {
    "Proposal Submission": [
      {
        step: "Digital Proposal",
        actions: [
          { name: "E-Proposal Form API", avgResp: "180", p95: "310", errorRate: "2", availability: "98.56" },
          { name: "Product Illustration Generator", avgResp: "340", p95: "560", errorRate: "3", availability: "97.12" },
          { name: "PIVC (Pre-Issuance Verification)", avgResp: "450", p95: "720", errorRate: "3", availability: "96.34" },
        ],
        metrics: { happy: 91, unhappy: 6, frustrated: 3 },
      },
    ],
    "Commission Statement": [
      {
        step: "Commission Processing",
        actions: [
          { name: "Commission Calculation Engine", avgResp: "560", p95: "890", errorRate: "3", availability: "97.12" },
          { name: "Clawback / Chargeback Processor", avgResp: "280", p95: "450", errorRate: "2", availability: "98.34" },
          { name: "Commission Statement PDF Service", avgResp: "340", p95: "560", errorRate: "2", availability: "98.56" },
        ],
        metrics: { happy: 95, unhappy: 3, frustrated: 2 },
      },
    ],
    "Persistency Tracking": [
      {
        step: "Persistency Monitoring",
        actions: [
          { name: "13th/25th Month Persistency API", avgResp: "210", p95: "380", errorRate: "2", availability: "97.89" },
          { name: "Lapse Prediction Model (ML)", avgResp: "450", p95: "720", errorRate: "3", availability: "96.45" },
        ],
        metrics: { happy: 93, unhappy: 5, frustrated: 2 },
      },
    ],
    "Lead Management": [
      {
        step: "Lead Distribution",
        actions: [
          { name: "Lead Scoring Engine", avgResp: "230", p95: "410", errorRate: "2", availability: "98.12" },
          { name: "Agent Territory Matcher", avgResp: "150", p95: "270", errorRate: "1", availability: "99.23" },
        ],
        metrics: { happy: 89, unhappy: 7, frustrated: 4 },
      },
    ],
    "Renewal Follow-up": [
      {
        step: "Renewal Outreach",
        actions: [
          { name: "Renewal Due List Generator", avgResp: "340", p95: "560", errorRate: "2", availability: "98.12" },
          { name: "WhatsApp / SMS Campaign Service", avgResp: "120", p95: "210", errorRate: "1", availability: "99.34" },
        ],
        metrics: { happy: 92, unhappy: 5, frustrated: 3 },
      },
    ],
  },
}

export function getPerformance(appId: string, journey: string): PerformanceStep[] {
  return JOURNEY_PERFORMANCE[appId]?.[journey] ?? []
}
