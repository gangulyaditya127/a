import { r as __toESM } from "../_runtime.mjs";
import { n as cn, r as getApp } from "./utils-C1QNtmDU.mjs";
import { n as require_react, r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { n as Link, o as useParams } from "../_libs/react-router.mjs";
import { D as GitBranch, I as ChevronRight, U as ArrowLeft, W as Activity, _ as Pause, a as TriangleAlert, c as Target, g as Play, h as RotateCcw, j as Clock, t as Zap, v as Network } from "../_libs/lucide-react.mjs";
import { t as getActionLayers } from "./layers-BECfAEif.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/S5DependencyGraph-BdZewIGM.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var TIER_ORDER = [
	"pres",
	"app",
	"integ",
	"data",
	"infra"
];
var STATUS_COLOR = {
	healthy: {
		fill: "hsl(var(--card))",
		stroke: "hsl(160 60% 45%)",
		text: "hsl(160 60% 35%)",
		badge: "bg-emerald-500/10 text-emerald-600 border-emerald-500/20"
	},
	degraded: {
		fill: "hsl(40 100% 96%)",
		stroke: "hsl(35 90% 55%)",
		text: "hsl(30 80% 40%)",
		badge: "bg-amber-500/10 text-amber-600 border-amber-500/20"
	},
	critical: {
		fill: "hsl(354 100% 97%)",
		stroke: "hsl(354 90% 55%)",
		text: "hsl(354 85% 42%)",
		badge: "bg-red-500/10 text-red-600 border-red-500/20"
	}
};
function tsToMs(ts) {
	if (!ts) return void 0;
	const parts = ts.split(":").map(Number);
	if (parts.some(isNaN)) return void 0;
	const [h = 0, m = 0, s = 0] = parts;
	return h * 36e5 + m * 6e4 + s * 1e3;
}
function S5DependencyGraph() {
	const { appId, journey } = useParams();
	const app = getApp(appId ?? "");
	const journeyName = decodeURIComponent(journey ?? "");
	const data = getActionLayers(appId ?? "", journeyName);
	const [selected, setSelected] = (0, import_react.useState)(null);
	const [playing, setPlaying] = (0, import_react.useState)(false);
	const [playCursor, setPlayCursor] = (0, import_react.useState)(0);
	const nodes = (0, import_react.useMemo)(() => {
		const out = [];
		data.tiers.forEach((tier) => {
			const tierIndex = TIER_ORDER.indexOf(tier.id) === -1 ? out.length : TIER_ORDER.indexOf(tier.id);
			tier.layers.forEach((layer) => {
				const alerts = layer.connectors.flatMap((c) => c.alerts);
				const firstAlert = alerts.filter((a) => a.timestamp).sort((a, b) => tsToMs(a.timestamp) - tsToMs(b.timestamp))[0];
				out.push({
					id: `${tier.id}::${layer.id}`,
					tierId: tier.id,
					tierName: tier.name,
					tierIndex,
					layer,
					alertCount: alerts.length,
					status: layer.status,
					firstAlertTs: firstAlert?.timestamp,
					firstAlertMs: tsToMs(firstAlert?.timestamp),
					sources: layer.connectors
				});
			});
		});
		return out;
	}, [data]);
	const edges = (0, import_react.useMemo)(() => {
		const out = [];
		const byTier = /* @__PURE__ */ new Map();
		nodes.forEach((n) => {
			if (!byTier.has(n.tierId)) byTier.set(n.tierId, []);
			byTier.get(n.tierId).push(n);
		});
		for (let i = 0; i < data.tiers.length - 1; i++) {
			const a = byTier.get(data.tiers[i].id) ?? [];
			const b = byTier.get(data.tiers[i + 1].id) ?? [];
			a.forEach((na) => {
				b.forEach((nb) => {
					const bothBad = na.status !== "healthy" && nb.status !== "healthy";
					out.push({
						from: na.id,
						to: nb.id,
						weight: bothBad ? .9 : .25,
						critical: na.status === "critical" && nb.status === "critical"
					});
				});
			});
		}
		return out;
	}, [nodes, data]);
	const timeline = (0, import_react.useMemo)(() => {
		const events = [];
		data.tiers.forEach((tier) => {
			tier.layers.forEach((layer) => {
				layer.connectors.forEach((conn) => {
					conn.alerts.forEach((a) => {
						const ms = tsToMs(a.timestamp);
						if (ms == null) return;
						events.push({
							ms,
							ts: a.timestamp,
							nodeId: `${tier.id}::${layer.id}`,
							layerName: layer.name,
							tierName: tier.name,
							severity: a.severity,
							message: a.message,
							source: conn.name,
							alertId: a.id
						});
					});
				});
			});
		});
		return events.sort((a, b) => a.ms - b.ms);
	}, [data]);
	const rootCauseNodeId = timeline.find((e) => e.severity === "critical")?.nodeId ?? timeline[0]?.nodeId;
	const rootCauseEvent = timeline.find((e) => e.nodeId === rootCauseNodeId);
	(0, import_react.useEffect)(() => {
		if (!playing) return;
		if (playCursor >= timeline.length - 1) {
			setPlaying(false);
			return;
		}
		const t = setTimeout(() => setPlayCursor((c) => c + 1), 900);
		return () => clearTimeout(t);
	}, [
		playing,
		playCursor,
		timeline.length
	]);
	const COL_W = 250;
	const NODE_W = 210;
	const NODE_H = 82;
	const V_GAP = 22;
	const PAD_X = 24;
	const PAD_Y = 32;
	const nodesByTier = (0, import_react.useMemo)(() => {
		const map = /* @__PURE__ */ new Map();
		data.tiers.forEach((t, i) => {
			map.set(t.id, nodes.filter((n) => n.tierId === t.id).map((n) => ({
				...n,
				tierIndex: i
			})));
		});
		return map;
	}, [nodes, data]);
	const maxRows = Math.max(...Array.from(nodesByTier.values()).map((ns) => ns.length), 1);
	const svgW = data.tiers.length * COL_W + PAD_X * 2;
	const svgH = maxRows * 104 + PAD_Y * 2 + 60;
	const nodePos = /* @__PURE__ */ new Map();
	data.tiers.forEach((tier, ci) => {
		const list = nodesByTier.get(tier.id) ?? [];
		const colX = PAD_X + ci * COL_W + (COL_W - NODE_W) / 2;
		const colTotalH = list.length * NODE_H + (list.length - 1) * V_GAP;
		const startY = 72 + (maxRows * 104 - colTotalH) / 2;
		list.forEach((n, ri) => {
			nodePos.set(n.id, {
				x: colX,
				y: startY + ri * 104
			});
		});
	});
	const activeNodes = (0, import_react.useMemo)(() => {
		if (!playing && playCursor === 0) return new Set(nodes.filter((n) => n.alertCount > 0).map((n) => n.id));
		const cutMs = timeline[Math.min(playCursor, timeline.length - 1)]?.ms ?? Infinity;
		const s = /* @__PURE__ */ new Set();
		nodes.forEach((n) => {
			if (n.firstAlertMs != null && n.firstAlertMs <= cutMs) s.add(n.id);
		});
		return s;
	}, [
		playing,
		playCursor,
		timeline,
		nodes
	]);
	const selectedNode = nodes.find((n) => n.id === selected) ?? null;
	const svgWrapRef = (0, import_react.useRef)(null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "w-full px-6 my-6 mb-16",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: `/${appId}/${journey}/timeline`,
				className: "inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-brand mb-4 transition-colors",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "h-4 w-4" }), " Back to Technical Layers"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
				className: "flex items-center gap-1.5 mb-4 rounded-md border border-brand/20 bg-brand-soft/55 px-2.5 py-1.5 text-[11.5px] w-fit text-muted-foreground",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "hover:text-brand transition-colors",
						children: "Home"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-3 w-3 text-brand/45" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: `/${appId}`,
						className: "hover:text-brand transition-colors",
						children: app?.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-3 w-3 text-brand/45" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: `/${appId}/${journey}`,
						className: "hover:text-brand transition-colors",
						children: journeyName
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-3 w-3 text-brand/45" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: `/${appId}/${journey}/timeline`,
						className: "hover:text-brand transition-colors",
						children: "Technical Layers"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-3 w-3 text-brand/45" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "rounded-sm bg-card px-1.5 py-0.5 font-semibold text-foreground shadow-sm ring-1 ring-border/70",
						children: "CI Dependency Graph"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-4 mb-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
						className: "text-sm font-medium uppercase text-muted-foreground flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Network, { className: "h-4 w-4 text-brand" }), " Event Correlation Engine — CI Dependency Layer"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3 mt-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-2.5 w-2.5 rounded-[3px] bg-brand" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-2xl font-semibold text-foreground",
							children: journeyName
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground mt-1 max-w-3xl",
						children: "Topological + temporal view of Configuration Items impacted by the correlated event. Edges show upstream/downstream dependencies; the pulsing node marks the earliest fault (root cause). Use the timeline scrubber to replay the fault cascade."
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => {
								setPlayCursor(0);
								setPlaying(true);
							},
							className: "inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium border border-brand/30 bg-brand-soft text-brand hover:bg-brand hover:text-white transition-colors",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "h-3.5 w-3.5" }), " Replay cascade"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => setPlaying((p) => !p),
							disabled: timeline.length === 0,
							className: "inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium border border-border bg-card hover:bg-accent transition-colors",
							children: [playing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "h-3.5 w-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "h-3.5 w-3.5" }), playing ? "Pause" : "Play"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => {
								setPlaying(false);
								setPlayCursor(0);
							},
							className: "inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium border border-border bg-card hover:bg-accent transition-colors",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "h-3.5 w-3.5" }), " Reset"]
						})
					]
				})]
			}),
			rootCauseEvent && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4 rounded-xl border border-red-500/30 bg-red-500/[0.04] p-4 flex items-start gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-8 w-8 rounded-full grid place-items-center bg-red-500/15 shrink-0",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Target, { className: "h-4 w-4 text-red-600" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex-1 min-w-0",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 flex-wrap",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs font-bold uppercase tracking-wider text-red-600",
									children: "Root Cause (earliest event)"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] font-mono text-muted-foreground",
									children: rootCauseEvent.alertId
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xs text-muted-foreground flex items-center gap-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "h-3 w-3" }),
										" ",
										rootCauseEvent.ts
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xs px-2 py-0.5 rounded-md border border-brand/20 bg-brand-soft text-brand font-medium",
									children: [
										rootCauseEvent.tierName,
										" → ",
										rootCauseEvent.layerName
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xs text-muted-foreground",
									children: ["Source: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-foreground font-medium",
										children: rootCauseEvent.source
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-foreground mt-1.5",
							children: rootCauseEvent.message
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground mt-1 italic",
							children: data.summary.rootCauseHint
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4 flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatChip, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "h-3.5 w-3.5" }),
						label: "Total alerts",
						value: data.summary.totalAlerts
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatChip, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Activity, { className: "h-3.5 w-3.5" }),
						label: "CIs impacted",
						value: data.summary.affectedLayers
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatChip, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GitBranch, { className: "h-3.5 w-3.5" }),
						label: "Sources correlated",
						value: data.summary.connectors
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatChip, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "h-3.5 w-3.5" }),
						label: "Cascade span",
						value: timeline.length > 0 ? formatSpan(timeline[timeline.length - 1].ms - timeline[0].ms) : "—"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 xl:grid-cols-[1fr_360px] gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl border border-border bg-card shadow-card overflow-hidden",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between px-4 py-3 border-b border-border",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Network, { className: "h-4 w-4 text-brand" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm font-semibold text-foreground",
									children: "Topology — CI dependency graph"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3 text-[11px] text-muted-foreground",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LegendDot, {
										color: "hsl(354 90% 55%)",
										label: "Critical"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LegendDot, {
										color: "hsl(35 90% 55%)",
										label: "Degraded"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LegendDot, {
										color: "hsl(160 60% 45%)",
										label: "Healthy"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "ml-2",
										children: [
											"Edges: ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-red-600 font-medium",
												children: "red"
											}),
											" = correlated fault path"
										]
									})
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							ref: svgWrapRef,
							className: "overflow-auto scrollbar-thin",
							style: { maxHeight: 640 },
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
								width: svgW,
								height: svgH,
								className: "block",
								children: [
									data.tiers.map((t, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
										x: PAD_X + i * COL_W + 6,
										y: 8,
										width: COL_W - 12,
										height: 26,
										rx: 6,
										fill: "hsl(var(--secondary))"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
										x: PAD_X + i * COL_W + COL_W / 2,
										y: 25,
										textAnchor: "middle",
										className: "fill-foreground",
										style: {
											fontSize: 11,
											fontWeight: 600,
											letterSpacing: .5
										},
										children: t.name.toUpperCase()
									})] }, t.id)),
									edges.map((e, i) => {
										const a = nodePos.get(e.from);
										const b = nodePos.get(e.to);
										if (!a || !b) return null;
										const activeA = activeNodes.has(e.from);
										const activeB = activeNodes.has(e.to);
										const bothActive = activeA && activeB;
										const stroke = e.critical && bothActive ? "hsl(354 90% 55%)" : bothActive ? "hsl(35 90% 55%)" : "hsl(var(--border))";
										const width = e.critical && bothActive ? 2.2 : bothActive ? 1.4 : 1;
										const opacity = bothActive ? .9 : .4;
										const x1 = a.x + NODE_W, y1 = a.y + NODE_H / 2;
										const x2 = b.x, y2 = b.y + NODE_H / 2;
										const cx = (x1 + x2) / 2;
										const path = `M ${x1} ${y1} C ${cx} ${y1}, ${cx} ${y2}, ${x2} ${y2}`;
										return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
											d: path,
											fill: "none",
											stroke,
											strokeWidth: width,
											opacity
										}), e.critical && bothActive && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
											r: 2.5,
											fill: "hsl(354 90% 55%)",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("animateMotion", {
												dur: "2.4s",
												repeatCount: "indefinite",
												path
											})
										})] }, i);
									}),
									nodes.map((n) => {
										const p = nodePos.get(n.id);
										const c = STATUS_COLOR[n.status];
										const active = activeNodes.has(n.id);
										const isRoot = n.id === rootCauseNodeId;
										const isSel = n.id === selected;
										return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
											transform: `translate(${p.x}, ${p.y})`,
											style: { cursor: "pointer" },
											onClick: () => setSelected(n.id === selected ? null : n.id),
											children: [
												isRoot && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
													x: -6,
													y: -6,
													width: 222,
													height: 94,
													rx: 12,
													fill: "none",
													stroke: "hsl(354 90% 55%)",
													strokeWidth: 2,
													strokeDasharray: "4 4",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("animate", {
														attributeName: "stroke-dashoffset",
														from: "0",
														to: "16",
														dur: "1.2s",
														repeatCount: "indefinite"
													})
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
													width: NODE_W,
													height: NODE_H,
													rx: 10,
													fill: active ? c.fill : "hsl(var(--card))",
													stroke: isSel ? "hsl(var(--brand))" : c.stroke,
													strokeWidth: isSel ? 2.5 : 1.5,
													opacity: active ? 1 : .55
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
													x: 12,
													y: 22,
													style: {
														fontSize: 12,
														fontWeight: 600
													},
													className: "fill-foreground",
													children: truncate(n.layer.name, 26)
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
													x: 12,
													y: 38,
													style: { fontSize: 10.5 },
													className: "fill-muted-foreground",
													children: truncate(n.layer.technology, 34)
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
													x: 12,
													y: NODE_H - 26,
													width: 54,
													height: 18,
													rx: 4,
													fill: c.stroke,
													opacity: .14
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
													x: 39,
													y: NODE_H - 13,
													textAnchor: "middle",
													style: {
														fontSize: 10,
														fontWeight: 700
													},
													fill: c.stroke,
													children: n.status.toUpperCase()
												}),
												n.alertCount > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
													x: 72,
													y: NODE_H - 26,
													width: 64,
													height: 18,
													rx: 4,
													fill: "hsl(354 90% 55%)",
													opacity: .14
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("text", {
													x: 104,
													y: NODE_H - 13,
													textAnchor: "middle",
													style: {
														fontSize: 10,
														fontWeight: 700
													},
													fill: "hsl(354 90% 42%)",
													children: [
														n.alertCount,
														" alert",
														n.alertCount === 1 ? "" : "s"
													]
												})] }),
												n.firstAlertTs && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
													x: NODE_W - 12,
													y: NODE_H - 13,
													textAnchor: "end",
													style: {
														fontSize: 10,
														fontFamily: "monospace"
													},
													className: "fill-muted-foreground",
													children: n.firstAlertTs
												})
											]
										}, n.id);
									})
								]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "border-t border-border p-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between mb-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "h-4 w-4 text-brand" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-sm font-semibold text-foreground",
										children: "Temporal correlation — event cascade"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-[11px] text-muted-foreground",
									children: [
										timeline.length,
										" events · replay position ",
										playCursor + 1,
										"/",
										timeline.length || 1
									]
								})]
							}), timeline.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative h-14 rounded-md bg-secondary/50 border border-border",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute left-4 right-4 top-1/2 h-px bg-border" }),
									timeline.map((e, i) => {
										const span = timeline[timeline.length - 1].ms - timeline[0].ms || 1;
										const pct = (e.ms - timeline[0].ms) / span * 100;
										const color = e.severity === "critical" ? "bg-red-500" : e.severity === "high" ? "bg-orange-500" : e.severity === "medium" ? "bg-amber-500" : "bg-emerald-500";
										const passed = i <= playCursor;
										return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											onClick: () => {
												setPlaying(false);
												setPlayCursor(i);
												setSelected(e.nodeId);
											},
											title: `${e.ts} — ${e.layerName}: ${e.message}`,
											className: cn("absolute -translate-x-1/2 -translate-y-1/2 top-1/2 h-3 w-3 rounded-full border-2 border-card transition-all", color, passed ? "opacity-100 scale-100" : "opacity-40 scale-75", i === playCursor && "ring-2 ring-brand ring-offset-1 ring-offset-card scale-125"),
											style: { left: `calc(1rem + ${pct}% * (100% - 2rem) / 100%)` }
										}, i);
									}),
									timeline[playCursor] && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "absolute -translate-x-1/2 top-full mt-1 text-[10px] font-mono text-muted-foreground whitespace-nowrap",
										style: { left: `calc(1rem + ${(timeline[playCursor].ms - timeline[0].ms) / (timeline[timeline.length - 1].ms - timeline[0].ms || 1) * 100}% * (100% - 2rem) / 100%)` },
										children: timeline[playCursor].ts
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-4 rounded-md border border-border bg-secondary/30 p-2.5 text-xs",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] font-mono text-muted-foreground mr-2",
										children: timeline[playCursor]?.ts
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-medium text-foreground",
										children: timeline[playCursor]?.layerName
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-muted-foreground",
										children: [" · ", timeline[playCursor]?.source]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-muted-foreground mt-1",
										children: timeline[playCursor]?.message
									})
								]
							})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: "No timestamped alerts for this journey."
							})]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl border border-border bg-card shadow-card overflow-hidden",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "px-4 py-3 border-b border-border flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, { className: "h-4 w-4 text-brand" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm font-semibold text-foreground",
							children: selectedNode ? "Selected CI" : "Fault propagation path"
						})]
					}), selectedNode ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "p-4 space-y-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] uppercase tracking-wider text-muted-foreground",
									children: selectedNode.tierName
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-base font-semibold text-foreground",
									children: selectedNode.layer.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground",
									children: selectedNode.layer.technology
								})
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2 flex-wrap",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: cn("text-[10px] font-bold px-2 py-0.5 rounded uppercase border", STATUS_COLOR[selectedNode.status].badge),
										children: selectedNode.status
									}),
									selectedNode.alertCount > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-[10px] font-bold px-2 py-0.5 rounded border bg-red-500/10 text-red-600 border-red-500/20",
										children: [selectedNode.alertCount, " alerts"]
									}),
									selectedNode.firstAlertTs && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-[10px] font-mono text-muted-foreground flex items-center gap-1",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "h-3 w-3" }),
											" first at ",
											selectedNode.firstAlertTs
										]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] uppercase tracking-wider text-muted-foreground mb-1.5",
								children: "Monitoring sources"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex flex-wrap gap-1.5",
								children: selectedNode.sources.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: cn("inline-flex items-center gap-1 text-[10.5px] px-2 py-1 rounded border font-medium", c.status === "healthy" ? "bg-secondary text-secondary-foreground border-border" : STATUS_COLOR[c.status === "alerting" ? "degraded" : c.status].badge),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("h-1.5 w-1.5 rounded-full", c.status === "healthy" ? "bg-emerald-500" : c.status === "alerting" ? "bg-amber-500" : "bg-red-500") }),
										c.name,
										c.alerts.length > 0 && ` [${c.alerts.length}]`
									]
								}, c.id))
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] uppercase tracking-wider text-muted-foreground mb-1.5",
								children: "Events on this CI"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5 max-h-72 overflow-y-auto pr-1",
								children: [selectedNode.sources.flatMap((c) => c.alerts.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-md border border-border bg-secondary/30 p-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2 flex-wrap",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: cn("text-[9px] font-bold px-1.5 py-0.5 rounded uppercase", a.severity === "critical" ? "bg-red-500/15 text-red-600" : a.severity === "high" ? "bg-orange-500/15 text-orange-600" : a.severity === "medium" ? "bg-amber-500/15 text-amber-600" : "bg-emerald-500/15 text-emerald-600"),
													children: a.severity
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[10px] font-mono text-muted-foreground",
													children: a.id
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "text-[10px] text-muted-foreground",
													children: ["· ", c.name]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[10px] font-mono text-muted-foreground ml-auto",
													children: a.timestamp
												})
											]
										}),
										a.eventname && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs font-semibold text-foreground mt-1",
											children: a.eventname
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs text-muted-foreground mt-0.5 leading-snug",
											children: a.message
										})
									]
								}, a.id))), selectedNode.alertCount === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground italic",
									children: "No open events on this CI."
								})]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => setSelected(null),
								className: "w-full text-xs font-medium px-3 py-1.5 rounded-md border border-border bg-card hover:bg-accent transition-colors",
								children: "Clear selection"
							})
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "p-4 space-y-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-muted-foreground",
								children: [
									"The correlation engine linked ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-foreground font-semibold",
										children: [data.summary.totalAlerts, " alerts"]
									}),
									" ",
									"from ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-foreground font-semibold",
										children: [data.summary.connectors, " sources"]
									}),
									" across",
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-foreground font-semibold",
										children: [data.summary.affectedLayers, " CIs"]
									}),
									" into a single incident."
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] uppercase tracking-wider text-muted-foreground mb-2",
								children: "Inferred cascade"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
								className: "space-y-2",
								children: inferCascade(nodes, timeline).map((step, i, arr) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex items-start gap-2.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: cn("h-5 w-5 shrink-0 rounded-full grid place-items-center text-[10px] font-bold text-white", i === 0 ? "bg-red-500" : i === arr.length - 1 ? "bg-brand" : "bg-amber-500"),
										children: i + 1
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "min-w-0",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs font-semibold text-foreground truncate",
											children: step.layer.name
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-[10px] text-muted-foreground",
											children: [
												step.tierName,
												" · ",
												step.firstAlertTs ?? "—"
											]
										})]
									})]
								}, step.id))
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] text-muted-foreground italic",
								children: "Click any node to inspect its events and sources."
							})
						]
					})]
				})]
			})
		]
	});
}
function StatChip({ icon, label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "inline-flex items-center gap-2 rounded-md border border-border bg-card px-2.5 py-1.5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-brand",
				children: icon
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-[11px] text-muted-foreground",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-xs font-semibold text-foreground",
				children: value
			})
		]
	});
}
function LegendDot({ color, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "inline-flex items-center gap-1.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "h-2 w-2 rounded-full",
			style: { background: color }
		}), label]
	});
}
function truncate(s, n) {
	return s.length > n ? s.slice(0, n - 1) + "…" : s;
}
function formatSpan(ms) {
	if (ms < 0 || !isFinite(ms)) return "—";
	const s = Math.round(ms / 1e3);
	if (s < 60) return `${s}s`;
	return `${Math.floor(s / 60)}m ${s % 60}s`;
}
function inferCascade(nodes, timeline) {
	const firstSeen = /* @__PURE__ */ new Map();
	timeline.forEach((e) => {
		if (!firstSeen.has(e.nodeId)) firstSeen.set(e.nodeId, e.ms);
	});
	return nodes.filter((n) => firstSeen.has(n.id)).sort((a, b) => firstSeen.get(a.id) - firstSeen.get(b.id)).slice(0, 6);
}
//#endregion
export { S5DependencyGraph as default };
