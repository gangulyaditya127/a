import { r as __toESM } from "../_runtime.mjs";
import { n as cn, r as getApp } from "./utils-C1QNtmDU.mjs";
import { n as require_react, r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { n as Link, o as useParams } from "../_libs/react-router.mjs";
import { A as Cpu, B as Brain, C as Layers, D as GitBranch, E as Globe, F as CircleCheck, I as ChevronRight, N as Circle, O as FileText, R as Cable, S as LoaderCircle, T as HardDrive, U as ArrowLeft, V as Box, W as Activity, _ as Pause, a as TriangleAlert, b as Monitor, c as Target, d as Shield, g as Play, h as RotateCcw, j as Clock, k as Database, l as Sparkles, m as Search, n as Workflow, o as TrendingUp, p as Server, r as Wifi, s as TrendingDown, t as Zap, u as Shuffle, x as Minus, y as MoveRight } from "../_libs/lucide-react.mjs";
import { a as generateChartData, i as PREDICTIVE_RISKS, n as HEALING_LOGS, o as useAppDispatch, r as NOISE_REDUCTION, s as useAppSelector, t as CORRELATION_INCIDENTS } from "./hooks-BiobBJ1_.mjs";
import { n as runAutoFixFlow } from "./agent-flow-slice-Bfjw2cpe.mjs";
import { a as Tooltip, i as Area, n as YAxis, o as ResponsiveContainer, r as XAxis, t as AreaChart } from "../_libs/recharts+victory-vendor.mjs";
import { t as getActionLayers } from "./layers-BECfAEif.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/S5Timeline-BNpRt3c3.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var STATUS_COLOR = {
	healthy: {
		fill: "hsl(var(--card))",
		stroke: "hsl(160 60% 45%)",
		badge: "bg-emerald-500/10 text-emerald-600 border-emerald-500/20"
	},
	degraded: {
		fill: "hsl(40 100% 96%)",
		stroke: "hsl(35 90% 55%)",
		badge: "bg-amber-500/10 text-amber-600 border-amber-500/20"
	},
	critical: {
		fill: "hsl(354 100% 97%)",
		stroke: "hsl(354 90% 55%)",
		badge: "bg-red-500/10 text-red-600 border-red-500/20"
	}
};
function tsToMs(ts) {
	if (!ts) return void 0;
	const parts = ts.split(":").map(Number);
	if (parts.some(isNaN)) return void 0;
	const [h = 0, m = 0, s = 0] = parts;
	return h * 36e5 + m * 6e4 + s * 1e3;
}
function DependencyGraphInline({ data }) {
	const [selected, setSelected] = (0, import_react.useState)(null);
	const [playing, setPlaying] = (0, import_react.useState)(false);
	const [playCursor, setPlayCursor] = (0, import_react.useState)(0);
	const nodes = (0, import_react.useMemo)(() => {
		const out = [];
		data.tiers.forEach((tier, tierIndex) => {
			tier.layers.forEach((layer) => {
				const alerts = layer.connectors.flatMap((c) => c.alerts);
				const firstAlert = alerts.filter((a) => a.timestamp).sort((a, b) => tsToMs(a.timestamp) - tsToMs(b.timestamp))[0];
				out.push({
					id: `${tier.id}::${layer.id}`,
					tierId: tier.id,
					tierName: tier.name,
					tierIndex,
					layer,
					alertCount: alerts.length,
					status: layer.status,
					firstAlertTs: firstAlert?.timestamp,
					firstAlertMs: tsToMs(firstAlert?.timestamp),
					sources: layer.connectors
				});
			});
		});
		return out;
	}, [data]);
	const edges = (0, import_react.useMemo)(() => {
		const out = [];
		const byTier = /* @__PURE__ */ new Map();
		nodes.forEach((n) => {
			if (!byTier.has(n.tierId)) byTier.set(n.tierId, []);
			byTier.get(n.tierId).push(n);
		});
		for (let i = 0; i < data.tiers.length - 1; i++) {
			const a = byTier.get(data.tiers[i].id) ?? [];
			const b = byTier.get(data.tiers[i + 1].id) ?? [];
			a.forEach((na) => b.forEach((nb) => {
				const bothBad = na.status !== "healthy" && nb.status !== "healthy";
				out.push({
					from: na.id,
					to: nb.id,
					weight: bothBad ? .9 : .25,
					critical: na.status === "critical" && nb.status === "critical"
				});
			}));
		}
		return out;
	}, [nodes, data]);
	const timeline = (0, import_react.useMemo)(() => {
		const events = [];
		data.tiers.forEach((tier) => tier.layers.forEach((layer) => layer.connectors.forEach((conn) => conn.alerts.forEach((a) => {
			const ms = tsToMs(a.timestamp);
			if (ms == null) return;
			events.push({
				ms,
				ts: a.timestamp,
				nodeId: `${tier.id}::${layer.id}`,
				layerName: layer.name,
				tierName: tier.name,
				severity: a.severity,
				message: a.message,
				source: conn.name,
				alertId: a.id
			});
		}))));
		return events.sort((a, b) => a.ms - b.ms);
	}, [data]);
	const rootCauseNodeId = (0, import_react.useMemo)(() => {
		const tierRank = new Map(data.tiers.map((t, i) => [t.id, i]));
		const criticalNodes = nodes.filter((n) => n.status === "critical" && n.alertCount > 0);
		if (criticalNodes.length) {
			criticalNodes.sort((a, b) => tierRank.get(b.tierId) - tierRank.get(a.tierId) || (a.firstAlertMs ?? 0) - (b.firstAlertMs ?? 0));
			return criticalNodes[0].id;
		}
		return timeline[0]?.nodeId;
	}, [
		nodes,
		timeline,
		data
	]);
	const rootCauseEvent = timeline.find((e) => e.nodeId === rootCauseNodeId);
	(0, import_react.useEffect)(() => {
		if (!playing) return;
		if (playCursor >= timeline.length - 1) {
			setPlaying(false);
			return;
		}
		const t = setTimeout(() => setPlayCursor((c) => c + 1), 900);
		return () => clearTimeout(t);
	}, [
		playing,
		playCursor,
		timeline.length
	]);
	const COL_W = 230, NODE_W = 200, NODE_H = 82, V_GAP = 22, PAD_X = 20, PAD_Y = 32;
	const nodesByTier = (0, import_react.useMemo)(() => {
		const map = /* @__PURE__ */ new Map();
		data.tiers.forEach((t) => {
			map.set(t.id, nodes.filter((n) => n.tierId === t.id));
		});
		return map;
	}, [nodes, data]);
	const maxRows = Math.max(...Array.from(nodesByTier.values()).map((ns) => ns.length), 1);
	const svgW = data.tiers.length * COL_W + PAD_X * 2;
	const svgH = maxRows * 104 + PAD_Y * 2 + 60;
	const nodePos = /* @__PURE__ */ new Map();
	data.tiers.forEach((tier, ci) => {
		const list = nodesByTier.get(tier.id) ?? [];
		const colX = PAD_X + ci * COL_W + (COL_W - NODE_W) / 2;
		const colTotalH = list.length * NODE_H + (list.length - 1) * V_GAP;
		const startY = 72 + (maxRows * 104 - colTotalH) / 2;
		list.forEach((n, ri) => nodePos.set(n.id, {
			x: colX,
			y: startY + ri * 104
		}));
	});
	const activeNodes = (0, import_react.useMemo)(() => {
		if (!playing && playCursor === 0) return new Set(nodes.filter((n) => n.alertCount > 0).map((n) => n.id));
		const cutMs = timeline[Math.min(playCursor, timeline.length - 1)]?.ms ?? Infinity;
		const s = /* @__PURE__ */ new Set();
		nodes.forEach((n) => {
			if (n.firstAlertMs != null && n.firstAlertMs <= cutMs) s.add(n.id);
		});
		return s;
	}, [
		playing,
		playCursor,
		timeline,
		nodes
	]);
	const selectedNode = nodes.find((n) => n.id === selected) ?? null;
	const svgWrapRef = (0, import_react.useRef)(null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg border border-border bg-card overflow-hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "px-4 py-3 border-b border-border flex items-center justify-end gap-3 bg-secondary/30",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => {
							setPlayCursor(0);
							setPlaying(true);
						},
						className: "inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-[11px] font-medium border border-brand/30 bg-brand-soft text-brand hover:bg-brand hover:text-white transition-colors",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "h-3 w-3" }), " Replay cascade"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => setPlaying((p) => !p),
						disabled: timeline.length === 0,
						className: "inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-[11px] font-medium border border-border bg-card hover:bg-accent transition-colors",
						children: [playing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "h-3 w-3" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "h-3 w-3" }), playing ? "Pause" : "Play"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => {
							setPlaying(false);
							setPlayCursor(0);
						},
						className: "inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-[11px] font-medium border border-border bg-card hover:bg-accent transition-colors",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "h-3 w-3" }), " Reset"]
					})
				]
			}),
			rootCauseEvent && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-4 mt-4 rounded-lg border border-red-500/30 bg-red-500/[0.04] p-3 flex items-start gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-7 w-7 rounded-full grid place-items-center bg-red-500/15 shrink-0",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Target, { className: "h-3.5 w-3.5 text-red-600" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex-1 min-w-0",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 flex-wrap",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] font-bold uppercase tracking-wider text-red-600",
									children: "Root Cause"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] font-mono text-muted-foreground",
									children: rootCauseEvent.alertId
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-[11px] text-muted-foreground flex items-center gap-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "h-3 w-3" }),
										" ",
										rootCauseEvent.ts
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-[11px] px-2 py-0.5 rounded-md border border-brand/20 bg-brand-soft text-brand font-medium",
									children: [
										rootCauseEvent.tierName,
										" → ",
										rootCauseEvent.layerName
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-[11px] text-muted-foreground",
									children: ["Source: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-foreground font-medium",
										children: rootCauseEvent.source
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-foreground mt-1",
							children: rootCauseEvent.message
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] text-muted-foreground mt-0.5 italic",
							children: data.summary.rootCauseHint
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "px-4 pt-3 flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatChip, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "h-3.5 w-3.5" }),
						label: "Total alerts",
						value: data.summary.totalAlerts
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatChip, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Activity, { className: "h-3.5 w-3.5" }),
						label: "CIs impacted",
						value: data.summary.affectedLayers
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatChip, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GitBranch, { className: "h-3.5 w-3.5" }),
						label: "Sources",
						value: data.summary.connectors
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatChip, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "h-3.5 w-3.5" }),
						label: "Cascade span",
						value: timeline.length > 0 ? formatSpan(timeline[timeline.length - 1].ms - timeline[0].ms) : "—"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "p-4 grid grid-cols-1 xl:grid-cols-[1fr_320px] gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-lg border border-border bg-background overflow-hidden",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between px-3 py-2 border-b border-border",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2 text-[11px] text-muted-foreground",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LegendDot, {
										color: "hsl(354 90% 55%)",
										label: "Critical"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LegendDot, {
										color: "hsl(35 90% 55%)",
										label: "Degraded"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LegendDot, {
										color: "hsl(160 60% 45%)",
										label: "Healthy"
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-[11px] text-muted-foreground",
								children: [
									"Edges: ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-red-600 font-medium",
										children: "red"
									}),
									" = correlated fault path"
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							ref: svgWrapRef,
							className: "overflow-auto",
							style: { maxHeight: 560 },
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
								width: svgW,
								height: svgH,
								className: "block",
								children: [
									data.tiers.map((t, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
										x: PAD_X + i * COL_W + 6,
										y: 8,
										width: COL_W - 12,
										height: 26,
										rx: 6,
										fill: "hsl(var(--secondary))"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
										x: PAD_X + i * COL_W + COL_W / 2,
										y: 25,
										textAnchor: "middle",
										className: "fill-foreground",
										style: {
											fontSize: 11,
											fontWeight: 600,
											letterSpacing: .5
										},
										children: t.name.replace(" / Middleware Tier", "").replace(" Tier", "").toUpperCase()
									})] }, t.id)),
									edges.map((e, i) => {
										const a = nodePos.get(e.from);
										const b = nodePos.get(e.to);
										if (!a || !b) return null;
										const bothActive = activeNodes.has(e.from) && activeNodes.has(e.to);
										const stroke = e.critical && bothActive ? "hsl(354 90% 55%)" : bothActive ? "hsl(35 90% 55%)" : "hsl(var(--border))";
										const width = e.critical && bothActive ? 2.2 : bothActive ? 1.4 : 1;
										const opacity = bothActive ? .9 : .35;
										const x1 = a.x + NODE_W, y1 = a.y + NODE_H / 2;
										const x2 = b.x, y2 = b.y + NODE_H / 2;
										const cx = (x1 + x2) / 2;
										const path = `M ${x1} ${y1} C ${cx} ${y1}, ${cx} ${y2}, ${x2} ${y2}`;
										return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
											d: path,
											fill: "none",
											stroke,
											strokeWidth: width,
											opacity
										}), e.critical && bothActive && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
											r: 2.5,
											fill: "hsl(354 90% 55%)",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("animateMotion", {
												dur: "2.4s",
												repeatCount: "indefinite",
												path
											})
										})] }, i);
									}),
									nodes.map((n) => {
										const p = nodePos.get(n.id);
										const c = STATUS_COLOR[n.status];
										const active = activeNodes.has(n.id);
										const isRoot = n.id === rootCauseNodeId;
										const isSel = n.id === selected;
										return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
											transform: `translate(${p.x}, ${p.y})`,
											style: { cursor: "pointer" },
											onClick: () => setSelected(n.id === selected ? null : n.id),
											children: [
												isRoot && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
													x: -6,
													y: -6,
													width: 212,
													height: 94,
													rx: 12,
													fill: "none",
													stroke: "hsl(354 90% 55%)",
													strokeWidth: 2,
													strokeDasharray: "4 4",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("animate", {
														attributeName: "stroke-dashoffset",
														from: "0",
														to: "16",
														dur: "1.2s",
														repeatCount: "indefinite"
													})
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
													width: NODE_W,
													height: NODE_H,
													rx: 10,
													fill: active ? c.fill : "hsl(var(--card))",
													stroke: isSel ? "hsl(var(--brand))" : c.stroke,
													strokeWidth: isSel ? 2.5 : 1.5,
													opacity: active ? 1 : .55
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
													x: 12,
													y: 22,
													style: {
														fontSize: 12,
														fontWeight: 600
													},
													className: "fill-foreground",
													children: truncate(n.layer.name, 26)
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
													x: 12,
													y: 38,
													style: { fontSize: 10.5 },
													className: "fill-muted-foreground",
													children: truncate(n.layer.technology, 32)
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
													x: 12,
													y: NODE_H - 26,
													width: 54,
													height: 18,
													rx: 4,
													fill: c.stroke,
													opacity: .14
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
													x: 39,
													y: NODE_H - 13,
													textAnchor: "middle",
													style: {
														fontSize: 10,
														fontWeight: 700
													},
													fill: c.stroke,
													children: n.status.toUpperCase()
												}),
												n.alertCount > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
													x: 72,
													y: NODE_H - 26,
													width: 64,
													height: 18,
													rx: 4,
													fill: "hsl(354 90% 55%)",
													opacity: .14
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("text", {
													x: 104,
													y: NODE_H - 13,
													textAnchor: "middle",
													style: {
														fontSize: 10,
														fontWeight: 700
													},
													fill: "hsl(354 90% 42%)",
													children: [
														n.alertCount,
														" alert",
														n.alertCount === 1 ? "" : "s"
													]
												})] }),
												n.firstAlertTs && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
													x: NODE_W - 12,
													y: NODE_H - 13,
													textAnchor: "end",
													style: {
														fontSize: 10,
														fontFamily: "monospace"
													},
													className: "fill-muted-foreground",
													children: n.firstAlertTs
												})
											]
										}, n.id);
									})
								]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "border-t border-border p-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between mb-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "h-3.5 w-3.5 text-brand" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs font-semibold text-foreground",
										children: "Temporal correlation — event cascade"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-[10.5px] text-muted-foreground",
									children: [
										timeline.length,
										" events · replay ",
										playCursor + 1,
										"/",
										timeline.length || 1
									]
								})]
							}), timeline.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative h-10 rounded-md bg-secondary/50 border border-border",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute left-4 right-4 top-1/2 h-px bg-border" }), timeline.map((e, i) => {
									const span = timeline[timeline.length - 1].ms - timeline[0].ms || 1;
									const pct = (e.ms - timeline[0].ms) / span * 100;
									const color = e.severity === "critical" ? "bg-red-500" : e.severity === "high" ? "bg-orange-500" : e.severity === "medium" ? "bg-amber-500" : "bg-emerald-500";
									const passed = i <= playCursor;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: () => {
											setPlaying(false);
											setPlayCursor(i);
											setSelected(e.nodeId);
										},
										title: `${e.ts} — ${e.layerName}: ${e.message}`,
										className: cn("absolute -translate-x-1/2 -translate-y-1/2 top-1/2 h-2.5 w-2.5 rounded-full border-2 border-card transition-all", color, passed ? "opacity-100 scale-100" : "opacity-40 scale-75", i === playCursor && "ring-2 ring-brand ring-offset-1 ring-offset-card scale-125"),
										style: { left: `calc(1rem + ${pct}% * (100% - 2rem) / 100%)` }
									}, i);
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 rounded-md border border-border bg-secondary/30 p-2 text-[11.5px]",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] font-mono text-muted-foreground mr-2",
										children: timeline[playCursor]?.ts
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-medium text-foreground",
										children: timeline[playCursor]?.layerName
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-muted-foreground",
										children: [" · ", timeline[playCursor]?.source]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-muted-foreground mt-0.5",
										children: timeline[playCursor]?.message
									})
								]
							})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: "No timestamped alerts."
							})]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-lg border border-border bg-background overflow-hidden",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "px-3 py-2 border-b border-border flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, { className: "h-3.5 w-3.5 text-brand" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs font-semibold text-foreground",
							children: selectedNode ? "Selected CI" : "Fault propagation path"
						})]
					}), selectedNode ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "p-3 space-y-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] uppercase tracking-wider text-muted-foreground",
									children: selectedNode.tierName
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm font-semibold text-foreground",
									children: selectedNode.layer.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[11px] text-muted-foreground",
									children: selectedNode.layer.technology
								})
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2 flex-wrap",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: cn("text-[10px] font-bold px-2 py-0.5 rounded uppercase border", STATUS_COLOR[selectedNode.status].badge),
										children: selectedNode.status
									}),
									selectedNode.alertCount > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-[10px] font-bold px-2 py-0.5 rounded border bg-red-500/10 text-red-600 border-red-500/20",
										children: [selectedNode.alertCount, " alerts"]
									}),
									selectedNode.firstAlertTs && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-[10px] font-mono text-muted-foreground flex items-center gap-1",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "h-3 w-3" }),
											" first at ",
											selectedNode.firstAlertTs
										]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] uppercase tracking-wider text-muted-foreground mb-1.5",
								children: "Monitoring sources"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex flex-wrap gap-1.5",
								children: selectedNode.sources.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: cn("inline-flex items-center gap-1 text-[10px] px-1.5 py-0.5 rounded border font-medium", c.status === "healthy" ? "bg-secondary text-secondary-foreground border-border" : STATUS_COLOR[c.status === "alerting" ? "degraded" : c.status].badge),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("h-1.5 w-1.5 rounded-full", c.status === "healthy" ? "bg-emerald-500" : c.status === "alerting" ? "bg-amber-500" : "bg-red-500") }),
										c.name,
										c.alerts.length > 0 && ` [${c.alerts.length}]`
									]
								}, c.id))
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] uppercase tracking-wider text-muted-foreground mb-1.5",
								children: "Events on this CI"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5 max-h-60 overflow-y-auto pr-1",
								children: [selectedNode.sources.flatMap((c) => c.alerts.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-md border border-border bg-secondary/30 p-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2 flex-wrap",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: cn("text-[9px] font-bold px-1.5 py-0.5 rounded uppercase", a.severity === "critical" ? "bg-red-500/15 text-red-600" : a.severity === "high" ? "bg-orange-500/15 text-orange-600" : a.severity === "medium" ? "bg-amber-500/15 text-amber-600" : "bg-emerald-500/15 text-emerald-600"),
													children: a.severity
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[10px] font-mono text-muted-foreground",
													children: a.id
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "text-[10px] text-muted-foreground",
													children: ["· ", c.name]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[10px] font-mono text-muted-foreground ml-auto",
													children: a.timestamp
												})
											]
										}),
										a.eventname && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[11.5px] font-semibold text-foreground mt-1",
											children: a.eventname
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[11px] text-muted-foreground mt-0.5 leading-snug",
											children: a.message
										})
									]
								}, a.id))), selectedNode.alertCount === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground italic",
									children: "No open events on this CI."
								})]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => setSelected(null),
								className: "w-full text-[11px] font-medium px-2.5 py-1 rounded-md border border-border bg-card hover:bg-accent transition-colors",
								children: "Clear selection"
							})
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "p-3 space-y-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-[11.5px] text-muted-foreground",
								children: [
									"The engine linked ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-foreground font-semibold",
										children: [data.summary.totalAlerts, " alerts"]
									}),
									" ",
									"from ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-foreground font-semibold",
										children: [data.summary.connectors, " sources"]
									}),
									" across",
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-foreground font-semibold",
										children: [data.summary.affectedLayers, " CIs"]
									}),
									" into one incident."
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] uppercase tracking-wider text-muted-foreground mb-2",
								children: "Inferred cascade (symptom → root)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
								className: "space-y-1.5",
								children: inferCascade(nodes, timeline).map((step, i, arr) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex items-start gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: cn("h-4 w-4 shrink-0 rounded-full grid place-items-center text-[9px] font-bold text-white", i === 0 ? "bg-brand" : i === arr.length - 1 ? "bg-red-500" : "bg-amber-500"),
										children: i + 1
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "min-w-0",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[11.5px] font-semibold text-foreground truncate",
											children: step.layer.name
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-[10px] text-muted-foreground",
											children: [
												step.tierName,
												" · ",
												step.firstAlertTs ?? "—"
											]
										})]
									})]
								}, step.id))
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10.5px] text-muted-foreground italic",
								children: "Click any node to inspect its events and sources."
							})
						]
					})]
				})]
			})
		]
	});
}
function StatChip({ icon, label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "inline-flex items-center gap-1.5 rounded-md border border-border bg-background px-2 py-1",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-brand",
				children: icon
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-[10.5px] text-muted-foreground",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-[11.5px] font-semibold text-foreground",
				children: value
			})
		]
	});
}
function LegendDot({ color, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "inline-flex items-center gap-1.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "h-2 w-2 rounded-full",
			style: { background: color }
		}), label]
	});
}
function truncate(s, n) {
	return s.length > n ? s.slice(0, n - 1) + "…" : s;
}
function formatSpan(ms) {
	if (ms < 0 || !isFinite(ms)) return "—";
	const s = Math.round(ms / 1e3);
	if (s < 60) return `${s}s`;
	return `${Math.floor(s / 60)}m ${s % 60}s`;
}
function inferCascade(nodes, timeline) {
	const firstSeen = /* @__PURE__ */ new Map();
	timeline.forEach((e) => {
		if (!firstSeen.has(e.nodeId)) firstSeen.set(e.nodeId, e.ms);
	});
	return nodes.filter((n) => firstSeen.has(n.id)).sort((a, b) => firstSeen.get(a.id) - firstSeen.get(b.id)).slice(0, 6);
}
var ICON_MAP = {
	monitor: Monitor,
	cpu: Cpu,
	cable: Cable,
	database: Database,
	"hard-drive": HardDrive,
	globe: Globe,
	server: Server,
	shuffle: Shuffle,
	workflow: Workflow,
	layers: Layers,
	"git-branch": GitBranch,
	box: Box,
	"file-text": FileText,
	zap: Zap,
	shield: Shield,
	search: Search,
	wifi: Wifi
};
var TIER_COLORS = {
	healthy: {
		bg: "bg-emerald-500",
		ring: "ring-emerald-500/30",
		text: "text-emerald-600"
	},
	degraded: {
		bg: "bg-amber-500",
		ring: "ring-amber-500/30",
		text: "text-amber-600"
	},
	critical: {
		bg: "bg-red-500",
		ring: "ring-red-500/30",
		text: "text-red-600"
	}
};
var STATUS = {
	healthy: {
		dot: "bg-emerald-500",
		text: "text-emerald-600",
		badge: "bg-emerald-500/10 text-emerald-600 border-emerald-500/20"
	},
	degraded: {
		dot: "bg-amber-500",
		text: "text-amber-600",
		badge: "bg-amber-500/10 text-amber-600 border-amber-500/20"
	},
	critical: {
		dot: "bg-red-500",
		text: "text-red-600",
		badge: "bg-red-500/10 text-red-600 border-red-500/20"
	},
	alerting: {
		dot: "bg-amber-500",
		text: "text-amber-600",
		badge: "bg-amber-500/10 text-amber-600 border-amber-500/20"
	}
};
var SEVERITY = {
	critical: "bg-red-500/10 text-red-600 border-red-500/20",
	high: "bg-orange-500/10 text-orange-600 border-orange-500/20",
	medium: "bg-amber-500/10 text-amber-600 border-amber-500/20",
	low: "bg-emerald-500/10 text-emerald-600 border-emerald-500/20",
	info: "bg-brand-soft text-brand border-brand/20"
};
function ConnectorChip({ connector }) {
	const s = STATUS[connector.status] ?? STATUS.healthy;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: cn("inline-flex items-center gap-1.5 text-[11px] px-2 py-1 rounded-md border font-medium", connector.status === "healthy" ? "bg-secondary text-secondary-foreground border-border" : s.badge),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("h-1.5 w-1.5 rounded-full", s.dot) }),
			connector.name,
			connector.alerts.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "font-bold",
				children: [
					"[",
					connector.alerts.length,
					"]"
				]
			})
		]
	});
}
function AlertRow({ alert }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-start gap-2 pl-3 py-2 border-l-2 border-border ml-1 mb-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: cn("text-[10px] font-bold px-1.5 py-0.5 rounded border shrink-0 uppercase mt-0.5", SEVERITY[alert.severity]),
			children: alert.severity
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex-1 min-w-0",
			children: [
				alert.eventname && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-bold text-foreground mb-0.5 mt-0.5",
					children: alert.eventname
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground leading-relaxed",
					children: alert.message
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start gap-4 mt-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[10px] text-muted-foreground font-mono pt-0.5",
							children: alert.id
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[10px] text-muted-foreground pt-0.5",
							children: alert.timestamp
						}),
						alert.metric && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-[10px] text-red-500 font-medium leading-tight ml-auto text-right",
							children: [
								alert.metric,
								":",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
								alert.value
							]
						})
					]
				})
			]
		})]
	});
}
function MetricChart({ title, description, data, color }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl border border-border bg-card p-4 shadow-card",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-semibold text-foreground",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground mb-3",
				children: description
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
				width: "100%",
				height: 150,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AreaChart, {
					data,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("defs", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
							id: `g-${title.replace(/\s/g, "")}`,
							x1: "0",
							y1: "0",
							x2: "0",
							y2: "1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
								offset: "5%",
								stopColor: color,
								stopOpacity: .3
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
								offset: "95%",
								stopColor: color,
								stopOpacity: 0
							})]
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
							dataKey: "time",
							tick: {
								fontSize: 10,
								fill: "#888"
							},
							axisLine: false,
							tickLine: false
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
							tick: {
								fontSize: 10,
								fill: "#888"
							},
							axisLine: false,
							tickLine: false,
							width: 40
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { contentStyle: {
							background: "hsl(var(--card))",
							border: "1px solid hsl(var(--border))",
							color: "hsl(var(--foreground))",
							borderRadius: "8px",
							fontSize: 12
						} }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
							type: "monotone",
							dataKey: "value",
							stroke: color,
							fill: `url(#g-${title.replace(/\s/g, "")})`,
							strokeWidth: 2
						})
					]
				})
			})
		]
	});
}
function S5Timeline() {
	const { appId, journey } = useParams();
	const app = getApp(appId ?? "");
	const journeyName = decodeURIComponent(journey ?? "");
	const data = getActionLayers(appId ?? "", journeyName);
	const hasCritical = data.tiers.some((t) => t.status === "critical");
	const dispatch = useAppDispatch();
	const agentFlow = useAppSelector((s) => s.agentFlow);
	const charts = (0, import_react.useMemo)(() => ({
		errorRate: generateChartData(30, 5, 3),
		responseTime: generateChartData(30, 800, 400),
		cpu: generateChartData(30, 55, 15),
		memory: generateChartData(30, 68, 10),
		connections: generateChartData(30, 150, 50),
		latency: generateChartData(30, 45, 20)
	}), []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "w-full px-6 my-6 mb-16",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: `/${appId}/${journey}`,
				className: "inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-brand mb-4 transition-colors",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "h-4 w-4" }), " Back"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
				className: "flex items-center gap-1.5 mb-4 rounded-md border border-brand/20 bg-brand-soft/55 px-2.5 py-1.5 text-[11.5px] w-fit text-muted-foreground",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "hover:text-brand transition-colors",
						children: "Home"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-3 w-3 text-brand/45" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "hover:text-brand transition-colors",
						children: "Canara Life"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-3 w-3 text-brand/45" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: `/${appId}`,
						className: "hover:text-brand transition-colors",
						children: app?.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-3 w-3 text-brand/45" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: `/${appId}/${journey}`,
						className: "hover:text-brand transition-colors",
						children: journeyName
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-3 w-3 text-brand/45" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "rounded-sm bg-card px-1.5 py-0.5 font-semibold text-foreground shadow-sm ring-1 ring-border/70",
						children: "Technical Layers"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-4 mb-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
						className: "text-sm font-medium uppercase text-muted-foreground",
						children: "Technical Layer Breakdown"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3 mt-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-2.5 w-2.5 rounded-[3px] bg-brand" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-2xl font-semibold text-foreground",
							children: journeyName
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted-foreground mt-1",
						children: ["Action: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-foreground font-medium",
							children: data.action
						})]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex items-center gap-2 shrink-0",
					children: hasCritical && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => dispatch(runAutoFixFlow()),
						disabled: agentFlow.running || agentFlow.fixed,
						className: cn("px-5 py-2.5 rounded-lg text-sm font-semibold flex items-center gap-2 transition-all shadow-sm", agentFlow.fixed ? "bg-emerald-500/10 text-emerald-600 border border-emerald-500/20 cursor-default" : agentFlow.running ? "bg-brand/20 text-brand border border-brand/20 cursor-wait" : "bg-brand hover:bg-brand-strong text-white"),
						children: agentFlow.fixed ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-4 w-4" }), " Resolved"] }) : agentFlow.running ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }), " Running..."] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, { className: "h-4 w-4" }), " Auto-Fix"] })
					})
				})]
			}),
			(agentFlow.running || agentFlow.fixed) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl border border-border bg-card p-5 mb-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
						className: "text-sm font-semibold text-foreground mb-4 flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brain, { className: "h-4 w-4 text-purple-400" }), " AI Agent Execution Flow"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex items-center gap-1 overflow-x-auto pb-2",
						children: agentFlow.steps.map((step, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col items-center min-w-[90px]",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: cn("h-8 w-8 rounded-full grid place-items-center text-xs font-bold", step.status === "completed" && "bg-green-500/20 text-green-400", step.status === "running" && "bg-blue-500/20 text-blue-400", step.status === "idle" && "bg-border text-muted-foreground"),
										children: step.status === "completed" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-4 w-4" }) : step.status === "running" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Circle, { className: "h-3 w-3" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[10px] text-center mt-1 text-foreground leading-tight w-20",
										children: step.title
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[9px] text-muted-foreground text-center",
										children: step.agent
									})
								]
							}), i < agentFlow.steps.length - 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: cn("h-0.5 w-6 shrink-0 mb-8", step.status === "completed" ? "bg-green-500" : "bg-border") })]
						}, step.key))
					}),
					agentFlow.activity.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 max-h-32 overflow-y-auto rounded-lg bg-background/50 p-3 space-y-1",
						children: agentFlow.activity.slice(-8).map((log, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted-foreground",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-primary font-medium",
									children: [
										"[",
										log.scope,
										"]"
									]
								}),
								" ",
								log.message
							]
						}, i))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
					className: "text-sm font-semibold text-foreground mb-4 flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-2.5 w-2.5 rounded-[3px] bg-brand" }), " Technical Tiers"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex gap-4 items-stretch w-full overflow-hidden",
					children: data.tiers.map((tier, idx) => {
						const colors = TIER_COLORS[tier.status];
						const Icon = ICON_MAP[tier.icon] ?? Activity;
						const totalAlerts = tier.layers.reduce((s, l) => s + l.connectors.reduce((s2, c) => s2 + c.alerts.length, 0), 0);
						const rawConnectors = tier.layers.flatMap((l) => l.connectors);
						const allConnectors = Array.from(rawConnectors.reduce((acc, curr) => {
							if (acc.has(curr.name)) {
								const existing = acc.get(curr.name);
								existing.alerts = [...existing.alerts, ...curr.alerts];
								const statuses = [
									"healthy",
									"degraded",
									"alerting",
									"critical"
								];
								if (statuses.indexOf(curr.status) > statuses.indexOf(existing.status)) existing.status = curr.status;
							} else acc.set(curr.name, {
								...curr,
								alerts: [...curr.alerts]
							});
							return acc;
						}, /* @__PURE__ */ new Map()).values());
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex-1 min-w-0 flex flex-col gap-6",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative flex justify-center",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-col items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: cn("relative h-20 w-20 rounded-full grid place-items-center transition-all duration-300", colors.bg, tier.status === "critical" && "animate-pulse ring-4 ring-red-500/30"),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-8 w-8 text-white" }), tier.status !== "healthy" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "absolute -top-1 -right-1",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: cn("h-5 w-5", tier.status === "critical" ? "text-red-500" : "text-amber-500") })
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-center",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm font-bold text-foreground",
											children: tier.name.replace(" / Middleware Tier", "").replace(" Tier", "")
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: cn("text-[10px] font-bold px-2 py-0.5 rounded-full mt-1 inline-block uppercase tracking-wider", tier.status === "healthy" && "bg-emerald-500/10 text-emerald-600", tier.status === "degraded" && "bg-amber-500/10 text-amber-600", tier.status === "critical" && "bg-red-500/10 text-red-600"),
											children: [
												tier.status,
												" ",
												totalAlerts > 0 && `(${totalAlerts})`
											]
										})]
									})]
								}), idx < data.tiers.length - 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "absolute top-10 left-full ml-2 -translate-x-1/2 -translate-y-1/2 z-10",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoveRight, { className: cn("h-6 w-6", data.tiers[idx + 1].status === "critical" ? "text-red-500" : data.tiers[idx + 1].status === "degraded" ? "text-amber-500" : "text-emerald-500/50") })
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex-1 rounded-xl shadow-card border border-border bg-card flex flex-col overflow-hidden",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: cn("p-4 border-b border-border bg-secondary/30", tier.status === "critical" && "bg-red-500/5"),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: cn("h-10 w-10 rounded-lg grid place-items-center shrink-0", colors.bg),
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-5 w-5 text-white" })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex-1 min-w-0",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-sm font-bold text-foreground truncate",
												children: tier.name.replace(" / Middleware Tier", "").replace(" Tier", "")
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: cn("text-[10px] font-bold px-2 py-0.5 rounded-full mt-1 inline-block uppercase tracking-wider", tier.status === "healthy" && "bg-emerald-500/10 text-emerald-600", tier.status === "degraded" && "bg-amber-500/10 text-amber-600", tier.status === "critical" && "bg-red-500/10 text-red-600"),
												children: [
													tier.status,
													" ",
													totalAlerts > 0 && `(${totalAlerts})`
												]
											})]
										})]
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-4 flex-1 overflow-y-auto max-h-[500px] flex flex-col gap-4 bg-secondary/10",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h5", {
										className: "text-[10px] font-semibold text-muted-foreground uppercase tracking-wider mb-2",
										children: "Event Summary"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "flex flex-wrap gap-1.5",
										children: allConnectors.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConnectorChip, { connector: c }, c.id))
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "pt-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h5", {
											className: "text-[10px] font-semibold text-muted-foreground uppercase tracking-wider mb-3",
											children: "Raw Alerts"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "space-y-4",
											children: allConnectors.every((c) => c.alerts.length === 0) ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "text-xs text-emerald-600 flex items-center gap-1.5 py-1 bg-background/50 rounded-lg p-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-3.5 w-3.5" }), " All systems healthy"]
											}) : allConnectors.filter((c) => c.alerts.length > 0).map((connector) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "space-y-1.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
													className: "text-xs font-semibold text-foreground flex items-center gap-1.5",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("h-1.5 w-1.5 rounded-full", STATUS[connector.status]?.dot ?? "bg-emerald-500") }), connector.name]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "space-y-1",
													children: connector.alerts.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertRow, { alert: a }, a.id))
												})]
											}, connector.id))
										})]
									})]
								})]
							})]
						}, tier.id);
					})
				})]
			}),
			hasCritical && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl border border-border overflow-hidden mb-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "bg-card px-5 py-4 border-b border-border flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "relative",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-2.5 w-2.5 rounded-full bg-emerald-500" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 h-2.5 w-2.5 rounded-full bg-emerald-500 animate-ping opacity-75" })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "text-base font-semibold text-foreground",
										children: "Event Correlation Engine"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs font-medium px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-600",
										children: "Active"
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-4 text-xs text-muted-foreground",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Interval: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-foreground",
										children: "30s"
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Last Run: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-foreground",
										children: "12s ago"
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Incidents: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-foreground font-semibold",
										children: CORRELATION_INCIDENTS.length
									})] })
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "bg-secondary/30 p-6 space-y-6",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h5", {
								className: "text-sm font-semibold text-foreground flex items-center gap-2 mb-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "h-4 w-4 text-red-600" }), " Root Cause"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-base font-medium text-foreground",
								children: CORRELATION_INCIDENTS[0].title
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h5", {
									className: "text-sm font-semibold text-foreground flex items-center gap-2 mb-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Target, { className: "h-4 w-4 text-red-600" }), " Root Cause Analysis"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-foreground mb-2",
									children: CORRELATION_INCIDENTS[0].rootCause
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-3",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs text-muted-foreground",
											children: "Confidence:"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "flex-1 max-w-xs h-2 bg-border rounded-full overflow-hidden",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "h-full bg-gradient-to-r from-brand to-brand-strong rounded-full",
												style: { width: `${CORRELATION_INCIDENTS[0].rootCauseConfidence}%` }
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-xs font-semibold text-brand",
											children: [CORRELATION_INCIDENTS[0].rootCauseConfidence, "%"]
										})
									]
								})
							] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "p-4 border-t border-border bg-secondary/10",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DependencyGraphInline, { data })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "bg-secondary/30 p-6 space-y-6 border-t border-border",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h5", {
								className: "text-sm font-semibold text-foreground flex items-center gap-2 mb-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "h-4 w-4 text-yellow-400" }), " Recommendations"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "space-y-1.5",
								children: CORRELATION_INCIDENTS[0].recommendations.map((rec, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex items-start gap-2 text-sm text-foreground",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-4 w-4 text-green-400 mt-0.5 shrink-0" }), rec]
								}, i))
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-lg border border-border bg-card p-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h5", {
									className: "text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2",
									children: "Executive Narrative"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-foreground leading-relaxed",
									children: CORRELATION_INCIDENTS[0].narrative
								})]
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl shadow-card border border-border bg-card p-5 mb-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-base font-semibold text-foreground mb-1",
							children: "Intelligent Noise Reduction"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted-foreground mb-4",
							children: [
								NOISE_REDUCTION.reductionPercent,
								"% noise reduction — from ",
								NOISE_REDUCTION.raw.toLocaleString(),
								" raw alerts to ",
								NOISE_REDUCTION.actionable,
								" actionable"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "space-y-3",
							children: [
								{
									label: "Raw Alerts",
									value: NOISE_REDUCTION.raw,
									pct: 100,
									color: "from-red-500 to-red-600"
								},
								{
									label: "Deduplicated",
									value: NOISE_REDUCTION.deduplicated,
									pct: NOISE_REDUCTION.deduplicated / NOISE_REDUCTION.raw * 100,
									color: "from-orange-500 to-orange-600"
								},
								{
									label: "Correlated",
									value: NOISE_REDUCTION.correlated,
									pct: NOISE_REDUCTION.correlated / NOISE_REDUCTION.raw * 100,
									color: "from-amber-500 to-amber-600"
								},
								{
									label: "Actionable",
									value: NOISE_REDUCTION.actionable,
									pct: NOISE_REDUCTION.actionable / NOISE_REDUCTION.raw * 100,
									color: "from-emerald-500 to-emerald-600"
								}
							].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs text-muted-foreground w-24 text-right",
									children: item.label
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex-1 h-7 bg-secondary/50 rounded-full overflow-hidden",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: cn("h-full rounded-full bg-gradient-to-r flex items-center justify-end pr-3 transition-all duration-700", item.color),
										style: { width: `${Math.max(item.pct, 6)}%` },
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs font-bold text-white",
											children: item.value.toLocaleString()
										})
									})
								})]
							}, item.label))
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl border border-border overflow-hidden mb-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-card px-5 py-4 border-b border-border",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
							className: "text-base font-semibold text-foreground flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, { className: "h-4 w-4 text-yellow-400" }), " Self-Healing Automation"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground mt-0.5",
							children: "Automated remediation actions triggered by the correlation engine"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-b border-border bg-secondary/55",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "text-left text-xs font-medium text-muted-foreground px-4 py-2.5",
									children: "Action"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "text-left text-xs font-medium text-muted-foreground px-4 py-2.5",
									children: "Target"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "text-center text-xs font-medium text-muted-foreground px-4 py-2.5",
									children: "Status"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "text-left text-xs font-medium text-muted-foreground px-4 py-2.5",
									children: "Triggered"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "text-right text-xs font-medium text-muted-foreground px-4 py-2.5",
									children: "Duration"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "text-left text-xs font-medium text-muted-foreground px-4 py-2.5",
									children: "Result"
								})
							]
						}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: HEALING_LOGS.map((log) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-b border-border last:border-0 hover:bg-accent/20 transition-colors",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 text-sm font-medium text-foreground",
									children: log.action
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 text-sm text-muted-foreground",
									children: log.target
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 text-center",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: cn("text-xs font-medium px-2 py-0.5 rounded-full", log.status === "success" && "bg-green-500/10 text-green-400", log.status === "failed" && "bg-red-500/10 text-red-400", log.status === "in-progress" && "bg-yellow-500/10 text-yellow-400"),
										children: log.status === "in-progress" ? "In Progress" : log.status.charAt(0).toUpperCase() + log.status.slice(1)
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 text-xs text-muted-foreground",
									children: log.triggeredAt
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 text-xs text-right text-foreground",
									children: log.duration
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 text-xs text-foreground max-w-xs",
									children: log.result
								})
							]
						}, log.id)) })]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
						className: "text-base font-semibold text-foreground flex items-center gap-2 mb-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brain, { className: "h-4 w-4 text-purple-400" }), " Predictive Risk Detection"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4",
						children: PREDICTIVE_RISKS.map((risk) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-xl border border-border bg-card p-4 shadow-card hover:border-brand/30 transition-colors",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-start justify-between mb-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
										className: "text-sm font-semibold text-foreground pr-2",
										children: risk.title
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "relative h-12 w-12 shrink-0",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
											viewBox: "0 0 36 36",
											className: "h-12 w-12 -rotate-90",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
												cx: "18",
												cy: "18",
												r: "15.5",
												fill: "none",
												strokeWidth: "3",
												className: "stroke-border"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
												cx: "18",
												cy: "18",
												r: "15.5",
												fill: "none",
												strokeWidth: "3",
												className: cn(risk.probability >= 70 ? "stroke-red-500" : risk.probability >= 50 ? "stroke-yellow-500" : "stroke-green-500"),
												strokeDasharray: `${risk.probability} ${100 - risk.probability}`,
												strokeLinecap: "round"
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "absolute inset-0 flex items-center justify-center text-xs font-bold text-foreground",
											children: [risk.probability, "%"]
										})]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2 mb-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-xs px-2 py-0.5 rounded bg-card border border-border text-muted-foreground flex items-center gap-1",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "h-3 w-3" }),
											" ETA: ",
											risk.eta
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-xs px-2 py-0.5 rounded bg-card border border-border flex items-center gap-1",
										children: [risk.trend === "rising" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { className: "h-3 w-3 text-red-400" }) : risk.trend === "falling" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingDown, { className: "h-3 w-3 text-green-400" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, { className: "h-3 w-3 text-yellow-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: cn("text-xs", risk.trend === "rising" && "text-red-400", risk.trend === "falling" && "text-green-400", risk.trend === "stable" && "text-yellow-400"),
											children: risk.trend
										})]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground",
									children: risk.indicator
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] text-primary mt-2",
									children: risk.affectedApp
								})
							]
						}, risk.id))
					})]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-3 gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricChart, {
						title: "Error Rate",
						description: "Errors per minute across services",
						data: charts.errorRate,
						color: "#ef4444"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricChart, {
						title: "Response Time",
						description: "Average response time (ms)",
						data: charts.responseTime,
						color: "#3b82f6"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricChart, {
						title: "CPU Usage",
						description: "Server CPU utilization (%)",
						data: charts.cpu,
						color: "#f59e0b"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricChart, {
						title: "Memory Usage",
						description: "Heap / RSS memory (%)",
						data: charts.memory,
						color: "#8b5cf6"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricChart, {
						title: "Active Connections",
						description: "Database & service connections",
						data: charts.connections,
						color: "#06b6d4"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricChart, {
						title: "Network Latency",
						description: "Inter-service latency (ms)",
						data: charts.latency,
						color: "#10b981"
					})
				]
			})
		]
	});
}
//#endregion
export { S5Timeline as default };
