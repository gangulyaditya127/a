import { n as cn, t as APPLICATIONS } from "./utils-C1QNtmDU.mjs";
import { r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { n as Link } from "../_libs/react-router.mjs";
import { I as ChevronRight, M as ClipboardList, P as CircleUser, W as Activity, f as ShieldCheck, l as Sparkles, w as HeartPulse, z as Briefcase } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/S5Catalog-9MYDXx1S.js
var import_jsx_runtime = require_jsx_runtime();
var ICON_MAP = {
	"policy-admin": ClipboardList,
	"claims-mgmt": HeartPulse,
	"underwriting": ShieldCheck,
	"customer-portal": CircleUser,
	"agent-portal": Briefcase
};
function avgAvailability(app) {
	if (app.journeys.length === 0) return 0;
	return +(app.journeys.reduce((s, j) => s + j.availability, 0) / app.journeys.length).toFixed(2);
}
function S5Catalog() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "max-w-7xl mx-auto px-6 mt-16 pb-16",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
				className: "flex w-fit items-center gap-1.5 rounded-md border border-brand/20 bg-brand-soft/55 px-2.5 py-1.5 text-[11.5px] text-muted-foreground mb-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium hover:text-foreground cursor-pointer transition-colors",
						children: "Home"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-3 w-3 text-brand/45" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "rounded-sm bg-card px-1.5 py-0.5 font-semibold text-foreground shadow-sm ring-1 ring-border/70",
						children: "S5 Proactive Monitoring"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative rounded-2xl overflow-hidden mb-10 shadow-card",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-br from-brand/90 via-brand-strong to-brand-strong" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute top-1/2 left-1/4 -translate-y-1/2 w-96 h-96 bg-white/10 rounded-full blur-3xl" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute bottom-0 right-1/4 w-64 h-64 bg-white/10 rounded-full blur-3xl" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative z-10 px-8 py-10",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2 mb-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "h-5 w-5 text-white/90" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[11px] font-semibold tracking-widest uppercase text-white/90",
									children: "AI-Powered Observability Platform"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
								className: "text-3xl font-bold text-white mb-2 flex items-center gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-2.5 w-2.5 rounded-[3px] bg-white shrink-0" }), "Proactive & Predictive Ops Monitoring"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-[13px] text-white/80 max-w-2xl mb-8",
								children: [
									"Intelligent noise reduction, cross-application event correlation, automated root cause analysis, self-healing, and predictive risk detection for ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-white font-semibold",
										children: "Canara Life Insurance"
									}),
									"."
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-4 gap-4",
								children: [
									{
										label: "Noise Reduced",
										value: "95.7%"
									},
									{
										label: "Prediction Accuracy",
										value: "91%"
									},
									{
										label: "MTTR",
										value: "4.2 min"
									},
									{
										label: "Monthly Savings",
										value: "₹1.54 Cr"
									}
								].map((stat) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-xl border bg-white/15 border-white/20 backdrop-blur-sm p-4 text-center",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-2xl font-bold text-white",
										children: stat.value
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[10.5px] text-white/80 mt-0.5 uppercase tracking-wider font-medium",
										children: stat.label
									})]
								}, stat.label))
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2 mb-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-2.5 w-2.5 rounded-[3px] bg-brand" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-semibold text-foreground",
						children: "Applications"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[11px] px-2 py-0.5 rounded-full bg-brand-soft text-brand font-medium",
						children: APPLICATIONS.length
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-3 gap-4",
				children: APPLICATIONS.map((app) => {
					const Icon = ICON_MAP[app.id] ?? Activity;
					const avail = avgAvailability(app);
					const hasIssue = avail < 92;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: `/${app.id}`,
						className: cn("group relative rounded-xl border border-border bg-card p-5", "shadow-card transition-all duration-300 hover:border-brand/50", "hover:shadow-md hover:-translate-y-0.5"),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute left-0 top-4 bottom-4 w-1 rounded-full bg-border transition-all duration-300 group-hover:bg-brand group-hover:shadow-lg group-hover:shadow-brand/40" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start gap-4 pl-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "h-11 w-11 rounded-lg bg-brand-soft grid place-items-center shrink-0",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-5 w-5 text-brand" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex-1 min-w-0",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
												className: "text-[13px] font-semibold text-foreground group-hover:text-brand transition-colors",
												children: app.name
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[11px] text-muted-foreground mt-1 line-clamp-2 leading-relaxed",
												children: app.description
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-3 mt-3",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "text-[10.5px] px-2 py-0.5 rounded bg-secondary text-secondary-foreground font-medium",
													children: [app.journeys.length, " journeys"]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "flex items-center gap-1.5 text-[11px]",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("h-2 w-2 rounded-full", avail >= 95 ? "bg-emerald-500" : avail >= 85 ? "bg-amber-500" : "bg-red-500") }),
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
															className: cn("font-medium", avail >= 95 ? "text-emerald-600 dark:text-emerald-500" : avail >= 85 ? "text-amber-600 dark:text-amber-500" : "text-red-600 dark:text-red-500"),
															children: [avail, "%"]
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-muted-foreground",
															children: "availability"
														})
													]
												})]
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-4 w-4 text-muted-foreground group-hover:text-brand transition-colors shrink-0 mt-1" })
								]
							}),
							hasIssue && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "absolute top-2 right-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "relative flex h-2.5 w-2.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "relative inline-flex rounded-full h-2.5 w-2.5 bg-red-500" })]
								})
							})
						]
					}, app.id);
				})
			})
		]
	});
}
//#endregion
export { S5Catalog as default };
