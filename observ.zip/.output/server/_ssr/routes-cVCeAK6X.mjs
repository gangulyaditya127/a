import { r as __toESM } from "../_runtime.mjs";
import { n as require_react, r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { a as Routes, i as Route, r as Outlet, t as HashRouter } from "../_libs/react-router.mjs";
import { t as Provider_default } from "../_libs/react-redux+[...].mjs";
import { n as configureStore } from "../_libs/@reduxjs/toolkit+[...].mjs";
import { t as agent_flow_slice_default } from "./agent-flow-slice-Bfjw2cpe.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-cVCeAK6X.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var store = configureStore({ reducer: { agentFlow: agent_flow_slice_default } });
var S5Catalog = (0, import_react.lazy)(() => import("./S5Catalog-9MYDXx1S.mjs"));
var S5Home = (0, import_react.lazy)(() => import("./S5Home--WSbd7RW.mjs"));
var S5Details = (0, import_react.lazy)(() => import("./S5Details-S5UDVvuA.mjs"));
var S5Timeline = (0, import_react.lazy)(() => import("./S5Timeline-BNpRt3c3.mjs"));
var S5Dashboard = (0, import_react.lazy)(() => import("./S5Dashboard-D2UY5P4t.mjs"));
var S5DependencyGraph = (0, import_react.lazy)(() => import("./S5DependencyGraph-BdZewIGM.mjs"));
var Loader = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: "flex items-center justify-center min-h-screen",
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "animate-spin rounded-full h-8 w-8 border-b-2 border-brand" })
});
function Shell() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "min-h-screen w-full bg-background",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
	});
}
function Index() {
	const [mounted, setMounted] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => setMounted(true), []);
	if (!mounted) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Loader, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Provider_default, {
		store,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HashRouter, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_react.Suspense, {
			fallback: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Loader, {}),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Routes, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Route, {
				path: "/",
				element: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, {}),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Route, {
						index: true,
						element: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(S5Catalog, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Route, {
						path: ":appId",
						element: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(S5Home, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Route, {
						path: ":appId/:journey",
						element: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(S5Details, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Route, {
						path: ":appId/:journey/timeline",
						element: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(S5Timeline, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Route, {
						path: ":appId/:journey/detail",
						element: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(S5Dashboard, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Route, {
						path: ":appId/:journey/dependency",
						element: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(S5DependencyGraph, {})
					})
				]
			}) })
		}) })
	});
}
//#endregion
export { Index as component };
