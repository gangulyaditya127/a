import { r as __toESM } from "../_runtime.mjs";
import { n as cn, r as getApp } from "./utils-C1QNtmDU.mjs";
import { n as require_react, r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { n as Link, o as useParams } from "../_libs/react-router.mjs";
import { B as Brain, C as Layers, F as CircleCheck, H as ArrowRight, I as ChevronRight, L as ChevronDown, N as Circle, S as LoaderCircle, U as ArrowLeft, W as Activity, c as Target, d as Shield, i as Users, j as Clock, l as Sparkles, o as TrendingUp, s as TrendingDown, t as Zap, x as Minus } from "../_libs/lucide-react.mjs";
import { a as generateChartData, i as PREDICTIVE_RISKS, n as HEALING_LOGS, o as useAppDispatch, r as NOISE_REDUCTION, s as useAppSelector, t as CORRELATION_INCIDENTS } from "./hooks-BiobBJ1_.mjs";
import { n as runAutoFixFlow } from "./agent-flow-slice-Bfjw2cpe.mjs";
import { a as Tooltip, i as Area, n as YAxis, o as ResponsiveContainer, r as XAxis, t as AreaChart } from "../_libs/recharts+victory-vendor.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/S5Dashboard-D2UY5P4t.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function MetricChart({ title, description, data, color, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("rounded-xl border border-border bg-card p-4", className),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-semibold text-foreground",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground mb-3",
				children: description
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
				width: "100%",
				height: 160,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AreaChart, {
					data,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("defs", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
							id: `grad-${title.replace(/\s/g, "")}`,
							x1: "0",
							y1: "0",
							x2: "0",
							y2: "1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
								offset: "5%",
								stopColor: color,
								stopOpacity: .3
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
								offset: "95%",
								stopColor: color,
								stopOpacity: 0
							})]
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
							dataKey: "time",
							tick: {
								fontSize: 10,
								fill: "#888"
							},
							axisLine: false,
							tickLine: false
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
							tick: {
								fontSize: 10,
								fill: "#888"
							},
							axisLine: false,
							tickLine: false,
							width: 40
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { contentStyle: {
							background: "#1a1a2e",
							border: "1px solid #333",
							borderRadius: "8px",
							fontSize: 12
						} }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
							type: "monotone",
							dataKey: "value",
							stroke: color,
							fill: `url(#grad-${title.replace(/\s/g, "")})`,
							strokeWidth: 2
						})
					]
				})
			})
		]
	});
}
function SeverityBadge({ severity }) {
	const styles = {
		critical: "bg-red-500/10 text-red-400 border-red-500/20",
		high: "bg-orange-500/10 text-orange-400 border-orange-500/20",
		medium: "bg-yellow-500/10 text-yellow-400 border-yellow-500/20",
		low: "bg-green-500/10 text-green-400 border-green-500/20"
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("text-xs font-medium px-2 py-0.5 rounded-full border", styles[severity] ?? styles.low),
		children: severity.charAt(0).toUpperCase() + severity.slice(1)
	});
}
function CorrelationRow({ incident }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
		className: "border-b border-border hover:bg-accent/20 cursor-pointer transition-colors",
		onClick: () => setOpen(!open),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-4 py-3 text-sm font-mono text-primary",
				children: incident.id
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-4 py-3 text-sm font-medium text-foreground",
				children: incident.title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-4 py-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SeverityBadge, { severity: incident.severity })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-4 py-3 text-sm text-muted-foreground",
				children: incident.affectedTiers.join(", ")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-4 py-3 text-sm text-center text-foreground",
				children: incident.alertCount
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-4 py-3 text-sm text-muted-foreground",
				children: incident.correlatedAt
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-4 py-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: cn("h-4 w-4 text-muted-foreground transition-transform", open && "rotate-180") })
			})
		]
	}), open && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
		colSpan: 7,
		className: "p-0",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "bg-card/50 border-t border-border p-6 space-y-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h5", {
						className: "text-sm font-semibold text-foreground flex items-center gap-2 mb-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Target, { className: "h-4 w-4 text-red-400" }), " Root Cause Analysis"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-foreground mb-2",
						children: incident.rootCause
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs text-muted-foreground",
								children: "Confidence:"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex-1 max-w-xs h-2 bg-border rounded-full overflow-hidden",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-full bg-gradient-to-r from-blue-500 to-cyan-400 rounded-full transition-all",
									style: { width: `${incident.rootCauseConfidence}%` }
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-xs font-semibold text-cyan-400",
								children: [incident.rootCauseConfidence, "%"]
							})
						]
					})
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h5", {
					className: "text-sm font-semibold text-foreground flex items-center gap-2 mb-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Layers, { className: "h-4 w-4 text-orange-400" }), " Blast Radius"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-3 gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-lg border border-border p-3 text-center",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "h-4 w-4 text-blue-400 mx-auto mb-1" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-lg font-bold text-foreground",
									children: incident.blastRadius.users.toLocaleString()
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground",
									children: "Affected Users"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-lg border border-border p-3 text-center",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Activity, { className: "h-4 w-4 text-purple-400 mx-auto mb-1" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-lg font-bold text-foreground",
									children: incident.blastRadius.transactions.toLocaleString()
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground",
									children: "Transactions"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-lg border border-border p-3 text-center",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Layers, { className: "h-4 w-4 text-orange-400 mx-auto mb-1" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-lg font-bold text-foreground",
									children: incident.blastRadius.apps
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground",
									children: "Applications"
								})
							]
						})
					]
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h5", {
					className: "text-sm font-semibold text-foreground flex items-center gap-2 mb-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { className: "h-4 w-4 text-green-400" }), " Evidence"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "rounded-lg border border-border overflow-hidden",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-b border-border bg-card",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "text-left text-xs font-medium text-muted-foreground px-3 py-2",
									children: "Source"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "text-left text-xs font-medium text-muted-foreground px-3 py-2",
									children: "Type"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "text-left text-xs font-medium text-muted-foreground px-3 py-2",
									children: "Detail"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "text-right text-xs font-medium text-muted-foreground px-3 py-2 w-32",
									children: "Weight"
								})
							]
						}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: incident.evidence.map((ev, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-b border-border last:border-0",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs font-medium px-2 py-0.5 rounded bg-primary/10 text-primary",
										children: ev.source
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2 text-xs text-muted-foreground",
									children: ev.type
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2 text-xs text-foreground",
									children: ev.detail
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "flex-1 h-1.5 bg-border rounded-full overflow-hidden",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "h-full bg-green-500 rounded-full",
												style: { width: `${ev.weight}%` }
											})
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs text-green-400 w-8 text-right",
											children: ev.weight
										})]
									})
								})
							]
						}, i)) })]
					})
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h5", {
					className: "text-sm font-semibold text-foreground flex items-center gap-2 mb-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-4 w-4 text-cyan-400" }), " Dependency Path"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex items-center gap-2 flex-wrap",
					children: incident.dependencyPath.map((node, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: cn("text-xs px-3 py-1.5 rounded-lg border", i === 0 ? "bg-red-500/10 border-red-500/20 text-red-400 font-medium" : "bg-card border-border text-foreground"),
							children: node
						}), i < incident.dependencyPath.length - 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-3 w-3 text-muted-foreground shrink-0" })]
					}, i))
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h5", {
					className: "text-sm font-semibold text-foreground flex items-center gap-2 mb-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "h-4 w-4 text-yellow-400" }), " Recommendations"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "space-y-1.5",
					children: incident.recommendations.map((rec, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-start gap-2 text-sm text-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-4 w-4 text-green-400 mt-0.5 shrink-0" }), rec]
					}, i))
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-lg border border-border bg-card p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h5", {
						className: "text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2",
						children: "Executive Narrative"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-foreground leading-relaxed",
						children: incident.narrative
					})]
				})
			]
		})
	}) })] });
}
function S5Dashboard() {
	const { appId, journey } = useParams();
	const app = getApp(appId ?? "");
	const journeyName = decodeURIComponent(journey ?? "");
	const dispatch = useAppDispatch();
	const agentFlow = useAppSelector((s) => s.agentFlow);
	const charts = (0, import_react.useMemo)(() => ({
		errorRate: generateChartData(30, 5, 3),
		responseTime: generateChartData(30, 800, 400),
		cpu: generateChartData(30, 55, 15),
		memory: generateChartData(30, 68, 10),
		connections: generateChartData(30, 150, 50),
		latency: generateChartData(30, 45, 20)
	}), []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "max-w-7xl mx-auto px-6 my-6 mb-16",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: `/${appId}/${journey}/timeline`,
				className: "inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground mb-4 transition-colors",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "h-4 w-4" }), " Back to Technical Layer"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
				className: "flex items-center gap-1.5 text-sm text-muted-foreground mb-4 flex-wrap",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "hover:text-foreground",
						children: "Home"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-3 w-3" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: `/${appId}`,
						className: "hover:text-foreground",
						children: app?.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-3 w-3" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: `/${appId}/${journey}`,
						className: "hover:text-foreground",
						children: journeyName
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-3 w-3" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: `/${appId}/${journey}/timeline`,
						className: "hover:text-foreground",
						children: "Timeline"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-3 w-3" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-foreground font-medium",
						children: "Investigation"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-4 mb-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex items-center gap-3 mb-1",
						children: agentFlow.fixed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs font-medium px-2.5 py-1 rounded-full bg-green-500/10 border border-green-500/20 text-green-400",
							children: "Resolved"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs font-medium px-2.5 py-1 rounded-full bg-red-500/10 border border-red-500/20 text-red-400",
							children: "Critical"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "text-2xl font-bold text-foreground",
						children: [
							agentFlow.fixed ? "Issue resolved" : "Performance degradation detected",
							" — ",
							journeyName
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-3 mt-3 flex-wrap",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-xs px-3 py-1.5 rounded-lg bg-card border border-border text-foreground",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-muted-foreground",
										children: "Affected:"
									}),
									" ",
									app?.name
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-xs px-3 py-1.5 rounded-lg bg-card border border-border text-foreground",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted-foreground",
									children: "Error Rate:"
								}), " 18%"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-xs px-3 py-1.5 rounded-lg bg-card border border-border text-foreground",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted-foreground",
									children: "First Seen:"
								}), " 43 min ago"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-xs px-3 py-1.5 rounded-lg bg-card border border-border text-foreground",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted-foreground",
									children: "Correlated Alerts:"
								}), " 7"]
							})
						]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => dispatch(runAutoFixFlow()),
					disabled: agentFlow.running || agentFlow.fixed,
					className: cn("px-5 py-2.5 rounded-lg text-sm font-semibold flex items-center gap-2 transition-all shrink-0", agentFlow.fixed ? "bg-green-600/20 text-green-400 border border-green-500/20 cursor-default" : agentFlow.running ? "bg-blue-600/20 text-blue-400 border border-blue-500/20 cursor-wait" : "bg-blue-600 hover:bg-blue-700 text-white shadow-lg shadow-blue-500/20 hover:shadow-blue-500/30"),
					children: agentFlow.fixed ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-4 w-4" }), " Resolved"] }) : agentFlow.running ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }), " Running..."] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, { className: "h-4 w-4" }), " Auto-Fix"] })
				})]
			}),
			(agentFlow.running || agentFlow.fixed) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl border border-border bg-card p-5 mb-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
						className: "text-sm font-semibold text-foreground mb-4 flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brain, { className: "h-4 w-4 text-purple-400" }), " AI Agent Execution Flow"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex items-center gap-1 overflow-x-auto pb-2",
						children: agentFlow.steps.map((step, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col items-center min-w-[90px]",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: cn("h-8 w-8 rounded-full grid place-items-center text-xs font-bold", step.status === "completed" && "bg-green-500/20 text-green-400", step.status === "running" && "bg-blue-500/20 text-blue-400", step.status === "idle" && "bg-border text-muted-foreground"),
										children: step.status === "completed" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-4 w-4" }) : step.status === "running" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Circle, { className: "h-3 w-3" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[10px] text-center mt-1 text-foreground leading-tight w-20",
										children: step.title
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[9px] text-muted-foreground text-center",
										children: step.agent
									})
								]
							}), i < agentFlow.steps.length - 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: cn("h-0.5 w-6 shrink-0 mb-8", step.status === "completed" ? "bg-green-500" : "bg-border") })]
						}, step.key))
					}),
					agentFlow.activity.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 max-h-32 overflow-y-auto rounded-lg bg-background/50 p-3 space-y-1",
						children: agentFlow.activity.slice(-8).map((log, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted-foreground",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-primary font-medium",
									children: [
										"[",
										log.scope,
										"]"
									]
								}),
								" ",
								log.message
							]
						}, i))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-3 gap-4 mb-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricChart, {
						title: "Error Rate",
						description: "Errors per minute across services",
						data: charts.errorRate,
						color: "#ef4444"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricChart, {
						title: "Response Time",
						description: "Average response time (ms)",
						data: charts.responseTime,
						color: "#3b82f6"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricChart, {
						title: "CPU Usage",
						description: "Server CPU utilization (%)",
						data: charts.cpu,
						color: "#f59e0b"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricChart, {
						title: "Memory Usage",
						description: "Heap / RSS memory (%)",
						data: charts.memory,
						color: "#8b5cf6"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricChart, {
						title: "Active Connections",
						description: "Database & service connections",
						data: charts.connections,
						color: "#06b6d4"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricChart, {
						title: "Network Latency",
						description: "Inter-service latency (ms)",
						data: charts.latency,
						color: "#10b981"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl border border-border overflow-hidden mb-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-card px-5 py-4 border-b border-border flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-2.5 w-2.5 rounded-full bg-green-500" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 h-2.5 w-2.5 rounded-full bg-green-500 animate-ping opacity-75" })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-base font-semibold text-foreground",
								children: "Event Correlation Engine"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs font-medium px-2 py-0.5 rounded-full bg-green-500/10 text-green-400",
								children: "Active"
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-4 text-xs text-muted-foreground",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Interval: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-foreground",
								children: "30s"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Last Run: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-foreground",
								children: "12s ago"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Incidents: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-foreground font-semibold",
								children: CORRELATION_INCIDENTS.length
							})] })
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-b border-border bg-card/50",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "text-left text-xs font-medium text-muted-foreground px-4 py-2.5",
								children: "ID"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "text-left text-xs font-medium text-muted-foreground px-4 py-2.5",
								children: "Incident"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "text-left text-xs font-medium text-muted-foreground px-4 py-2.5",
								children: "Severity"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "text-left text-xs font-medium text-muted-foreground px-4 py-2.5",
								children: "Affected Apps"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "text-center text-xs font-medium text-muted-foreground px-4 py-2.5",
								children: "Alerts"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "text-left text-xs font-medium text-muted-foreground px-4 py-2.5",
								children: "Correlated"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { className: "w-8" })
						]
					}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: CORRELATION_INCIDENTS.map((inc) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CorrelationRow, { incident: inc }, inc.id)) })]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl border border-border bg-card p-5 mb-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-base font-semibold text-foreground mb-1",
						children: "Intelligent Noise Reduction"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted-foreground mb-4",
						children: [
							NOISE_REDUCTION.reductionPercent,
							"% noise reduction — from ",
							NOISE_REDUCTION.raw.toLocaleString(),
							" raw alerts to ",
							NOISE_REDUCTION.actionable,
							" actionable"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "space-y-3",
						children: [
							{
								label: "Raw Alerts",
								value: NOISE_REDUCTION.raw,
								pct: 100,
								color: "from-red-500 to-red-600"
							},
							{
								label: "Deduplicated",
								value: NOISE_REDUCTION.deduplicated,
								pct: NOISE_REDUCTION.deduplicated / NOISE_REDUCTION.raw * 100,
								color: "from-orange-500 to-orange-600"
							},
							{
								label: "Correlated",
								value: NOISE_REDUCTION.correlated,
								pct: NOISE_REDUCTION.correlated / NOISE_REDUCTION.raw * 100,
								color: "from-yellow-500 to-yellow-600"
							},
							{
								label: "Actionable",
								value: NOISE_REDUCTION.actionable,
								pct: NOISE_REDUCTION.actionable / NOISE_REDUCTION.raw * 100,
								color: "from-green-500 to-green-600"
							}
						].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs text-muted-foreground w-24 text-right",
								children: item.label
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex-1 h-7 bg-border/30 rounded-full overflow-hidden",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: cn("h-full rounded-full bg-gradient-to-r flex items-center justify-end pr-3 transition-all duration-700", item.color),
									style: { width: `${Math.max(item.pct, 6)}%` },
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs font-bold text-white",
										children: item.value.toLocaleString()
									})
								})
							})]
						}, item.label))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl border border-border overflow-hidden mb-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-card px-5 py-4 border-b border-border",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
						className: "text-base font-semibold text-foreground flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, { className: "h-4 w-4 text-yellow-400" }), " Self-Healing Automation"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground mt-0.5",
						children: "Automated remediation actions triggered by the correlation engine"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-b border-border bg-card/50",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "text-left text-xs font-medium text-muted-foreground px-4 py-2.5",
								children: "Action"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "text-left text-xs font-medium text-muted-foreground px-4 py-2.5",
								children: "Target"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "text-center text-xs font-medium text-muted-foreground px-4 py-2.5",
								children: "Status"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "text-left text-xs font-medium text-muted-foreground px-4 py-2.5",
								children: "Triggered"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "text-right text-xs font-medium text-muted-foreground px-4 py-2.5",
								children: "Duration"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "text-left text-xs font-medium text-muted-foreground px-4 py-2.5",
								children: "Result"
							})
						]
					}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: HEALING_LOGS.map((log) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-b border-border last:border-0 hover:bg-accent/20 transition-colors",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3 text-sm font-medium text-foreground",
								children: log.action
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3 text-sm text-muted-foreground",
								children: log.target
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3 text-center",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: cn("text-xs font-medium px-2 py-0.5 rounded-full", log.status === "success" && "bg-green-500/10 text-green-400", log.status === "failed" && "bg-red-500/10 text-red-400", log.status === "in-progress" && "bg-yellow-500/10 text-yellow-400"),
									children: log.status === "in-progress" ? "In Progress" : log.status.charAt(0).toUpperCase() + log.status.slice(1)
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3 text-xs text-muted-foreground",
								children: log.triggeredAt
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3 text-xs text-right text-foreground",
								children: log.duration
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3 text-xs text-foreground max-w-xs",
								children: log.result
							})
						]
					}, log.id)) })]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
					className: "text-base font-semibold text-foreground flex items-center gap-2 mb-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brain, { className: "h-4 w-4 text-purple-400" }), " Predictive Risk Detection"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4",
					children: PREDICTIVE_RISKS.map((risk) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl border border-border bg-card p-4 hover:border-primary/30 transition-colors",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between mb-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
									className: "text-sm font-semibold text-foreground pr-2",
									children: risk.title
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative h-12 w-12 shrink-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
										viewBox: "0 0 36 36",
										className: "h-12 w-12 -rotate-90",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
											cx: "18",
											cy: "18",
											r: "15.5",
											fill: "none",
											strokeWidth: "3",
											className: "stroke-border"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
											cx: "18",
											cy: "18",
											r: "15.5",
											fill: "none",
											strokeWidth: "3",
											className: cn(risk.probability >= 70 ? "stroke-red-500" : risk.probability >= 50 ? "stroke-yellow-500" : "stroke-green-500"),
											strokeDasharray: `${risk.probability} ${100 - risk.probability}`,
											strokeLinecap: "round"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "absolute inset-0 flex items-center justify-center text-xs font-bold text-foreground",
										children: [risk.probability, "%"]
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2 mb-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xs px-2 py-0.5 rounded bg-card border border-border text-muted-foreground flex items-center gap-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "h-3 w-3" }),
										" ETA: ",
										risk.eta
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xs px-2 py-0.5 rounded bg-card border border-border flex items-center gap-1",
									children: [risk.trend === "rising" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { className: "h-3 w-3 text-red-400" }) : risk.trend === "falling" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingDown, { className: "h-3 w-3 text-green-400" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, { className: "h-3 w-3 text-yellow-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: cn("text-xs", risk.trend === "rising" && "text-red-400", risk.trend === "falling" && "text-green-400", risk.trend === "stable" && "text-yellow-400"),
										children: risk.trend
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: risk.indicator
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] text-primary mt-2",
								children: risk.affectedApp
							})
						]
					}, risk.id))
				})]
			})
		]
	});
}
//#endregion
export { S5Dashboard as default };
