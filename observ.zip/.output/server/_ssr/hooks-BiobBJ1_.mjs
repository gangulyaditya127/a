import { i as useSelector, r as useDispatch } from "../_libs/react-redux+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/hooks-BiobBJ1_.js
var CORRELATION_INCIDENTS = [{
	id: "COR-001",
	title: "Oracle RAC Failover Cascade — Cross-App Connection Pool Exhaustion",
	severity: "critical",
	affectedTiers: [
		"Data Tier",
		"Integration Tier",
		"Application Tier"
	],
	alertCount: 16,
	correlatedAt: "2 minutes ago",
	rootCause: "Oracle RAC Node-2 unplanned failover during CHG0045231 maintenance window — all 200 active connections invalidated, causing pool exhaustion across 3 applications sharing the CanaraPolicyDS datasource",
	rootCauseConfidence: 94,
	blastRadius: {
		users: 4580,
		transactions: 2340,
		apps: 3
	},
	symptoms: [
		"Benefit Recalculation Service: p95 latency 7.8s, 18% error rate (Policy Admin)",
		"TIBCO BusinessWorks process stuck threads: 47/50 (Integration Tier)",
		"WebLogic thread pool exhaustion: 198/200 on PAS_MS1",
		"IBM MQ queue depth: 4,500/5,000 on DEV.PAS.ENDORSEMENT.Q1",
		"Redis cache miss rate spiked to 67% (stale policy data post-failover)"
	],
	evidence: [
		{
			source: "Oracle Enterprise Manager",
			type: "Data Tier (Root Cause)",
			detail: "RAC Node-2 instance failover detected at 14:23:05 — unplanned (CHG0045231 maintenance overrun)",
			weight: 99
		},
		{
			source: "Oracle Enterprise Manager",
			type: "Data Tier (Load Spike)",
			detail: "Active sessions spike: 340→890 on Node-1 (absorbing Node-2 load)",
			weight: 95
		},
		{
			source: "Splunk",
			type: "Data Tier (Connection Drop)",
			detail: "ORA-12516: TNS listener could not find available handler with matching protocol stack",
			weight: 92
		},
		{
			source: "AppDynamics Database",
			type: "Data Tier (Pool Exhaustion)",
			detail: "Connection pool wait time: 4,200ms (baseline: 15ms) — pool 'CanaraPolicyDS' exhausted at maxActive=200",
			weight: 88
		},
		{
			source: "TIBCO Hawk",
			type: "Integration Tier (Bottleneck)",
			detail: "Process engine stuck thread count: 47/50 — process 'PolicyEndorsement.bwp' backlogged",
			weight: 85
		},
		{
			source: "AppDynamics",
			type: "Integration Tier (Latency)",
			detail: "ESB backend call latency to Oracle DB: 3,200ms (baseline: 45ms)",
			weight: 82
		},
		{
			source: "AppDynamics",
			type: "Application Tier (Starvation)",
			detail: "Thread pool exhaustion: 198/200 threads busy on managed server 'PAS_MS1'",
			weight: 78
		}
	],
	dependencyPath: [
		"Oracle RAC 19c (Node-2 failover @ 14:23:05)",
		"Connection Pool 'CanaraPolicyDS' (maxActive: 200 → exhausted)",
		"TIBCO BusinessWorks 6.x (ESB process stall → queue backlog)",
		"IBM MQ 9.3 (queue depth: 4,500/5,000)",
		"Oracle WebLogic 14c (thread pool: 198/200)",
		"Drools Rules Engine (rule execution timeout: 4.8s)",
		"Benefit Recalculation Service (18% error rate → endorsement failures)"
	],
	recommendations: [
		"Increase Oracle connection pool maxActive from 200 to 400 with validation query",
		"Enable connection pool warm-up and stale connection eviction after RAC failover",
		"Implement circuit breaker on Drools Rules Engine with cached fallback for non-critical endorsements",
		"Add retry with exponential backoff on TIBCO-to-Oracle JDBC connections",
		"Configure Redis cache invalidation hook on Oracle failover event",
		"Update CHG0045231 maintenance SOP with pre-failover connection drain"
	],
	narrative: "At 14:23, Oracle RAC Node-2 underwent an unplanned failover during scheduled maintenance window CHG0045231. The maintenance overran by 18 minutes, causing an abrupt switchover. All 200 active connections in the shared 'CanaraPolicyDS' connection pool were invalidated simultaneously. Three applications — Policy Administration, Claims Management, and Customer Portal — competed for new connections on the surviving Node-1, causing pool exhaustion within 30 seconds. The TIBCO ESB, which holds long-lived database transactions for endorsement processing, was most severely impacted with 47 of 50 process threads stuck. This cascaded into WebLogic thread pool exhaustion and Drools rule evaluation timeouts. The correlation engine identified this as a single root cause affecting 4,580 policyholders across 2,340 in-flight transactions by analyzing 16 alerts from 9 different monitoring connectors across all 5 technical tiers."
}];
var HEALING_LOGS = [
	{
		id: "HL-001",
		action: "Oracle Connection Pool Scale-Up",
		target: "Policy Admin → WebLogic 'CanaraPolicyDS'",
		status: "success",
		triggeredAt: "1 min ago",
		duration: "28s",
		result: "Pool maxActive increased 200→400; active connections stabilized at 220, wait time dropped to 18ms"
	},
	{
		id: "HL-002",
		action: "TIBCO ESB Process Restart (Rolling)",
		target: "Policy Admin → TIBCO BW 'PolicyEndorsement.bwp'",
		status: "success",
		triggeredAt: "2 min ago",
		duration: "45s",
		result: "Process engine restarted; stuck threads cleared, queue depth dropping at 150 msg/min"
	},
	{
		id: "HL-003",
		action: "Circuit Breaker Activation",
		target: "Policy Admin → Drools Rules Engine",
		status: "success",
		triggeredAt: "3 min ago",
		duration: "2s",
		result: "Circuit opened; fallback to cached benefit calculation for non-critical endorsement types"
	},
	{
		id: "HL-004",
		action: "Redis Cache Flush & Warm-up",
		target: "Policy Admin → Redis Cluster",
		status: "success",
		triggeredAt: "4 min ago",
		duration: "12s",
		result: "Stale policy cache invalidated; warm-up from Oracle completed, miss rate dropped 67%→15%"
	},
	{
		id: "HL-005",
		action: "IBM MQ Queue Drain",
		target: "Policy Admin → DEV.PAS.ENDORSEMENT.Q1",
		status: "success",
		triggeredAt: "5 min ago",
		duration: "35s",
		result: "Dead-letter queue consumer activated; backlog cleared from 4,500 to 280 messages"
	},
	{
		id: "HL-006",
		action: "MuleSoft Circuit Breaker Reset",
		target: "Claims Mgmt → MuleSoft 'hospital-network-v2'",
		status: "in-progress",
		triggeredAt: "12 min ago",
		duration: "—",
		result: "Awaiting TPA certificate renewal; fallback to manual verification workflow activated"
	},
	{
		id: "HL-007",
		action: "Oracle RAC Node-2 Recovery",
		target: "Data Tier → Oracle RAC 19c",
		status: "success",
		triggeredAt: "15 min ago",
		duration: "120s",
		result: "Node-2 recovered and rejoined cluster; connections rebalanced across both nodes"
	},
	{
		id: "HL-008",
		action: "Kong Rate Limit Override",
		target: "Underwriting → Kong Gateway 'canara-uw-prod'",
		status: "success",
		triggeredAt: "20 min ago",
		duration: "3s",
		result: "Temporary rate limit increase to 1000 req/min for real-time UW; batch job paused"
	},
	{
		id: "HL-009",
		action: "PostgreSQL Lock Cleanup",
		target: "Claims Mgmt → Azure PostgreSQL 'claim_assessments'",
		status: "success",
		triggeredAt: "22 min ago",
		duration: "8s",
		result: "Long-running transactions terminated; lock wait count dropped from 45 to 0"
	},
	{
		id: "HL-010",
		action: "Auto-Scale Pods",
		target: "Claims Mgmt → AKS 'claims-assessment' deployment",
		status: "success",
		triggeredAt: "25 min ago",
		duration: "65s",
		result: "Scaled from 3→6 pods; request queue clearing at 200 req/s"
	}
];
var PREDICTIVE_RISKS = [
	{
		id: "PR-001",
		title: "WebLogic JVM Heap Pressure — Policy Admin",
		probability: 78,
		eta: "~45 min",
		trend: "rising",
		affectedApp: "Policy Administration",
		indicator: "JVM heap usage trending from 87%→92% post-recovery; full GC frequency increased 3x. Risk of OutOfMemoryError if endorsement backlog processes."
	},
	{
		id: "PR-002",
		title: "TLS Certificate Expiry — Agent Portal API Gateway",
		probability: 65,
		eta: "~6 hours",
		trend: "stable",
		affectedApp: "Agent & Distributor Portal",
		indicator: "Kong TLS certificate for agent-portal.canaralife.com expires in 6 hours; no automated renewal job detected in cert-manager."
	},
	{
		id: "PR-003",
		title: "Storage Capacity — FileNet Policy Documents",
		probability: 58,
		eta: "~2 days",
		trend: "rising",
		affectedApp: "Policy Administration",
		indicator: "IBM FileNet P8 document store volume at 87% capacity; growth rate 2.1 GB/day from endorsement document uploads."
	},
	{
		id: "PR-004",
		title: "Kafka Consumer Lag — Claims Event Stream",
		probability: 52,
		eta: "~90 min",
		trend: "rising",
		affectedApp: "Claims Management",
		indicator: "Consumer lag on 'claims.assessment.events' at 8,400 messages; if TPA gateway remains down, lag will exceed 50K in ~90 min."
	},
	{
		id: "PR-005",
		title: "Oracle RAC Tablespace — POLICY_DATA",
		probability: 45,
		eta: "~3 days",
		trend: "falling",
		affectedApp: "Policy Administration",
		indicator: "POLICY_DATA tablespace at 82% capacity; trending down post-recovery as stale sessions are cleared."
	}
];
var NOISE_REDUCTION = {
	raw: 4280,
	deduplicated: 1850,
	correlated: 420,
	actionable: 185,
	reductionPercent: 95.7
};
function generateChartData(points, base, variability) {
	return Array.from({ length: points }, (_, i) => {
		const date = /* @__PURE__ */ new Date(Date.now() - (points - i - 1) * 5 * 6e4);
		const spikeAt = Math.floor(points * .7);
		let value = base + (Math.random() - .5) * 2 * variability;
		if (i >= spikeAt && i <= spikeAt + 2) value = base * 2.5 + Math.random() * variability;
		return {
			time: date.toLocaleTimeString("en-US", {
				hour: "2-digit",
				minute: "2-digit"
			}),
			value: Math.max(0, Math.round(value * 100) / 100)
		};
	});
}
var useAppDispatch = useDispatch.withTypes();
var useAppSelector = useSelector.withTypes();
//#endregion
export { generateChartData as a, PREDICTIVE_RISKS as i, HEALING_LOGS as n, useAppDispatch as o, NOISE_REDUCTION as r, useAppSelector as s, CORRELATION_INCIDENTS as t };
