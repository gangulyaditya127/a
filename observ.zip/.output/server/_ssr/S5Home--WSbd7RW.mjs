import { n as cn, r as getApp } from "./utils-C1QNtmDU.mjs";
import { r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { n as Link, o as useParams } from "../_libs/react-router.mjs";
import { I as ChevronRight, U as ArrowLeft } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/S5Home--WSbd7RW.js
var import_jsx_runtime = require_jsx_runtime();
function formatDate() {
	return (/* @__PURE__ */ new Date()).toLocaleDateString("en-US", {
		weekday: "long",
		year: "numeric",
		month: "long",
		day: "numeric"
	});
}
function S5Home() {
	const { appId } = useParams();
	const app = getApp(appId ?? "");
	if (!app) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "max-w-7xl mx-auto px-6 my-6 mb-12",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: "/",
			className: "inline-flex items-center gap-1.5 text-[13px] text-muted-foreground hover:text-brand transition-colors",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "h-4 w-4" }), "Back to catalog"]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-10 text-center text-muted-foreground text-[13px]",
			children: "Application not found."
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "max-w-7xl mx-auto px-6 my-6 mb-12",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/",
				className: "inline-flex items-center gap-1.5 text-[11.5px] font-medium text-muted-foreground hover:text-brand transition-colors mb-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "h-3.5 w-3.5" }), "Back to catalog"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
				className: "flex w-fit items-center gap-1.5 rounded-md border border-brand/20 bg-brand-soft/55 px-2.5 py-1.5 text-[11.5px] text-muted-foreground mb-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "font-medium hover:text-foreground transition-colors",
						children: "Home"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-3 w-3 text-brand/45" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "font-medium hover:text-foreground transition-colors",
						children: "Canara Life"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-3 w-3 text-brand/45" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "rounded-sm bg-card px-1.5 py-0.5 font-semibold text-foreground shadow-sm ring-1 ring-border/70",
						children: app.name
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-2.5 w-2.5 rounded-[3px] bg-brand" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-2xl font-semibold tracking-tight text-foreground",
						children: app.name
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 flex items-center gap-2 text-[13px] text-muted-foreground pl-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Canara Life — Observability Dashboard" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted-foreground/40",
							children: "·"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: formatDate() })
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-xl border border-border/60 bg-card overflow-hidden shadow-card",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full text-[13px]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
						className: "border-b border-border/60 bg-secondary/55",
						children: [
							{
								key: "name",
								label: "Journey Name",
								align: "left"
							},
							{
								key: "activeUsers",
								label: "Active Users",
								align: "right"
							},
							{
								key: "happy",
								label: "Happy %",
								align: "right"
							},
							{
								key: "unhappy",
								label: "Unhappy %",
								align: "right"
							},
							{
								key: "frustrated",
								label: "Frustrated %",
								align: "right"
							},
							{
								key: "availability",
								label: "Availability %",
								align: "right"
							}
						].map((col) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: cn("px-5 py-3 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground", col.align === "right" ? "text-right" : "text-left"),
							children: col.label
						}, col.key))
					}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: app.journeys.map((j, idx) => {
						const isLowAvail = j.availability < 80;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: cn("group transition-colors duration-150", !(idx === app.journeys.length - 1) && "border-b border-border/40", isLowAvail ? "bg-destructive/[0.06] hover:bg-destructive/[0.10]" : "hover:bg-secondary/55"),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-5 py-3.5",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
										to: `/${app.id}/${encodeURIComponent(j.name)}`,
										className: cn("font-medium text-foreground hover:text-brand transition-colors", "inline-flex items-center gap-1.5"),
										children: [j.name, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-3.5 w-3.5 opacity-0 -translate-x-1 group-hover:opacity-100 group-hover:translate-x-0 transition-all duration-150 text-brand" })]
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-5 py-3.5 text-right tabular-nums text-muted-foreground",
									children: j.activeUsers.toLocaleString()
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-5 py-3.5 text-right tabular-nums",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-emerald-600 dark:text-emerald-500 font-medium",
										children: [j.happy, "%"]
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-5 py-3.5 text-right tabular-nums",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-amber-600 dark:text-amber-500 font-medium",
										children: [j.unhappy, "%"]
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-5 py-3.5 text-right tabular-nums",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-red-600 dark:text-red-500 font-medium",
										children: [j.frustrated, "%"]
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-5 py-3.5 text-right tabular-nums",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: cn("inline-flex items-center gap-1.5 font-semibold", j.availability >= 80 ? "text-emerald-600 dark:text-emerald-500" : "text-red-600 dark:text-red-500"),
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("inline-block h-1.5 w-1.5 rounded-full", j.availability >= 80 ? "bg-emerald-500" : "bg-red-500") }),
											j.availability.toFixed(2),
											"%"
										]
									})
								})
							]
						}, j.name);
					}) })]
				})
			})
		]
	});
}
//#endregion
export { S5Home as default };
