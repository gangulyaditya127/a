//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Bw2DIZmj.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "C:/Users/MrAditya/Downloads/event-topology-graph-main (1)/event-topology-graph-main/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-D3lPQOPZ.js", "/assets/preload-helper-BQ_0dKee.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-D3lPQOPZ.js"
		} }]
	},
	"/": {
		filePath: "C:/Users/MrAditya/Downloads/event-topology-graph-main (1)/event-topology-graph-main/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-GKb2jYYC.js",
			"/assets/chunk-KS7C4IRE-DAJ0M71J.js",
			"/assets/agent-flow-slice-Bfuk9lmO.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
