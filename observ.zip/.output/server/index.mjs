globalThis.__nitro_main__ = import.meta.url;
import { a as FastResponse, n as HTTPError, r as defineLazyEventHandler, t as H3Core } from "./_libs/h3+rou3+srvx+unenv.mjs";
import { t as HookableCore } from "./_libs/hookable.mjs";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/assets/activity-gss-UE81.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e7-8yZYmaSqDQuUD59iOBF6nXF0vG4\"",
		"mtime": "2026-07-21T08:13:50.217Z",
		"size": 231,
		"path": "../public/assets/activity-gss-UE81.js"
	},
	"/assets/agent-flow-slice-Bfuk9lmO.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"78b8-TfQs8oVNljmg4fftruiMQhqKsnQ\"",
		"mtime": "2026-07-21T08:13:50.219Z",
		"size": 30904,
		"path": "../public/assets/agent-flow-slice-Bfuk9lmO.js"
	},
	"/favicon.ico": {
		"type": "image/vnd.microsoft.icon",
		"etag": "\"4f95-3RXc3p2mhEAs1WBwaIvE0Y0uu0Y\"",
		"mtime": "2026-07-21T06:02:30.841Z",
		"size": 20373,
		"path": "../public/favicon.ico"
	},
	"/assets/arrow-left-Cb2SLunc.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a2-DidqBPfXwY0OZ2wibvp2/YFan0Y\"",
		"mtime": "2026-07-21T08:13:50.223Z",
		"size": 162,
		"path": "../public/assets/arrow-left-Cb2SLunc.js"
	},
	"/assets/chevron-right-Do6wySHZ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7cf0-R00JtFhX7Jvlw6RGxWCV2Fxcd48\"",
		"mtime": "2026-07-21T08:13:50.226Z",
		"size": 31984,
		"path": "../public/assets/chevron-right-Do6wySHZ.js"
	},
	"/assets/AreaChart-WkX3O2WV.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"50077-IH7LtvlPAd0/PKi/GkTHpFvK8Po\"",
		"mtime": "2026-07-21T08:13:50.127Z",
		"size": 327799,
		"path": "../public/assets/AreaChart-WkX3O2WV.js"
	},
	"/assets/chunk-KS7C4IRE-DAJ0M71J.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9da2-j8nKCt2IoAKns6gcACHP4fsObkI\"",
		"mtime": "2026-07-21T08:13:50.234Z",
		"size": 40354,
		"path": "../public/assets/chunk-KS7C4IRE-DAJ0M71J.js"
	},
	"/assets/layers-MGl1YGI5.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5278-hYxDCPfR/jWpnwa/8Y8r00sK/Vg\"",
		"mtime": "2026-07-21T08:13:50.246Z",
		"size": 21112,
		"path": "../public/assets/layers-MGl1YGI5.js"
	},
	"/assets/preload-helper-BQ_0dKee.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"25fb-o2dVMcuVAIsSo+Zga8CcMJGoPhM\"",
		"mtime": "2026-07-21T08:13:50.253Z",
		"size": 9723,
		"path": "../public/assets/preload-helper-BQ_0dKee.js"
	},
	"/assets/index-D3lPQOPZ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"51e17-pgPTmkt/bQvlJJ1V/Ig0TN4QVic\"",
		"mtime": "2026-07-21T08:13:50.116Z",
		"size": 335383,
		"path": "../public/assets/index-D3lPQOPZ.js"
	},
	"/assets/routes-GKb2jYYC.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9b1-dd8aLrE+qwijNrA3/Stw2E8eBbI\"",
		"mtime": "2026-07-21T08:13:50.256Z",
		"size": 2481,
		"path": "../public/assets/routes-GKb2jYYC.js"
	},
	"/assets/S5Catalog-PBToUFcz.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1a42-2UJjARRu5Ohb/MoBY3WzAHiwoOY\"",
		"mtime": "2026-07-21T08:13:50.179Z",
		"size": 6722,
		"path": "../public/assets/S5Catalog-PBToUFcz.js"
	},
	"/assets/S5Dashboard-thb0chpF.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"598a-CZEzreR48KIpit+VsGSjFrDfYHY\"",
		"mtime": "2026-07-21T08:13:50.181Z",
		"size": 22922,
		"path": "../public/assets/S5Dashboard-thb0chpF.js"
	},
	"/assets/S5DependencyGraph-CvGqLblR.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4f47-KvOBA6bmKaALfxZyNQllwq1om/4\"",
		"mtime": "2026-07-21T08:13:50.195Z",
		"size": 20295,
		"path": "../public/assets/S5DependencyGraph-CvGqLblR.js"
	},
	"/assets/S5Home-CC11o56M.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1307-dFPRY3OKl+1wynUkE6HAkHNVYMk\"",
		"mtime": "2026-07-21T08:13:50.207Z",
		"size": 4871,
		"path": "../public/assets/S5Home-CC11o56M.js"
	},
	"/assets/S5Timeline-TbkaLXrM.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ad16-M4QhkR4mgdZtKlbfPh/asX1172I\"",
		"mtime": "2026-07-21T08:13:50.210Z",
		"size": 44310,
		"path": "../public/assets/S5Timeline-TbkaLXrM.js"
	},
	"/assets/S5Details-01dyTLY-.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"45a6-3jOPooH0axkpJf5tx7IfJJk8Lrw\"",
		"mtime": "2026-07-21T08:13:50.201Z",
		"size": 17830,
		"path": "../public/assets/S5Details-01dyTLY-.js"
	},
	"/assets/sparkles-CXhpN2mR.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1eb-SFQcvVkt+gnZ2ipH9UjZTXymYT0\"",
		"mtime": "2026-07-21T08:13:50.262Z",
		"size": 491,
		"path": "../public/assets/sparkles-CXhpN2mR.js"
	},
	"/assets/styles-wNYRd6xY.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"17b64-uUw9vFGEweGPgjLEcPUcHsN6vsY\"",
		"mtime": "2026-07-21T08:13:50.367Z",
		"size": 97124,
		"path": "../public/assets/styles-wNYRd6xY.css"
	},
	"/assets/triangle-alert-C6mLzVZR.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"106-q7DYHl6crRNnV49iqTiH6DFLsL8\"",
		"mtime": "2026-07-21T08:13:50.320Z",
		"size": 262,
		"path": "../public/assets/triangle-alert-C6mLzVZR.js"
	},
	"/assets/zap-CvaKK-te.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"21a-oyz7fMsjECwxndkzdpcAs0AYCY4\"",
		"mtime": "2026-07-21T08:13:50.323Z",
		"size": 538,
		"path": "../public/assets/zap-CvaKK-te.js"
	}
};
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_onackG = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_onackG
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
[].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new FastResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function useNitroHooks() {
	const nitroApp = useNitroApp();
	const hooks = nitroApp.hooks;
	if (hooks) return hooks;
	return nitroApp.hooks = new HookableCore();
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/_module-handler.mjs
function createHandler(hooks) {
	const nitroApp = useNitroApp();
	const nitroHooks = useNitroHooks();
	return {
		async fetch(request, env, context) {
			globalThis.__env__ = env;
			augmentReq(request, {
				env,
				context
			});
			const ctxExt = {};
			const url = new URL(request.url);
			if (hooks.fetch) {
				const res = await hooks.fetch(request, env, context, url, ctxExt);
				if (res) return res;
			}
			return await nitroApp.fetch(request);
		},
		scheduled(controller, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:scheduled", {
				controller,
				env,
				context
			}) || Promise.resolve());
		},
		email(message, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:email", {
				message,
				event: message,
				env,
				context
			}) || Promise.resolve());
		},
		queue(batch, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:queue", {
				batch,
				event: batch,
				env,
				context
			}) || Promise.resolve());
		},
		tail(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:tail", {
				traces,
				env,
				context
			}) || Promise.resolve());
		},
		trace(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:trace", {
				traces,
				env,
				context
			}) || Promise.resolve());
		}
	};
}
function augmentReq(cfReq, ctx) {
	const req = cfReq;
	req.ip = cfReq.headers.get("cf-connecting-ip") || void 0;
	req.runtime ??= { name: "cloudflare" };
	req.runtime.cloudflare = {
		...req.runtime.cloudflare,
		...ctx
	};
	req.waitUntil = ctx.context?.waitUntil.bind(ctx.context);
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/cloudflare-module.mjs
var cloudflare_module_default = createHandler({ fetch(cfRequest, env, context, url) {
	if (env.ASSETS && isPublicAssetURL(url.pathname)) return env.ASSETS.fetch(cfRequest);
} });
//#endregion
export { cloudflare_module_default as default };
