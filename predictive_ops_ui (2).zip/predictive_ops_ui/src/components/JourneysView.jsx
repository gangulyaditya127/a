import { useToast } from '../context/ToastContext';
import { nowLong } from '../utils/time';

export default function JourneysView({ journeys, subJourneys, onOpenSteps }) {
  const { showToast } = useToast();
  const availColor = (v, status) => (status === 'warning' || status === 'critical') ? 'var(--cl-red)' : (v >= 95 ? 'var(--green)' : v >= 80 ? 'var(--amber)' : 'var(--cl-red)');

  const onRow = async (jid) => {
    // Await the lazy-loaded API call
    const success = await onOpenSteps(jid);

    if (!success) {
      // If no data was returned from the DB for this journey, show the toast
      showToast(`<b>${journeys.find(x => x.id === jid).name}</b> - sub-journey not populated. Try <b>Submit Health & Dental Claim</b> or <b>Group Benefits Enrollment</b>.`);
    }
  };

  return (
    <div className="view">
      <div className="eyebrow">Individual Insurance · Group Benefits · Wealth</div>
      <h1>Observability Dashboard</h1>
      <div className="timestamp">{nowLong()}</div>

      <div className="table-panel">
        <table className="j-table">
          <thead>
            <tr>
              <th>Journey</th>
              <th className="n">Active Users</th>
              <th className="n">Experience Split
                <div className="sub-labels">
                  <span style={{ color: 'var(--green)' }}>Happy</span>
                  <span style={{ color: 'var(--amber)' }}>Unhappy</span>
                  <span style={{ color: 'var(--cl-red)' }}>Frustrated</span>
                </div>
              </th>
              <th className="n">Availability</th>
              <th className="n">Open Alerts</th>
            </tr>
          </thead>
          <tbody>
            {journeys.map(j => (
              <tr key={j.id} className="row-click" onClick={() => onRow(j.id)}>
                <td>
                  <div className="j-name" style={{ color: (j.status === 'warning' || j.status === 'critical') ? 'var(--cl-red)' : 'inherit' }}>
                    {j.name} <span className="chev">›</span>
                  </div>
                </td>
                <td className="active-users">{j.users.toLocaleString()}</td>
                <td className="pct multi">
                  <span style={{ color: 'var(--green)' }}>{j.happy}%</span>
                  <span style={{ color: 'var(--amber)' }}>{j.unhappy}%</span>
                  <span style={{ color: 'var(--cl-red)' }}>{j.frustrated}%</span>
                </td>
                <td className="avail" style={{ color: availColor(j.avail, j.status) }}>{j.avail.toFixed(2)}%</td>
                <td className={'num-cell' + (j.alerts >= 5 ? ' crit' : '')}>{j.alerts === 0 ? '—' : j.alerts}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}