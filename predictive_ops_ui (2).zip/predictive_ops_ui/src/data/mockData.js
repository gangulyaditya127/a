export const journeys = [
  {
    id: "JRN-001",
    name: "Member & Sponsor Administration",
    segment: "enterprise",
    status: "ok",
    users: 1500,
    happy: 88, unhappy: 9, frustrated: 3, avail: 99.5, alerts: 0,
    subJourneysCount: 4
  },
  {
    id: "JRN-002",
    name: "Health, Dental & Disability Claims",
    segment: "enterprise",
    status: "warning",
    users: 3200,
    happy: 75, unhappy: 15, frustrated: 10, avail: 98.2, alerts: 4,
    subJourneysCount: 3
  },
  {
    id: "JRN-003",
    name: "Group Retirement & Wealth Servicing",
    segment: "enterprise",
    status: "ok",
    users: 800,
    happy: 95, unhappy: 3, frustrated: 2, avail: 99.9, alerts: 0,
    subJourneysCount: 1
  }
];

export const subJourneys = {
  "JRN-001": {
    title: "Member & Sponsor Administration",
    steps: [
      { id: "SUB-101", name: "1.1 Plan Member Onboarding & Digital Enrollment", status: "ok", resp: 120, avail: 99.9, errRate: 0.1, happy: 90, alerts: 0 },
      { id: "SUB-102", name: "1.2 Group Contract & Underwriting Setup", status: "ok", resp: 150, avail: 99.8, errRate: 0.2, happy: 88, alerts: 0 },
      { id: "SUB-103", name: "1.3 Plan Sponsor Billing & Premium Collection", status: "ok", resp: 200, avail: 99.5, errRate: 0.5, happy: 85, alerts: 0 },
      { id: "SUB-104", name: "1.4 Core Member Data & Operational Storage", status: "ok", resp: 100, avail: 99.9, errRate: 0.1, happy: 95, alerts: 0 },
    ]
  },
  "JRN-002": {
    title: "Health, Dental & Disability Claims",
    steps: [
      { id: "SUB-201", name: "2.1 Benefits Adjudication & Straight-Through Processing", status: "ok", resp: 180, avail: 99.5, errRate: 0.5, happy: 85, alerts: 0 },
      { id: "SUB-202", name: "2.2 Claims Intake & Manual Adjudication Support", status: "error", resp: 550, avail: 96.5, errRate: 4.5, happy: 60, alerts: 4 },
      { id: "SUB-203", name: "2.3 Disability Case & Rehabilitation Management", status: "warning", resp: 300, avail: 98.5, errRate: 1.5, happy: 75, alerts: 0 },
    ]
  },
  "JRN-003": {
    title: "Group Retirement & Wealth Servicing",
    steps: [
      { id: "SUB-301", name: "3.1 Workplace Savings & Pension Record-Keeping", status: "ok", resp: 150, avail: 99.9, errRate: 0.1, happy: 95, alerts: 0 }
    ]
  }
};

export const correlationCluster = {
  incident: {
    id: "INC2150158",
    root_cause: "PAGER79 309B TRANSACTION GS49RLC1 HAS ABENDED IN REGION IMSMPR01. USER MEDINN",
    root_cause_desc: "Transaction Abend detected for job <b>GS49RLC1</b> in region <b>IMSMPR01</b>. This matches the known PAGER Transaction Abend pattern family.",
    raw_alerts_grouped: 4,
    tools_contributing: 1,
    correlation_confidence_pct: 94,
    frustrated_user_count: 320
  },
  parent: {
    id: "INC2150158",
    time: "15-06-2025 10:20:15 AM",
    description: "PAGER79 309B TRANSACTION GS49RLC1 HAS ABENDED IN REGION IMSMPR01. USER MEDINN",
    grammar: "TRANSACTION_ABEND",
    extractedJob: "GS49RLC1",
    service: "Benefits"
  },
  children: [
    {
      id: "INC2150172",
      time: "15-06-2025 10:25:17 AM",
      description: "PAGER79 309B TRANSACTION GS49RLC1 HAS ABENDED IN REGION IMSMPR01. USER SIMYOL",
      delta: "5 min",
      confidence: 0.95,
      boosters: ["Same Service", "Same Assignment Group", "< 15m proximity"]
    },
    {
      id: "INC2150183",
      time: "15-06-2025 10:30:18 AM",
      description: "PAGER79 309B TRANSACTION GS49RLC1 HAS ABENDED IN REGION IMSMPR06. USER SIMYOL",
      delta: "10 min",
      confidence: 0.95,
      boosters: ["Same Service", "Same Assignment Group", "< 15m proximity"]
    },
    {
      id: "INC2150191",
      time: "15-06-2025 10:35:16 AM",
      description: "PAGER79 309B TRANSACTION GS49RLC1 HAS ABENDED IN REGION IMSMPR06. USER SIMYOL",
      delta: "15 min",
      confidence: 0.95,
      boosters: ["Same Service", "Same Assignment Group", "< 15m proximity"]
    },
    {
      id: "INC2150225",
      time: "15-06-2025 10:50:16 AM",
      description: "PAGER79 309B TRANSACTION GS49RLC1 HAS ABENDED IN REGION IMSMPR06. USER HINOGW",
      delta: "30 min",
      confidence: 0.90,
      boosters: ["Same Service", "Same Assignment Group"]
    },
    {
      id: "INC2150281",
      time: "15-06-2025 11:10:19 AM",
      description: "PAGER79 309B TRANSACTION GS49RLC1 HAS ABENDED IN REGION IMSMPR04. USER SIMYOL",
      delta: "50 min",
      confidence: 0.85,
      boosters: ["Same Service", "Same Assignment Group"]
    },
    {
      id: "INC2150284",
      time: "15-06-2025 11:10:34 AM",
      description: "PAGER79 309B TRANSACTION GS49RLC1 HAS ABENDED IN REGION IMSMPR02. USER SIMYOL",
      delta: "50 min",
      confidence: 0.85,
      boosters: ["Same Service", "Same Assignment Group"]
    },
    {
      id: "INC2150287",
      time: "15-06-2025 11:10:36 AM",
      description: "PAGER79 309B TRANSACTION GS49RLC1 HAS ABENDED IN REGION IMSMPR03. USER SIMYOL",
      delta: "50 min",
      confidence: 0.85,
      boosters: ["Same Service", "Same Assignment Group"]
    },
    {
      id: "INC2150313",
      time: "15-06-2025 11:20:18 AM",
      description: "PAGER79 309B TRANSACTION GS49RLC1 HAS ABENDED IN REGION IMSMPR05. USER SIMYOL",
      delta: "60 min",
      confidence: 0.80,
      boosters: ["Same Service", "Same Assignment Group"]
    },
    {
      id: "INC2150353",
      time: "15-06-2025 11:40:18 AM",
      description: "PAGER79 309B TRANSACTION GS49RLC1 HAS ABENDED IN REGION IMSMPR05. USER SIMYOL",
      delta: "80 min",
      confidence: 0.75,
      boosters: ["Same Service", "Same Assignment Group"]
    }
  ]
};

export const ruleDiscoveryData = {
  families: [
    { name: "PAGER Transaction Abend", count: 150, window: "65 min" },
    { name: "PAGER Job Abend", count: 10, window: "55 min" },
    { name: "IEF Job Failure", count: 15, window: "420 min" },
    { name: "Health Score Alerts", count: 320, window: "30 min" },
    { name: "CICS System Events", count: 40, window: "35 min" }
  ],
  jobNames: [
    "GH85RCOA", "GH85RCOC", "GS00NSCH", "GS20CUS1", "GS20RUSA", "GS26NCL2", "GS26NCTU", "GS26NSYB", "GS49RLC1",
    "GH20KHI1", "GS20KUS1", "GH10CLEX", "GH10MSHT", "GH20FTPI", "GH20FTPJ", "GH20LAKD", "GH20P256", "GH20R05P", 
    "GH20R07P", "GH20R10P", "GH20RRUN", "GS29PAEM"
  ],
  crossFamilyCascades: [
    {
      id: "CICS_CASCADE_001",
      parentFamily: "CICS System Events",
      childrenFamilies: ["IEF Job Failure", "PAGER Job Abend"],
      extractedKey: "CICSCN",
      timeWindow: "35 min",
      confidence: "High",
      groundTruthOccurrences: 6
    }
  ]
};
