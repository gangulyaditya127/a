"""Tier grid + correlation swim-lane data.

Aggregates (sev.crit/high, sources[], alertCount) are computed via SQL — never stored.
Source-mix order is **count-desc, then tool_id-asc** for stable output.
"""
from collections import defaultdict
from sqlalchemy import select, func
from sqlalchemy.orm import Session

from app.models.reference import (
    Tier, MonitoringTool, Component, ComponentDependency,
)
from app.models.alerts import Alert
from app.models.incidents import Incident, IncidentAlert, TierIncidentSummary, IncidentTopologyState, IncidentCriticalEdge
from app.models.analytics import TierHistoricalStat, TierTopCause


class AnalysisService:

    @staticmethod
    def get_tier_cards(db: Session, incident_id: str) -> list[dict]:
        inc = db.get(Incident, incident_id)
        if inc is None:
            raise ValueError(f"Unknown incident {incident_id}")

        tiers = db.execute(select(Tier).order_by(Tier.display_order)).scalars().all()

        alert_rows = db.execute(
            select(Alert, MonitoringTool)
            .join(IncidentAlert, IncidentAlert.alert_ref == Alert.alert_ref)
            .join(MonitoringTool, MonitoringTool.tool_id == Alert.tool_id)
            .where(IncidentAlert.incident_id == incident_id)
            .order_by(Alert.detected_at)
        ).all()

        summaries = {
            s.tier_id: s for s in
            db.execute(
                select(TierIncidentSummary).where(TierIncidentSummary.incident_id == incident_id)
            ).scalars().all()
        }

        latest_stats_ts = (
            select(TierHistoricalStat.tier_id,
                   func.max(TierHistoricalStat.computed_at).label("max_ts"))
            .group_by(TierHistoricalStat.tier_id).subquery()
        )
        stats_rows = db.execute(
            select(TierHistoricalStat)
            .join(latest_stats_ts,
                  (latest_stats_ts.c.tier_id == TierHistoricalStat.tier_id) &
                  (latest_stats_ts.c.max_ts  == TierHistoricalStat.computed_at))
        ).scalars().all()
        stats_by_tier = {s.tier_id: s for s in stats_rows}

        latest_causes_ts = (
            select(TierTopCause.tier_id, func.max(TierTopCause.computed_at).label("max_ts"))
            .group_by(TierTopCause.tier_id).subquery()
        )
        causes_rows = db.execute(
            select(TierTopCause)
            .join(latest_causes_ts,
                  (latest_causes_ts.c.tier_id == TierTopCause.tier_id) &
                  (latest_causes_ts.c.max_ts  == TierTopCause.computed_at))
            .order_by(TierTopCause.tier_id, TierTopCause.rank)
        ).scalars().all()
        causes_by_tier: dict[str, list] = defaultdict(list)
        for c in causes_rows:
            causes_by_tier[c.tier_id].append(c)

        cards = []
        for tier in tiers:
            tier_alerts = [(a, t) for a, t in alert_rows if a.tier_id == tier.tier_id]

            alerts_out = [
                {
                    "ref":  a.alert_ref,
                    "name": a.name,
                    "src":  t.name,
                    "sev":  a.severity,
                    "time": a.first_seen_today.strftime("%H:%M:%S"),
                }
                for a, t in tier_alerts
            ]

            sev = {
                "crit": sum(1 for a, _ in tier_alerts if a.severity == "crit"),
                "high": sum(1 for a, _ in tier_alerts if a.severity == "high"),
            }

            # Source mix — count-desc, tool_id-asc for deterministic ordering
            src_counts: dict[str, dict] = {}
            for a, tool in tier_alerts:
                label = tool.short_name or tool.name
                key = tool.tool_id
                if key not in src_counts:
                    src_counts[key] = {"k": label, "n": 0, "c": tool.color_hex, "_tid": key}
                src_counts[key]["n"] += 1
            sources = sorted(src_counts.values(), key=lambda s: (-s["n"], s["_tid"]))
            for s in sources:
                s.pop("_tid", None)

            sum_row = summaries.get(tier.tier_id)
            hist = stats_by_tier.get(tier.tier_id)
            hist_out = {
                "today":   hist.alerts_today if hist else 0,
                "last7d":  hist.alerts_last_7d if hist else 0,
                "last30d": hist.alerts_last_30d if hist else 0,
                "mttr":    f"{hist.median_mttr_minutes} min" if hist else "0 min",
            }
            top_causes = [
                {"name": c.cause_name, "pct": c.percentage}
                for c in causes_by_tier.get(tier.tier_id, [])
            ]

            cards.append({
                "id":         tier.tier_id,
                "name":       tier.name,
                "level":      tier.level,
                "icon":       tier.icon,
                "alertCount": len(tier_alerts),
                "isRoot":     bool(sum_row.is_root_cause) if sum_row else False,
                "summary":    sum_row.summary_text if sum_row else "",
                "sev":        sev,
                "sources":    sources,
                "hist":       hist_out,
                "topCauses":  top_causes,
                "alerts":     alerts_out,
            })
        return cards

    @staticmethod
    def get_corr_data(db: Session, incident_id: str) -> dict:
        inc = db.get(Incident, incident_id)
        if inc is None:
            raise ValueError(f"Unknown incident {incident_id}")

        tiers = db.execute(select(Tier).order_by(Tier.display_order)).scalars().all()
        lane_meta = [{"name": t.name, "level": t.level} for t in tiers]
        tier_order = {t.tier_id: t.display_order for t in tiers}

        # Deterministic order for stable output
        components = db.execute(
            select(Component).order_by(Component.display_order, Component.component_id)
        ).scalars().all()

        # Group by tier for y-layout
        by_tier: dict[str, list] = defaultdict(list)
        for c in components:
            by_tier[c.tier_id].append(c)

        states = db.execute(
            select(IncidentTopologyState).where(IncidentTopologyState.incident_id == incident_id)
        ).scalars().all()
        state_map = {s.component_id: s for s in states}

        nodes = []
        # Iterate in tier display order so JSON node order matches frontend expectation
        for tier in tiers:
            comps = by_tier.get(tier.tier_id, [])
            comps.sort(key=lambda c: c.layout_row)
            n = len(comps)
            for c in comps:
                # y-layout — matches corrData.json original coordinates
                if tier.tier_id == "pres" and n == 1:
                    y = 180
                elif tier.tier_id == "infra" and n == 2:
                    y = 120 if c.layout_row == 0 else 240
                elif tier.tier_id == "int" and n == 2:
                    y = 80 if c.layout_row == 0 else 220
                elif n == 1:
                    y = 180
                elif n == 2:
                    y = 80 if c.layout_row == 0 else 220
                elif n == 3:
                    y = 80 + c.layout_row * 100
                else:
                    y = 80 + c.layout_row * 100

                node = {
                    "id":    c.component_id,
                    "x":     125 + tier_order[c.tier_id] * 250,
                    "y":     y,
                    "w":     170,
                    "h":     44,
                    "label": c.name,
                    "sub":   c.sub_label or "",
                    "level": state_map.get(c.component_id).level_at_time if state_map.get(c.component_id) else c.level,
                    "tier":  tier_order[c.tier_id],
                }
                is_rc = state_map.get(c.component_id).is_rc_at_time if state_map.get(c.component_id) else c.is_rc
                if is_rc:
                    node["rc"] = True
                nodes.append(node)

        edges_all = db.execute(
            select(ComponentDependency).order_by(ComponentDependency.display_order,
                                                 ComponentDependency.dep_id)
        ).scalars().all()
        crit_edges_db = db.execute(
            select(IncidentCriticalEdge).where(IncidentCriticalEdge.incident_id == incident_id)
        ).scalars().all()
        crit_set = {(e.from_component, e.to_component) for e in crit_edges_db}

        crit_edges = []
        edges = []
        for e in edges_all:
            if (e.from_component, e.to_component) in crit_set:
                crit_edges.append([e.from_component, e.to_component])
            else:
                edges.append([e.from_component, e.to_component])

        return {
            "laneMeta":  lane_meta,
            "nodes":     nodes,
            "edges":     edges,
            "critEdges": crit_edges,
            "incident": {
                "id": inc.incident_id,
                "title": inc.title,
                "root_cause": inc.root_cause,
                "root_cause_desc": inc.root_cause_desc,
                "raw_alerts_grouped": inc.raw_alerts_grouped,
                "tools_contributing": inc.tools_contributing,
                "correlation_confidence_pct": float(inc.correlation_confidence_pct),
                "frustrated_user_count": inc.frustrated_user_count,
            }
        }
