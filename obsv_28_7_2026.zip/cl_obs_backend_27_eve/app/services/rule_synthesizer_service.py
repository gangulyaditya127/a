"""LLM-backed rule synthesizer. Uses internal proxy at http://10.73.74.36:20119/v1."""
import json, uuid
from datetime import datetime, timezone
from sqlalchemy.orm import Session

from app.core.config import settings
from app.models.ai_discovery import DiscoveredPattern, AiRuleProposal
from app.services.llm_call import invoke



PROMPT_TEMPLATE = """You are an AIOps rule designer. Given a co-firing pattern,
propose a correlation rule as strict JSON.

Pattern: {name}
Signals: {signals}
CIs involved: {cis}
Tiers involved: {tiers}
Support: pattern recurred {support}x in 90 days with avg time delta {delta}s.

Return ONLY a JSON object (no code fences, no prose) with EXACTLY these keys:
- "name": short human-readable name (max 90 chars)
- "plain_english": 1-2 sentence explanation (max 260 chars)
- "trigger_when": "<Tool> . <Signal>" for the anchor signal
- "trigger_target": what the anchor targets
- "combine_logic": e.g. "AND within 180 s AND on dependent topology chain (Data -> Integration -> Application)"
- "output_summary": what the rule accomplishes
- "confidence_score": float 0.0-1.0
- "expected_precision": float 0.0-1.0
- "expected_alert_reduction": integer, alerts collapsed into 1 incident
- "explanation": array of 2-3 short paragraphs justifying the rule
"""


class RuleSynthesizerService:

    @staticmethod
    def synthesize_from_pattern(db: Session, pattern_id: str) -> dict:
        pattern = db.get(DiscoveredPattern, pattern_id)
        if pattern is None:
            raise ValueError(f"Unknown pattern {pattern_id}")

        signals = json.loads(pattern.signals_json)
        cis     = json.loads(pattern.cis_json)
        tiers   = json.loads(pattern.tiers_json)

        proposal_dict = RuleSynthesizerService._call_llm(
            pattern.name, signals, cis, tiers,
            pattern.support_count, pattern.avg_time_delta_s
        )

        proposal_id = f"AI-PROP-{uuid.uuid4().hex[:8].upper()}"
        combine_inputs = RuleSynthesizerService._derive_combine_inputs(signals)

        proposal = AiRuleProposal(
            proposal_id=proposal_id,
            source_pattern_id=pattern_id,
            name=proposal_dict["name"],
            plain_english=proposal_dict["plain_english"],
            trigger_when=proposal_dict["trigger_when"],
            trigger_target=proposal_dict["trigger_target"],
            combine_logic=proposal_dict["combine_logic"],
            output_summary=proposal_dict["output_summary"],
            combine_inputs_json=json.dumps(combine_inputs),
            explanation_json=json.dumps(proposal_dict["explanation"]),
            confidence_score=float(proposal_dict["confidence_score"]),
            expected_precision=float(proposal_dict["expected_precision"]),
            expected_alert_reduction=int(proposal_dict["expected_alert_reduction"]),
            generated_by=proposal_dict.get("_generated_by", "openai"),
            llm_model=proposal_dict.get("_llm_model"),
            created_at=datetime.now(timezone.utc),
            status="pending",
        )
        db.add(proposal)
        pattern.status = "used"
        db.commit()

        return RuleSynthesizerService._to_dict(proposal, combine_inputs, proposal_dict["explanation"])

    @staticmethod
    def _call_llm(name, signals, cis, tiers, support, delta) -> dict:
        try:
            from app.services.llm_call import gemini_invoke
            prompt = PROMPT_TEMPLATE.format(
                name=name, signals=json.dumps(signals),
                cis=json.dumps(cis), tiers=json.dumps(tiers),
                support=support, delta=delta,
            )
            content = gemini_invoke(prompt, system_prompt="You synthesize AIOps correlation rules. Output strict JSON only.")
            data = json.loads(content)
            data["_generated_by"] = "gemini"
            data["_llm_model"] = getattr(settings, "GEMINI_LLM_MODEL", "gemini")
            return data
        except Exception as ex:
            print(f"[synthesizer] Gemini LLM call failed, using fallback: {ex}")
            return RuleSynthesizerService._fallback(name, signals, cis, tiers, support, delta)

    @staticmethod
    def _fallback(name, signals, cis, tiers, support, delta) -> dict:
        anchor = signals[0] if signals else {"tool_name": "Unknown", "signal": "Unknown"}
        chain = " -> ".join(tiers) if tiers else "any tier"
        confidence = min(0.60 + 0.05 * support, 0.95)
        return {
            "name": f"[Fallback] {name}",
            "plain_english": (
                f"Pattern seen {support} times over 90 days with avg time delta {delta}s. "
                f"Anchor: {anchor['tool_name']} - {anchor['signal']}. "
                "Groups matching alerts on the same topology chain."
            ),
            "trigger_when": f"{anchor['tool_name']} . {anchor['signal']}",
            "trigger_target": cis[0] if cis else "root cause component",
            "combine_logic": f"AND within {delta * 2}s AND on dependent topology chain ({chain})",
            "output_summary": "Single incident with grouped downstream symptoms.",
            "confidence_score": confidence,
            "expected_precision": min(confidence + 0.04, 0.95),
            "expected_alert_reduction": max(len(signals) * 2, 3),
            "explanation": [
                f"The pattern has recurred {support} times in 90 days - strong empirical support.",
                f"All signals arrive within {delta}s of anchor, indicating a causal link.",
                f"Topology chain ({chain}) confirms components are on a dependency path.",
            ],
            "_generated_by": "fallback-template",
            "_llm_model": None,
        }

    @staticmethod
    def _derive_combine_inputs(signals) -> list[dict]:
        out = []
        seen = set()
        for s in signals:
            key = (s.get("tool_id") or s.get("tool_name",""), s.get("signal",""))
            if key in seen:
                continue
            seen.add(key)
            out.append({
                "tool_id": s.get("tool_id",""),
                "tool_name": s.get("tool_name",""),
                "signal_pattern": s.get("signal",""),
            })
        return out

    @staticmethod
    def _to_dict(p: AiRuleProposal, combine_inputs, explanation) -> dict:
        return {
            "proposal_id":              p.proposal_id,
            "source_pattern_id":        p.source_pattern_id,
            "name":                     p.name,
            "plain_english":            p.plain_english,
            "trigger_when":             p.trigger_when,
            "trigger_target":           p.trigger_target,
            "combine_logic":            p.combine_logic,
            "output_summary":           p.output_summary,
            "combine_inputs":           combine_inputs,
            "explanation":              explanation,
            "confidence_score":         float(p.confidence_score),
            "expected_precision":       float(p.expected_precision),
            "expected_alert_reduction": p.expected_alert_reduction,
            "generated_by":             p.generated_by,
            "llm_model":                p.llm_model,
            "status":                   p.status,
            "deployed_rule_id":         p.deployed_rule_id,
            "created_at":               p.created_at.isoformat() if p.created_at else None,
        }
