"""Settings loaded from .env — same pattern as the reference skeleton."""
import os
from dotenv import load_dotenv

load_dotenv()


class Settings:
    APP_NAME       = os.getenv("APP_NAME", "Canada Life ARE Observability")
    APP_VERSION    = os.getenv("APP_VERSION", "1.0.0")
    DATABASE_URL   = os.getenv(
        "DATABASE_URL",
        "postgresql+psycopg2://postgres:postgres@localhost:5432/cl_observability",
    )
    OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
    OPENAI_MODEL   = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
    GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")
    GEMINI_LLM_MODEL   = os.getenv("GEMINI_LLM_MODEL",)
    OPENAI_ENABLED = os.getenv("OPENAI_ENABLED", "false").lower() == "true"
    CORS_ORIGINS   = [
        o.strip()
        for o in os.getenv("CORS_ORIGINS", "http://localhost:5173").split(",")
        if o.strip()
    ]
    CORRELATION_WINDOW_MINUTES = int(os.getenv("CORRELATION_WINDOW_MINUTES", "60"))


settings = Settings()
