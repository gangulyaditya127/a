import { useEffect, useState } from 'react';
import { observabilityService } from './services/observabilityService';
import { ToastProvider } from './context/ToastContext';
import { ModalProvider } from './context/ModalContext';
import TopBar from './components/TopBar';
import JourneysView from './components/JourneysView';
import StepsView from './components/StepsView';
import AnalysisView from './components/AnalysisView';
import DetailView from './components/DetailView';
import RuleDiscoveryView from './components/RuleDiscoveryView';

const CRUMB_LABELS = {
  journeys: 'Journeys',
  steps: 'Journey',
  analysis: 'Reliability Analysis',
  detail: 'Detailed Analysis',
};

function AppInner() {
  const [data, setData] = useState(null);
  const [err, setErr] = useState(null);
  const [view, setView] = useState('journeys');
  const [selectedJourney, setSelectedJourney] = useState(null);
  const [selectedStep, setSelectedStep] = useState(null);

  useEffect(() => {
    observabilityService.getAll()
      .then(setData)
      .catch(e => setErr(e.message));
  }, []);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [view]);

  if (err) return <div style={{ padding: 40 }}>Error: {err}</div>;
  if (!data) return <div style={{ padding: 40 }}>Loading…</div>;

  const { journeys, subJourneys, tiers, rawAlerts, corrData, rules } = data;

  const nav = (id) => setView(id);

  const openSteps = async (jid) => {
    try {
      const specificSubJourneys = await observabilityService.getSubJourneys(jid);

      // If the backend returned an empty object, no sub-journeys exist for this ID
      if (Object.keys(specificSubJourneys).length === 0) {
        return false;
      }

      setData(prevData => ({
        ...prevData,
        subJourneys: {
          ...prevData.subJourneys,
          ...specificSubJourneys
        }
      }));

      setSelectedJourney(jid);
      setView('steps');
      return true;
    } catch (e) {
      setErr(e.message);
      return false;
    }
  };

  const openAnalysis = async (stepId) => {
    try {
      // Dynamically fetch and replace alerts, corrData, tiers, and rules for this sub-journey
      const [scopedAlerts, scopedCorrData, tiersData, rulesData] = await Promise.all([
        observabilityService.getSubJourneyAlertsMap(stepId),
        observabilityService.getCorrData(stepId),
        observabilityService.getSubJourneyTiers(stepId),
        observabilityService.getRules()
      ]);

      setData(prevData => ({
        ...prevData,
        rawAlerts: scopedAlerts,
        corrData: scopedCorrData,
        tiers: tiersData,
        rules: rulesData
      }));

      setSelectedStep(stepId);
      setView('analysis');
    } catch (e) {
      setErr(e.message);
    }
  };

  const crumbs = [{ id: 'journeys', label: CRUMB_LABELS.journeys }];
  if (['steps', 'analysis', 'detail'].includes(view)) {
    crumbs.push({ id: 'steps', label: (selectedJourney && subJourneys[selectedJourney]?.title) || 'Journey' });
  }
  if (['analysis', 'detail'].includes(view)) {
    crumbs.push({ id: 'analysis', label: CRUMB_LABELS.analysis });
  }
  if (view === 'detail') {
    crumbs.push({ id: 'detail', label: CRUMB_LABELS.detail });
  }

  let subjourneyStepName = '';
  if (selectedJourney && selectedStep) {
    const s = subJourneys[selectedJourney]?.steps.find(x => x.id === selectedStep);
    if (s) subjourneyStepName = s.name;
  }
  const analysisBreadcrumb = selectedJourney && subJourneys[selectedJourney]
    ? `${subJourneys[selectedJourney].title} · ${subjourneyStepName || 'Upload Receipts'}`
    : 'Reliability Analysis';

  return (
    <>
      <TopBar crumbs={crumbs} onNav={nav} />
      <div className="main">
        {view === 'journeys' && (
          <JourneysView journeys={journeys} subJourneys={subJourneys} onOpenSteps={openSteps} />
        )}
        {view === 'steps' && (
          <StepsView
            journeyKey={selectedJourney}
            subJourneys={subJourneys}
            onBack={() => nav('journeys')}
            onOpenStep={openAnalysis}
          />
        )}
        {view === 'analysis' && (
          <AnalysisView
            tiers={tiers}
            corrData={corrData}
            incident={corrData?.incident}
            rawAlerts={rawAlerts}
            rules={rules}
            breadcrumb={analysisBreadcrumb}
            onBack={() => nav('steps')}
            onGoDetail={() => nav('detail')}
            subJourneyId={selectedStep}
          />
        )}
        {view === 'detail' && (
          <DetailView
            rules={rules}
            rawAlerts={rawAlerts}
            onBack={() => nav('analysis')}
          />
        )}
        {view === 'rule-discovery' && (
          <RuleDiscoveryView onBack={() => nav('journeys')} />
        )}
      </div>
      <footer>© Canada Life · ARE Observability Platform · Illustrative prototype</footer>
    </>
  );
}

export default function App() {
  return (
    <ToastProvider>
      <ModalProvider>
        <AppInner />
      </ModalProvider>
    </ToastProvider>
  );
}