"""
Main FastAPI application for CloudOps Onboarding workflow
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from contextlib import asynccontextmanager
import logging

from config import settings
from database import create_all_tables
from routes import onboarding_router, account_details_router, requirement_assessment_router

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


# Lifecycle startup and shutdown
@asynccontextmanager
async def lifespan(app: FastAPI):
    """Handle startup and shutdown events"""
    # Startup
    logger.info("🚀 Starting CloudOps Onboarding API...")
    logger.info(f"Database URL: {settings.DATABASE_URL}")
    create_all_tables()
    logger.info("✅ Database tables created/verified")
    yield
    # Shutdown
    logger.info("🛑 Shutting down CloudOps Onboarding API...")


# Create FastAPI app
app = FastAPI(
    title=settings.API_TITLE,
    description=settings.API_DESCRIPTION,
    version=settings.API_VERSION,
    lifespan=lifespan,
)

# Configure CORS
# For development, allow localhost origins; customize for production
allowed_origins = [
    "http://localhost:5173",      # Vite dev server (default)
    "http://localhost:3000",      # Create React App dev server
    "http://localhost:8080",      # Alternative dev server
    "http://127.0.0.1:5173",
    "http://127.0.0.1:3000",
    "http://127.0.0.1:8080",
]
# allowed_origins = ["*"]

app.add_middleware(
    CORSMiddleware,
    allow_origins=allowed_origins,
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
    allow_headers=["*"],
)


# Health check endpoint
@app.get("/health", tags=["System"])
async def health_check():
    """Health check endpoint"""
    return JSONResponse(
        {
            "status": "healthy",
            "service": settings.API_TITLE,
            "version": settings.API_VERSION,
        }
    )


# Include routers
app.include_router(onboarding_router)
app.include_router(account_details_router)
app.include_router(requirement_assessment_router)


# Root endpoint
@app.get("/", tags=["System"])
async def root():
    """Root endpoint with API information"""
    return {
        "message": "CloudOps Onboarding API",
        "description": settings.API_DESCRIPTION,
        "version": settings.API_VERSION,
        "docs": "/docs",
        "openapi_schema": "/openapi.json",
    }


# Exception handlers
@app.exception_handler(ValueError)
async def value_error_handler(request, exc):
    """Handle ValueError exceptions"""
    return JSONResponse(
        status_code=400,
        content={"error": "Invalid request", "details": str(exc)},
        headers={
            "Access-Control-Allow-Origin": request.headers.get("origin", "*"),
        },
    )


@app.exception_handler(Exception)
async def general_exception_handler(request, exc):
    """Handle general exceptions"""
    logger.error(f"Unhandled exception: {str(exc)}", exc_info=True)
    return JSONResponse(
        status_code=500,
        content={"error": "Internal server error", "details": str(exc)},
        headers={
            "Access-Control-Allow-Origin": request.headers.get("origin", "*"),
        }
    )


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        app,
        host="0.0.0.0",
        port=8000,
        reload=settings.DEBUG,
    )
