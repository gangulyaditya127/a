# CloudOps Onboarding API - Usage Guide

## Quick Start Examples

### 1. Create a New Onboarding Record

This creates a complete onboarding with account details and requirement assessment in one call.

```bash
curl -X POST "http://localhost:8000/api/onboarding/" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "TCS GenAI POC",
    "account_details": {
      "project_name": "GenAI Analytics Platform",
      "isu": "ISU-98765",
      "account_name": "tcs-prod-01",
      "owner": "Rajesh Kumar",
      "emp_id": "EMP-45678",
      "description": "Large Language Model based analytics platform for real-time insights",
      "business_unit": "Technology"
    },
    "requirement_assessment": {
      "solution_type": "generative-ai",
      "deployment_environments": ["development"],
      "cloud_providers": ["AWS"],
      "region": "ap-south-1"
    }
  }'
```

**Response:**
```json
{
  "id": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
  "name": "TCS GenAI POC",
  "status": "draft",
  "created_at": "2024-01-15T10:30:00",
  "updated_at": "2024-01-15T10:30:00",
  "account_details": {
    "id": "detail-uuid-here",
    "onboarding_id": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
    "project_name": "GenAI Analytics Platform",
    "isu": "ISU-98765",
    "account_name": "tcs-prod-01",
    "owner": "Rajesh Kumar",
    "emp_id": "EMP-45678",
    "description": "Large Language Model based analytics platform...",
    "business_unit": "Technology",
    "created_at": "2024-01-15T10:30:00",
    "updated_at": "2024-01-15T10:30:00"
  },
  "requirement_assessment": {
    "id": "requirement-uuid-here",
    "onboarding_id": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
    "solution_type": "generative-ai",
    "deployment_environments": ["development"],
    "cloud_providers": ["AWS"],
    "region": "ap-south-1",
    "created_at": "2024-01-15T10:30:00",
    "updated_at": "2024-01-15T10:30:00"
  }
}
```

---

### 2. Get Onboarding Details

Retrieve complete onboarding information by ID.

```bash
curl "http://localhost:8000/api/onboarding/a1b2c3d4-e5f6-7890-abcd-ef1234567890"
```

**Response:** (Same structure as above)

---

### 3. List All Onboarding Records

Get paginated list of all onboarding records with optional filtering.

```bash
# Get first 10 records
curl "http://localhost:8000/api/onboarding/"

# Get records with pagination
curl "http://localhost:8000/api/onboarding/?skip=0&limit=10"

# Filter by status
curl "http://localhost:8000/api/onboarding/?status=draft"

# Combine pagination and filtering
curl "http://localhost:8000/api/onboarding/?skip=10&limit=5&status=in_progress"
```

**Response:**
```json
{
  "data": [
    {
      "id": "uuid-1",
      "name": "Project 1",
      "status": "draft",
      "created_at": "2024-01-15T10:30:00",
      "updated_at": "2024-01-15T10:30:00",
      "account_details": {...},
      "requirement_assessment": {...}
    },
    {
      "id": "uuid-2",
      "name": "Project 2",
      "status": "in_progress",
      "created_at": "2024-01-14T14:22:00",
      "updated_at": "2024-01-15T09:15:00",
      "account_details": {...},
      "requirement_assessment": {...}
    }
  ],
  "total": 25,
  "skip": 0,
  "limit": 10
}
```

---

### 4. Update Onboarding Status

Progress the onboarding through the workflow.

```bash
curl -X PATCH "http://localhost:8000/api/onboarding/a1b2c3d4-e5f6-7890-abcd-ef1234567890/status?new_status=in_progress"
```

**Valid Status Values:**
- `draft` - Initial state
- `in_progress` - Workflow in progress
- `completed` - Workflow completed
- `submitted` - Submitted for approval

---

### 5. Update Account Details

Modify existing account details (partial update supported).

```bash
curl -X PUT "http://localhost:8000/api/account-details/detail-uuid-here" \
  -H "Content-Type: application/json" \
  -d '{
    "description": "Updated: Now includes real-time data processing",
    "business_unit": "Healthcare"
  }'
```

**Note:** Only include fields you want to update.

---

### 6. Update Requirement Assessment

Modify solution requirements and deployment settings.

```bash
curl -X PUT "http://localhost:8000/api/requirement-assessment/requirement-uuid-here" \
  -H "Content-Type: application/json" \
  -d '{
    "cloud_providers": ["AWS", "Azure"],
    "region": "us-east-1"
  }'
```

---

## Complete Workflow Example

Here's a typical workflow progression:

```bash
# Step 1: Create onboarding
ONBOARDING_ID=$(curl -s -X POST "http://localhost:8000/api/onboarding/" \
  -H "Content-Type: application/json" \
  -d '{...}' | jq -r '.id')

echo "Created Onboarding: $ONBOARDING_ID"

# Step 2: Get details to verify
curl "http://localhost:8000/api/onboarding/$ONBOARDING_ID"

# Step 3: Update account details if needed
curl -X PUT "http://localhost:8000/api/account-details/{account_details_id}" \
  -H "Content-Type: application/json" \
  -d '{...}'

# Step 4: Update requirement assessment if needed
curl -X PUT "http://localhost:8000/api/requirement-assessment/{requirement_assessment_id}" \
  -H "Content-Type: application/json" \
  -d '{...}'

# Step 5: Progress to next step
curl -X PATCH "http://localhost:8000/api/onboarding/$ONBOARDING_ID/status?new_status=in_progress"

# Step 6: Verify updated status
curl "http://localhost:8000/api/onboarding/$ONBOARDING_ID"
```

---

## Data Validation Examples

### Account Details Validation

**Required Fields:**
- `project_name` - Must be non-empty string (max 255 chars)
- `account_name` - Must be non-empty string (max 255 chars)
- `owner` - Must be non-empty string (max 255 chars)
- `emp_id` - Must be non-empty string (max 50 chars)

**Optional Fields:**
- `isu` - String (max 50 chars)
- `description` - Any text
- `business_unit` - Must be one of: BFSI, Manufacturing, Retail, Healthcare, Technology, Energy & Utilities

**Example - Invalid Request:**
```json
{
  "project_name": "",  // INVALID: Empty string
  "account_name": "account",
  "owner": "owner",
  "emp_id": "emp-id"
}
```

### Requirement Assessment Validation

**Required Fields:**
- `solution_type` - Must be:
  - `generative-ai` - For LLM, NLP, Computer Vision, GenAI POC
  - `non-generative-ai` - For Web Apps, APIs, Databases, Microservices

**Optional but Recommended:**
- `deployment_environments` - Array of: `development` or `production`
- `cloud_providers` - Array of: `AWS`, `Azure`, `GCP`, or `On-Prem`
- `region` - String specifying target region

**Business Rules:**
- If `solution_type` is `generative-ai`:
  - Only `development` environment is allowed
  - Production environment will be automatically rejected
  - If environments list is empty, defaults to `development`

**Example - Invalid Request:**
```json
{
  "solution_type": "generative-ai",
  "deployment_environments": ["production"],  // INVALID: GenAI cannot use production
  "cloud_providers": ["AWS"]
}
```

**Example - Valid Request (Auto-corrected):**
```json
{
  "solution_type": "generative-ai",
  "deployment_environments": [],  // Will default to ["development"]
  "cloud_providers": ["AWS"]
}
```

---

## Error Handling Examples

### 404 Not Found

```bash
curl "http://localhost:8000/api/onboarding/invalid-uuid"
```

**Response:**
```json
{
  "detail": "Onboarding with ID invalid-uuid not found"
}
```

### 400 Bad Request

```bash
curl -X POST "http://localhost:8000/api/onboarding/" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Project",
    "account_details": {
      "project_name": ""  // INVALID: Empty string
    }
  }'
```

**Response:**
```json
{
  "detail": [
    {
      "type": "value_error",
      "loc": ["body", "account_details", "project_name"],
      "msg": "ensure this value has at least 1 characters",
      "input": ""
    }
  ]
}
```

---

## Common Scenarios

### Scenario 1: Creating a Non-Generative AI Solution

```bash
curl -X POST "http://localhost:8000/api/onboarding/" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "E-Commerce Platform",
    "account_details": {
      "project_name": "Next-Gen E-Commerce",
      "isu": "ISU-11111",
      "account_name": "ecom-prod",
      "owner": "Amit Patel",
      "emp_id": "EMP-123",
      "description": "Scalable e-commerce platform with microservices",
      "business_unit": "Retail"
    },
    "requirement_assessment": {
      "solution_type": "non-generative-ai",
      "deployment_environments": ["development", "production"],
      "cloud_providers": ["AWS", "Azure"],
      "region": "us-east-1"
    }
  }'
```

### Scenario 2: Multi-Cloud Deployment

```bash
curl -X POST "http://localhost:8000/api/onboarding/" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Multi-Cloud Migration",
    "account_details": {
      "project_name": "Cloud Migration Initiative",
      "isu": "ISU-22222",
      "account_name": "multi-cloud",
      "owner": "Priya Singh",
      "emp_id": "EMP-456",
      "description": "Multi-cloud strategy with AWS, Azure, and GCP",
      "business_unit": "Technology"
    },
    "requirement_assessment": {
      "solution_type": "non-generative-ai",
      "deployment_environments": ["development", "production"],
      "cloud_providers": ["AWS", "Azure", "GCP"],
      "region": "ap-south-1"
    }
  }'
```

### Scenario 3: On-Premises Only Deployment

```bash
curl -X POST "http://localhost:8000/api/onboarding/" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "On-Premises Data Center",
    "account_details": {
      "project_name": "Legacy System Modernization",
      "isu": "ISU-33333",
      "account_name": "onprem-dc",
      "owner": "Vikram Verma",
      "emp_id": "EMP-789",
      "description": "Modernizing legacy on-premises infrastructure",
      "business_unit": "Manufacturing"
    },
    "requirement_assessment": {
      "solution_type": "non-generative-ai",
      "deployment_environments": ["production"],
      "cloud_providers": ["On-Prem"],
      "region": "on-prem"
    }
  }'
```

---

## Using Python Requests

```python
import requests
import json

BASE_URL = "http://localhost:8000/api"

# Create onboarding
response = requests.post(
    f"{BASE_URL}/onboarding/",
    json={
        "name": "Python Example",
        "account_details": {
            "project_name": "Test Project",
            "account_name": "test-account",
            "owner": "Test Owner",
            "emp_id": "EMP-999"
        },
        "requirement_assessment": {
            "solution_type": "generative-ai",
            "deployment_environments": ["development"],
            "cloud_providers": ["AWS"]
        }
    }
)

onboarding = response.json()
onboarding_id = onboarding["id"]
print(f"Created Onboarding: {onboarding_id}")

# Get details
response = requests.get(f"{BASE_URL}/onboarding/{onboarding_id}")
print(json.dumps(response.json(), indent=2))

# Update status
response = requests.patch(
    f"{BASE_URL}/onboarding/{onboarding_id}/status",
    params={"new_status": "in_progress"}
)
print(json.dumps(response.json(), indent=2))
```

---

## Api Testing with Postman

Import this collection into Postman:

```json
{
  "info": {
    "name": "CloudOps Onboarding API",
    "schema": "https://schema.getpostman.com/json/collection/v2.1.0/collection.json"
  },
  "item": [
    {
      "name": "Create Onboarding",
      "request": {
        "method": "POST",
        "header": [{"key": "Content-Type", "value": "application/json"}],
        "url": {"raw": "{{base_url}}/api/onboarding/", "host": ["{{base_url}}"], "path": ["api", "onboarding"]},
        "body": {"mode": "raw", "raw": "{\n  \"name\": \"{{$timestamp}}\",\n  \"account_details\": {...},\n  \"requirement_assessment\": {...}\n}"}
      }
    },
    {
      "name": "Get Onboarding",
      "request": {
        "method": "GET",
        "url": {"raw": "{{base_url}}/api/onboarding/{{onboarding_id}}", "host": ["{{base_url}}"], "path": ["api", "onboarding", "{{onboarding_id}}"]}
      }
    }
  ]
}
```

Set Postman variables:
- `base_url`: http://localhost:8000
- `onboarding_id`: (from create response)

---

## Tips & Tricks

1. **Use `jq` to parse JSON responses** (if installed):
   ```bash
   curl -s "http://localhost:8000/api/onboarding/" | jq '.[0]'
   ```

2. **Save responses to files**:
   ```bash
   curl -s "http://localhost:8000/api/onboarding/" > onboardings.json
   ```

3. **Use environment variables**:
   ```bash
   ONBOARDING_ID="abc123"
   curl "http://localhost:8000/api/onboarding/$ONBOARDING_ID"
   ```

4. **Pretty print responses**:
   ```bash
   curl -s "http://localhost:8000/api/onboarding/" | python -m json.tool
   ```

5. **Count total records**:
   ```bash
   curl -s "http://localhost:8000/api/onboarding/?limit=1" | jq '.total'
   ```

