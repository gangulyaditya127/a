# CloudOps Onboarding API - FastAPI Backend

A structured, production-ready FastAPI backend framework for the CloudOps New Onboarding workflow. This API handles the account creation, requirement assessment, and manages the entire onboarding process with PostgreSQL database persistence.

## 📋 Table of Contents

- [Overview](#overview)
- [Project Structure](#project-structure)
- [Prerequisites](#prerequisites)
- [Installation](#installation)
- [Configuration](#configuration)
- [Running the Application](#running-the-application)
- [API Documentation](#api-documentation)
- [Workflow Steps](#workflow-steps)
- [Database Models](#database-models)
- [API Endpoints](#api-endpoints)
- [Business Logic](#business-logic)
- [Development](#development)

## 🎯 Overview

This backend provides REST APIs for the CloudOps onboarding workflow, supporting:

1. **Account Details** - Project and account information
2. **Requirement Assessment** - Solution type, environment, and cloud provider selection
3. **Onboarding Management** - Workflow orchestration and status tracking

### Currently Implemented Steps

✅ **Account Details** - Create and manage project/account information
✅ **Requirement Assessment** - Configure solution type and deployment requirements

### Upcoming Steps

- Cloud Resources
- Architecture Overview
- Recommendations
- Approval Tracker
- Service ID Creation
- RFC Tracking

## 📁 Project Structure

```
backend/
├── main.py                          # FastAPI application entry point
├── config.py                        # Configuration settings
├── database.py                      # Database setup and connections
├── models.py                        # SQLAlchemy ORM models
├── schemas.py                       # Pydantic validation schemas
├── services.py                      # Business logic layer
├── routes/
│   ├── __init__.py
│   ├── onboarding.py               # Onboarding CRUD operations
│   ├── account_details.py          # Account Details APIs
│   └── requirement_assessment.py   # Requirement Assessment APIs
├── requirements.txt                # Python dependencies
├── .env.example                    # Environment variables template
└── README.md                       # This file
```

## 🔧 Prerequisites

- Python 3.9+
- PostgreSQL 12+
- pip (Python package manager)

## 📦 Installation

### 1. Clone/Navigate to the project

```bash
cd backend
```

### 2. Create a Python virtual environment

```bash
python -m venv venv

# On Windows
venv\Scripts\activate

# On macOS/Linux
source venv/bin/activate
```

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

### 4. Setup environment variables

```bash
# Copy the example environment file
cp .env.example .env

# Edit .env with your database credentials
# Update DB_HOST, DB_PORT, DB_USER, DB_PASSWORD, DB_NAME
```

Example `.env`:

```env
# Database Configuration
DB_HOST=localhost
DB_PORT=5432
DB_USER=postgres
DB_PASSWORD=your_password
DB_NAME=cloudops_onboarding

# API Configuration
DEBUG=True
```

### 5. Create PostgreSQL database

```bash
# Connect to PostgreSQL
psql -U postgres

# Create database
CREATE DATABASE cloudops_onboarding;

# Exit psql
\q
```

## 🚀 Running the Application

### Development mode (with auto-reload)

```bash
python main.py
```

Or using Uvicorn directly:

```bash
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

### Production mode

```bash
uvicorn main:app --host 0.0.0.0 --port 8000 --workers 4
```

The API will be available at: `http://localhost:8000`

## 📚 API Documentation

### Interactive Documentation

Once the server is running:

- **Swagger UI**: http://localhost:8000/docs
- **ReDoc**: http://localhost:8000/redoc

### Health Check

```bash
curl http://localhost:8000/health
```

## 🔄 Workflow Steps

### Step 1: Account Details

Collects project and account information:

- **Project Name** (required) - Name of the project
- **ISU** (optional) - ISU code
- **Account Name** (required) - Name of the account
- **Owner** (required) - Owner name
- **Employee ID** (required) - Employee ID
- **Description** (optional) - Project description
- **Business Unit** (optional) - BFSI, Manufacturing, Retail, Healthcare, Technology, Energy & Utilities

### Step 2: Requirement Assessment

Evaluates the solution requirements:

- **Solution Type** (required)
  - `generative-ai`: For LLM, NLP, Computer Vision, GenAI POC
  - `non-generative-ai`: For Web Apps, APIs, Databases, Microservices

- **Deployment Environments** (required)
  - `development`: Development Sandbox
  - `production`: Production environment
  - **Note**: Generative AI only supports development

- **Cloud Providers** (required) - Multiple select
  - `AWS`
  - `Azure`
  - `GCP`
  - `On-Prem`

- **Region** (optional) - Target deployment region

## 🗄️ Database Models

### Onboarding (Main Record)

```
id              : String (UUID) - Primary Key
name            : String - Onboarding name
status          : Enum - draft, in_progress, completed, submitted
created_at      : DateTime
updated_at      : DateTime
```

### AccountDetails

```
id              : String (UUID) - Primary Key
onboarding_id   : String (FK) - Reference to Onboarding
project_name    : String - Project name (indexed)
isu             : String - ISU code
account_name    : String - Account name (indexed)
owner           : String - Owner name
emp_id          : String - Employee ID (indexed)
description     : Text - Project description
business_unit   : String - Business unit
created_at      : DateTime
updated_at      : DateTime
created_by      : String - User who created
updated_by      : String - User who updated
```

### RequirementAssessment

```
id                        : String (UUID) - Primary Key
onboarding_id             : String (FK) - Reference to Onboarding
solution_type             : String - generative-ai or non-generative-ai
deployment_environments   : Array[String] - development, production
cloud_providers           : Array[String] - AWS, Azure, GCP, On-Prem
region                    : String - Target region
created_at                : DateTime
updated_at                : DateTime
created_by                : String - User who created
updated_by                : String - User who updated
```

## 🔌 API Endpoints

### Onboarding Management

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/onboarding/` | Create new onboarding |
| GET | `/api/onboarding/{id}` | Get onboarding by ID |
| GET | `/api/onboarding/` | List all onboarding records |
| PATCH | `/api/onboarding/{id}/status` | Update onboarding status |
| DELETE | `/api/onboarding/{id}` | Delete onboarding |

### Account Details

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/account-details/create/{onboarding_id}` | Create account details |
| GET | `/api/account-details/{id}` | Get account details by ID |
| GET | `/api/account-details/onboarding/{onboarding_id}` | Get by onboarding ID |
| PUT | `/api/account-details/{id}` | Update account details |
| DELETE | `/api/account-details/{id}` | Delete account details |

### Requirement Assessment

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/requirement-assessment/create/{onboarding_id}` | Create requirement assessment |
| GET | `/api/requirement-assessment/{id}` | Get assessment by ID |
| GET | `/api/requirement-assessment/onboarding/{onboarding_id}` | Get by onboarding ID |
| PUT | `/api/requirement-assessment/{id}` | Update assessment |
| DELETE | `/api/requirement-assessment/{id}` | Delete assessment |

## 💼 Business Logic

The business logic is organized in the `services.py` file with three main service classes:

### AccountDetailsService

- `create_account_details()` - Create new account details
- `get_account_details()` - Retrieve by ID
- `get_account_details_by_onboarding()` - Retrieve by onboarding ID
- `update_account_details()` - Update with partial data
- `delete_account_details()` - Delete record

### RequirementAssessmentService

- `create_requirement_assessment()` - Create new assessment
- `get_requirement_assessment()` - Retrieve by ID
- `get_requirement_assessment_by_onboarding()` - Retrieve by onboarding ID
- `update_requirement_assessment()` - Update with partial data
- `delete_requirement_assessment()` - Delete record

### OnboardingService

- `create_onboarding()` - Create complete onboarding record
- `get_onboarding()` - Retrieve by ID
- `get_all_onboardings()` - List with pagination and filtering
- `update_onboarding_status()` - Update workflow status
- `delete_onboarding()` - Delete record and cascade delete related data

## 🛠️ Development

### Adding a New Workflow Step

To add a new workflow step (e.g., Cloud Resources):

1. **Create Model** in `models.py`:
   ```python
   class CloudResource(Base):
       __tablename__ = "cloud_resources"
       # Define columns
   ```

2. **Create Schema** in `schemas.py`:
   ```python
   class CloudResourceCreate(BaseModel):
       # Define fields
   ```

3. **Create Service** in `services.py`:
   ```python
   class CloudResourceService:
       @staticmethod
       def create_cloud_resource(...):
           # Implementation
   ```

4. **Create Routes** in `routes/cloud_resources.py`:
   ```python
   router = APIRouter(prefix="/api/cloud-resources")
   # Define endpoints
   ```

5. **Register Router** in `main.py`:
   ```python
   from routes import cloud_resources_router
   app.include_router(cloud_resources_router)
   ```

### Database Migrations

To reset the database during development:

```python
# This will drop all tables (USE WITH CAUTION)
from database import drop_all_tables
drop_all_tables()

# Then restart the app to recreate tables
```

## 🧪 Testing

Example API calls:

### Create Onboarding with Account Details and Requirement Assessment

```bash
curl -X POST "http://localhost:8000/api/onboarding/" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "My Project Onboarding",
    "account_details": {
      "project_name": "AI Analytics Platform",
      "isu": "ISU-12345",
      "account_name": "prod-account",
      "owner": "John Doe",
      "emp_id": "EMP-001",
      "description": "Analytics platform using GenAI",
      "business_unit": "Technology"
    },
    "requirement_assessment": {
      "solution_type": "generative-ai",
      "deployment_environments": ["development"],
      "cloud_providers": ["AWS"],
      "region": "ap-south-1"
    }
  }'
```

### Get Onboarding Details

```bash
curl "http://localhost:8000/api/onboarding/{onboarding_id}"
```

### Update Account Details

```bash
curl -X PUT "http://localhost:8000/api/account-details/{account_details_id}" \
  -H "Content-Type: application/json" \
  -d '{
    "description": "Updated project description"
  }'
```

### List All Onboardings

```bash
curl "http://localhost:8000/api/onboarding/?skip=0&limit=10"
```

## 📝 Notes

- All IDs are UUID v4
- Timestamps are in UTC
- Pagination defaults: skip=0, limit=10 (max 100)
- Database connections use connection pooling (pool_size=10, max_overflow=20)
- CORS is enabled for all origins in development
- Comprehensive error handling with meaningful error messages
- Database uses PostgreSQL with SQLAlchemy ORM

## 🔐 Security Considerations (For Future Implementation)

- Add authentication/authorization
- Use `updated_by` and `created_by` fields to track changes
- Add audit logging
- Implement rate limiting
- Validate user permissions before operations
- Use prepared statements (already using SQLAlchemy)
- Add input sanitization
- Implement HTTPS in production

## 📞 Support

For issues or questions:

1. Check the FastAPI docs at `http://localhost:8000/docs`
2. Review database logs for connection issues
3. Check application logs for detailed error messages
4. Ensure PostgreSQL is running and accessible

---

**Status**: Actively developed - Core framework and first two workflow steps complete.
