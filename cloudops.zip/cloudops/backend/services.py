"""
Business logic layer for onboarding workflow
Handles database operations and business rules
"""

import uuid
from datetime import datetime
from sqlalchemy.orm import Session
from models import Onboarding, AccountDetails, RequirementAssessment, OnboardingStatusEnum
from schemas import (
    AccountDetailsCreate,
    AccountDetailsUpdate,
    RequirementAssessmentCreate,
    RequirementAssessmentUpdate,
    OnboardingCreate,
)


# ============================================================================
# ACCOUNT DETAILS BUSINESS LOGIC
# ============================================================================

class AccountDetailsService:
    """Service class for Account Details operations"""

    @staticmethod
    def create_account_details(
        db: Session,
        onboarding_id: str,
        data: AccountDetailsCreate,
        created_by: str = None,
    ) -> AccountDetails:
        """
        Create new account details record

        Args:
            db: Database session
            onboarding_id: ID of the parent onboarding record
            data: Account details data
            created_by: User who created the record

        Returns:
            Created AccountDetails object

        Raises:
            ValueError: If onboarding record doesn't exist
        """
        # Verify onboarding exists
        onboarding = db.query(Onboarding).filter(Onboarding.id == onboarding_id).first()
        if not onboarding:
            raise ValueError(f"Onboarding with ID {onboarding_id} not found")

        # Check if account details already exists
        existing = db.query(AccountDetails).filter(
            AccountDetails.onboarding_id == onboarding_id
        ).first()
        if existing:
            # Update existing instead of creating new
            return AccountDetailsService.update_account_details(db, existing.id, data, created_by)

        # Create new account details
        db_account_details = AccountDetails(
            id=str(uuid.uuid4()),
            onboarding_id=onboarding_id,
            project_name=data.project_name,
            isu=data.isu,
            account_name=data.account_name,
            owner=data.owner,
            emp_id=data.emp_id,
            description=data.description,
            business_unit=data.business_unit,
            created_by=created_by,
            updated_by=created_by,
        )

        db.add(db_account_details)
        db.commit()
        db.refresh(db_account_details)
        return db_account_details

    @staticmethod
    def get_account_details(db: Session, account_details_id: str) -> AccountDetails:
        """Get account details by ID"""
        account_details = db.query(AccountDetails).filter(
            AccountDetails.id == account_details_id
        ).first()
        if not account_details:
            raise ValueError(f"Account Details with ID {account_details_id} not found")
        return account_details

    @staticmethod
    def get_account_details_by_onboarding(db: Session, onboarding_id: str) -> AccountDetails:
        """Get account details by onboarding ID"""
        account_details = db.query(AccountDetails).filter(
            AccountDetails.onboarding_id == onboarding_id
        ).first()
        return account_details

    @staticmethod
    def update_account_details(
        db: Session,
        account_details_id: str,
        data: AccountDetailsUpdate,
        updated_by: str = None,
    ) -> AccountDetails:
        """
        Update account details

        Args:
            db: Database session
            account_details_id: ID of account details to update
            data: Update data (only provided fields will be updated)
            updated_by: User who updated the record

        Returns:
            Updated AccountDetails object
        """
        account_details = db.query(AccountDetails).filter(
            AccountDetails.id == account_details_id
        ).first()
        if not account_details:
            raise ValueError(f"Account Details with ID {account_details_id} not found")

        # Update only provided fields
        update_data = data.dict(exclude_unset=True)
        for field, value in update_data.items():
            setattr(account_details, field, value)

        account_details.updated_by = updated_by
        account_details.updated_at = datetime.utcnow()

        db.commit()
        db.refresh(account_details)
        return account_details

    @staticmethod
    def delete_account_details(db: Session, account_details_id: str) -> bool:
        """Delete account details"""
        account_details = db.query(AccountDetails).filter(
            AccountDetails.id == account_details_id
        ).first()
        if not account_details:
            raise ValueError(f"Account Details with ID {account_details_id} not found")

        db.delete(account_details)
        db.commit()
        return True


# ============================================================================
# REQUIREMENT ASSESSMENT BUSINESS LOGIC
# ============================================================================

class RequirementAssessmentService:
    """Service class for Requirement Assessment operations"""

    @staticmethod
    def create_requirement_assessment(
        db: Session,
        onboarding_id: str,
        data: RequirementAssessmentCreate,
        created_by: str = None,
    ) -> RequirementAssessment:
        """
        Create new requirement assessment record

        Args:
            db: Database session
            onboarding_id: ID of the parent onboarding record
            data: Requirement assessment data
            created_by: User who created the record

        Returns:
            Created RequirementAssessment object

        Raises:
            ValueError: If onboarding record doesn't exist
        """
        # Verify onboarding exists
        onboarding = db.query(Onboarding).filter(Onboarding.id == onboarding_id).first()
        if not onboarding:
            raise ValueError(f"Onboarding with ID {onboarding_id} not found")

        # Check if requirement assessment already exists
        existing = db.query(RequirementAssessment).filter(
            RequirementAssessment.onboarding_id == onboarding_id
        ).first()
        if existing:
            # Update existing instead of creating new
            return RequirementAssessmentService.update_requirement_assessment(
                db, existing.id, data, created_by
            )

        # Create new requirement assessment
        db_requirement = RequirementAssessment(
            id=str(uuid.uuid4()),
            onboarding_id=onboarding_id,
            solution_type=data.solution_type,
            deployment_environments=data.deployment_environments,
            cloud_providers=data.cloud_providers,
            region=data.region,
            created_by=created_by,
            updated_by=created_by,
        )

        db.add(db_requirement)
        db.commit()
        db.refresh(db_requirement)
        return db_requirement

    @staticmethod
    def get_requirement_assessment(db: Session, requirement_assessment_id: str) -> RequirementAssessment:
        """Get requirement assessment by ID"""
        requirement = db.query(RequirementAssessment).filter(
            RequirementAssessment.id == requirement_assessment_id
        ).first()
        if not requirement:
            raise ValueError(f"Requirement Assessment with ID {requirement_assessment_id} not found")
        return requirement

    @staticmethod
    def get_requirement_assessment_by_onboarding(
        db: Session,
        onboarding_id: str,
    ) -> RequirementAssessment:
        """Get requirement assessment by onboarding ID"""
        requirement = db.query(RequirementAssessment).filter(
            RequirementAssessment.onboarding_id == onboarding_id
        ).first()
        return requirement

    @staticmethod
    def update_requirement_assessment(
        db: Session,
        requirement_assessment_id: str,
        data: RequirementAssessmentUpdate,
        updated_by: str = None,
    ) -> RequirementAssessment:
        """
        Update requirement assessment

        Args:
            db: Database session
            requirement_assessment_id: ID of requirement assessment to update
            data: Update data (only provided fields will be updated)
            updated_by: User who updated the record

        Returns:
            Updated RequirementAssessment object
        """
        requirement = db.query(RequirementAssessment).filter(
            RequirementAssessment.id == requirement_assessment_id
        ).first()
        if not requirement:
            raise ValueError(f"Requirement Assessment with ID {requirement_assessment_id} not found")

        # Update only provided fields
        update_data = data.dict(exclude_unset=True)
        for field, value in update_data.items():
            setattr(requirement, field, value)

        requirement.updated_by = updated_by
        requirement.updated_at = datetime.utcnow()

        db.commit()
        db.refresh(requirement)
        return requirement

    @staticmethod
    def delete_requirement_assessment(db: Session, requirement_assessment_id: str) -> bool:
        """Delete requirement assessment"""
        requirement = db.query(RequirementAssessment).filter(
            RequirementAssessment.id == requirement_assessment_id
        ).first()
        if not requirement:
            raise ValueError(
                f"Requirement Assessment with ID {requirement_assessment_id} not found"
            )

        db.delete(requirement)
        db.commit()
        return True


# ============================================================================
# ONBOARDING BUSINESS LOGIC
# ============================================================================

class OnboardingService:
    """Service class for Onboarding operations"""

    @staticmethod
    def create_onboarding(
        db: Session,
        data: OnboardingCreate,
        created_by: str = None,
    ) -> Onboarding:
        """
        Create new onboarding record with account details and requirement assessment

        Args:
            db: Database session
            data: Onboarding data including nested account details and requirement assessment
            created_by: User who created the record

        Returns:
            Created Onboarding object with nested data
        """
        onboarding_id = str(uuid.uuid4())

        # Create main onboarding record
        db_onboarding = Onboarding(
            id=onboarding_id,
            name=data.name,
            status=OnboardingStatusEnum.DRAFT,
        )
        db.add(db_onboarding)
        db.flush()  # Flush to ensure ID is available

        # Create account details
        account_details = AccountDetailsService.create_account_details(
            db, onboarding_id, data.account_details, created_by
        )

        # Create requirement assessment
        # requirement_assessment = RequirementAssessmentService.create_requirement_assessment(
        #     db, onboarding_id, data.requirement_assessment, created_by
        # )

        db.commit()
        db.refresh(db_onboarding)
        return db_onboarding

    @staticmethod
    def get_onboarding(db: Session, onboarding_id: str) -> Onboarding:
        """Get onboarding record by ID"""
        onboarding = db.query(Onboarding).filter(Onboarding.id == onboarding_id).first()
        if not onboarding:
            raise ValueError(f"Onboarding with ID {onboarding_id} not found")
        return onboarding

    @staticmethod
    def get_all_onboardings(
        db: Session,
        skip: int = 0,
        limit: int = 10,
        status: str = None,
    ) -> tuple:
        """
        Get all onboarding records with pagination

        Returns:
            Tuple of (onboardings, total_count)
        """
        query = db.query(Onboarding)

        if status:
            query = query.filter(Onboarding.status == status)

        total_count = query.count()
        onboardings = query.order_by(Onboarding.created_at.desc()).offset(skip).limit(limit).all()

        return onboardings, total_count

    @staticmethod
    def update_onboarding_status(
        db: Session,
        onboarding_id: str,
        new_status: str,
    ) -> Onboarding:
        """Update onboarding status"""
        onboarding = db.query(Onboarding).filter(Onboarding.id == onboarding_id).first()
        if not onboarding:
            raise ValueError(f"Onboarding with ID {onboarding_id} not found")

        onboarding.status = new_status
        onboarding.updated_at = datetime.utcnow()

        db.commit()
        db.refresh(onboarding)
        return onboarding

    @staticmethod
    def delete_onboarding(db: Session, onboarding_id: str) -> bool:
        """Delete onboarding and all related data"""
        onboarding = db.query(Onboarding).filter(Onboarding.id == onboarding_id).first()
        if not onboarding:
            raise ValueError(f"Onboarding with ID {onboarding_id} not found")

        db.delete(onboarding)
        db.commit()
        return True
