from datetime import datetime
from sqlalchemy import Column, String, DateTime, Integer, Enum as SQLEnum, ForeignKey, ARRAY, Text, Boolean
from sqlalchemy.orm import relationship
import enum
from database import Base


class OnboardingStatusEnum(str, enum.Enum):
    """Enum for onboarding status"""
    DRAFT = "draft"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    SUBMITTED = "submitted"


class Onboarding(Base):
    """Main onboarding record that ties all steps together"""
    __tablename__ = "onboarding"

    id = Column(String(36), primary_key=True, index=True)
    name = Column(String(255), nullable=False)
    status = Column(SQLEnum(OnboardingStatusEnum), default=OnboardingStatusEnum.DRAFT, index=True)
    created_at = Column(DateTime, default=datetime.utcnow, index=True)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, index=True)

    # Relationships
    account_details = relationship("AccountDetails", back_populates="onboarding", uselist=False, cascade="all, delete-orphan")
    requirement_assessment = relationship("RequirementAssessment", back_populates="onboarding", uselist=False, cascade="all, delete-orphan")

    def __repr__(self):
        return f"<Onboarding(id={self.id}, name={self.name}, status={self.status})>"


class AccountDetails(Base):
    """Account Details for onboarding workflow"""
    __tablename__ = "account_details"

    id = Column(String(36), primary_key=True, index=True)
    onboarding_id = Column(String(36), ForeignKey("onboarding.id"), nullable=False, index=True)

    # Account fields
    project_name = Column(String(255), nullable=False, index=True)
    isu = Column(String(50), nullable=True)
    account_name = Column(String(255), nullable=False, index=True)
    owner = Column(String(255), nullable=False)
    emp_id = Column(String(50), nullable=False, index=True)
    description = Column(Text, nullable=True)
    business_unit = Column(String(100), nullable=True)

    # Metadata
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    created_by = Column(String(255), nullable=True)
    updated_by = Column(String(255), nullable=True)

    # Relationship
    onboarding = relationship("Onboarding", back_populates="account_details")

    def __repr__(self):
        return f"<AccountDetails(id={self.id}, project_name={self.project_name}, account_name={self.account_name})>"


class RequirementAssessment(Base):
    """Requirement Assessment for onboarding workflow"""
    __tablename__ = "requirement_assessment"

    id = Column(String(36), primary_key=True, index=True)
    onboarding_id = Column(String(36), ForeignKey("onboarding.id"), nullable=False, index=True)

    # Assessment fields
    solution_type = Column(String(50), nullable=False)  # 'generative-ai' or 'non-generative-ai'
    deployment_environments = Column(ARRAY(String), nullable=False, default=[])  # Array of environments
    cloud_providers = Column(ARRAY(String), nullable=False, default=[])  # Array of providers (AWS, Azure, GCP, On-Prem)
    region = Column(String(100), nullable=True)

    # Metadata
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    created_by = Column(String(255), nullable=True)
    updated_by = Column(String(255), nullable=True)

    # Relationship
    onboarding = relationship("Onboarding", back_populates="requirement_assessment")

    def __repr__(self):
        return f"<RequirementAssessment(id={self.id}, solution_type={self.solution_type}, providers={self.cloud_providers})>"
