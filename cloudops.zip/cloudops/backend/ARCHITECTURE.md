# CloudOps Onboarding API - Architecture & Design Document

## System Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                     Frontend (React/TypeScript)                 │
│                      (UI Folder - Separate)                     │
└────────────────────────────┬────────────────────────────────────┘
                             │ HTTP/REST API
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│                    FastAPI Backend Server                        │
├─────────────────────────────────────────────────────────────────┤
│ main.py                                                          │
│ ├── Routes Layer (routes/)                                       │
│ │   ├── onboarding.py - Main onboarding CRUD operations        │
│ │   ├── account_details.py - Account management               │
│ │   └── requirement_assessment.py - Requirements management   │
│ │                                                               │
│ ├── Services Layer (services.py)                               │
│ │   ├── OnboardingService                                     │
│ │   ├── AccountDetailsService                                 │
│ │   └── RequirementAssessmentService                          │
│ │                                                               │
│ ├── Data Validation Layer (schemas.py - Pydantic)             │
│ │   ├── Request/Response Schemas                              │
│ │   └── Business Logic Validation                             │
│ │                                                               │
│ └── Database Layer                                             │
│     ├── models.py - SQLAlchemy ORM Models                     │
│     └── database.py - Connection Management                   │
└────────────────────────────┬────────────────────────────────────┘
                             │ SQL
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│                    PostgreSQL Database                           │
│  ├── onboarding table                                           │
│  ├── account_details table                                      │
│  └── requirement_assessment table                               │
└─────────────────────────────────────────────────────────────────┘
```

## Layered Architecture Design

### 1. **Route/Controller Layer** (`routes/`)
- **Responsibility:** Handle HTTP requests and responses
- **Files:**
  - `onboarding.py` - Onboarding CRUD endpoints
  - `account_details.py` - Account Details endpoints
  - `requirement_assessment.py` - Requirement Assessment endpoints

**Key Functions:**
- Request validation (Pydantic schemas)
- HTTP response formatting
- Error handling with appropriate status codes
- Documentation with OpenAPI/Swagger

### 2. **Service Layer** (`services.py`)
- **Responsibility:** Encapsulate business logic
- **Classes:**
  - `OnboardingService` - Onboarding workflow logic
  - `AccountDetailsService` - Account operations
  - `RequirementAssessmentService` - Requirement operations

**Key Functions:**
- Data persistence operations
- Business rule enforcement
- Database transaction management
- Cross-entity relationships

### 3. **Data Layer** (`models.py` + `database.py`)
- **Responsibility:** Data access and persistence
- **Models:**
  - `Onboarding` - Main workflow record
  - `AccountDetails` - Project account information
  - `RequirementAssessment` - Solution requirements
  
**Key Features:**
- SQLAlchemy ORM mapping
- Relationships and foreign keys
- Cascade delete operations
- Timestamps (created_at, updated_at)
- Audit fields (created_by, updated_by)

### 4. **Validation Layer** (`schemas.py`)
- **Responsibility:** Request/response validation
- **Uses:** Pydantic models
- **Features:**
  - Type validation
  - Field constraints
  - Custom validators
  - Business rule validation

## Data Flow Diagram

```
Request
   │
   ▼
┌─────────────────────────────┐
│  HTTP Route Handlers        │  (routes/)
│  (Request parsing)          │
└──────────────┬──────────────┘
               │
               ▼
        ┌────────────────────┐
        │ Pydantic Schemas   │  (schemas.py)
        │ (Validation)       │
        └────────┬───────────┘
                 │
                 ▼
        ┌────────────────────┐
        │ Service Classes    │  (services.py)
        │ (Business Logic)   │
        └────────┬───────────┘
                 │
                 ▼
        ┌────────────────────┐
        │ SQLAlchemy Models  │  (models.py)
        │ (ORM)              │
        └────────┬───────────┘
                 │
                 ▼
        ┌────────────────────┐
        │ SQLAlchemy Engine  │  (database.py)
        │ (Connection Pool)  │
        └────────┬───────────┘
                 │
                 ▼
        ┌────────────────────┐
        │ PostgreSQL DB      │
        └────────────────────┘
                 │
   ┌─────────────┴─────────────┐
   ▼                           ▼
Response                 Database State
```

## API Flow Example: Create Onboarding

```
1. Client sends POST request with JSON body
   POST /api/onboarding/
   {
     "name": "Project Name",
     "account_details": {...},
     "requirement_assessment": {...}
   }

2. FastAPI routes/onboarding.py::create_onboarding() receives request
   - Validates schema using Pydantic

3. OnboardingService.create_onboarding() is called
   - Creates Onboarding record
   - Calls AccountDetailsService.create_account_details()
   - Calls RequirementAssessmentService.create_requirement_assessment()

4. AccountDetailsService creates AccountDetails model
   - Validates onboarding exists
   - Generates UUID
   - Persists to database

5. RequirementAssessmentService creates RequirementAssessment model
   - Applies business rules (e.g., GenAI restriction)
   - Persists to database

6. Database returns created records

7. Response formatted as OnboardingDetailResponse schema

8. FastAPI returns JSON response to client
```

## Workflow States

```
┌─────────┐
│ DRAFT   │ <- Initial state when onboarding created
└────┬────┘
     │
     ▼
┌──────────────┐
│ IN_PROGRESS  │ <- User is filling out workflow steps
└────┬─────────┘
     │
     ▼
┌───────────┐
│ SUBMITTED │ <- Ready for approval
└────┬──────┘
     │
     ▼
┌───────────┐
│ COMPLETED │ <- Final state
└───────────┘
```

## Database Schema

### Onboarding Table
```sql
CREATE TABLE onboarding (
  id VARCHAR(36) PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  status ENUM('draft', 'in_progress', 'completed', 'submitted') DEFAULT 'draft',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

### Account Details Table
```sql
CREATE TABLE account_details (
  id VARCHAR(36) PRIMARY KEY,
  onboarding_id VARCHAR(36) NOT NULL REFERENCES onboarding(id) ON DELETE CASCADE,
  project_name VARCHAR(255) NOT NULL,
  isu VARCHAR(50),
  account_name VARCHAR(255) NOT NULL,
  owner VARCHAR(255) NOT NULL,
  emp_id VARCHAR(50) NOT NULL,
  description TEXT,
  business_unit VARCHAR(100),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  created_by VARCHAR(255),
  updated_by VARCHAR(255),
  INDEX(onboarding_id),
  INDEX(project_name),
  INDEX(emp_id)
);
```

### Requirement Assessment Table
```sql
CREATE TABLE requirement_assessment (
  id VARCHAR(36) PRIMARY KEY,
  onboarding_id VARCHAR(36) NOT NULL REFERENCES onboarding(id) ON DELETE CASCADE,
  solution_type VARCHAR(50) NOT NULL,
  deployment_environments TEXT[] NOT NULL,
  cloud_providers TEXT[] NOT NULL,
  region VARCHAR(100),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  created_by VARCHAR(255),
  updated_by VARCHAR(255),
  INDEX(onboarding_id)
);
```

## Business Rules & Validations

### Account Details
- ✅ `project_name` required, max 255 chars
- ✅ `account_name` required, max 255 chars
- ✅ `owner` required, max 255 chars
- ✅ `emp_id` required, max 50 chars
- ✅ `business_unit` must be valid enum value
- ✅ One account_details per onboarding

### Requirement Assessment
- ✅ `solution_type` required (generative-ai or non-generative-ai)
- ✅ If generative-ai: only development environment allowed
- ✅ If generative-ai + no environments: defaults to development
- ✅ `cloud_providers` must be from: AWS, Azure, GCP, On-Prem
- ✅ `deployment_environments` must be: development, production
- ✅ One requirement_assessment per onboarding

## Error Handling Strategy

```
HTTP Request
    │
    ├─ Validation Error (400)
    │  └─ Pydantic validation fails
    │
    ├─ Not Found (404)
    │  └─ Resource doesn't exist
    │
    ├─ Business Logic Error (400)
    │  └─ Rule violation (e.g., FK constraint)
    │
    └─ Server Error (500)
       └─ Unexpected exception
```

## Security Features

### Implemented
- ✅ SQL injection prevention (SQLAlchemy parameterized queries)
- ✅ CORS configuration
- ✅ Input validation using Pydantic
- ✅ Error messages without leaking system details (production)
- ✅ Connection pooling with connection limits

### Future Enhancements
- 🔲 JWT authentication
- 🔲 Role-based access control
- 🔲 Audit logging
- 🔲 Rate limiting
- 🔲 Request signing
- 🔲 API key management

## Performance Considerations

### Optimizations
- **Connection Pooling:** Pool size=10, max_overflow=20
- **Query Optimization:** Indexed fields (onboarding_id, emp_id, project_name)
- **Lazy Loading:** Relationships configured appropriately
- **Database Pre-ping:** Verify connections before use

### Scaling Strategy
- **Horizontal:** Multiple API instances behind load balancer
- **Vertical:** Increase PostgreSQL resources
- **Read Replicas:** For high-read scenarios
- **Caching:** Future: Redis for frequently accessed data

## Extension Points

### Adding a New Workflow Step

1. **Model** (models.py)
   ```python
   class CloudResources(Base):
       __tablename__ = "cloud_resources"
       # Define columns
   ```

2. **Schema** (schemas.py)
   ```python
   class CloudResourcesCreate(BaseModel):
       # Define fields
   ```

3. **Service** (services.py)
   ```python
   class CloudResourcesService:
       @staticmethod
       def create_cloud_resources(...):
           # Implementation
   ```

4. **Routes** (routes/cloud_resources.py)
   ```python
   @router.post("/create/{onboarding_id}")
   async def create_cloud_resources(...):
       # Handler
   ```

5. **Register** in main.py
   ```python
   from routes import cloud_resources_router
   app.include_router(cloud_resources_router)
   ```

## Testing Strategy

### Unit Tests (services.py)
```python
def test_create_account_details():
    # Test AccountDetailsService.create_account_details()
    pass

def test_invalid_business_unit():
    # Test validation
    pass
```

### Integration Tests (end-to-end)
```python
def test_complete_onboarding_flow():
    # 1. Create onboarding
    # 2. Verify account details
    # 3. Update requirement assessment
    # 4. Check status change
    pass
```

### API Tests
```bash
# Using pytest + httpx
def test_api_create_onboarding():
    # Test API endpoint
    pass
```

## Deployment Architecture

```
┌────────────────────────────────────────────────────────────────┐
│                         Load Balancer                          │
│                      (Nginx/HAProxy)                           │
└────┬──────────────────────────────────────────┬────────────────┘
     │                                          │
     ▼                                          ▼
┌─────────────────────────┐          ┌─────────────────────────┐
│   API Instance 1        │          │   API Instance 2        │
│  (FastAPI + Uvicorn)    │          │  (FastAPI + Uvicorn)    │
└────────┬────────────────┘          └────────┬────────────────┘
         │                                    │
         └────────────────┬───────────────────┘
                          │
                          ▼
           ┌──────────────────────────────┐
           │   PostgreSQL Database        │
           │   (Master + Read Replicas)   │
           └──────────────────────────────┘
```

## Monitoring & Logging

### Application Logs
- Request/Response logging
- Database query logging (DEBUG mode)
- Error tracking
- Performance metrics

### Database Logs
- Query performance
- Connection pool status
- Slow query logs

### Health Checks
- `/health` - Application health
- Database connectivity
- Connection pool status

## Future Enhancements

### Phase 2: Cloud Resources
- Store cloud resource configurations
- Provider-specific validation
- Resource counting and tracking

### Phase 3: Architecture Overview
- Upload and store diagrams
- Security violation detection
- Architecture analysis

### Phase 4: Recommendations & Approvals
- Recommendation engine
- Approval workflow
- Notification system

### Phase 5: Service ID & RFC
- Service ID generation
- RFC tracking and management
- Change management integration

