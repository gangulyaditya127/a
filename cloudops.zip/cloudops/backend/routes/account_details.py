"""
API routes for Account Details operations
"""

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from database import get_db
from schemas import (
    AccountDetailsCreate,
    AccountDetailsUpdate,
    AccountDetailsResponse,
    SuccessResponse,
    ErrorResponse,
)
from services import AccountDetailsService

router = APIRouter(prefix="/api/account-details", tags=["Account Details"])


@router.post(
    "/create/{onboarding_id}",
    response_model=AccountDetailsResponse,
    status_code=status.HTTP_201_CREATED,
    responses={
        400: {"model": ErrorResponse, "description": "Invalid input"},
        404: {"model": ErrorResponse, "description": "Onboarding not found"},
    },
)
async def create_account_details(
    onboarding_id: str,
    data: AccountDetailsCreate,
    db: Session = Depends(get_db),
):
    """
    Create account details for an onboarding record

    **Required fields:**
    - project_name: Name of the project
    - account_name: Name of the account
    - owner: Owner name
    - emp_id: Employee ID

    **Optional fields:**
    - isu: ISU code
    - description: Project description
    - business_unit: Business unit (BFSI, Manufacturing, Retail, Healthcare, Technology, Energy & Utilities)
    """
    try:
        account_details = AccountDetailsService.create_account_details(
            db=db,
            onboarding_id=onboarding_id,
            data=data,
            created_by="system",  # TODO: Get from authentication context
        )
        return account_details
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Failed to create account details: {str(e)}",
        )


@router.get(
    "/{account_details_id}",
    response_model=AccountDetailsResponse,
    responses={404: {"model": ErrorResponse, "description": "Account Details not found"}},
)
async def get_account_details(
    account_details_id: str,
    db: Session = Depends(get_db),
):
    """Get account details by ID"""
    try:
        account_details = AccountDetailsService.get_account_details(db, account_details_id)
        return account_details
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))


@router.get(
    "/onboarding/{onboarding_id}",
    response_model=AccountDetailsResponse,
)
async def get_account_details_by_onboarding(
    onboarding_id: str,
    db: Session = Depends(get_db),
):
    """Get account details by onboarding ID"""
    account_details = AccountDetailsService.get_account_details_by_onboarding(db, onboarding_id)
    if not account_details:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Account Details for onboarding {onboarding_id} not found",
        )
    return account_details


@router.put(
    "/{account_details_id}",
    response_model=AccountDetailsResponse,
    responses={404: {"model": ErrorResponse, "description": "Account Details not found"}},
)
async def update_account_details(
    account_details_id: str,
    data: AccountDetailsUpdate,
    db: Session = Depends(get_db),
):
    """
    Update account details

    **Updateable fields:**
    - project_name
    - isu
    - account_name
    - owner
    - emp_id
    - description
    - business_unit

    Only provide fields you want to update.
    """
    try:
        account_details = AccountDetailsService.update_account_details(
            db=db,
            account_details_id=account_details_id,
            data=data,
            updated_by="system",  # TODO: Get from authentication context
        )
        return account_details
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Failed to update account details: {str(e)}",
        )


@router.delete(
    "/{account_details_id}",
    response_model=SuccessResponse,
    responses={404: {"model": ErrorResponse, "description": "Account Details not found"}},
)
async def delete_account_details(
    account_details_id: str,
    db: Session = Depends(get_db),
):
    """Delete account details"""
    try:
        AccountDetailsService.delete_account_details(db, account_details_id)
        return SuccessResponse(message="Account Details deleted successfully")
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Failed to delete account details: {str(e)}",
        )
