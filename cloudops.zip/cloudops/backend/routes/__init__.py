"""
API routes package
"""

from .onboarding import router as onboarding_router
from .account_details import router as account_details_router
from .requirement_assessment import router as requirement_assessment_router

__all__ = [
    "onboarding_router",
    "account_details_router",
    "requirement_assessment_router",
]
