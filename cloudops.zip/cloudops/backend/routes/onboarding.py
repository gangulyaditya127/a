"""
API routes for Onboarding operations
"""

from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session
from datetime import datetime
import uuid
from database import get_db
from schemas import (
    OnboardingCreate,
    OnboardingResponse,
    OnboardingDetailResponse,
    SuccessResponse,
    ErrorResponse,
    OnboardingIDResponse,
)
from services import OnboardingService

router = APIRouter(prefix="/api/onboarding", tags=["Onboarding"])


@router.get(
    "/generate-id",
    response_model=OnboardingIDResponse,
    status_code=status.HTTP_200_OK,
)
async def generate_onboarding_id():
    """
    Generate a new onboarding ID

    This endpoint generates and returns a unique onboarding ID that can be used
    to create a new onboarding record.

    **Returns:**
    - onboarding_id: Generated unique identifier
    - created_at: Timestamp when the ID was generated
    """
    try:
        onboarding_id = str(uuid.uuid4())
        return OnboardingIDResponse(
            onboarding_id=onboarding_id,
            created_at=datetime.utcnow(),
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to generate onboarding ID: {str(e)}",
        )


@router.post(
    "/",
    response_model=OnboardingDetailResponse,
    status_code=status.HTTP_201_CREATED,
    responses={400: {"model": ErrorResponse, "description": "Invalid input"}},
)
async def create_onboarding(
    data: OnboardingCreate,
    db: Session = Depends(get_db),
):
    """
    Create new onboarding record with account details and requirement assessment

    This endpoint creates a complete onboarding record with:
    - Account Details (project info, owner, business unit, etc.)
    - Requirement Assessment (solution type, environments, cloud providers, region)

    The onboarding starts in DRAFT status and can be progressed through the workflow steps.
    """
    try:
        onboarding = OnboardingService.create_onboarding(
            db=db,
            data=data,
            created_by="system",  # TODO: Get from authentication context
        )
        return onboarding
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Failed to create onboarding: {str(e)}",
        )


@router.get(
    "/{onboarding_id}",
    response_model=OnboardingDetailResponse,
    responses={404: {"model": ErrorResponse, "description": "Onboarding not found"}},
)
async def get_onboarding(
    onboarding_id: str,
    db: Session = Depends(get_db),
):
    """Get onboarding record by ID"""
    try:
        onboarding = OnboardingService.get_onboarding(db, onboarding_id)
        return onboarding
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))


@router.get(
    "",
    response_model=dict,
)
async def list_onboardings(
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(10, ge=1, le=100, description="Number of records to return"),
    status_filter: str = Query(None, description="Filter by status (draft, in_progress, completed, submitted)"),
    db: Session = Depends(get_db),
):
    """
    List all onboarding records with pagination and optional filtering

    **Query Parameters:**
    - skip: Number of records to skip (default: 0)
    - limit: Number of records to return (default: 10, max: 100)
    - status: Filter by status (optional)

    **Returns:**
    - data: List of onboarding records
    - total: Total number of records matching the filter
    - skip: Number of records skipped
    - limit: Number of records returned
    """
    try:
        onboardings, total = OnboardingService.get_all_onboardings(db, skip, limit, status_filter)
        print(f"Retrieved {len(onboardings)} onboardings (total: {total}) with status filter: {status_filter}")
        print(f"Onboarding IDs: {[o.id for o in onboardings]}")
        
        serialized_data = [
            {
                "id": o.id,
                "name": o.name,
                "status": o.status,
                "created_at": o.created_at,
                "updated_at": o.updated_at
            }
            for o in onboardings
        ]
        print(f"Serialized onboarding data: {serialized_data}")
        return {
            # "data": onboardings,
            "data": serialized_data,
            "total": total,
            "skip": skip,
            "limit": limit,
        }
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Failed to list onboardings: {str(e)}",
        )


@router.patch(
    "/{onboarding_id}/status",
    response_model=OnboardingResponse,
    responses={404: {"model": ErrorResponse, "description": "Onboarding not found"}},
)
async def update_onboarding_status(
    onboarding_id: str,
    new_status: str = Query(..., description="New status (draft, in_progress, completed, submitted)"),
    db: Session = Depends(get_db),
):
    """
    Update onboarding status

    **Valid statuses:**
    - draft: Initial state
    - in_progress: Workflow in progress
    - completed: Workflow completed
    - submitted: Submitted for approval

    This endpoint transitions the onboarding through different states.
    """
    try:
        onboarding = OnboardingService.update_onboarding_status(db, onboarding_id, new_status)
        return onboarding
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Failed to update onboarding status: {str(e)}",
        )


@router.delete(
    "/{onboarding_id}",
    response_model=SuccessResponse,
    responses={404: {"model": ErrorResponse, "description": "Onboarding not found"}},
)
async def delete_onboarding(
    onboarding_id: str,
    db: Session = Depends(get_db),
):
    """Delete onboarding and all related data"""
    try:
        OnboardingService.delete_onboarding(db, onboarding_id)
        return SuccessResponse(
            message="Onboarding deleted successfully",
            data={"onboarding_id": onboarding_id},
        )
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Failed to delete onboarding: {str(e)}",
        )
