"""
API routes for Requirement Assessment operations
"""

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from database import get_db
from schemas import (
    RequirementAssessmentCreate,
    RequirementAssessmentUpdate,
    RequirementAssessmentResponse,
    SuccessResponse,
    ErrorResponse,
)
from services import RequirementAssessmentService

router = APIRouter(prefix="/api/requirement-assessment", tags=["Requirement Assessment"])


@router.post(
    "/create/{onboarding_id}",
    response_model=RequirementAssessmentResponse,
    status_code=status.HTTP_201_CREATED,
    responses={
        400: {"model": ErrorResponse, "description": "Invalid input"},
        404: {"model": ErrorResponse, "description": "Onboarding not found"},
    },
)
async def create_requirement_assessment(
    onboarding_id: str,
    data: RequirementAssessmentCreate,
    db: Session = Depends(get_db),
):
    """
    Create requirement assessment for an onboarding record

    **Required fields:**
    - solution_type: Type of solution
        - 'generative-ai': For Generative AI solutions (LLM, NLP, Computer Vision, GenAI POC)
        - 'non-generative-ai': For other solutions (Web Apps, APIs, Databases, Microservices)

    **Optional fields:**
    - deployment_environments: List of environments
        - Valid values: 'development', 'production'
        - Note: Generative AI only supports 'development'
    - cloud_providers: List of cloud providers
        - Valid values: 'AWS', 'Azure', 'GCP', 'On-Prem'
    - region: Target region

    **Business Rules:**
    - Generative AI solutions can only be deployed to development environments
    - If generative-ai is selected and no environments specified, defaults to 'development'
    """
    try:
        requirement_assessment = RequirementAssessmentService.create_requirement_assessment(
            db=db,
            onboarding_id=onboarding_id,
            data=data,
            created_by="system",  # TODO: Get from authentication context
        )
        return requirement_assessment
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Failed to create requirement assessment: {str(e)}",
        )


@router.get(
    "/{requirement_assessment_id}",
    response_model=RequirementAssessmentResponse,
    responses={404: {"model": ErrorResponse, "description": "Requirement Assessment not found"}},
)
async def get_requirement_assessment(
    requirement_assessment_id: str,
    db: Session = Depends(get_db),
):
    """Get requirement assessment by ID"""
    try:
        requirement_assessment = RequirementAssessmentService.get_requirement_assessment(
            db, requirement_assessment_id
        )
        return requirement_assessment
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))


@router.get(
    "/onboarding/{onboarding_id}",
    response_model=RequirementAssessmentResponse,
)
async def get_requirement_assessment_by_onboarding(
    onboarding_id: str,
    db: Session = Depends(get_db),
):
    """Get requirement assessment by onboarding ID"""
    requirement_assessment = RequirementAssessmentService.get_requirement_assessment_by_onboarding(
        db, onboarding_id
    )
    if not requirement_assessment:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Requirement Assessment for onboarding {onboarding_id} not found",
        )
    return requirement_assessment


@router.put(
    "/{requirement_assessment_id}",
    response_model=RequirementAssessmentResponse,
    responses={404: {"model": ErrorResponse, "description": "Requirement Assessment not found"}},
)
async def update_requirement_assessment(
    requirement_assessment_id: str,
    data: RequirementAssessmentUpdate,
    db: Session = Depends(get_db),
):
    """
    Update requirement assessment

    **Updateable fields:**
    - solution_type: Type of solution ('generative-ai' or 'non-generative-ai')
    - deployment_environments: List of environments
    - cloud_providers: List of cloud providers
    - region: Target region

    Only provide fields you want to update.

    **Business Rules:**
    - Updating to generative-ai will restrict environments to 'development' only
    - Non-generative-ai can use both 'development' and 'production'
    """
    try:
        requirement_assessment = RequirementAssessmentService.update_requirement_assessment(
            db=db,
            requirement_assessment_id=requirement_assessment_id,
            data=data,
            updated_by="system",  # TODO: Get from authentication context
        )
        return requirement_assessment
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Failed to update requirement assessment: {str(e)}",
        )


@router.delete(
    "/{requirement_assessment_id}",
    response_model=SuccessResponse,
    responses={404: {"model": ErrorResponse, "description": "Requirement Assessment not found"}},
)
async def delete_requirement_assessment(
    requirement_assessment_id: str,
    db: Session = Depends(get_db),
):
    """Delete requirement assessment"""
    try:
        RequirementAssessmentService.delete_requirement_assessment(db, requirement_assessment_id)
        return SuccessResponse(message="Requirement Assessment deleted successfully")
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Failed to delete requirement assessment: {str(e)}",
        )
