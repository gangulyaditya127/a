from pydantic import BaseModel, Field, validator
from typing import Optional, List
from datetime import datetime
from enum import Enum


class SolutionTypeEnum(str, Enum):
    """Solution type options"""
    GENERATIVE_AI = "generative-ai"
    NON_GENERATIVE_AI = "non-generative-ai"


class BusinessUnitEnum(str, Enum):
    """Business unit options"""
    BFSI = "BFSI"
    MANUFACTURING = "Manufacturing"
    RETAIL = "Retail"
    HEALTHCARE = "Healthcare"
    TECHNOLOGY = "Technology"
    ENERGY = "Energy & Utilities"


# ============================================================================
# ACCOUNT DETAILS SCHEMAS
# ============================================================================

class AccountDetailsBase(BaseModel):
    """Base schema for Account Details"""
    project_name: str = Field(..., min_length=1, max_length=255, description="Project name")
    isu: Optional[str] = Field(None, max_length=50, description="ISU code")
    account_name: str = Field(..., min_length=1, max_length=255, description="Account name")
    owner: str = Field(..., min_length=1, max_length=255, description="Owner name")
    emp_id: str = Field(..., min_length=1, max_length=50, description="Employee ID")
    description: Optional[str] = Field(None, description="Project description")
    business_unit: Optional[str] = Field(None, description="Business unit")

    @validator("business_unit")
    def validate_business_unit(cls, v):
        if v and v not in [unit.value for unit in BusinessUnitEnum]:
            raise ValueError(f"Invalid business unit: {v}")
        return v


class AccountDetailsCreate(AccountDetailsBase):
    """Schema for creating Account Details"""
    pass


class AccountDetailsUpdate(BaseModel):
    """Schema for updating Account Details"""
    project_name: Optional[str] = Field(None, max_length=255)
    isu: Optional[str] = Field(None, max_length=50)
    account_name: Optional[str] = Field(None, max_length=255)
    owner: Optional[str] = Field(None, max_length=255)
    emp_id: Optional[str] = Field(None, max_length=50)
    description: Optional[str] = None
    business_unit: Optional[str] = None


class AccountDetailsResponse(AccountDetailsBase):
    """Schema for Account Details API response"""
    id: str
    onboarding_id: str
    created_at: datetime
    updated_at: datetime
    created_by: Optional[str]
    updated_by: Optional[str]

    class Config:
        from_attributes = True


# ============================================================================
# REQUIREMENT ASSESSMENT SCHEMAS
# ============================================================================

class RequirementAssessmentBase(BaseModel):
    """Base schema for Requirement Assessment"""
    solution_type: SolutionTypeEnum = Field(..., description="Type of solution")
    deployment_environments: List[str] = Field([], description="Deployment environments")
    cloud_providers: List[str] = Field([], description="Cloud providers")
    region: Optional[str] = Field(None, max_length=100, description="Region")

    @validator("deployment_environments")
    def validate_environments(cls, v):
        valid_envs = {"development", "production"}
        for env in v:
            if env not in valid_envs:
                raise ValueError(f"Invalid environment: {env}. Must be one of {valid_envs}")
        return v

    @validator("cloud_providers")
    def validate_providers(cls, v):
        valid_providers = {"AWS", "Azure", "GCP", "On-Prem"}
        for provider in v:
            if provider not in valid_providers:
                raise ValueError(f"Invalid provider: {provider}. Must be one of {valid_providers}")
        return v

    @validator("solution_type", pre=True)
    def validate_solution_type(cls, v):
        if isinstance(v, str):
            if v not in ["generative-ai", "non-generative-ai"]:
                raise ValueError("Invalid solution type")
        return v

    @validator("deployment_environments", pre=True, always=True)
    def restrict_genai_env(cls, v, values):
        """For generative AI, only development is allowed"""
        if "solution_type" in values and values["solution_type"] == SolutionTypeEnum.GENERATIVE_AI:
            if "production" in v:
                raise ValueError("Generative AI solutions can only be deployed to development environments")
            if not v:  # If empty, default to development
                return ["development"]
        return v


class RequirementAssessmentCreate(RequirementAssessmentBase):
    """Schema for creating Requirement Assessment"""
    pass


class RequirementAssessmentUpdate(BaseModel):
    """Schema for updating Requirement Assessment"""
    solution_type: Optional[SolutionTypeEnum] = None
    deployment_environments: Optional[List[str]] = None
    cloud_providers: Optional[List[str]] = None
    region: Optional[str] = None


class RequirementAssessmentResponse(RequirementAssessmentBase):
    """Schema for Requirement Assessment API response"""
    id: str
    onboarding_id: str
    created_at: datetime
    updated_at: datetime
    created_by: Optional[str]
    updated_by: Optional[str]

    class Config:
        from_attributes = True


# ============================================================================
# ONBOARDING SCHEMAS
# ============================================================================

# class OnboardingCreate(BaseModel):
#     """Schema for creating Onboarding record"""
#     name: str = Field(..., min_length=1, max_length=255)
#     account_details: AccountDetailsCreate
#     requirement_assessment: RequirementAssessmentCreate

class OnboardingCreate(BaseModel):
    """Schema for creating Onboarding record"""
    name: str = Field(..., min_length=1, max_length=255)
    account_details: AccountDetailsCreate
    #requirement_assessment: RequirementAssessmentCreate

class OnboardingResponse(BaseModel):
    """Schema for Onboarding API response"""
    id: str
    name: str
    status: str
    created_at: datetime
    updated_at: datetime
    account_details: Optional[AccountDetailsResponse]
    requirement_assessment: Optional[RequirementAssessmentResponse]

    class Config:
        from_attributes = True


class OnboardingDetailResponse(OnboardingResponse):
    """Detailed onboarding response with all information"""
    pass


# ============================================================================
# GENERIC RESPONSE SCHEMAS
# ============================================================================

class SuccessResponse(BaseModel):
    """Generic success response"""
    message: str
    data: Optional[dict] = None


class ErrorResponse(BaseModel):
    """Generic error response"""
    error: str
    details: Optional[dict] = None


class OnboardingIDResponse(BaseModel):
    """Response for generating onboarding ID"""
    onboarding_id: str
    created_at: datetime
