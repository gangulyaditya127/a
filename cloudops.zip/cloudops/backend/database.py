from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, Session
from config import settings

# Create engine
engine = create_engine(
    settings.DATABASE_URL,
    #echo=settings.DEBUG,
    echo=False,  # Disable SQL logging for cleaner output; set to True for debugging
    pool_pre_ping=True,  # Verify connections before using
    pool_size=10,
    max_overflow=20,
)

# Create session factory
SessionLocal = sessionmaker(
    autocommit=False,
    autoflush=False,
    bind=engine,
)

# Base class for models
Base = declarative_base()


def get_db() -> Session:
    """Dependency to get database session"""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def create_all_tables():
    """Create all tables in the database"""
    Base.metadata.create_all(bind=engine)


def drop_all_tables():
    """Drop all tables from the database (USE WITH CAUTION)"""
    Base.metadata.drop_all(bind=engine)
