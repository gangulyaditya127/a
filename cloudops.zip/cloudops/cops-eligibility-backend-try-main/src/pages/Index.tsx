import { useState } from "react";
import { Dashboard } from "@/components/Dashboard";
import { OnboardingWizard } from "@/components/OnboardingWizard";
import { EligibilityAssessment } from "@/components/EligibilityAssessment";
import { EligibilityDisclaimer } from "@/components/EligibilityDisclaimer";
import { type PopularOnboardingTemplate } from "@/data/onboardingTemplates";
import type { SavedOnboarding } from "@/lib/onboardingStorage";

type Mode = "dashboard" | "eligibility" | "disclaimer" | "wizard";

const Index = () => {
  const [mode, setMode] = useState<Mode>("dashboard");
  const [template, setTemplate] = useState<PopularOnboardingTemplate | null>(null);
  const [existing, setExisting] = useState<SavedOnboarding | null>(null);

  const backToDashboard = () => setMode("dashboard");

  if (mode === "dashboard") {
    return (
      <Dashboard
        onStartBlank={() => { setTemplate(null); setExisting(null); setMode("eligibility"); }}
        onUseTemplate={(t) => { setTemplate(t); setExisting(null); setMode("eligibility"); }}
        onResume={(item) => { setTemplate(null); setExisting(item); setMode("wizard"); }}
      />
    );
  }

  if (mode === "eligibility") {
    return (
      <EligibilityAssessment
        onPass={() => setMode("disclaimer")}
        onCancel={backToDashboard}
      />
    );
  }

  if (mode === "disclaimer") {
    return (
      <EligibilityDisclaimer
        onAgree={() => setMode("wizard")}
        onDisagree={backToDashboard}
      />
    );
  }

  return (
    <OnboardingWizard
      initialTemplate={template?.state}
      existing={existing}
      onBackToDashboard={backToDashboard}
    />
  );
};

export default Index;
