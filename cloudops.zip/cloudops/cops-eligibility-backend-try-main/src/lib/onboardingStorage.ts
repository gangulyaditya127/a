// Local-only persistence for the parts of the onboarding workflow that
// don't yet have FastAPI endpoints (cloud resources, architecture,
// recommendations, approvals, service ID, RFCs, current step).
//
// Keyed by the backend onboarding id so the local extension travels with
// the server-side record.

import type { OnboardingState } from "@/types/onboarding";
import {
  type BackendOnboarding,
  type DisplayStatus,
  displayStatus,
  toFrontendAccountDetails,
  toFrontendRequirement,
} from "./onboardingApi";

const KEY = "dis_onboarding_local_v2";

export type ExtendedLocalState = Pick<
  OnboardingState,
  | "currentStep"
  | "cloudResources"
  | "architectureOverview"
  | "recommendations"
  | "approvals"
  | "serviceId"
  | "rfcs"
>;

const emptyLocal = (): ExtendedLocalState => ({
  currentStep: 1,
  cloudResources: [],
  architectureOverview: {
    uploadedDiagram: null,
    generatedFromBucket: false,
    securityViolations: [],
    revisedDiagram: null,
    analysisComplete: false,
  },
  recommendations: [],
  approvals: [],
  serviceId: {
    serviceId: "",
    status: "not-started",
    disTeamAssigned: "",
    createdDate: null,
  },
  rfcs: [],
});

const readAll = (): Record<string, ExtendedLocalState> => {
  try {
    return JSON.parse(localStorage.getItem(KEY) || "{}");
  } catch {
    return {};
  }
};

const writeAll = (all: Record<string, ExtendedLocalState>) => {
  localStorage.setItem(KEY, JSON.stringify(all));
};

export const loadLocal = (id: string): ExtendedLocalState =>
  readAll()[id] ?? emptyLocal();

export const saveLocal = (id: string, state: ExtendedLocalState) => {
  const all = readAll();
  all[id] = state;
  writeAll(all);
};

export const removeLocal = (id: string) => {
  const all = readAll();
  delete all[id];
  writeAll(all);
};

// Combined view used by the dashboard list.
export interface SavedOnboarding {
  id: string;
  name: string;
  status: DisplayStatus;
  createdAt: string;
  updatedAt: string;
  accountDetailsId?: string;
  requirementAssessmentId?: string;
  state: OnboardingState;
}

export const hydrate = (b: BackendOnboarding): SavedOnboarding => {
  const local = loadLocal(b.id);
  return {
    id: b.id,
    name: b.name,
    status: displayStatus(b.status),
    createdAt: b.created_at,
    updatedAt: b.updated_at,
    accountDetailsId: b.account_details?.id,
    requirementAssessmentId: b.requirement_assessment?.id,
    state: {
      ...local,
      accountDetails: toFrontendAccountDetails(b.account_details),
      requirementAssessment: toFrontendRequirement(b.requirement_assessment),
    },
  };
};
