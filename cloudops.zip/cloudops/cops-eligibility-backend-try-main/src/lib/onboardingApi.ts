// API layer for onboarding workflow. Wraps the FastAPI endpoints documented
// in the backend reference. Translates between backend snake_case payloads
// and the frontend camelCase types used across the app.

import { apiFetch } from "./api";
import type {
  AccountDetails,
  OnboardingState,
  RequirementAssessment,
} from "@/types/onboarding";

// ---------- Backend wire types ----------

export type BackendStatus =
  | "draft"
  | "in_progress"
  | "submitted"
  | "completed";

export interface BackendAccountDetails {
  id?: string;
  project_name: string;
  isu?: string | null;
  account_name: string;
  owner: string;
  emp_id: string;
  description?: string | null;
  business_unit?: string | null;
  created_at?: string;
  updated_at?: string;
}

export interface BackendRequirementAssessment {
  id?: string;
  solution_type: "generative-ai" | "non-generative-ai";
  deployment_environments: string[];
  cloud_providers: string[];
  region?: string | null;
  created_at?: string;
  updated_at?: string;
}

export interface BackendOnboarding {
  id: string;
  name: string;
  status: BackendStatus;
  created_at: string;
  updated_at: string;
  account_details?: BackendAccountDetails | null;
  requirement_assessment?: BackendRequirementAssessment | null;
}

export interface BackendList<T> {
  data: T[];
  total: number;
  skip: number;
  limit: number;
}

// ---------- Mapping ----------

export const toFrontendAccountDetails = (
  b?: BackendAccountDetails | null
): AccountDetails => ({
  projectName: b?.project_name ?? "",
  isu: b?.isu ?? "",
  accountName: b?.account_name ?? "",
  owner: b?.owner ?? "",
  empId: b?.emp_id ?? "",
  description: b?.description ?? "",
  businessUnit: b?.business_unit ?? "",
});

export const toBackendAccountDetails = (
  a: AccountDetails
): BackendAccountDetails => ({
  project_name: a.projectName,
  isu: a.isu || null,
  account_name: a.accountName,
  owner: a.owner,
  emp_id: a.empId,
  description: a.description || null,
  business_unit: a.businessUnit || null,
});

export const toFrontendRequirement = (
  b?: BackendRequirementAssessment | null
): RequirementAssessment => ({
  solutionType: (b?.solution_type ?? "") as RequirementAssessment["solutionType"],
  deploymentEnvironments: b?.deployment_environments ?? [],
  cloudProviders: b?.cloud_providers ?? [],
  region: b?.region ?? "",
});

export const toBackendRequirement = (
  r: RequirementAssessment
): BackendRequirementAssessment => ({
  solution_type:
    (r.solutionType || "non-generative-ai") as BackendRequirementAssessment["solution_type"],
  deployment_environments: r.deploymentEnvironments,
  cloud_providers: r.cloudProviders,
  region: r.region || null,
});

// ---------- Validation (mirrors backend rules) ----------

const VALID_BUSINESS_UNITS = [
  "BFSI",
  "Manufacturing",
  "Retail",
  "Healthcare",
  "Technology",
  "Energy & Utilities",
];
const VALID_PROVIDERS = ["AWS", "Azure", "GCP", "On-Prem"];

export function validateAccountDetails(a: AccountDetails): string | null {
  if (!a.projectName.trim()) return "Project Name is required";
  if (a.projectName.length > 255) return "Project Name must be ≤ 255 characters";
  if (!a.accountName.trim()) return "Account Name is required";
  if (a.accountName.length > 255) return "Account Name must be ≤ 255 characters";
  if (!a.empId.trim()) return "Employee ID is required";
  if (a.empId.length > 50) return "Employee ID must be ≤ 50 characters";
  if (a.isu && a.isu.length > 50) return "ISU must be ≤ 50 characters";
  if (a.businessUnit && !VALID_BUSINESS_UNITS.includes(a.businessUnit))
    return `Business Unit must be one of: ${VALID_BUSINESS_UNITS.join(", ")}`;
  return null;
}

export function validateRequirement(r: RequirementAssessment): string | null {
  if (r.solutionType !== "generative-ai" && r.solutionType !== "non-generative-ai")
    return "Solution Type is required";
  if (!r.deploymentEnvironments.length)
    return "At least one deployment environment is required";
  if (
    r.solutionType === "generative-ai" &&
    r.deploymentEnvironments.some((e) => e !== "development")
  )
    return "Generative AI solutions can only target the Development sandbox";
  if (!r.cloudProviders.length) return "Select at least one cloud provider";
  const bad = r.cloudProviders.filter((p) => !VALID_PROVIDERS.includes(p));
  if (bad.length) return `Invalid providers: ${bad.join(", ")}`;
  return null;
}

// ---------- Endpoints ----------

export function listOnboardings(opts: {
  skip?: number;
  limit?: number;
  status?: BackendStatus;
} = {}) {
  const params = new URLSearchParams();
  params.set("skip", String(opts.skip ?? 0));
  params.set("limit", String(opts.limit ?? 50));
  if (opts.status) params.set("status", opts.status);
  return apiFetch<BackendList<BackendOnboarding>>(`/onboarding?${params}`);
}

export function getOnboarding(id: string) {
  return apiFetch<BackendOnboarding>(`/onboarding/${id}`);
}

export function createOnboarding(payload: {
  name: string;
  account_details: BackendAccountDetails;
  requirement_assessment?: BackendRequirementAssessment | null;
}) {
  return apiFetch<BackendOnboarding>(`/onboarding/`, {
    method: "POST",
    body: JSON.stringify(payload),
  });
}

export function patchOnboardingStatus(id: string, newStatus: BackendStatus) {
  return apiFetch<BackendOnboarding>(
    `/onboarding/${id}/status?new_status=${encodeURIComponent(newStatus)}`,
    { method: "PATCH" }
  );
}

export function createAccountDetails(
  onboardingId: string,
  data: BackendAccountDetails
) {
  return apiFetch<BackendAccountDetails>(
    `/account-details/create/${onboardingId}`,
    { method: "POST", body: JSON.stringify(data) }
  );
}

export function updateAccountDetails(
  accountDetailsId: string,
  data: Partial<BackendAccountDetails>
) {
  return apiFetch<BackendAccountDetails>(`/account-details/${accountDetailsId}`, {
    method: "PUT",
    body: JSON.stringify(data),
  });
}

export function createRequirementAssessment(
  onboardingId: string,
  data: BackendRequirementAssessment
) {
  return apiFetch<BackendRequirementAssessment>(
    `/requirement-assessment/create/${onboardingId}`,
    { method: "POST", body: JSON.stringify(data) }
  );
}

export function updateRequirementAssessment(
  id: string,
  data: Partial<BackendRequirementAssessment>
) {
  return apiFetch<BackendRequirementAssessment>(`/requirement-assessment/${id}`, {
    method: "PUT",
    body: JSON.stringify(data),
  });
}

// ---------- UI status mapping ----------

export type DisplayStatus =
  | "Draft"
  | "In Progress"
  | "In Approval"
  | "Complete";

export const displayStatus = (s: BackendStatus): DisplayStatus => {
  switch (s) {
    case "draft":
      return "Draft";
    case "in_progress":
      return "In Progress";
    case "submitted":
      return "In Approval";
    case "completed":
      return "Complete";
  }
};

// Decide what backend status the onboarding should be in, given local state.
export const inferBackendStatus = (s: OnboardingState): BackendStatus => {
  const allRfcsClosed =
    s.rfcs.length > 0 &&
    s.rfcs.every((r) => r.status === "implemented" || r.status === "closed");
  if (s.serviceId.status === "completed" && allRfcsClosed) return "completed";
  if (s.approvals.length > 0) return "submitted";
  if (s.currentStep > 1 || s.requirementAssessment.solutionType) return "in_progress";
  return "draft";
};
