// Thin fetch wrapper around the FastAPI backend.
// Override the base URL by setting VITE_API_BASE_URL in your environment.

export const API_BASE_URL =
  (import.meta.env.VITE_API_BASE_URL as string | undefined) ??
  "http://localhost:8000/api";

export class ApiError extends Error {
  status: number;
  body: unknown;
  constructor(status: number, message: string, body: unknown) {
    super(message);
    this.status = status;
    this.body = body;
  }
}

export async function apiFetch<T = unknown>(
  path: string,
  init: RequestInit = {}
): Promise<T> {
  const res = await fetch(`${API_BASE_URL}${path}`, {
    ...init,
    headers: {
      "Content-Type": "application/json",
      Accept: "application/json",
      ...(init.headers ?? {}),
    },
  });

  const text = await res.text();
  let json: unknown = undefined;
  if (text) {
    try {
      json = JSON.parse(text);
    } catch {
      json = text;
    }
  }

  if (!res.ok) {
    const detail =
      (json && typeof json === "object" && "detail" in json
        ? String((json as { detail: unknown }).detail)
        : undefined) ?? res.statusText;
    throw new ApiError(res.status, `API ${res.status}: ${detail}`, json);
  }

  return json as T;
}
