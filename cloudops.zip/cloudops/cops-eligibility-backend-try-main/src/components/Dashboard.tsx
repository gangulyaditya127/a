import { useEffect, useState } from "react";
import { ArrowRight, Bot, Cloud, Layers, Plus, ShieldCheck, Sparkles, FileText, Clock, Loader2, AlertTriangle } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { TopNav } from "@/components/TopNav";
import { popularOnboardingTemplates, type PopularOnboardingTemplate } from "@/data/onboardingTemplates";
import { hydrate, type SavedOnboarding } from "@/lib/onboardingStorage";
import { listOnboardings, getOnboarding, type DisplayStatus } from "@/lib/onboardingApi";
import { STEPS } from "@/types/onboarding";
import { toast } from "@/hooks/use-toast";

interface Props {
  onStartBlank: () => void;
  onUseTemplate: (template: PopularOnboardingTemplate) => void;
  onResume: (item: SavedOnboarding) => void;
}

const statusStyles: Record<DisplayStatus, string> = {
  Draft: "bg-muted text-muted-foreground",
  "In Progress": "bg-warning/10 text-warning border-warning/20",
  "In Approval": "bg-info/10 text-info border-info/20",
  Complete: "bg-success/10 text-success border-success/20",
};

export const Dashboard = ({ onStartBlank, onUseTemplate, onResume }: Props) => {
  const [items, setItems] = useState<SavedOnboarding[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [resumingId, setResumingId] = useState<string | null>(null);

  const refresh = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await listOnboardings({ skip: 0, limit: 50 });
      setItems(res.data.map(hydrate));
    } catch (e) {
      const msg = e instanceof Error ? e.message : "Failed to load onboardings";
      setError(msg);
      toast({ title: "Could not load onboardings", description: msg, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { refresh(); }, []);

  // Fetch the full onboarding record (with nested account_details +
  // requirement_assessment) before opening the wizard. The list endpoint
  // only returns top-level fields, so resuming from list data would leave
  // all form fields blank.
  const handleResume = async (item: SavedOnboarding) => {
    setResumingId(item.id);
    try {
      const full = await getOnboarding(item.id);
      onResume(hydrate(full));
    } catch (e) {
      const msg = e instanceof Error ? e.message : "Could not fetch latest data";
      toast({
        title: "Using cached data",
        description: `Detail fetch failed (${msg}). Opening with last known state.`,
        variant: "destructive",
      });
      onResume(item); // graceful fallback to list-cached data
    } finally {
      setResumingId(null);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <TopNav />
      <main className="max-w-7xl mx-auto px-6 py-8 space-y-8">
        <section className="grid grid-cols-1 lg:grid-cols-[1.2fr_0.8fr] gap-6 items-stretch">
          <div className="rounded-lg border bg-card p-6 shadow-card space-y-5">
            <Badge variant="outline" className="w-fit gap-1.5"><Cloud className="h-3.5 w-3.5" /> CloudOps Workspace</Badge>
            <div className="space-y-2">
              <h1 className="text-3xl font-semibold tracking-normal text-foreground">DIS Cloud Onboarding</h1>
              <p className="text-muted-foreground max-w-2xl">
                Start a new onboarding from scratch, reuse a popular pattern, or resume one you previously started. Workflow: account → requirements → resources → architecture → recommendations → approvals → service ID → RFCs.
              </p>
            </div>
            <div className="flex flex-wrap gap-3">
              <Button onClick={onStartBlank} className="gradient-primary text-primary-foreground">
                <Plus className="h-4 w-4" /> New Onboarding
              </Button>
              <Button variant="outline" onClick={() => onUseTemplate(popularOnboardingTemplates[0])}>
                <Sparkles className="h-4 w-4" /> Use Popular GenAI Pattern
              </Button>
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-1 gap-4">
            {[
              { label: "My onboardings", value: loading ? "…" : String(items.length), icon: Layers },
              { label: "AI assistants", value: "Resources + RFC", icon: Bot },
              { label: "Workflow", value: `${STEPS.length} steps`, icon: ShieldCheck },
            ].map((item) => (
              <Card key={item.label}>
                <CardContent className="p-4 flex items-center gap-3">
                  <div className="h-10 w-10 rounded-md bg-primary/10 text-primary flex items-center justify-center">
                    <item.icon className="h-5 w-5" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">{item.label}</p>
                    <p className="font-semibold text-foreground">{item.value}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* My Onboardings */}
        <section className="space-y-4">
          <div className="flex items-end justify-between gap-4">
            <div>
              <h2 className="text-xl font-semibold text-foreground">My Onboardings</h2>
              <p className="text-sm text-muted-foreground">Resume an in-progress onboarding or review completed ones. Synced from the CloudOps backend.</p>
            </div>
            <Button variant="ghost" size="sm" onClick={refresh} disabled={loading}>
              {loading ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : "Refresh"}
            </Button>
          </div>

          {loading ? (
            <Card><CardContent className="p-8 flex items-center justify-center gap-2 text-sm text-muted-foreground">
              <Loader2 className="h-4 w-4 animate-spin" /> Loading onboardings…
            </CardContent></Card>
          ) : error ? (
            <Card><CardContent className="p-8 text-center text-sm text-destructive flex items-center justify-center gap-2">
              <AlertTriangle className="h-4 w-4" /> {error}
            </CardContent></Card>
          ) : items.length === 0 ? (
            <Card>
              <CardContent className="p-8 text-center text-sm text-muted-foreground">
                No onboardings yet. Start a new one or use a popular template below.
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {items.map((it) => {
                const stepLabel = STEPS[it.state.currentStep - 1]?.title ?? "—";
                const rfcDone = it.state.rfcs.filter((r) => r.status === "implemented" || r.status === "closed").length;
                return (
                  <Card key={it.id} className="shadow-card hover:shadow-card-hover transition-shadow">
                    <CardHeader className="space-y-2">
                      <div className="flex items-start justify-between gap-2">
                        <CardTitle className="text-base leading-snug">{it.name}</CardTitle>
                        <Badge className={statusStyles[it.status]}>{it.status}</Badge>
                      </div>
                      <p className="text-xs text-muted-foreground flex items-center gap-1.5">
                        <Clock className="h-3 w-3" /> Updated {new Date(it.updatedAt).toLocaleString()}
                      </p>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="text-xs text-muted-foreground space-y-1">
                        <div>Current step: <span className="text-foreground font-medium">{stepLabel}</span> ({it.state.currentStep}/{STEPS.length})</div>
                        {it.state.serviceId.serviceId && (
                          <div>Service ID: <span className="font-mono text-primary">{it.state.serviceId.serviceId}</span></div>
                        )}
                        {it.state.rfcs.length > 0 && (
                          <div className="flex items-center gap-1"><FileText className="h-3 w-3" /> RFCs: {rfcDone}/{it.state.rfcs.length} complete</div>
                        )}
                      </div>
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          className="flex-1 justify-between"
                          disabled={resumingId === it.id}
                          onClick={() => handleResume(it)}
                        >
                          {resumingId === it.id
                            ? <><Loader2 className="h-3.5 w-3.5 animate-spin" /> Loading…</>
                            : <>{it.status === "Complete" ? "View" : "Resume"} <ArrowRight className="h-3.5 w-3.5" /></>}
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </section>

        {/* Templates */}
        <section className="space-y-4">
          <div>
            <h2 className="text-xl font-semibold text-foreground">Popular onboarding patterns</h2>
            <p className="text-sm text-muted-foreground">Pick a proven template to prefill account, requirements, and cloud resources.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {popularOnboardingTemplates.map((template) => (
              <Card key={template.id} className="shadow-card hover:shadow-card-hover transition-shadow">
                <CardHeader className="space-y-3">
                  <Badge variant="secondary" className="w-fit">{template.category}</Badge>
                  <CardTitle className="text-lg leading-snug">{template.name}</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-sm text-muted-foreground min-h-20">{template.description}</p>
                  <div className="flex flex-wrap gap-2">
                    {template.tags.map((tag) => <Badge key={tag} variant="outline">{tag}</Badge>)}
                  </div>
                  <Button variant="outline" className="w-full justify-between" onClick={() => onUseTemplate(template)}>
                    Use this template <ArrowRight className="h-4 w-4" />
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>
      </main>
    </div>
  );
};
