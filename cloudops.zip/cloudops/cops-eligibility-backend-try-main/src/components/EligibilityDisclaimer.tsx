import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { TopNav } from "./TopNav";
import { ArrowLeft, CheckCircle2, FileCheck2, ShieldAlert, XCircle } from "lucide-react";

interface Props {
  onAgree: () => void;
  onDisagree: () => void;
}

interface Clause {
  id: string;
  title: string;
  text: string;
}

const CLAUSES: Clause[] = [
  {
    id: "Q4",
    title: "Infrastructure Governance",
    text: "All cloud infrastructure is provisioned, owned, and managed exclusively by the DIS/Platform team. Project teams will not receive resource creation rights, administrative access, or subscription/account ownership permissions.",
  },
  {
    id: "Q5b",
    title: "Cloud-to-On-Premise Connectivity",
    text: "Connectivity requirements between cloud and on-premise environments (new connectivity, existing connections, or none) must be declared during onboarding and reviewed by the platform team.",
  },
  {
    id: "Q8a",
    title: "External Data Ingestion",
    text: "Any copy, transfer, or ingestion of data from external or project-managed accounts/environments into the DIS managed cloud must be declared upfront.",
  },
  {
    id: "Q8b",
    title: "ISM Approval for Data Transfer",
    text: "Where data transfer is required, formal ISM approval, compliance review, and security validation must be obtained before any data movement.",
  },
  {
    id: "Q9",
    title: "VM Image Standards",
    text: "Servers/VMs must use organization-approved hardened images. Marketplace or public images require formal ISM exception approval prior to deployment.",
  },
  {
    id: "Q10",
    title: "GenAI Sandbox Isolation",
    text: "All GenAI workloads will be provisioned exclusively within designated, isolated sandbox environments — segregated from the enterprise intranet/network and not exposed via enterprise connectivity.",
  },
  {
    id: "Q11",
    title: "Data Restrictions for GenAI",
    text: "Customer confidential data, organization confidential data, sensitive internal documents, and regulated/restricted datasets must never be uploaded into GenAI environments.",
  },
  {
    id: "Q12",
    title: "GenAI Data Transfer Approval",
    text: "Any permissible data transfer into GenAI sandbox environments requires prior ISM approval, Data Privacy approval, and security compliance validation.",
  },
];

export const EligibilityDisclaimer = ({ onAgree, onDisagree }: Props) => {
  const [disagreed, setDisagreed] = useState(false);

  if (disagreed) {
    return (
      <div className="min-h-screen bg-background flex flex-col">
        <TopNav />
        <main className="flex-1 flex items-center justify-center p-6">
          <Card className="max-w-2xl w-full shadow-card border-destructive/30">
            <CardHeader className="space-y-3">
              <div className="h-12 w-12 rounded-full bg-destructive/10 text-destructive flex items-center justify-center">
                <XCircle className="h-7 w-7" />
              </div>
              <CardTitle className="text-2xl">Onboarding cannot proceed</CardTitle>
            </CardHeader>
            <CardContent className="space-y-5 text-sm text-muted-foreground">
              <p>Agreement to the DIS Managed Cloud governance, security, and compliance terms is mandatory. Onboarding has been cancelled.</p>
              <div className="flex gap-2">
                <Button variant="outline" onClick={onDisagree}><ArrowLeft className="h-4 w-4 mr-1" /> Back to Dashboard</Button>
                <Button onClick={() => setDisagreed(false)}>Review Terms Again</Button>
              </div>
            </CardContent>
          </Card>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <TopNav />
      <main className="flex-1 overflow-auto">
        <div className="max-w-3xl mx-auto p-6">
          <Card className="shadow-card">
            <CardHeader className="space-y-3">
              <Badge variant="outline" className="w-fit gap-1.5"><FileCheck2 className="h-3.5 w-3.5" /> Disclaimer & Acknowledgement</Badge>
              <CardTitle className="text-2xl">DIS Managed Cloud — Governance, Security & Compliance Terms</CardTitle>
              <p className="text-sm text-muted-foreground">
                You have passed the initial eligibility gate. Before proceeding to onboarding, please review and acknowledge the following operational and compliance commitments.
              </p>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="rounded-lg border border-warning/20 bg-warning/5 p-3 text-xs flex items-start gap-2">
                <ShieldAlert className="h-4 w-4 text-warning mt-0.5 shrink-0" />
                <span>By selecting <strong>I Agree</strong>, you confirm that your project will adhere to each of the following policies. Any exception requires formal approval from ISM, Security, and Compliance authorities.</span>
              </div>
              <ul className="space-y-3">
                {CLAUSES.map((c) => (
                  <li key={c.id} className="rounded-lg border bg-card p-4">
                    <div className="flex items-start gap-3">
                      <div className="space-y-1">
                        <p className="font-medium text-foreground text-sm">{c.title}</p>
                        <p className="text-sm text-muted-foreground leading-relaxed">{c.text}</p>
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
              <div className="flex items-center justify-end gap-2 pt-3 border-t">
                <Button variant="outline" onClick={() => setDisagreed(true)}>
                  <XCircle className="h-4 w-4 mr-1" /> I Disagree
                </Button>
                <Button onClick={onAgree} className="gradient-primary text-primary-foreground">
                  <CheckCircle2 className="h-4 w-4 mr-1" /> I Agree — Proceed to Onboarding
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
};
