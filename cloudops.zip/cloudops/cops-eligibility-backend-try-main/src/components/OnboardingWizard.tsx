import { useEffect, useRef, useState } from "react";
import { STEPS, type OnboardingState } from "@/types/onboarding";
import { StepIndicator } from "./StepIndicator";
import { TopNav } from "./TopNav";
import { StepAccountDetails } from "./steps/StepAccountDetails";
import { StepRequirementAssessment } from "./steps/StepRequirementAssessment";
import { StepCloudResources } from "./steps/StepCloudResources";
import { StepArchitectureOverview } from "./steps/StepArchitectureOverview";
import { StepRecommendations } from "./steps/StepRecommendations";
import { StepApprovalTracker } from "./steps/StepApprovalTracker";
import { StepServiceIdCreation } from "./steps/StepServiceIdCreation";
import { StepRfcTracking } from "./steps/StepRfcTracking";
import { Button } from "./ui/button";
import { ChevronLeft, ChevronRight, LayoutDashboard, Loader2, Save } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import {
  type SavedOnboarding,
  saveLocal,
  type ExtendedLocalState,
} from "@/lib/onboardingStorage";
import {
  createAccountDetails,
  createOnboarding,
  createRequirementAssessment,
  inferBackendStatus,
  patchOnboardingStatus,
  toBackendAccountDetails,
  toBackendRequirement,
  updateAccountDetails,
  updateRequirementAssessment,
  validateAccountDetails,
  validateRequirement,
  type BackendStatus,
} from "@/lib/onboardingApi";

const initialState: OnboardingState = {
  currentStep: 1,
  accountDetails: {
    projectName: "", isu: "", accountName: "", owner: "", empId: "", description: "", businessUnit: "",
  },
  requirementAssessment: {
    solutionType: "", deploymentEnvironments: [], cloudProviders: [], region: "",
  },
  cloudResources: [],
  architectureOverview: {
    uploadedDiagram: null, generatedFromBucket: false, securityViolations: [], revisedDiagram: null, analysisComplete: false,
  },
  recommendations: [],
  approvals: [],
  serviceId: {
    serviceId: "", status: "not-started", disTeamAssigned: "", createdDate: null,
  },
  rfcs: [],
};

interface Props {
  initialTemplate?: Partial<OnboardingState> | null;
  existing?: SavedOnboarding | null;
  onBackToDashboard?: () => void;
}

const TOTAL = STEPS.length;

const extractLocal = (s: OnboardingState): ExtendedLocalState => ({
  currentStep: s.currentStep,
  cloudResources: s.cloudResources,
  architectureOverview: s.architectureOverview,
  recommendations: s.recommendations,
  approvals: s.approvals,
  serviceId: s.serviceId,
  rfcs: s.rfcs,
});

export const OnboardingWizard = ({ initialTemplate, existing, onBackToDashboard }: Props) => {
  const [state, setState] = useState<OnboardingState>(() => {
    if (existing) return existing.state;
    return { ...initialState, ...initialTemplate, currentStep: 1 };
  });

  // Backend ids — assigned after first successful save to the API.
  const onboardingIdRef = useRef<string | undefined>(existing?.id);
  const accountDetailsIdRef = useRef<string | undefined>(existing?.accountDetailsId);
  const requirementIdRef = useRef<string | undefined>(existing?.requirementAssessmentId);
  const lastBackendStatusRef = useRef<BackendStatus>("draft");

  const [saving, setSaving] = useState(false);

  // Auto-persist local-only steps (3-8) whenever we already have a backend id.
  useEffect(() => {
    if (onboardingIdRef.current) {
      saveLocal(onboardingIdRef.current, extractLocal(state));
    }
  }, [state]);

  const updateState = <K extends keyof OnboardingState>(key: K, value: OnboardingState[K]) => {
    setState((prev) => ({ ...prev, [key]: value }));
  };

  // Push account details + requirement assessment to the backend, creating the
  // onboarding record on first save. Returns true on success.
  const persistToBackend = async (opts: { silent?: boolean } = {}): Promise<boolean> => {
    const ad = state.accountDetails;
    const ra = state.requirementAssessment;

    const adError = validateAccountDetails(ad);
    if (adError) {
      if (!opts.silent) toast({ title: "Fix account details", description: adError, variant: "destructive" });
      return false;
    }
    // Requirement validation only enforced once user has chosen a solution type.
    if (ra.solutionType) {
      const raError = validateRequirement(ra);
      if (raError) {
        if (!opts.silent) toast({ title: "Fix requirement assessment", description: raError, variant: "destructive" });
        return false;
      }
    }

    setSaving(true);
    try {
      if (!onboardingIdRef.current) {
        // Create onboarding (with account details + optional requirement).
        const created = await createOnboarding({
          name: ad.projectName.trim() || "Untitled Onboarding",
          account_details: toBackendAccountDetails(ad),
          requirement_assessment: ra.solutionType ? toBackendRequirement(ra) : null,
        });
        onboardingIdRef.current = created.id;
        accountDetailsIdRef.current = created.account_details?.id;
        requirementIdRef.current = created.requirement_assessment?.id;
        lastBackendStatusRef.current = created.status;
        saveLocal(created.id, extractLocal(state));
      } else {
        // Update existing records.
        if (accountDetailsIdRef.current) {
          await updateAccountDetails(accountDetailsIdRef.current, toBackendAccountDetails(ad));
        } else {
          const adRes = await createAccountDetails(onboardingIdRef.current, toBackendAccountDetails(ad));
          accountDetailsIdRef.current = adRes.id;
        }
        if (ra.solutionType) {
          if (requirementIdRef.current) {
            await updateRequirementAssessment(requirementIdRef.current, toBackendRequirement(ra));
          } else {
            const raRes = await createRequirementAssessment(onboardingIdRef.current, toBackendRequirement(ra));
            requirementIdRef.current = raRes.id;
          }
        }
      }

      // Sync workflow status if it changed.
      const nextStatus = inferBackendStatus(state);
      if (onboardingIdRef.current && nextStatus !== lastBackendStatusRef.current) {
        await patchOnboardingStatus(onboardingIdRef.current, nextStatus);
        lastBackendStatusRef.current = nextStatus;
      }

      if (!opts.silent) toast({ title: "Saved", description: "Onboarding synced to the CloudOps backend." });
      return true;
    } catch (e) {
      const msg = e instanceof Error ? e.message : "Save failed";
      toast({ title: "Save failed", description: msg, variant: "destructive" });
      return false;
    } finally {
      setSaving(false);
    }
  };

  const goNext = async () => {
    if (state.currentStep >= TOTAL) return;
    // Save to backend at the end of step 1 and step 2 (the only steps with API endpoints).
    if (state.currentStep === 1 || state.currentStep === 2) {
      const ok = await persistToBackend();
      if (!ok) return;
    }
    setState((p) => ({ ...p, currentStep: p.currentStep + 1 }));
  };
  const goPrev = () => state.currentStep > 1 && setState((p) => ({ ...p, currentStep: p.currentStep - 1 }));
  const goToStep = (step: number) => setState((p) => ({ ...p, currentStep: step }));

  const handleSaveDraft = async () => {
    if (!state.accountDetails.projectName.trim()) {
      toast({ title: "Project Name required", description: "Enter a project name before saving a draft.", variant: "destructive" });
      return;
    }
    await persistToBackend();
  };

  const handleFinish = async () => {
    if (!onboardingIdRef.current) {
      toast({ title: "Not synced", description: "Save the draft first.", variant: "destructive" });
      return;
    }
    try {
      await patchOnboardingStatus(onboardingIdRef.current, "completed");
      lastBackendStatusRef.current = "completed";
      toast({ title: "Onboarding Submitted", description: "Status set to completed. Dashboard updated." });
    } catch (e) {
      const msg = e instanceof Error ? e.message : "Could not update status";
      toast({ title: "Submit failed", description: msg, variant: "destructive" });
    }
  };

  const renderStep = () => {
    switch (state.currentStep) {
      case 1: return <StepAccountDetails data={state.accountDetails} onChange={(d) => updateState("accountDetails", d)} />;
      case 2: return <StepRequirementAssessment data={state.requirementAssessment} onChange={(d) => updateState("requirementAssessment", d)} />;
      case 3: return <StepCloudResources data={state.cloudResources} providers={state.requirementAssessment.cloudProviders} onChange={(d) => updateState("cloudResources", d)} />;
      case 4: return <StepArchitectureOverview data={state.architectureOverview} onChange={(d) => updateState("architectureOverview", d)} />;
      case 5: return <StepRecommendations data={state.recommendations} solutionType={state.requirementAssessment.solutionType} onChange={(d) => updateState("recommendations", d)} />;
      case 6: return <StepApprovalTracker data={state.approvals} solutionType={state.requirementAssessment.solutionType} onChange={(d) => updateState("approvals", d)} />;
      case 7: return <StepServiceIdCreation data={state.serviceId} onChange={(d) => updateState("serviceId", d)} />;
      case 8: return <StepRfcTracking data={state.rfcs} serviceIdReady={state.serviceId.status === "completed"} onChange={(d) => updateState("rfcs", d)} />;
      default: return null;
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <TopNav />
      <div className="flex-1 flex flex-col">
        <div className="border-b bg-card px-6 py-4">
          <StepIndicator steps={STEPS} currentStep={state.currentStep} onStepClick={goToStep} />
        </div>
        <div className="flex-1 overflow-auto">
          <div className="max-w-6xl mx-auto px-6 py-8">
            <div className="mb-6">
              <h2 className="text-2xl font-semibold text-foreground">{STEPS[state.currentStep - 1].title}</h2>
              <p className="text-muted-foreground text-sm mt-1">
                Step {state.currentStep} of {TOTAL} — {STEPS[state.currentStep - 1].description}
              </p>
            </div>
            <div className="bg-card rounded-lg border shadow-card p-6">{renderStep()}</div>
          </div>
        </div>
        <div className="border-t bg-card px-6 py-4">
          <div className="max-w-6xl mx-auto flex items-center justify-between">
            <div className="flex items-center gap-2">
              {onBackToDashboard && (
                <Button variant="ghost" onClick={onBackToDashboard}>
                  <LayoutDashboard className="h-4 w-4 mr-1" /> Dashboard
                </Button>
              )}
              <Button variant="outline" onClick={goPrev} disabled={state.currentStep === 1 || saving}>
                <ChevronLeft className="h-4 w-4 mr-1" /> Previous
              </Button>
            </div>
            <Button variant="ghost" onClick={handleSaveDraft} disabled={saving}>
              {saving ? <Loader2 className="h-4 w-4 mr-1 animate-spin" /> : <Save className="h-4 w-4 mr-1" />}
              Save Draft
            </Button>
            {state.currentStep < TOTAL ? (
              <Button onClick={goNext} disabled={saving} className="gradient-primary text-primary-foreground">
                {saving ? <Loader2 className="h-4 w-4 mr-1 animate-spin" /> : null}
                Next <ChevronRight className="h-4 w-4 ml-1" />
              </Button>
            ) : (
              <Button onClick={handleFinish} className="gradient-accent text-accent-foreground">
                Finish
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
