import type { OnboardingState } from "@/types/onboarding";

const KEY = "dis_onboardings_v1";

export type OnboardingStatus = "Draft" | "In Approval" | "Provisioning" | "RFC Pending" | "Complete";

export interface SavedOnboarding {
  id: string;
  name: string;
  createdAt: string;
  updatedAt: string;
  status: OnboardingStatus;
  state: OnboardingState;
}

export const computeStatus = (s: OnboardingState): OnboardingStatus => {
  const allRfcsClosed = s.rfcs.length > 0 && s.rfcs.every((r) => r.status === "implemented" || r.status === "closed");
  if (s.serviceId.status === "completed" && allRfcsClosed) return "Complete";
  if (s.serviceId.status === "completed") return "RFC Pending";
  if (s.serviceId.status !== "not-started") return "Provisioning";
  if (s.approvals.length > 0) return "In Approval";
  return "Draft";
};

export const loadAll = (): SavedOnboarding[] => {
  try {
    return JSON.parse(localStorage.getItem(KEY) || "[]");
  } catch {
    return [];
  }
};

export const saveOne = (item: SavedOnboarding) => {
  const all = loadAll();
  const idx = all.findIndex((o) => o.id === item.id);
  if (idx >= 0) all[idx] = item;
  else all.unshift(item);
  localStorage.setItem(KEY, JSON.stringify(all));
};

export const deleteOne = (id: string) => {
  localStorage.setItem(KEY, JSON.stringify(loadAll().filter((o) => o.id !== id)));
};

export const newId = () => "onb_" + Math.random().toString(36).slice(2, 10);
