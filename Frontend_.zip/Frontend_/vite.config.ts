import path from "path";
import react from "@vitejs/plugin-react";
import { defineConfig, type PluginOption } from "vite";

// import viteCompression from 'vite-plugin-compression';
export default defineConfig({
  plugins: [
    react()
  ],
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    },
  },
  server: {
    watch: {
      followSymlinks: false,
    },
  },
  build: {
    minify: "terser",
    terserOptions: {
      compress: {
        drop_console: true, // Remove console.log in production
        drop_debugger: true, // Remove debugger in production
      },
    },
    cssMinify: "esbuild",
    rollupOptions: {
      treeshake: true,
    },
    outDir: "dist/",
    cssCodeSplit: true,
    // sourcemap:true
  },
});
