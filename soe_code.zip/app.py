# app.py — Firewall Rule Builder with SQLite Deduplication
# Run with:
# streamlit run app.py

import streamlit as st
import ipaddress
import itertools
import sqlite3
import re
import os
import csv
import io

from subnet_lists import SUBNET_GROUPS

# ──────────────────────────────────────────────────────────────────────────────
# Group ordering
# ──────────────────────────────────────────────────────────────────────────────

GROUP_ORDER = [
    'On Prem Prod (PR)',
    'On Prem Prod (DR)',
    'On Prem Prod (PR+DR)',
    'On Prem Non Prod',
    'Azure Prod (PR)',
    'Azure Prod (DR)',
    'Azure Prod (PR+DR)',
    'Azure Non Prod',
    'AWS Prod (PR)',
    'AWS Prod (DR)',
    'AWS Prod (PR+DR)',
    'AWS Non Prod',
    'All Prod',
    'All Non Prod',
    'All Subnets',
]

GROUP_ORDER = [g for g in GROUP_ORDER if g in SUBNET_GROUPS]

# ──────────────────────────────────────────────────────────────────────────────
# IP expansion helpers
# ──────────────────────────────────────────────────────────────────────────────

def expand_token(token: str) -> list[str]:

    token = token.strip()

    if not token:
        return []

    # IP Range
    if '-' in token and '/' not in token:

        parts = token.split('-', 1)

        try:
            start = int(ipaddress.ip_address(parts[0].strip()))
            end = int(ipaddress.ip_address(parts[1].strip()))

            if start > end:
                raise ValueError('Start IP greater than end IP')

            return [
                str(ipaddress.ip_address(i))
                for i in range(start, end + 1)
            ]

        except Exception as ex:
            st.error(f'Cannot expand range {token!r}: {ex}')
            return []

    # CIDR
    if '/' in token:

        try:
            net = ipaddress.ip_network(token, strict=False)

            return [str(ip) for ip in net.hosts()] or [
                str(net.network_address)
            ]

        except Exception as ex:
            st.error(f'Cannot expand subnet {token!r}: {ex}')
            return []

    # Single IP
    try:
        ipaddress.ip_address(token)
        return [token]

    except Exception as ex:
        st.error(f'Invalid IP {token!r}: {ex}')
        return []


def expand_token_list(tokens: list[str]) -> list[str]:

    seen = set()
    result = []

    for tok in tokens:

        for ip in expand_token(tok):

            if ip not in seen:
                seen.add(ip)
                result.append(ip)

    return result


# ──────────────────────────────────────────────────────────────────────────────
# Parse helpers
# ──────────────────────────────────────────────────────────────────────────────

def parse_ip_input(text: str) -> list[str]:

    entries = []

    for token in re.split(r'[,\n]+', text):

        token = token.strip()

        if not token:
            continue

        # Range
        if '-' in token and '/' not in token:

            parts = token.split('-', 1)

            if len(parts) == 2:

                try:
                    s = int(ipaddress.ip_address(parts[0].strip()))
                    e = int(ipaddress.ip_address(parts[1].strip()))

                    if s > e:
                        raise ValueError('Start must be <= End')

                    entries.append(token)

                except ValueError as ex:
                    st.error(f'Invalid IP range {token!r}: {ex}')

        else:

            try:
                if '/' in token:
                    ipaddress.ip_network(token, strict=False)
                else:
                    ipaddress.ip_address(token)

                entries.append(token)

            except ValueError as ex:
                st.error(f'Invalid IP/Subnet {token!r}: {ex}')

    seen = set()
    result = []

    for e in entries:

        if e not in seen:
            seen.add(e)
            result.append(e)

    return result


def parse_port_input(text: str) -> list[str]:

    entries = []

    for token in re.split(r'[,\n]+', text):

        token = token.strip()

        if not token:
            continue

        if token.lower() == 'any':
            entries.append('Any')
            continue

        if '-' in token:

            parts = token.split('-', 1)

            if len(parts) == 2:

                try:
                    lo = int(parts[0].strip())
                    hi = int(parts[1].strip())

                    if not (0 <= lo <= 65535 and 0 <= hi <= 65535):
                        raise ValueError('Port out of range')

                    if lo > hi:
                        raise ValueError('Start port > End port')

                    entries.append(f'{lo}-{hi}')

                except ValueError as ex:
                    st.error(f'Invalid port range {token!r}: {ex}')

        else:

            try:
                p = int(token)

                if not (0 <= p <= 65535):
                    raise ValueError('Port out of range')

                entries.append(str(p))

            except ValueError as ex:
                st.error(f'Invalid port {token!r}: {ex}')

    seen = set()
    result = []

    for e in entries:

        if e not in seen:
            seen.add(e)
            result.append(e)

    return result


def expand_port_token(token: str) -> list[str]:

    if token == 'Any':
        return ['Any']

    if '-' in token:

        lo, hi = token.split('-', 1)

        return [
            str(p)
            for p in range(int(lo), int(hi) + 1)
        ]

    return [token]


def expand_port_list(tokens: list[str]) -> list[str]:

    seen = set()
    result = []

    for tok in tokens:

        for p in expand_port_token(tok):

            if p not in seen:
                seen.add(p)
                result.append(p)

    return result


# ──────────────────────────────────────────────────────────────────────────────
# Combination builder
# ──────────────────────────────────────────────────────────────────────────────

def build_combinations(src_ips, dst_ips, ports):

    return list(itertools.product(src_ips, dst_ips, ports))


# ──────────────────────────────────────────────────────────────────────────────
# SQLite Helpers
# ──────────────────────────────────────────────────────────────────────────────

def get_connection(db_path):

    conn = sqlite3.connect(db_path)

    conn.row_factory = sqlite3.Row

    # Performance tuning
    conn.execute("PRAGMA journal_mode=WAL;")
    conn.execute("PRAGMA synchronous=NORMAL;")
    conn.execute("PRAGMA temp_store=MEMORY;")
    conn.execute("PRAGMA cache_size=-200000;")

    return conn


def ensure_table(conn, table_name):

    conn.execute(
        f'''
        CREATE TABLE IF NOT EXISTS "{table_name}" (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            src_ip TEXT NOT NULL,
            dst_ip TEXT NOT NULL,
            dst_port TEXT NOT NULL,
            protocol TEXT,
            description TEXT
        )
        '''
    )

    # UNIQUE index for deduplication
    conn.execute(
        f'''
        CREATE UNIQUE INDEX IF NOT EXISTS idx_unique_rule
        ON "{table_name}" (
            src_ip,
            dst_ip,
            dst_port,
            protocol
        )
        '''
    )

    # Optional indexes
    conn.execute(
        f'''
        CREATE INDEX IF NOT EXISTS idx_src_ip
        ON "{table_name}" (src_ip)
        '''
    )

    conn.execute(
        f'''
        CREATE INDEX IF NOT EXISTS idx_dst_ip
        ON "{table_name}" (dst_ip)
        '''
    )

    conn.execute(
        f'''
        CREATE INDEX IF NOT EXISTS idx_dst_port
        ON "{table_name}" (dst_port)
        '''
    )

    conn.commit()


def insert_rules(conn, table_name, combos, protocol, description):

    rows = [
        (src, dst, port, protocol, description)
        for src, dst, port in combos
    ]

    before_changes = conn.total_changes

    conn.executemany(
        f'''
        INSERT OR IGNORE INTO "{table_name}" (
            src_ip,
            dst_ip,
            dst_port,
            protocol,
            description
        )
        VALUES (?, ?, ?, ?, ?)
        ''',
        rows,
    )

    conn.commit()

    inserted_count = conn.total_changes - before_changes

    skipped_count = len(rows) - inserted_count

    return inserted_count, skipped_count


def fetch_recent(conn, table_name, limit=100):

    cur = conn.execute(
        f'''
        SELECT
            id,
            src_ip,
            dst_ip,
            dst_port,
            protocol,
            description
        FROM "{table_name}"
        ORDER BY id DESC
        LIMIT ?
        ''',
        (limit,),
    )

    return [dict(r) for r in cur.fetchall()]


def count_rows(conn, table_name):

    cur = conn.execute(f'SELECT COUNT(*) FROM "{table_name}"')

    return cur.fetchone()[0]


def export_csv_data(conn, table_name):

    cur = conn.execute(f'SELECT * FROM "{table_name}" ORDER BY id')

    rows = cur.fetchall()

    cols = [d[0] for d in cur.description]

    buf = io.StringIO()

    writer = csv.writer(buf)

    writer.writerow(cols)

    writer.writerows(rows)

    return buf.getvalue()


# ──────────────────────────────────────────────────────────────────────────────
# Streamlit UI
# ──────────────────────────────────────────────────────────────────────────────

st.set_page_config(
    page_title='Firewall Rule Builder',
    page_icon='🔥',
    layout='wide',
)

st.title('🔥 Firewall Rule Builder')

st.caption(
    'Subnet/range entries are expanded to individual IPs. '
    'Database-level deduplication is enabled.'
)

# ──────────────────────────────────────────────────────────────────────────────
# Sidebar
# ──────────────────────────────────────────────────────────────────────────────

with st.sidebar:

    st.header('⚙️ SQLite Database')

    db_path = st.text_input(
        'Database file path',
        value='firewall_rules.db'
    )

    db_table = st.text_input(
        'Table name',
        value='firewall_rules'
    )

    st.divider()

    st.header('📋 Rule Metadata')

    protocol = st.selectbox(
        'Protocol',
        ['TCP', 'UDP', 'TCP/UDP', 'ICMP', 'Any']
    )

    desc_text = st.text_area(
        'Description / Comment'
    )

    st.divider()

    expand_ports = st.checkbox(
        'Expand port ranges',
        value=False
    )

    st.divider()

    st.header('📂 Database Info')

    if os.path.exists(db_path):

        size_kb = os.path.getsize(db_path) / 1024

        st.metric(
            'DB File Size',
            f'{size_kb:.1f} KB'
        )

        try:

            c = get_connection(db_path)

            ensure_table(c, db_table)

            st.metric(
                'Rows',
                f'{count_rows(c, db_table):,}'
            )

            c.close()

        except Exception:
            pass

    else:
        st.info('Database will be created automatically.')

# ──────────────────────────────────────────────────────────────────────────────
# Tabs
# ──────────────────────────────────────────────────────────────────────────────

tab_add, tab_view = st.tabs([
    '➕ Add Rules',
    '🔍 View Rules'
])

# ──────────────────────────────────────────────────────────────────────────────
# Input helper
# ──────────────────────────────────────────────────────────────────────────────

def ip_input_block(label, key_prefix):

    mode = st.radio(
        'Input mode',
        ['Manual entry', 'Select subnet group'],
        key=f'{key_prefix}_mode',
        horizontal=True,
    )

    if mode == 'Select subnet group':

        group = st.selectbox(
            f'{label} subnet group',
            options=GROUP_ORDER,
            key=f'{key_prefix}_group',
        )

        tokens = SUBNET_GROUPS[group]

        st.info(f'{len(tokens)} subnet(s) selected.')

    else:

        raw = st.text_area(
            f'{label} IPs / Subnets / Ranges',
            placeholder='10.10.1.1, 10.10.2.0/24',
            key=f'{key_prefix}_raw',
            height=150,
        )

        tokens = parse_ip_input(raw) if raw.strip() else []

    return tokens


# ──────────────────────────────────────────────────────────────────────────────
# Add Rules tab
# ──────────────────────────────────────────────────────────────────────────────

with tab_add:

    col1, col2 = st.columns(2)

    with col1:
        st.subheader('📤 Source')
        src_tokens = ip_input_block('Source', 'src')

    with col2:
        st.subheader('📥 Destination')
        dst_tokens = ip_input_block('Destination', 'dst')

    st.subheader('🚪 Destination Ports')

    port_raw = st.text_input(
        'Ports',
        placeholder='80,443,8080-8090'
    )

    port_tokens = parse_port_input(port_raw) if port_raw.strip() else []

    if src_tokens and dst_tokens and port_tokens:

        with st.spinner('Expanding inputs...'):

            src_ips = expand_token_list(src_tokens)

            dst_ips = expand_token_list(dst_tokens)

            ports = (
                expand_port_list(port_tokens)
                if expand_ports
                else port_tokens
            )

        total_combos = (
            len(src_ips)
            * len(dst_ips)
            * len(ports)
        )

        st.info(
            f'''
            Source IPs: {len(src_ips):,}

            Destination IPs: {len(dst_ips):,}

            Ports: {len(ports):,}

            Total combinations: {total_combos:,}
            '''
        )

        if st.button(
            f'🚀 Insert {total_combos:,} Rules',
            type='primary'
        ):

            try:

                BATCH = 50000

                conn = get_connection(db_path)

                ensure_table(conn, db_table)

                inserted = 0
                skipped = 0

                progress = st.progress(
                    0,
                    text='Inserting rules...'
                )

                all_combos = itertools.product(
                    src_ips,
                    dst_ips,
                    ports
                )

                processed = 0

                while True:

                    batch = list(
                        itertools.islice(all_combos, BATCH)
                    )

                    if not batch:
                        break

                    batch_inserted, batch_skipped = insert_rules(
                        conn,
                        db_table,
                        batch,
                        protocol,
                        desc_text
                    )

                    inserted += batch_inserted
                    skipped += batch_skipped

                    processed += len(batch)

                    progress.progress(
                        min(processed / total_combos, 1.0),
                        text=f'''
                        Processed: {processed:,}/{total_combos:,}

                        Inserted: {inserted:,}

                        Skipped duplicates: {skipped:,}
                        '''
                    )

                conn.close()

                progress.empty()

                st.success(
                    f'''
                    ✅ Inserted: {inserted:,} new rules

                    ⏭️ Skipped duplicates: {skipped:,}

                    Database: {db_path}
                    '''
                )

                st.balloons()

            except Exception as ex:

                st.error(f'Insert failed: {ex}')

# ──────────────────────────────────────────────────────────────────────────────
# View Rules tab
# ──────────────────────────────────────────────────────────────────────────────

with tab_view:

    st.subheader('🔍 Recent Rules')

    limit = st.slider(
        'Rows to display',
        10,
        500,
        100,
        step=10
    )

    try:

        c = get_connection(db_path)

        ensure_table(c, db_table)

        rows = fetch_recent(c, db_table, limit)

        c.close()

        if rows:

            st.dataframe(
                rows,
                use_container_width=True
            )

        else:
            st.info('No rules present.')

    except Exception as ex:

        st.error(f'Could not fetch data: {ex}')

# ──────────────────────────────────────────────────────────────────────────────
# Footer
# ──────────────────────────────────────────────────────────────────────────────

st.divider()

st.caption(
    'Run using: streamlit run app.py'
)