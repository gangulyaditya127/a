import { useState, useEffect } from "react";
import {
  Loader2,
  Plus,
  Pencil,
  Trash2,
  ArrowLeft,
  ShieldAlert,
} from "lucide-react";
import { SuperAdminLayout } from "@/components/admin/SuperAdminLayout";
import {
  fetchArchitectureRules,
  createArchitectureRule,
  updateArchitectureRule,
  deleteArchitectureRule,
  type ArchitectureRule,
} from "@/lib/adminApi";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useNavigate } from "react-router-dom";

const ArchitectureRulesConfig = () => {
  const [rules, setRules] = useState<ArchitectureRule[]>([]);
  const [loading, setLoading] = useState(true);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [currentRule, setCurrentRule] = useState<Partial<ArchitectureRule> | null>(null);
  const [providerFilter, setProviderFilter] = useState<string>("ALL");
  const { toast } = useToast();
  const navigate = useNavigate();

  const loadRules = () => {
    setLoading(true);
    fetchArchitectureRules()
      .then(setRules)
      .catch(() => {
        toast({
          title: "Error",
          description: "Failed to load architecture rules.",
          variant: "destructive",
        });
      })
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    loadRules();
  }, []);

  const handleSave = async () => {
    if (!currentRule?.cloud_provider || !currentRule?.category || !currentRule?.rule_text) {
      toast({ title: "Validation Error", description: "Provider, category, and rule text are required.", variant: "destructive" });
      return;
    }

    try {
      const payload = {
        cloud_provider: currentRule.cloud_provider,
        category: currentRule.category,
        rule_text: currentRule.rule_text,
        severity: currentRule.severity || "CRITICAL",
      };

      if (currentRule.id) {
        await updateArchitectureRule(currentRule.id, payload);
        toast({ title: "Success", description: "Rule updated successfully." });
      } else {
        await createArchitectureRule(payload);
        toast({ title: "Success", description: "Rule created successfully." });
      }
      setIsDialogOpen(false);
      loadRules();
    } catch (e: any) {
      toast({ title: "Error", description: e.message, variant: "destructive" });
    }
  };

  const handleDelete = async (id: string) => {
    if (confirm("Are you sure you want to delete this rule?")) {
      try {
        await deleteArchitectureRule(id);
        toast({ title: "Success", description: "Rule deleted successfully." });
        loadRules();
      } catch (e: any) {
        toast({ title: "Error", description: e.message, variant: "destructive" });
      }
    }
  };

  const openDialog = (rule?: ArchitectureRule) => {
    setCurrentRule(rule || { cloud_provider: "AWS", severity: "CRITICAL" });
    setIsDialogOpen(true);
  };

  const filteredRules = providerFilter === "ALL" 
    ? rules 
    : rules.filter((r) => r.cloud_provider.toUpperCase() === providerFilter.toUpperCase());

  const getSeverityColor = (sev: string) => {
    switch (sev.toUpperCase()) {
      case "CRITICAL": return "bg-red-100 text-red-700 border-red-200";
      case "HIGH": return "bg-orange-100 text-orange-700 border-orange-200";
      case "MEDIUM": return "bg-yellow-100 text-yellow-700 border-yellow-200";
      case "LOW": return "bg-blue-100 text-blue-700 border-blue-200";
      default: return "bg-gray-100 text-gray-700";
    }
  };

  const providers = ["ALL", ...Array.from(new Set(rules.map((r) => r.cloud_provider.toUpperCase())))];
  if (!providers.includes("AWS")) providers.push("AWS");
  if (!providers.includes("AZURE")) providers.push("AZURE");
  if (!providers.includes("GCP")) providers.push("GCP");
  const uniqueProviders = Array.from(new Set(providers));

  return (
    <SuperAdminLayout
      title="Architecture Rules"
      subtitle="Define validation rules applied during architecture review."
    >
      <div className="mb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <Button variant="ghost" onClick={() => navigate("/superadmin/config")} className="pl-0 text-muted-foreground hover:text-foreground w-fit">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Configuration
        </Button>
        <div className="flex items-center gap-3">
          <Select value={providerFilter} onValueChange={setProviderFilter}>
            <SelectTrigger className="w-[150px]">
              <SelectValue placeholder="Filter Provider" />
            </SelectTrigger>
            <SelectContent>
              {uniqueProviders.map(p => (
                <SelectItem key={p} value={p}>{p === "ALL" ? "All Providers" : p}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button onClick={() => openDialog()} className="bg-emerald-600 hover:bg-emerald-700">
            <Plus className="mr-2 h-4 w-4" />
            Add Rule
          </Button>
        </div>
      </div>

      {loading ? (
        <div className="flex justify-center py-20">
          <Loader2 className="h-8 w-8 animate-spin text-emerald-500" />
        </div>
      ) : (
        <Card className="shadow-sm">
          <CardHeader className="border-b bg-muted/20">
            <CardTitle>Rules ({filteredRules.length})</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            {filteredRules.length === 0 ? (
              <div className="p-8 text-center text-muted-foreground">
                No rules found. Click "Add Rule" to create one.
              </div>
            ) : (
              <div className="divide-y">
                {filteredRules.map((r) => (
                  <div key={r.id} className="flex items-start justify-between p-4 hover:bg-muted/30 transition-colors">
                    <div className="flex gap-3 items-start">
                      <div className="mt-1 text-emerald-600">
                        <ShieldAlert className="h-5 w-5" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <Badge variant="outline" className="font-mono text-xs">{r.cloud_provider}</Badge>
                          <span className="font-semibold text-sm">{r.category}</span>
                          <Badge variant="secondary" className={`text-[10px] ${getSeverityColor(r.severity)}`}>{r.severity}</Badge>
                        </div>
                        <p className="text-sm text-muted-foreground mt-1">{r.rule_text}</p>
                      </div>
                    </div>
                    <div className="flex gap-2 shrink-0">
                      <Button variant="ghost" size="icon" onClick={() => openDialog(r)}>
                        <Pencil className="h-4 w-4 text-blue-500" />
                      </Button>
                      <Button variant="ghost" size="icon" onClick={() => handleDelete(r.id)}>
                        <Trash2 className="h-4 w-4 text-red-500" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      )}

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>{currentRule?.id ? "Edit Rule" : "Add Rule"}</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Cloud Provider</Label>
                <Input
                  value={currentRule?.cloud_provider || ""}
                  onChange={(e) => setCurrentRule({ ...currentRule, cloud_provider: e.target.value.toUpperCase() })}
                  placeholder="AWS, AZURE, GCP"
                />
              </div>
              <div className="space-y-2">
                <Label>Severity</Label>
                <Select
                  value={currentRule?.severity || "CRITICAL"}
                  onValueChange={(v) => setCurrentRule({ ...currentRule, severity: v })}
                >
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="CRITICAL">CRITICAL</SelectItem>
                    <SelectItem value="HIGH">HIGH</SelectItem>
                    <SelectItem value="MEDIUM">MEDIUM</SelectItem>
                    <SelectItem value="LOW">LOW</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-2">
              <Label>Category</Label>
              <Input
                value={currentRule?.category || ""}
                onChange={(e) => setCurrentRule({ ...currentRule, category: e.target.value })}
                placeholder="e.g. Network Security, Identity, Storage"
              />
            </div>
            <div className="space-y-2">
              <Label>Rule Text</Label>
              <Textarea
                value={currentRule?.rule_text || ""}
                onChange={(e) => setCurrentRule({ ...currentRule, rule_text: e.target.value })}
                rows={3}
                placeholder="Describe the validation rule..."
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSave} className="bg-emerald-600 hover:bg-emerald-700">Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </SuperAdminLayout>
  );
};

export default ArchitectureRulesConfig;
