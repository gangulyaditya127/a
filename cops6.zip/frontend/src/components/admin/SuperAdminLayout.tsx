import { type ReactNode } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { Cloud, Bell, LayoutDashboard, Users, UserCog, Settings, LogOut } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { useAuth } from "@/contexts/AuthContext";

interface SuperAdminLayoutProps {
  children: ReactNode;
  title?: string;
  subtitle?: string;
}

const sidebarLinks = [
  { label: "Dashboard", icon: LayoutDashboard, path: "/superadmin" },
  { label: "Onboarding Assignment", icon: Users, path: "/superadmin/onboardings" },
  { label: "Admin Management", icon: UserCog, path: "/superadmin/admins" },
  { label: "Configuration", icon: Settings, path: "/superadmin/config" },
];

export const SuperAdminLayout = ({ children, title, subtitle }: SuperAdminLayoutProps) => {
  const navigate = useNavigate();
  const location = useLocation();
  const { user, logout } = useAuth();

  const isActive = (path: string) => location.pathname === path;

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* Top Nav — purple accent */}
      <header className="h-14 flex items-center px-6 justify-between shrink-0 bg-gradient-to-r from-purple-600 to-indigo-800">
        <div className="flex items-center gap-3">
          <Cloud className="h-6 w-6 text-white" />
          <div>
            <h1 className="text-sm font-semibold text-white leading-tight">
              DIS Cloud Onboarding — Super Admin Portal
            </h1>
            <p className="text-[10px] text-white/60">
              Digital Infrastructure Services — Platform Management
            </p>
          </div>
        </div>
        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="icon"
            className="text-white/70 hover:text-white hover:bg-white/10 relative"
          >
            <Bell className="h-4 w-4" />
            <span className="absolute top-1.5 right-1.5 h-2 w-2 rounded-full bg-red-400" />
          </Button>
          <Separator orientation="vertical" className="h-6 mx-2 bg-white/20" />
          <div className="flex items-center gap-2">
            <div className="h-7 w-7 rounded-full bg-purple-400/30 flex items-center justify-center">
              <span className="text-xs font-bold text-white">
                {user?.name?.charAt(0) ?? 'S'}
              </span>
            </div>
            <div className="text-right">
              <p className="text-xs font-medium text-white leading-tight">{user?.name ?? 'Super Admin'}</p>
              <Badge className="bg-purple-400/20 text-purple-100 border-purple-400/30 text-[9px] px-1.5 py-0">
                Super Admin
              </Badge>
            </div>
          </div>
          <Button
            variant="ghost"
            size="icon"
            className="text-white/70 hover:text-white hover:bg-white/10 ml-1"
            onClick={() => { logout(); navigate('/'); }}
          >
            <LogOut className="h-4 w-4" />
          </Button>
        </div>
      </header>

      <div className="flex flex-1 overflow-hidden">
        {/* Left Sidebar */}
        <aside className="w-56 shrink-0 border-r bg-card flex flex-col">
          <div className="p-4 space-y-1">
            {sidebarLinks.map((link) => (
              <button
                key={link.label}
                onClick={() => navigate(link.path)}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium transition-colors ${
                  isActive(link.path)
                    ? 'bg-purple-50 text-purple-700 dark:bg-purple-950/30 dark:text-purple-400'
                    : 'text-muted-foreground hover:bg-muted hover:text-foreground'
                }`}
              >
                <link.icon className={`h-4 w-4 ${isActive(link.path) ? 'text-purple-600' : ''}`} />
                {link.label}
              </button>
            ))}
          </div>
          <div className="mt-auto p-4 border-t space-y-1">
            <button
              onClick={() => navigate('/admin')}
              className="w-full flex items-center gap-3 px-3 py-2 rounded-md text-xs text-muted-foreground hover:bg-muted hover:text-foreground transition-colors"
            >
              <UserCog className="h-3.5 w-3.5" /> Admin Portal
            </button>
            <button
              onClick={() => navigate('/')}
              className="w-full flex items-center gap-3 px-3 py-2 rounded-md text-xs text-muted-foreground hover:bg-muted hover:text-foreground transition-colors"
            >
              <Cloud className="h-3.5 w-3.5" /> User Portal
            </button>
          </div>
        </aside>

        {/* Main content */}
        <main className="flex-1 overflow-auto">
          {(title || subtitle) && (
            <div className="border-b bg-card px-8 py-5">
              {title && <h1 className="text-xl font-semibold text-foreground">{title}</h1>}
              {subtitle && <p className="text-sm text-muted-foreground mt-0.5">{subtitle}</p>}
            </div>
          )}
          <div className="p-8">{children}</div>
        </main>
      </div>
    </div>
  );
};
