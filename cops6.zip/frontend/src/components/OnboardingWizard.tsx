import { useEffect, useRef, useState } from "react";
import { STEPS, type OnboardingState, type RequirementAssessment } from "@/types/onboarding";
import { StepIndicator } from "./StepIndicator";
import { TopNav } from "./TopNav";
import { StepAccountDetails } from "./steps/StepAccountDetails";
import { StepRequirementAssessment } from "./steps/StepRequirementAssessment";
import { StepCloudResources } from "./steps/StepCloudResources";
import { StepArchitectureOverview } from "./steps/StepArchitectureOverview";
import StepCostEstimation from "./steps/StepCostEstimation";
import { StepRecommendations } from "./steps/StepRecommendations";
import { StepApprovalTracker } from "./steps/StepApprovalTracker";
import { StepServiceIdCreation } from "./steps/StepServiceIdCreation";
import { StepRfcTracking } from "./steps/StepRfcTracking";
import { InteractionTimeline, type InteractionEvent } from "./InteractionTimeline";
import { Button } from "./ui/button";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "./ui/sheet";
import { AlertTriangle, CheckCircle2, ChevronLeft, ChevronRight, Clock, FileCheck, FileWarning, History, LayoutDashboard, Loader2, MessageSquare, RefreshCw, Save, Send, Sparkles } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { createOnboarding, updateOnboarding, upsertAccountDetails, upsertRequirements, upsertCloudResourceBucket, resubmitOnboarding, fetchUserEvents, type ApiInteractionEvent } from "@/lib/api";
import type { ApiOnboardingFull } from "@/lib/api";

const initialState: OnboardingState = {
  currentStep: 1,
  accountDetails: {
    projectName: "", isu: "", accountName: "", owner: "", empId: "", description: "", businessUnit: "",
  },
  requirementAssessment: {
    solutionType: "", deploymentEnvironments: [], cloudProvider: "", region: "",
  },
  cloudResources: [],
  architectureOverview: {
    uploadedDiagram: null, generatedFromBucket: false, securityViolations: [], revisedDiagram: null, analysisComplete: false,
  },
  recommendations: [],
  approvals: [],
  serviceId: {
    serviceId: "", status: "not-started", disTeamAssigned: "", createdDate: null,
  },
  rfcs: [],
};

interface Props {
  initialTemplate?: Partial<OnboardingState> | null;
  existing?: ApiOnboardingFull | null;
  onBackToDashboard?: () => void;
}

const TOTAL = STEPS.length;

/** Steps 1–4 are user-fillable. Steps 5+ require admin approval first. */
const USER_STEPS = 4;

export const OnboardingWizard = ({ initialTemplate, existing, onBackToDashboard }: Props) => {
  const [state, setState] = useState<OnboardingState>(() => {
    if (existing) {
      const acct = existing.account_details;
      const req = existing.requirement_assessment;
      const remaining = (existing.remaining_state ?? {}) as Partial<OnboardingState>;
      return {
        ...initialState,
        currentStep: existing.current_step,
        accountDetails: acct ? {
          projectName: acct.project_name,
          isu: acct.isu,
          accountName: acct.account_name,
          owner: acct.owner,
          empId: acct.emp_id,
          description: acct.description,
          businessUnit: acct.business_unit,
        } : initialState.accountDetails,
        requirementAssessment: req ? {
          solutionType: (req.solution_type || '') as RequirementAssessment['solutionType'],
          deploymentEnvironments: req.deployment_environments ?? [],
          cloudProvider: req.cloud_provider ?? '',
          region: req.region ?? '',
        } : initialState.requirementAssessment,
        cloudResources: remaining.cloudResources ?? initialState.cloudResources,
        architectureOverview: remaining.architectureOverview ?? initialState.architectureOverview,
        recommendations: remaining.recommendations ?? initialState.recommendations,
        approvals: remaining.approvals ?? initialState.approvals,
        serviceId: remaining.serviceId ?? initialState.serviceId,
        rfcs: remaining.rfcs ?? initialState.rfcs,
      };
    }
    return { ...initialState, ...initialTemplate, currentStep: 1 };
  });

  const idRef = useRef<string>(existing?.id ?? '');
  const createdRef = useRef<string>(existing?.created_at ?? new Date().toISOString());
  const [ready, setReady] = useState(!!existing);
  const [saving, setSaving] = useState(false);
  const [events, setEvents] = useState<InteractionEvent[]>([]);

  // Admin review status — read from the API response
  const adminStatus: string | undefined = existing?.admin_status;
  const adminComments = existing?.admin_comments ?? [];

  // Determine whether the user is in the "pending admin" state.
  // This is true when:
  //   - User has submitted (step > 4) but admin hasn't sent recommendations yet
  //   - OR admin has sent back for changes (sent_back)
  const pendingAdminStatuses = ['pending_assignment', 'assigned', 'under_review', 'cost_pending', 'cost_done', 'approved'];
  const isSentBack = adminStatus === 'sent_back';
  const isPendingAdmin = adminStatus != null && pendingAdminStatuses.includes(adminStatus);
  const isAdminDone = adminStatus === 'recommendations_sent';

  // If the admin hasn't finished yet and current step is > USER_STEPS, show the pending view
  const showPendingView = (isPendingAdmin || isSentBack) && state.currentStep > USER_STEPS;

  useEffect(() => {
    if (!existing) {
      const name = initialTemplate?.accountDetails?.projectName || 'Untitled Onboarding';
      createOnboarding({ name }).then((data) => {
        idRef.current = data.id;
        createdRef.current = data.created_at;
        setReady(true);
      });
    }
  }, []);

  // Load interaction events
  useEffect(() => {
    if (!idRef.current) return;
    fetchUserEvents(idRef.current)
      .then((evts: ApiInteractionEvent[]) => {
        setEvents(evts.map((e) => ({
          id: e.id, ts: e.ts, actor: e.actor as InteractionEvent['actor'], actorName: e.actor_name,
          kind: e.kind as InteractionEvent['kind'],
          title: e.title, body: e.body ?? undefined, scope: e.scope ?? undefined,
        })));
      })
      .catch(() => {});
  }, [existing]);

  /** Build the remaining_state blob for steps 3-8 */
  const buildRemainingState = (s: OnboardingState) => {
    const { cloudResources, architectureOverview, recommendations, approvals, serviceId, rfcs } = s;
    return { cloudResources, architectureOverview, recommendations, approvals, serviceId, rfcs };
  };

  /** Save only the data relevant to the current step */
  const saveCurrentStep = async (s: OnboardingState, targetStep?: number): Promise<void> => {
    if (!idRef.current) return;

    const stepToSave = targetStep ?? s.currentStep;
    const remainingState = buildRemainingState(s);

    if (s.currentStep === 1) {
      // Step 1 — Account Details: update onboarding + upsert account details
      await Promise.all([
        updateOnboarding(idRef.current, {
          name: s.accountDetails.projectName?.trim() || 'Untitled Onboarding',
          current_step: stepToSave,
          remaining_state: remainingState,
        }),
        upsertAccountDetails(idRef.current, {
          project_name: s.accountDetails.projectName,
          isu: s.accountDetails.isu,
          account_name: s.accountDetails.accountName,
          owner: s.accountDetails.owner,
          emp_id: s.accountDetails.empId,
          description: s.accountDetails.description,
          business_unit: s.accountDetails.businessUnit,
        }),
      ]);
    } else if (s.currentStep === 2) {
      // Step 2 — Requirement Assessment: update onboarding + upsert requirements
      await Promise.all([
        updateOnboarding(idRef.current, {
          name: s.accountDetails.projectName?.trim() || 'Untitled Onboarding',
          current_step: stepToSave,
          remaining_state: remainingState,
        }),
        upsertRequirements(idRef.current, {
          solution_type: s.requirementAssessment.solutionType,
          deployment_environments: s.requirementAssessment.deploymentEnvironments,
          cloud_provider: s.requirementAssessment.cloudProvider,
          region: s.requirementAssessment.region,
        }),
      ]);
    } else if (s.currentStep === 3) {
      // Step 3 — Cloud Resources: update onboarding step + persist resource bucket
      const currentProvider = s.requirementAssessment.cloudProvider || 'AWS';
      const bucket = s.cloudResources.find(b => b.provider === currentProvider) || { provider: currentProvider, resources: [] };
      await Promise.all([
        updateOnboarding(idRef.current, {
          name: s.accountDetails.projectName?.trim() || 'Untitled Onboarding',
          current_step: stepToSave,
          remaining_state: remainingState,
        }),
        upsertCloudResourceBucket(idRef.current, {
          provider: bucket.provider,
          resources: bucket.resources.map((r) => ({
            service: r.service,
            count: r.count,
            configDetails: r.configDetails,
          })),
        }),
      ]);
    } else {
      // Steps 4-8 — only update the onboarding remaining_state blob
      await updateOnboarding(idRef.current, {
        name: s.accountDetails.projectName?.trim() || 'Untitled Onboarding',
        current_step: stepToSave,
        remaining_state: remainingState,
      });
    }
  };

  const updateState = <K extends keyof OnboardingState>(key: K, value: OnboardingState[K]) => {
    setState((prev) => ({ ...prev, [key]: value }));
  };

  const goNext = async () => {
    if (state.currentStep >= TOTAL || saving) return;
    setSaving(true);
    try {
      await saveCurrentStep(state, state.currentStep + 1);
      setState((p) => ({ ...p, currentStep: p.currentStep + 1 }));
    } catch {
      toast({ title: "Save Failed", description: "Could not save progress. Please try again.", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  /** Submit for admin review — saves step 4, moves to step 5 (shows pending view) */
  const handleSubmitForReview = async () => {
    if (saving) return;
    setSaving(true);
    try {
      await saveCurrentStep(state, USER_STEPS + 1);
      setState((p) => ({ ...p, currentStep: USER_STEPS + 1 }));
      toast({ title: "Submitted for Review", description: "Your onboarding has been submitted. An admin will review it shortly." });
    } catch {
      toast({ title: "Submit Failed", description: "Could not submit. Please try again.", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  const goPrev = () => state.currentStep > 1 && setState((p) => ({ ...p, currentStep: p.currentStep - 1 }));
  const goToStep = (step: number) => {
    // Allow going to steps 1-4 always; steps 5+ only if admin is done
    if (step <= USER_STEPS || isAdminDone) {
      setState((p) => ({ ...p, currentStep: step }));
    }
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      await saveCurrentStep(state);
      toast({ title: "Progress Saved", description: "Onboarding saved to the server." });
    } catch {
      toast({ title: "Save Failed", description: "Could not save progress.", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  const renderStep = () => {
    switch (state.currentStep) {
      case 1: return <StepAccountDetails data={state.accountDetails} onChange={(d) => updateState("accountDetails", d)} />;
      case 2: return <StepRequirementAssessment data={state.requirementAssessment} onChange={(d) => updateState("requirementAssessment", d)} />;
      case 3: return <StepCloudResources data={state.cloudResources} provider={state.requirementAssessment.cloudProvider} onboardingId={idRef.current} onChange={(d) => updateState("cloudResources", d)} />;
      case 4: return <StepArchitectureOverview data={state.architectureOverview} onboardingId={idRef.current} onChange={(d) => updateState("architectureOverview", d)} />;
      case 5: return <StepCostEstimation onboardingId={idRef.current} />;
      case 6: return <StepRecommendations data={state.recommendations} solutionType={state.requirementAssessment.solutionType} onboardingId={idRef.current} onChange={(d) => updateState("recommendations", d)} />;
      case 7: return <StepApprovalTracker data={state.approvals} solutionType={state.requirementAssessment.solutionType} onChange={(d) => updateState("approvals", d)} />;
      case 8: return <StepServiceIdCreation data={state.serviceId} onChange={(d) => updateState("serviceId", d)} />;
      case 9: return <StepRfcTracking data={state.rfcs} serviceIdReady={state.serviceId.status === "completed"} onChange={(d) => updateState("rfcs", d)} />;
      default: return null;
    }
  };

  /** Resubmit after making changes — resets admin_status for re-review */
  const handleResubmit = async () => {
    if (!idRef.current || saving) return;
    setSaving(true);
    try {
      await saveCurrentStep(state, USER_STEPS + 1);
      await resubmitOnboarding(idRef.current);
      setState((p) => ({ ...p, currentStep: USER_STEPS + 1 }));
      toast({ title: "Resubmitted Successfully", description: "Your onboarding has been resubmitted for admin review." });
      // Reload to get fresh admin_status
      window.location.reload();
    } catch {
      toast({ title: "Resubmit Failed", description: "Could not resubmit. Please try again.", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  // Get the latest admin comment entry (which contains both overall + section comments)
  const latestComment = adminComments.length > 0 ? adminComments[adminComments.length - 1] : null;

  /** Render the intermediate pending/sent-back view */
  const renderPendingView = () => (
    <div className="max-w-2xl mx-auto py-12 px-6 text-center">
      {isSentBack ? (
        /* ── Sent Back View ── */
        <div className="space-y-6">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-amber-100">
            <FileWarning className="h-10 w-10 text-amber-600" />
          </div>
          <div>
            <h2 className="text-2xl font-semibold text-foreground">Changes Requested by Admin</h2>
            <p className="text-muted-foreground mt-2">
              The admin has reviewed your submission and requested some changes. Please review all the feedback below, go back to the relevant sections, make corrections, and resubmit.
            </p>
          </div>

          {latestComment && (
            <div className="bg-card rounded-lg border shadow-card text-left overflow-hidden">
              {/* Overall comment */}
              <div className="px-5 py-4 bg-amber-50 border-b border-amber-200">
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-full bg-amber-200 flex items-center justify-center shrink-0 mt-0.5">
                    <span className="text-xs font-bold text-amber-800">{(latestComment.admin_name || 'A').charAt(0).toUpperCase()}</span>
                  </div>
                  <div>
                    <span className="font-semibold text-sm text-amber-900">{latestComment.admin_name}</span>
                    <span className="text-xs text-amber-600 ml-2">Overall Comment</span>
                    <p className="mt-1 text-sm text-amber-800">{latestComment.comment}</p>
                  </div>
                </div>
              </div>

              {/* Per-section rejected comments */}
              {latestComment.section_comments && latestComment.section_comments.length > 0 && (
                <div className="divide-y">
                  <div className="px-5 py-3 bg-red-50/50 border-b">
                    <h4 className="text-xs font-semibold text-red-700 uppercase tracking-wider flex items-center gap-1.5">
                      <AlertTriangle className="h-3.5 w-3.5" /> Section-wise Feedback
                    </h4>
                  </div>
                  {latestComment.section_comments.map((sc, i) => (
                    <div key={i} className="px-5 py-3 flex items-start gap-3">
                      <div className="w-6 h-6 rounded bg-red-100 flex items-center justify-center shrink-0 mt-0.5">
                        <span className="text-[10px] font-bold text-red-600">{i + 1}</span>
                      </div>
                      <div>
                        <span className="text-xs font-semibold text-red-700 uppercase tracking-wider">{sc.section_label}</span>
                        <p className="mt-0.5 text-sm text-muted-foreground">{sc.comment}</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Previous comment rounds (if any) */}
          {adminComments.length > 1 && (
            <details className="text-left">
              <summary className="text-xs text-muted-foreground cursor-pointer hover:text-foreground transition-colors">
                View {adminComments.length - 1} previous review round{adminComments.length > 2 ? 's' : ''}
              </summary>
              <div className="mt-2 space-y-2">
                {adminComments.slice(0, -1).reverse().map((c, i) => (
                  <div key={i} className="bg-muted/30 rounded-lg p-3 text-sm">
                    <span className="font-semibold text-foreground">{c.admin_name}:</span>
                    <span className="ml-1 text-muted-foreground">{c.comment}</span>
                    {c.section_comments && c.section_comments.length > 0 && (
                      <ul className="mt-1.5 space-y-0.5 ml-4">
                        {c.section_comments.map((sc, j) => (
                          <li key={j} className="text-xs text-muted-foreground">
                            <span className="font-medium text-foreground">{sc.section_label}:</span> {sc.comment}
                          </li>
                        ))}
                      </ul>
                    )}
                  </div>
                ))}
              </div>
            </details>
          )}

          <div className="flex items-center justify-center gap-3 pt-2">
            <Button variant="outline" onClick={() => setState((p) => ({ ...p, currentStep: 1 }))}>
              <ChevronLeft className="h-4 w-4 mr-1" /> Go Back to Edit
            </Button>
            <Button onClick={handleResubmit} disabled={saving} className="gradient-primary text-primary-foreground">
              {saving ? <><Loader2 className="h-4 w-4 mr-1 animate-spin" /> Resubmitting...</> : <><RefreshCw className="h-4 w-4 mr-1" /> Resubmit for Review</>}
            </Button>
          </div>
        </div>
      ) : (
        /* ── Pending Admin Review View ── */
        <div className="space-y-6">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-blue-100">
            <FileCheck className="h-10 w-10 text-blue-600" />
          </div>
          <div>
            <h2 className="text-2xl font-semibold text-foreground">Pending with Admin for Review</h2>
            <p className="text-muted-foreground mt-2">
              Your onboarding has been submitted successfully and is now pending admin review and approval.
              You'll be notified once the admin completes the review.
            </p>
          </div>
          <div className="bg-card rounded-lg border shadow-card p-6 text-left space-y-4">
            <h3 className="text-sm font-semibold text-foreground">What happens next?</h3>
            <ol className="space-y-3 text-sm text-muted-foreground">
              <li className="flex items-start gap-3">
                <span className="w-6 h-6 rounded-full bg-blue-100 text-blue-700 font-semibold text-xs flex items-center justify-center shrink-0 mt-0.5">1</span>
                <span>A <strong>SuperAdmin</strong> will assign your onboarding to a <strong>DIS Admin</strong> for review.</span>
              </li>
              <li className="flex items-start gap-3">
                <span className="w-6 h-6 rounded-full bg-blue-100 text-blue-700 font-semibold text-xs flex items-center justify-center shrink-0 mt-0.5">2</span>
                <span>The admin will review all sections — account details, requirements, resources, and architecture.</span>
              </li>
              <li className="flex items-start gap-3">
                <span className="w-6 h-6 rounded-full bg-blue-100 text-blue-700 font-semibold text-xs flex items-center justify-center shrink-0 mt-0.5">3</span>
                <span>Once approved, the admin will generate <strong>cost estimation</strong> and <strong>recommendations</strong> (GPS, RFC, Approvals) for you.</span>
              </li>
              <li className="flex items-start gap-3">
                <span className="w-6 h-6 rounded-full bg-blue-100 text-blue-700 font-semibold text-xs flex items-center justify-center shrink-0 mt-0.5">4</span>
                <span>You'll then be able to proceed with the remaining steps of the onboarding.</span>
              </li>
            </ol>
          </div>
          <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground">
            <Clock className="h-4 w-4 animate-pulse" />
            <span>
              Status: <strong className="text-foreground">{adminStatus?.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}</strong>
            </span>
          </div>
        </div>
      )}
    </div>
  );

  if (!ready) {
    return (
      <div className="min-h-screen flex flex-col bg-background">
        <TopNav />
        <div className="flex-1 flex items-center justify-center">
          <p className="text-muted-foreground">Initializing onboarding...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <TopNav />
      <div className="flex-1 flex flex-col">
        <div className="border-b bg-card px-6 py-4 flex items-center gap-4">
          <div className="flex-1">
            <StepIndicator steps={STEPS} currentStep={state.currentStep} onStepClick={goToStep} />
          </div>
          {/* Activity Sheet drawer */}
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="outline" size="sm" className="gap-1.5 shrink-0">
                <History className="h-3.5 w-3.5" />
                Activity
                {events.length > 0 && (
                  <span className="ml-1 h-4 min-w-[16px] px-1 rounded-full bg-primary text-primary-foreground text-[10px] font-semibold flex items-center justify-center">
                    {events.length}
                  </span>
                )}
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-[420px] p-0">
              <SheetHeader className="px-4 pt-4 pb-2">
                <SheetTitle>User ↔ Admin Activity</SheetTitle>
              </SheetHeader>
              <div className="px-4 pb-4 h-[calc(100vh-5rem)]">
                <InteractionTimeline
                  events={events}
                  compact
                  emptyHint="No activity yet. Submissions, comments and decisions will appear here."
                />
              </div>
            </SheetContent>
          </Sheet>
        </div>

        {/* ── Recommendations ready banner (only when admin is done) ── */}
        {isAdminDone && (
          <div className="mx-4 mt-2 rounded-lg border p-3 flex items-center gap-3 text-sm bg-blue-50 border-blue-200 text-blue-800">
            <Sparkles className="h-4 w-4 shrink-0" />
            <span>Recommendations are ready! You can now proceed with the remaining steps.</span>
          </div>
        )}

        <div className="flex-1 overflow-auto">
          {showPendingView ? (
            /* ── Intermediate Pending / Sent-Back View ── */
            renderPendingView()
          ) : (
            /* ── Normal Step Content ── */
            <div className="max-w-6xl mx-auto px-6 py-8">
              <div className="mb-6">
                <h2 className="text-2xl font-semibold text-foreground">{STEPS[state.currentStep - 1].title}</h2>
                <p className="text-muted-foreground text-sm mt-1">
                  Step {state.currentStep} of {TOTAL} — {STEPS[state.currentStep - 1].description}
                </p>
              </div>
              <div className="bg-card rounded-lg border shadow-card p-6">{renderStep()}</div>
            </div>
          )}
        </div>
        <div className="border-t bg-card px-6 py-4">
          <div className="max-w-6xl mx-auto flex items-center justify-between">
            <div className="flex items-center gap-2">
              {onBackToDashboard && (
                <Button variant="ghost" onClick={onBackToDashboard}>
                  <LayoutDashboard className="h-4 w-4 mr-1" /> Dashboard
                </Button>
              )}
              {!showPendingView && (
                <Button variant="outline" onClick={goPrev} disabled={state.currentStep === 1 || saving}>
                  <ChevronLeft className="h-4 w-4 mr-1" /> Previous
                </Button>
              )}
            </div>
            {!showPendingView && (
              <Button variant="ghost" onClick={handleSave} disabled={saving}>
                {saving ? <Loader2 className="h-4 w-4 mr-1 animate-spin" /> : <Save className="h-4 w-4 mr-1" />} Save Draft
              </Button>
            )}
            {showPendingView ? (
              /* No next/submit button in pending view */
              <div />
            ) : state.currentStep === USER_STEPS ? (
              /* Step 4 — Show "Submit for Review" instead of "Next" */
              <Button onClick={handleSubmitForReview} disabled={saving} className="gradient-primary text-primary-foreground">
                {saving ? <><Loader2 className="h-4 w-4 mr-1 animate-spin" /> Submitting...</> : <><Send className="h-4 w-4 mr-1" /> Submit for Review</>}
              </Button>
            ) : state.currentStep < TOTAL ? (
              <Button onClick={goNext} disabled={saving} className="gradient-primary text-primary-foreground">
                {saving ? <><Loader2 className="h-4 w-4 mr-1 animate-spin" /> Saving...</> : <>Next <ChevronRight className="h-4 w-4 ml-1" /></>}
              </Button>
            ) : (
              <Button onClick={() => toast({ title: "Onboarding Submitted", description: "All RFCs tracked. Dashboard updated." })} className="gradient-accent text-accent-foreground">
                Finish
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
