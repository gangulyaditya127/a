import { useEffect, useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import { Clock, DollarSign, CheckCircle2, Loader2 } from "lucide-react";

interface CostData {
  status: "pending" | "published";
  resource_costs?: Array<{
    resource_name: string;
    unit_cost: number;
    quantity: number;
    monthly_cost: number;
  }>;
  infra_support_cost?: number;
  total_monthly_cost?: number;
  total_annual_cost?: number;
  currency?: string;
  notes?: string;
}

interface Props {
  onboardingId: string;
}

const StepCostEstimation = ({ onboardingId }: Props) => {
  const [costData, setCostData] = useState<CostData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!onboardingId) return;
    fetch(`/api/onboardings/${onboardingId}/cost`, {
      headers: { 'X-User-Id': localStorage.getItem('auth_user_id') || '' },
    })
      .then((res) => res.json())
      .then(setCostData)
      .catch(() => setCostData({ status: "pending" }))
      .finally(() => setLoading(false));
  }, [onboardingId]);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  // Waiting state — cost not yet published by admin
  if (!costData || costData.status === "pending") {
    return (
      <div className="space-y-4">
        <h2 className="text-lg font-semibold flex items-center gap-2">
          <DollarSign className="h-5 w-5 text-primary" /> Cost Estimation
        </h2>
        <div className="rounded-lg border-2 border-dashed border-muted-foreground/25 bg-muted/30 p-10 text-center space-y-4">
          <div className="h-14 w-14 rounded-full bg-primary/10 flex items-center justify-center mx-auto">
            <Clock className="h-7 w-7 text-primary" />
          </div>
          <h3 className="text-base font-semibold text-foreground">
            Waiting for admin cost budgeting…
          </h3>
          <p className="text-sm text-muted-foreground max-w-md mx-auto">
            Your DIS Admin is reviewing your cloud resource configuration and will
            publish a cost estimation once the architecture validation is complete.
          </p>
          <div className="flex items-center justify-center gap-3 pt-2">
            <Badge className="bg-blue-500/10 text-blue-600 border-blue-500/20">
              <Clock className="h-3 w-3 mr-1" /> Awaiting admin action
            </Badge>
          </div>
        </div>
      </div>
    );
  }

  // Published state — show cost data
  const {
    resource_costs = [],
    infra_support_cost = 0,
    total_monthly_cost = 0,
    total_annual_cost = 0,
    currency = "INR",
    notes,
  } = costData;

  const resourceSubtotal = resource_costs.reduce((s, r) => s + (r.monthly_cost || 0), 0);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold flex items-center gap-2">
          <DollarSign className="h-5 w-5 text-primary" /> Cost Estimation
        </h2>
        <Badge className="bg-green-500/10 text-green-600 border-green-500/20 gap-1">
          <CheckCircle2 className="h-3 w-3" /> Cost published
        </Badge>
      </div>

      {/* Cost table (read-only) */}
      <Card>
        <CardContent className="p-4">
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Resource</TableHead>
                  <TableHead className="w-28 text-right">Qty</TableHead>
                  <TableHead className="w-32 text-right">Unit/mo ({currency})</TableHead>
                  <TableHead className="w-32 text-right">Monthly ({currency})</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {resource_costs.map((r, i) => (
                  <TableRow key={i}>
                    <TableCell className="font-medium">{r.resource_name}</TableCell>
                    <TableCell className="text-right">{r.quantity}</TableCell>
                    <TableCell className="text-right font-mono text-xs">
                      {(r.unit_cost || 0).toLocaleString("en-IN")}
                    </TableCell>
                    <TableCell className="text-right font-mono text-xs">
                      {(r.monthly_cost || 0).toLocaleString("en-IN")}
                    </TableCell>
                  </TableRow>
                ))}
                {resource_costs.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={4} className="text-center text-muted-foreground text-sm py-6">
                      No resource costs.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Summary cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        <Card>
          <CardContent className="p-4 text-center">
            <p className="text-xs text-muted-foreground mb-1">Resources (monthly)</p>
            <p className="text-lg font-semibold font-mono">{currency} {resourceSubtotal.toLocaleString("en-IN")}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <p className="text-xs text-muted-foreground mb-1">Infra Support (monthly)</p>
            <p className="text-lg font-semibold font-mono">{currency} {infra_support_cost.toLocaleString("en-IN")}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <p className="text-xs text-muted-foreground mb-1">Total Annual</p>
            <p className="text-lg font-semibold font-mono">{currency} {total_annual_cost.toLocaleString("en-IN")}</p>
          </CardContent>
        </Card>
      </div>

      {/* Total monthly highlight */}
      <div className="rounded-lg bg-primary/5 border border-primary/20 p-4 flex items-center gap-3">
        <DollarSign className="h-6 w-6 text-primary" />
        <div>
          <p className="text-xs text-muted-foreground">Total monthly run-rate</p>
          <p className="text-xl font-bold font-mono text-primary">
            {currency} {total_monthly_cost.toLocaleString("en-IN")}
          </p>
        </div>
      </div>

      {notes && (
        <div className="rounded border p-3">
          <p className="text-xs text-muted-foreground mb-1">Notes from Admin</p>
          <p className="text-sm whitespace-pre-wrap">{notes}</p>
        </div>
      )}
    </div>
  );
};

export default StepCostEstimation;
