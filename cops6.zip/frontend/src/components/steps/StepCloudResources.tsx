import { useState, useEffect, useRef } from "react";
import { type CloudResourceBucket, type CloudResource } from "@/types/onboarding";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Bot, Send, CheckCircle2, Sparkles, Trash2, Plus, User, Loader2, Package, Pencil, X, RotateCcw
} from "lucide-react";
import { toast } from "@/hooks/use-toast";
import {
  chatCloudResources,
  getCloudResourceBucket,
  type ApiChatMessage,
  type ApiProposedResource,
} from "@/lib/api";

interface Props {
  data: CloudResourceBucket[];
  provider: string;
  onboardingId: string;
  onChange: (data: CloudResourceBucket[]) => void;
}

interface Message {
  role: "user" | "model";
  text: string;
}

export const StepCloudResources = ({ data, provider = "AWS", onboardingId, onChange }: Props) => {

  const getBucket = (): CloudResourceBucket =>
    data.find((b) => b.provider === provider) || { provider, resources: [] };

  const updateBucket = (resources: CloudResource[]) => {
    const existing = data.filter((b) => b.provider !== provider);
    onChange([...existing, { provider, resources }]);
  };

  // ── Chat state ────────────────────────────────────────────────────────────
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "model",
      text: `Hello! I'm your AI Cloud Solution Architect specialising in **${provider}**. Describe your workload and I'll help you design the right resource configuration. What are you building?`,
    },
  ]);
  const [inputText, setInputText] = useState("");
  const [isChatLoading, setIsChatLoading] = useState(false);
  const [proposedResources, setProposedResources] = useState<ApiProposedResource[]>([]);
  const [showClearChat, setShowClearChat] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  // ── Manual add state ──────────────────────────────────────────────────────
  const [manualService, setManualService] = useState("");
  const [manualConfig, setManualConfig] = useState("");
  const [manualCount, setManualCount] = useState(1);

  // ── Inline edit state ──────────────────────────────────────────────────────
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editService, setEditService] = useState("");
  const [editCount, setEditCount] = useState(1);
  const [editConfig, setEditConfig] = useState("");

  const startEdit = (r: CloudResource) => {
    setEditingId(r.id);
    setEditService(r.service);
    setEditCount(r.count);
    setEditConfig(r.configDetails);
  };

  const saveEdit = () => {
    if (!editingId) return;
    const bucket = getBucket();
    updateBucket(bucket.resources.map(r => 
      r.id === editingId 
        ? { ...r, service: editService, count: editCount, configDetails: editConfig } 
        : r
    ));
    setEditingId(null);
  };

  const cancelEdit = () => setEditingId(null);

  // ── Load existing bucket from API on mount ────────────────────────────────
  useEffect(() => {
    if (!onboardingId) return;
    getCloudResourceBucket(onboardingId)
      .then((bucket) => {
        if (bucket.resources.length > 0) {
          updateBucket(
            bucket.resources.map((r) => ({
              id: crypto.randomUUID(),
              service: r.service,
              count: r.count,
              configDetails: r.configDetails,
            }))
          );
        }
      })
      .catch(() => {
        // 404 is expected for new onboardings — bucket not yet created
      });
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [onboardingId]);

  // Auto-scroll chat
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isChatLoading]);

  // ── Chat send ─────────────────────────────────────────────────────────────
  const sendMessage = async () => {
    const text = inputText.trim();
    if (!text || isChatLoading) return;

    const userMessage: Message = { role: "user", text };
    const updatedMessages = [...messages, userMessage];
    setMessages(updatedMessages);
    setInputText("");
    setIsChatLoading(true);
    setProposedResources([]);

    try {
      const history: ApiChatMessage[] = updatedMessages.slice(0, -1).map((m) => ({
        role: m.role,
        text: m.text,
      }));

      const response = await chatCloudResources({ provider, message: text, history });

      setMessages((prev) => [...prev, { role: "model", text: response.reply }]);

      if (response.proposed_resources.length > 0) {
        setProposedResources(response.proposed_resources);
      }
    } catch (err) {
      setMessages((prev) => [
        ...prev,
        { role: "model", text: "Sorry, I encountered an error. Please try again." },
      ]);
      toast({ title: "Error", description: "Failed to reach the AI architect.", variant: "destructive" });
    } finally {
      setIsChatLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  // ── Approve proposed resources (append, don't replace) ───────────────────
  const approveResources = () => {
    const bucket = getBucket();
    const newResources: CloudResource[] = proposedResources.map((r) => ({
      id: crypto.randomUUID(),
      service: r.service,
      count: r.count,
      configDetails: r.configDetails,
    }));
    updateBucket([...bucket.resources, ...newResources]);
    setProposedResources([]);
    setShowClearChat(true);
    toast({
      title: "Bucket Approved",
      description: `${newResources.length} resources added to the ${provider} bucket.`,
    });
  };

  // ── Clear chat and start fresh ────────────────────────────────────────────
  const clearChat = () => {
    setMessages([
      {
        role: "model",
        text: `Chat cleared! I'm ready for a new conversation. Describe your next workload for **${provider}** and I'll help you design the resources.`,
      },
    ]);
    setProposedResources([]);
    setShowClearChat(false);
    setInputText("");
  };

  // ── Manual add ───────────────────────────────────────────────────────────
  const addManualResource = () => {
    if (!manualService.trim()) {
      toast({ title: "Resource name required", variant: "destructive" });
      return;
    }
    const bucket = getBucket();
    const newResource: CloudResource = {
      id: crypto.randomUUID(),
      service: manualService.trim(),
      count: manualCount,
      configDetails: manualConfig.trim(),
    };
    updateBucket([...bucket.resources, newResource]);
    setManualService("");
    setManualConfig("");
    setManualCount(1);
  };

  // ── Remove resource ───────────────────────────────────────────────────────
  const removeResource = (id: string) => {
    const bucket = getBucket();
    updateBucket(bucket.resources.filter((r) => r.id !== id));
  };

  const bucket = getBucket();

  if (!provider) {
    return (
      <div className="text-center py-12 text-muted-foreground">
        <p>Please select a Cloud Provider in the previous step.</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 h-[600px]">

      {/* ── LEFT: Chat Panel ──────────────────────────────────────────── */}
      <div className="flex flex-col border rounded-xl bg-muted/20 overflow-hidden">
        {/* Chat header */}
        <div className="flex items-center justify-between px-4 py-3 border-b bg-background">
          <div className="flex items-center gap-2">
            <Bot className="h-5 w-5 text-primary" />
            <span className="font-semibold text-sm">AI Cloud Architect</span>
          </div>
          <div className="flex items-center gap-2">
            {showClearChat && (
              <Button variant="ghost" size="sm" onClick={clearChat} className="h-7 text-xs gap-1 text-muted-foreground hover:text-foreground">
                <RotateCcw className="h-3 w-3" /> New Chat
              </Button>
            )}
            <Badge variant="outline" className="gap-1 text-xs">
              <Sparkles className="h-3 w-3" />{provider}
            </Badge>
          </div>
        </div>

        {/* Messages */}
        <ScrollArea className="flex-1 px-4 py-3">
          <div className="space-y-4">
            {messages.map((msg, idx) => (
              <div
                key={idx}
                className={`flex gap-3 ${
                  msg.role === "user" ? "flex-row-reverse" : "flex-row"
                }`}
              >
                <div
                  className={`h-8 w-8 rounded-full flex items-center justify-center shrink-0 ${
                    msg.role === "user"
                      ? "bg-primary text-primary-foreground"
                      : "bg-muted border"
                  }`}
                >
                  {msg.role === "user" ? (
                    <User className="h-4 w-4" />
                  ) : (
                    <Bot className="h-4 w-4 text-primary" />
                  )}
                </div>
                <div
                  className={`max-w-[80%] rounded-xl px-4 py-2.5 text-sm leading-relaxed ${
                    msg.role === "user"
                      ? "bg-primary text-primary-foreground rounded-tr-none"
                      : "bg-background border rounded-tl-none"
                  }`}
                >
                  {msg.text}
                </div>
              </div>
            ))}

            {/* Loading bubble */}
            {isChatLoading && (
              <div className="flex gap-3">
                <div className="h-8 w-8 rounded-full flex items-center justify-center bg-muted border shrink-0">
                  <Bot className="h-4 w-4 text-primary" />
                </div>
                <div className="bg-background border rounded-xl rounded-tl-none px-4 py-2.5 flex items-center gap-2">
                  <Loader2 className="h-4 w-4 animate-spin text-primary" />
                  <span className="text-sm text-muted-foreground">Thinking...</span>
                </div>
              </div>
            )}

            {/* Proposed resources inline */}
            {proposedResources.length > 0 && !isChatLoading && (
              <div className="border rounded-xl bg-primary/5 border-primary/20 p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <p className="text-sm font-semibold text-primary flex items-center gap-1.5">
                    <Sparkles className="h-4 w-4" /> Proposed Resource Bucket
                  </p>
                  <Button size="sm" onClick={approveResources} className="h-7 text-xs gap-1">
                    <CheckCircle2 className="h-3.5 w-3.5" /> Approve All
                  </Button>
                </div>
                <div className="grid grid-cols-1 gap-2">
                  {proposedResources.map((r, i) => (
                    <div key={i} className="flex items-center justify-between bg-background rounded-lg border px-3 py-2">
                      <div>
                        <p className="text-sm font-medium">{r.service}</p>
                        <p className="text-xs text-muted-foreground">{r.configDetails}</p>
                      </div>
                      <Badge variant="secondary">x{r.count}</Badge>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div ref={chatEndRef} />
          </div>
        </ScrollArea>

        {/* Input */}
        <div className="px-4 py-3 border-t bg-background flex gap-2">
          <Textarea
            placeholder="Describe your workload or ask a follow-up..."
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            onKeyDown={handleKeyDown}
            rows={2}
            className="resize-none text-sm flex-1"
            disabled={isChatLoading}
          />
          <Button
            onClick={sendMessage}
            disabled={isChatLoading || !inputText.trim()}
            className="self-end h-10 w-10 p-0 gradient-primary"
          >
            {isChatLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
          </Button>
        </div>
      </div>

      {/* ── RIGHT: Resource Bucket Panel ──────────────────────────────── */}
      <div className="flex flex-col gap-4 overflow-hidden">

        {/* Approved bucket table */}
        <div className="flex-1 border rounded-xl overflow-hidden flex flex-col">
          <div className="flex items-center justify-between px-4 py-3 border-b bg-background">
            <div className="flex items-center gap-2">
              <Package className="h-5 w-5 text-primary" />
              <span className="font-semibold text-sm">Approved Bucket — {provider}</span>
            </div>
            <Badge variant="outline">{bucket.resources.length} resource(s)</Badge>
          </div>
          <ScrollArea className="flex-1">
            <Table>
              <TableHeader>
                <TableRow className="bg-muted/50">
                  <TableHead>Service</TableHead>
                  <TableHead className="w-[70px] text-center">Count</TableHead>
                  <TableHead>Config Details</TableHead>
                  <TableHead className="w-[50px]"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {bucket.resources.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={4} className="text-center text-muted-foreground py-8 text-sm">
                      No resources yet. Approve a proposal or add manually below.
                    </TableCell>
                  </TableRow>
                ) : (
                  bucket.resources.map((res) => (
                    editingId === res.id ? (
                      <TableRow key={res.id}>
                        <TableCell><Input value={editService} onChange={e => setEditService(e.target.value)} className="h-8 text-sm w-full" /></TableCell>
                        <TableCell><Input type="number" value={editCount} onChange={e => setEditCount(parseInt(e.target.value) || 1)} className="h-8 text-sm text-center w-[60px]" /></TableCell>
                        <TableCell><Input value={editConfig} onChange={e => setEditConfig(e.target.value)} className="h-8 text-sm w-full" /></TableCell>
                        <TableCell>
                          <div className="flex items-center gap-1">
                            <Button variant="ghost" size="icon" onClick={saveEdit} className="h-8 w-8 text-green-600 hover:text-green-700 hover:bg-green-50"><CheckCircle2 className="h-4 w-4" /></Button>
                            <Button variant="ghost" size="icon" onClick={cancelEdit} className="h-8 w-8 hover:bg-muted"><X className="h-4 w-4" /></Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ) : (
                      <TableRow key={res.id}>
                        <TableCell className="font-medium text-sm">{res.service}</TableCell>
                        <TableCell className="text-center">{res.count}</TableCell>
                        <TableCell className="text-sm text-muted-foreground">{res.configDetails}</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-1 justify-end">
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => startEdit(res)}
                              className="h-8 w-8 text-muted-foreground hover:text-foreground"
                            >
                              <Pencil className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => removeResource(res.id)}
                              className="text-destructive hover:text-destructive h-8 w-8"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    )
                  ))
                )}
              </TableBody>
            </Table>
          </ScrollArea>
        </div>

        {/* Manual add */}
        <div className="border rounded-xl p-4 bg-muted/10 space-y-3">
          <p className="text-sm font-semibold flex items-center gap-2">
            <Plus className="h-4 w-4 text-primary" /> Add Resource Manually
          </p>
          <div className="grid grid-cols-[1fr_70px] gap-2">
            <Input
              placeholder="Service name (e.g. AWS EKS, Azure Blob)..."
              value={manualService}
              onChange={(e) => setManualService(e.target.value)}
              className="text-sm"
            />
            <Input
              type="number"
              min={1}
              value={manualCount}
              onChange={(e) => setManualCount(parseInt(e.target.value) || 1)}
              className="text-sm"
            />
          </div>
          <Input
            placeholder="Configuration details (e.g. t3.medium, Multi-AZ, 100GB SSD)..."
            value={manualConfig}
            onChange={(e) => setManualConfig(e.target.value)}
            className="text-sm"
          />
          <Button variant="outline" size="sm" onClick={addManualResource} className="w-full">
            <Plus className="h-4 w-4 mr-1" /> Add to Bucket
          </Button>
        </div>
      </div>
    </div>
  );
};
