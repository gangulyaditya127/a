import { useState, useEffect, useRef } from "react";
import { type ArchitectureOverview } from "@/types/onboarding";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Upload,
  Cpu,
  ShieldAlert,
  ShieldCheck,
  FileImage,
  Loader2,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  Info,
} from "lucide-react";
import { toast } from "@/hooks/use-toast";
import {
  uploadArchitectureDiagram,
  validateArchitecture,
  getArchitectureValidation,
  type ApiValidationViolation,
} from "@/lib/api";

interface Props {
  data: ArchitectureOverview;
  onboardingId: string;
  onChange: (data: ArchitectureOverview) => void;
}

const SEVERITY_CONFIG: Record<string, { color: string; bg: string; border: string; icon: typeof AlertTriangle }> = {
  CRITICAL: { color: "text-red-700", bg: "bg-red-50", border: "border-red-200", icon: XCircle },
  HIGH: { color: "text-orange-700", bg: "bg-orange-50", border: "border-orange-200", icon: AlertTriangle },
  MEDIUM: { color: "text-amber-700", bg: "bg-amber-50", border: "border-amber-200", icon: Info },
  LOW: { color: "text-blue-700", bg: "bg-blue-50", border: "border-blue-200", icon: Info },
};

export const StepArchitectureOverview = ({ data, onboardingId, onChange }: Props) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [isValidating, setIsValidating] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [violations, setViolations] = useState<ApiValidationViolation[]>([]);
  const [verdict, setVerdict] = useState<string | null>(null);
  const [validatedAt, setValidatedAt] = useState<string | null>(null);
  const [imageKey, setImageKey] = useState(Date.now()); // cache-busting for image preview

  // ── Load existing validation from DB on mount ──────────────────────
  useEffect(() => {
    if (!onboardingId) { setIsLoading(false); return; }
    getArchitectureValidation(onboardingId)
      .then((res) => {
        onChange({
          ...data,
          uploadedDiagram: res.image_filename,
          securityViolations: res.violations.map((v) => v.finding),
          analysisComplete: !!res.verdict,
        });
        setViolations(res.violations);
        setVerdict(res.verdict);
        setValidatedAt(res.validated_at);
        setImageKey(Date.now());
      })
      .catch(() => {
        // 404 is expected for new onboardings
      })
      .finally(() => setIsLoading(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [onboardingId]);

  // ── Upload handler ─────────────────────────────────────────────────
  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !onboardingId) return;

    setIsUploading(true);
    try {
      const res = await uploadArchitectureDiagram(onboardingId, file);
      onChange({
        ...data,
        uploadedDiagram: res.image_filename,
        analysisComplete: false,
        securityViolations: [],
        revisedDiagram: null,
      });
      setViolations([]);
      setVerdict(null);
      setValidatedAt(null);
      setImageKey(Date.now());
      toast({ title: "Diagram Uploaded", description: `${res.image_filename} uploaded successfully.` });
    } catch {
      toast({ title: "Upload Failed", description: "Could not upload the diagram.", variant: "destructive" });
    } finally {
      setIsUploading(false);
      // Reset input so re-uploading the same file triggers onChange
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  };

  // ── Validate handler ───────────────────────────────────────────────
  const handleValidate = async () => {
    if (!onboardingId) return;
    setIsValidating(true);
    try {
      const res = await validateArchitecture(onboardingId);
      setVerdict(res.verdict);
      setViolations(res.violations);
      setValidatedAt(res.validated_at);
      onChange({
        ...data,
        analysisComplete: true,
        securityViolations: res.violations.map((v) => v.finding),
      });
      toast({
        title: "Validation Complete",
        description: res.verdict === "not_a_diagram"
          ? "The image is not a valid cloud architecture diagram."
          : res.verdict === "valid"
          ? "Architecture passed all rule checks!"
          : `Found ${res.violations.length} violation(s).`,
      });
    } catch {
      toast({ title: "Validation Failed", description: "Could not validate the architecture.", variant: "destructive" });
    } finally {
      setIsValidating(false);
    }
  };

  // ── Severity badge helper ──────────────────────────────────────────
  const SeverityBadge = ({ severity }: { severity: string }) => {
    const upper = severity.toUpperCase();
    const variant = upper === "CRITICAL" ? "destructive" : "secondary";
    return <Badge variant={variant} className="text-xs font-mono">{upper}</Badge>;
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-16">
        <Loader2 className="h-6 w-6 animate-spin text-primary mr-2" />
        <span className="text-muted-foreground">Loading architecture data...</span>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Hidden file input */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/png,image/jpeg,image/svg+xml,image/webp,application/pdf"
        className="hidden"
        onChange={handleFileSelect}
      />

      {/* Upload or Generate */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Upload card */}
        <div
          className="border-2 border-dashed rounded-lg p-8 text-center hover:border-primary/50 transition-colors cursor-pointer group"
          onClick={() => !isUploading && fileInputRef.current?.click()}
        >
          {isUploading ? (
            <Loader2 className="h-10 w-10 mx-auto text-primary mb-3 animate-spin" />
          ) : (
            <Upload className="h-10 w-10 mx-auto text-muted-foreground mb-3 group-hover:text-primary transition-colors" />
          )}
          <p className="font-medium">
            {data.uploadedDiagram ? "Re-upload Architecture Diagram" : "Upload Architecture Diagram"}
          </p>
          <p className="text-sm text-muted-foreground mt-1">
            Click to upload (.png, .jpg, .svg, .pdf)
          </p>
          {data.uploadedDiagram && (
            <Badge className="mt-3" variant="secondary">
              <CheckCircle2 className="h-3 w-3 mr-1" /> {data.uploadedDiagram}
            </Badge>
          )}
        </div>

        {/* Generate from Bucket card — DISABLED / Coming Soon */}
        <div className="border-2 border-dashed rounded-lg p-8 text-center opacity-50 cursor-not-allowed relative">
          <div className="absolute top-2 right-2">
            <Badge variant="outline" className="text-xs">Coming Soon</Badge>
          </div>
          <Cpu className="h-10 w-10 mx-auto text-muted-foreground mb-3" />
          <p className="font-medium">Generate from Resource Bucket</p>
          <p className="text-sm text-muted-foreground mt-1">
            Auto-generate architecture from your configured resources
          </p>
        </div>
      </div>

      {/* Image Preview */}
      {data.uploadedDiagram && (
        <div className="border rounded-lg p-4 bg-muted/20">
          <h4 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3 flex items-center gap-2">
            <FileImage className="h-4 w-4" /> Uploaded Diagram
          </h4>
          <div className="rounded-lg overflow-hidden border bg-white">
            <img
              key={imageKey}
              src={`/api/architecture-validation/${onboardingId}/image?t=${imageKey}`}
              alt={data.uploadedDiagram}
              className="w-full h-auto max-h-[500px] object-contain"
              onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }}
            />
          </div>
          <p className="text-xs text-muted-foreground mt-2">{data.uploadedDiagram}</p>
        </div>
      )}

      {/* Validate button — appears after upload */}
      {data.uploadedDiagram && (
        <div className="flex items-center justify-between border rounded-lg p-4 bg-muted/30">
          <div className="flex items-center gap-3">
            <FileImage className="h-5 w-5 text-primary" />
            <div>
              <p className="text-sm font-medium">Diagram ready for validation</p>
              <p className="text-xs text-muted-foreground">{data.uploadedDiagram}</p>
            </div>
          </div>
          <Button
            onClick={handleValidate}
            disabled={isValidating}
            className="gradient-primary text-primary-foreground"
          >
            {isValidating ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                Validating...
              </>
            ) : verdict ? (
              "Re-validate"
            ) : (
              "Validate Architecture"
            )}
          </Button>
        </div>
      )}

      {/* Verdict & Violations */}
      {verdict && (
        <div className="space-y-4">
          {/* Verdict banner */}
          {verdict === "not_a_diagram" ? (
            <div className="flex items-center gap-3 p-4 bg-purple-50 border border-purple-200 rounded-lg">
              <XCircle className="h-6 w-6 text-purple-600 shrink-0" />
              <div>
                <p className="font-semibold text-purple-800">Not a Cloud Architecture Diagram</p>
                <p className="text-sm text-purple-700">
                  The uploaded image was not recognized as a valid cloud architecture diagram.
                  Please upload an actual architecture diagram and try again.
                  {validatedAt && <> Checked at {new Date(validatedAt).toLocaleString()}</>}
                </p>
              </div>
            </div>
          ) : verdict === "valid" ? (
            <div className="flex items-center gap-3 p-4 bg-green-50 border border-green-200 rounded-lg">
              <ShieldCheck className="h-6 w-6 text-green-600 shrink-0" />
              <div>
                <p className="font-semibold text-green-800">Architecture Validated — No Violations</p>
                <p className="text-sm text-green-700">
                  Your cloud architecture diagram passes all configured security and compliance rules.
                  {validatedAt && <> Validated at {new Date(validatedAt).toLocaleString()}</>}
                </p>
              </div>
            </div>
          ) : (
            <div className="flex items-center gap-3 p-4 bg-red-50 border border-red-200 rounded-lg">
              <ShieldAlert className="h-6 w-6 text-red-600 shrink-0" />
              <div>
                <p className="font-semibold text-red-800">
                  Architecture Invalid — {violations.length} Violation{violations.length !== 1 && "s"} Found
                </p>
                <p className="text-sm text-red-700">
                  Review the findings below and update your architecture accordingly.
                  {validatedAt && <> Validated at {new Date(validatedAt).toLocaleString()}</>}
                </p>
              </div>
            </div>
          )}

          {/* Violations list */}
          {violations.length > 0 && (
            <div className="space-y-3">
              <h4 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">
                Violations
              </h4>
              {violations.map((v, idx) => {
                const sev = v.severity?.toUpperCase() || "HIGH";
                const cfg = SEVERITY_CONFIG[sev] || SEVERITY_CONFIG.HIGH;
                const IconComp = cfg.icon;
                return (
                  <div
                    key={idx}
                    className={`flex items-start gap-3 p-4 rounded-lg border ${cfg.bg} ${cfg.border}`}
                  >
                    <IconComp className={`h-5 w-5 ${cfg.color} mt-0.5 shrink-0`} />
                    <div className="flex-1 min-w-0 space-y-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <SeverityBadge severity={sev} />
                        <Badge variant="outline" className="text-xs">{v.category}</Badge>
                      </div>
                      <p className="text-sm font-medium">{v.finding}</p>
                      <p className="text-xs text-muted-foreground">Rule: {v.rule_text}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
