import { useState, useEffect } from "react";
import { type Recommendation } from "@/types/onboarding";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Copy, FileText, ShieldCheck, ClipboardList, Clock, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "@/hooks/use-toast";
import {
  fetchUserRecommendations,
  type ApiRecommendation,
  type ApiRecommendationsResponse,
} from "@/lib/api";

interface Props {
  data: Recommendation[];
  solutionType: string;
  onChange: (data: Recommendation[]) => void;
  onboardingId?: string;
}

interface DetailedRecommendation {
  id: string;
  category: "gps" | "rfc" | "approval";
  title: string;
  summary: string;
  parameters: { label: string; value: string }[];
  copyText: string;
}

// ── Static fallback recommendations ──────────────────────────────────
// These are shown only when the backend has no admin-generated recommendations.
const generateStaticRecommendations = (solutionType: string): DetailedRecommendation[] => {
  const recs: DetailedRecommendation[] = [
    {
      id: "gps-1", category: "gps",
      title: "GPS – Cloud Infrastructure Provisioning",
      summary: "Raise a GPS request for compute, storage, and networking resources required for the project environment.",
      parameters: [
        { label: "GPS Category", value: "Cloud Infrastructure – IaaS Provisioning" },
        { label: "Request Type", value: "New Resource Provisioning" },
        { label: "Priority", value: "High" },
        { label: "Approval Chain", value: "Project Manager → Delivery Head → ISM → DIS CloudOps" },
        { label: "SLA", value: "5 business days post-approval" },
      ],
      copyText: `GPS Request: Cloud Infrastructure Provisioning\nCategory: Cloud Infrastructure – IaaS Provisioning\nRequest Type: New Resource Provisioning\nPriority: High`,
    },
    {
      id: "rfc-1", category: "rfc",
      title: "RFC – Active Directory Group Creation",
      summary: "Create AD security groups for cloud subscription access, RBAC role assignments, and identity governance.",
      parameters: [
        { label: "RFC Category", value: "Identity & Access Management" },
        { label: "Change Type", value: "Standard Change" },
        { label: "Group Type", value: "Security Group (Mail-enabled optional)" },
        { label: "SLA", value: "3 business days" },
      ],
      copyText: `RFC: Active Directory Group Creation\nCategory: Identity & Access Management\nChange Type: Standard Change`,
    },
    {
      id: "approval-1", category: "approval",
      title: "Architecture Approval from ISM",
      summary: "Submit the finalized architecture diagram and resource plan to the unit ISM for security and compliance validation.",
      parameters: [
        { label: "Submission To", value: "Unit Information Security Manager (ISM)" },
        { label: "Artifacts Required", value: "Architecture Diagram, Data Flow Diagram, Security Controls Matrix" },
        { label: "Expected Turnaround", value: "3–5 business days" },
      ],
      copyText: `Approval Request: Architecture Validation\nSubmit To: Unit ISM`,
    },
  ];

  if (solutionType === "generative-ai") {
    recs.push({
      id: "approval-2", category: "approval",
      title: "Legal Approval for LLM Usage",
      summary: "Obtain legal clearance for using non-TCS-approved LLM models, including IP and licensing review.",
      parameters: [
        { label: "Submission To", value: "Legal & Compliance Team" },
        { label: "Review Criteria", value: "IP ownership, data residency, model licensing, output liability" },
        { label: "Expected Turnaround", value: "5–7 business days" },
      ],
      copyText: `Approval Request: LLM Legal Clearance\nSubmit To: Legal & Compliance Team`,
    });
  }

  return recs;
};

// ── Convert backend API recommendations to the display format ────────
const apiToDetailed = (recs: ApiRecommendation[]): DetailedRecommendation[] =>
  recs.map((r) => ({
    id: r.id,
    category: r.category as "gps" | "rfc" | "approval",
    title: r.title,
    summary: r.summary,
    parameters: r.parameters ?? [],
    copyText: r.copy_text ?? "",
  }));

const categoryIcon = (cat: string) => {
  switch (cat) {
    case "gps": return <ClipboardList className="h-4 w-4" />;
    case "rfc": return <FileText className="h-4 w-4" />;
    case "approval": return <ShieldCheck className="h-4 w-4" />;
    default: return null;
  }
};

export const StepRecommendations = ({ data, solutionType, onChange, onboardingId }: Props) => {
  const [activeTab, setActiveTab] = useState("gps");
  const [detailedRecs, setDetailedRecs] = useState<DetailedRecommendation[]>([]);
  const [loading, setLoading] = useState(true);
  const [isPending, setIsPending] = useState(false);
  const [isFromAdmin, setIsFromAdmin] = useState(false);

  useEffect(() => {
    if (!onboardingId) {
      // No onboarding ID — use static fallback
      const staticRecs = generateStaticRecommendations(solutionType);
      setDetailedRecs(staticRecs);
      syncBasicState(staticRecs);
      setLoading(false);
      return;
    }

    setLoading(true);
    fetchUserRecommendations(onboardingId)
      .then((res: ApiRecommendationsResponse) => {
        if (res.status === "published" && res.recommendations.length > 0) {
          // Real admin-generated recommendations
          const detailed = apiToDetailed(res.recommendations);
          setDetailedRecs(detailed);
          setIsFromAdmin(true);
          setIsPending(false);
          syncBasicState(detailed);
        } else {
          // Admin hasn't sent recommendations yet
          setIsPending(true);
          setIsFromAdmin(false);
          // Show static fallback for reference
          const staticRecs = generateStaticRecommendations(solutionType);
          setDetailedRecs(staticRecs);
          syncBasicState(staticRecs);
        }
      })
      .catch(() => {
        // API error — fall back to static
        const staticRecs = generateStaticRecommendations(solutionType);
        setDetailedRecs(staticRecs);
        syncBasicState(staticRecs);
      })
      .finally(() => setLoading(false));
  }, [onboardingId]);

  const syncBasicState = (recs: DetailedRecommendation[]) => {
    if (data.length === 0) {
      const basic: Recommendation[] = recs.map((r) => ({
        id: r.id,
        category: r.category,
        title: r.title,
        description: r.summary,
        status: "recommended" as const,
      }));
      onChange(basic);
    }
  };

  const copyToClipboard = (text: string, title: string) => {
    navigator.clipboard.writeText(text);
    toast({ title: "Copied to Clipboard", description: `"${title}" details copied. Paste it into your GPS/RFC portal.` });
  };

  const filterByCategory = (cat: string) => detailedRecs.filter((r) => r.category === cat);

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-16 gap-3">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
        <p className="text-sm text-muted-foreground">Loading recommendations…</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Status banner */}
      {isPending ? (
        <div className="bg-amber-500/5 border border-amber-500/20 rounded-lg p-5 text-center space-y-2">
          <Clock className="h-8 w-8 text-amber-500 mx-auto" />
          <h3 className="font-semibold text-lg">Recommendations Pending</h3>
          <p className="text-sm text-muted-foreground max-w-md mx-auto">
            The DIS Admin is reviewing your submission and preparing project-specific recommendations.
            Once generated and sent, they will appear here automatically.
          </p>
          <Badge variant="secondary" className="mt-2">
            Showing default templates below for reference
          </Badge>
        </div>
      ) : isFromAdmin ? (
        <div className="bg-green-500/5 border border-green-500/20 rounded-lg p-4 text-sm text-muted-foreground">
          <strong className="text-foreground">Admin-Generated Recommendations:</strong>{" "}
          The following GPS requests, RFC change requests, and approval items have been prepared by the DIS Admin
          based on your specific project requirements. Copy the details and raise them in your organization's respective portals.
        </div>
      ) : (
        <div className="bg-muted/50 border rounded-lg p-4 text-sm text-muted-foreground">
          <strong className="text-foreground">Default Recommendations:</strong>{" "}
          Based on your project requirements, the following GPS requests, RFC change requests, and approval items are recommended.
          Copy the details and raise them in your organization's respective portals.
        </div>
      )}

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="gps" className="gap-1.5"><ClipboardList className="h-3.5 w-3.5" /> GPS Requests ({filterByCategory("gps").length})</TabsTrigger>
          <TabsTrigger value="rfc" className="gap-1.5"><FileText className="h-3.5 w-3.5" /> RFC Change Requests ({filterByCategory("rfc").length})</TabsTrigger>
          <TabsTrigger value="approval" className="gap-1.5"><ShieldCheck className="h-3.5 w-3.5" /> Approval Checklist ({filterByCategory("approval").length})</TabsTrigger>
        </TabsList>

        {["gps", "rfc", "approval"].map((cat) => (
          <TabsContent key={cat} value={cat} className="space-y-4 mt-4">
            {filterByCategory(cat).length === 0 ? (
              <div className="text-center py-8 text-sm text-muted-foreground">
                No {cat.toUpperCase()} recommendations {isPending ? "yet" : "for this project"}.
              </div>
            ) : (
              filterByCategory(cat).map((rec) => (
                <div key={rec.id} className="border rounded-lg overflow-hidden">
                  <div className="flex items-center justify-between p-4 bg-muted/30 border-b">
                    <div className="flex items-center gap-2">
                      {categoryIcon(rec.category)}
                      <span className="font-semibold">{rec.title}</span>
                      <Badge variant="secondary" className="text-xs">
                        {isFromAdmin ? "Admin Prepared" : isPending ? "Template" : "AI Recommended"}
                      </Badge>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => copyToClipboard(rec.copyText, rec.title)}
                      className="gap-1.5"
                    >
                      <Copy className="h-3.5 w-3.5" /> Copy for Portal
                    </Button>
                  </div>
                  <div className="p-4 space-y-3">
                    <p className="text-sm text-muted-foreground">{rec.summary}</p>
                    {rec.parameters.length > 0 && (
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                        {rec.parameters.map((param, idx) => (
                          <div key={idx} className="flex flex-col gap-0.5 p-2 bg-muted/20 rounded text-sm">
                            <span className="text-xs font-medium text-muted-foreground uppercase tracking-wide">{param.label}</span>
                            <span className="text-foreground">{param.value}</span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              ))
            )}
          </TabsContent>
        ))}
      </Tabs>

      {solutionType === "generative-ai" && (
        <div className="bg-warning/5 border border-warning/20 rounded-lg p-4 text-sm">
          <strong>GenAI Note:</strong> Additional approvals from Legal and Data Privacy teams are required for Generative AI projects. These have been included in the Approval Checklist tab.
        </div>
      )}
    </div>
  );
};
