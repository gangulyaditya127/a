"""API router for the cloud resources domain."""

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.domains.cloud_resources import service
from app.domains.cloud_resources.schemas import (
    BucketResponse,
    BucketUpsert,
    ChatRequest,
    ChatResponse,
)

router = APIRouter()


@router.post("/chat", response_model=ChatResponse)
def chat_with_architect(request: ChatRequest) -> ChatResponse:
    """Run a conversational turn with the AI Cloud Architect.

    The LLM may return proposed resources embedded in a ```json block.
    The endpoint parses and returns them separately from the reply text.
    """
    try:
        return service.chat(request)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@router.get("/{onboarding_id}/bucket", response_model=BucketResponse)
def get_bucket(
    onboarding_id: str,
    db: Session = Depends(get_db),
) -> BucketResponse:
    """Retrieve the approved cloud resource bucket for an onboarding."""
    bucket = service.get_bucket(db, onboarding_id)
    if bucket is None:
        raise HTTPException(status_code=404, detail="Cloud resource bucket not found")
    return bucket


@router.put("/{onboarding_id}/bucket", response_model=BucketResponse)
def upsert_bucket(
    onboarding_id: str,
    data: BucketUpsert,
    db: Session = Depends(get_db),
) -> BucketResponse:
    """Create or update the approved cloud resource bucket for an onboarding."""
    return service.upsert_bucket(db, onboarding_id, data)
