"""Auth dependencies for role-based access control."""

from typing import Optional

from fastapi import Depends, HTTPException, Request
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.models.user import User
from app.domains.auth import service


def get_current_user(
    request: Request,
    db: Session = Depends(get_db),
) -> User:
    """Read X-User-Id header and return the corresponding User.

    Raises 401 if header is missing or user not found.
    """
    user_id = request.headers.get("X-User-Id")
    if not user_id:
        raise HTTPException(status_code=401, detail="Missing X-User-Id header")

    user = service.get_user_by_id(db, user_id)
    if user is None:
        raise HTTPException(status_code=401, detail="Invalid user")
    if not user.is_active:
        raise HTTPException(status_code=403, detail="User account is deactivated")

    return user


def get_optional_user(
    request: Request,
    db: Session = Depends(get_db),
) -> Optional[User]:
    """Return the current user if X-User-Id header is present, else None."""
    user_id = request.headers.get("X-User-Id")
    if not user_id:
        return None
    return service.get_user_by_id(db, user_id)


def require_admin(
    user: User = Depends(get_current_user),
) -> User:
    """Ensure the current user has admin or superadmin role."""
    if user.role.lower() not in ("admin", "superadmin"):
        raise HTTPException(status_code=403, detail="Admin access required")
    return user


def require_superadmin(
    user: User = Depends(get_current_user),
) -> User:
    """Ensure the current user has superadmin role."""
    if user.role.lower() != "superadmin":
        raise HTTPException(status_code=403, detail="Superadmin access required")
    return user
