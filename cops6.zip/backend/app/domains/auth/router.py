"""Auth API router — login, user info, user listing."""

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.domains.auth import service
from app.domains.auth.dependencies import get_current_user
from app.domains.auth.schemas import LoginRequest, UserResponse
from app.models.user import User

router = APIRouter()


@router.post("/login", response_model=UserResponse)
def login(
    data: LoginRequest,
    db: Session = Depends(get_db),
) -> UserResponse:
    """Authenticate by email or emp_id. Returns the user object."""
    user: User | None = None

    if data.email:
        user = service.get_user_by_email(db, data.email)
    elif data.emp_id:
        user = service.get_user_by_emp_id(db, data.emp_id)
    else:
        raise HTTPException(status_code=400, detail="Provide email or emp_id")

    if user is None:
        raise HTTPException(status_code=404, detail="User not found")
    if not user.is_active:
        raise HTTPException(status_code=403, detail="User account is deactivated")

    return user


@router.get("/me", response_model=UserResponse)
def me(
    current_user: User = Depends(get_current_user),
) -> UserResponse:
    """Return the currently authenticated user."""
    return current_user


@router.get("/users", response_model=list[UserResponse])
def list_users(
    db: Session = Depends(get_db),
) -> list[UserResponse]:
    """List all users (dev/testing convenience endpoint)."""
    return service.get_all_users(db)
