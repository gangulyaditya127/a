"""Pydantic schemas for authentication endpoints."""

from datetime import datetime
from typing import Optional

from pydantic import BaseModel, ConfigDict


class LoginRequest(BaseModel):
    """Login via email or emp_id — no password required."""

    email: Optional[str] = None
    emp_id: Optional[str] = None


class UserResponse(BaseModel):
    """Public representation of a user."""

    id: str
    email: str
    name: str
    emp_id: str
    role: str
    is_active: bool
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)
