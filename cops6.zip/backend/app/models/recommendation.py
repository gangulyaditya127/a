"""SQLAlchemy model for recommendations."""

from datetime import datetime
from typing import Optional

from sqlalchemy import JSON, ForeignKey, Text, func
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base


class Recommendation(Base):
    """A GPS, RFC, or approval recommendation generated for an onboarding."""

    __tablename__ = "recommendations"

    id: Mapped[str] = mapped_column(primary_key=True)
    onboarding_id: Mapped[str] = mapped_column(
        ForeignKey("onboardings.id", ondelete="CASCADE"),
    )
    category: Mapped[str] = mapped_column()  # 'gps', 'rfc', 'approval'
    title: Mapped[str] = mapped_column()
    summary: Mapped[str] = mapped_column(Text)
    parameters: Mapped[list] = mapped_column(JSON, default=list)  # [{label, value}]
    copy_text: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    status: Mapped[str] = mapped_column(default="generated")  # 'generated', 'edited', 'sent'
    created_at: Mapped[datetime] = mapped_column(server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(
        server_default=func.now(),
        onupdate=func.now(),
    )
