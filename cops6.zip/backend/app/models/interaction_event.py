"""InteractionEvent model — stores user↔admin activity timeline entries."""

from datetime import datetime, timezone

from sqlalchemy import Column, DateTime, ForeignKey, String, Text
from sqlalchemy.orm import relationship

from app.core.database import Base


class InteractionEvent(Base):
    __tablename__ = "interaction_events"

    id = Column(String, primary_key=True)
    onboarding_id = Column(
        String, ForeignKey("onboardings.id", ondelete="CASCADE"), nullable=False, index=True
    )
    ts = Column(DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)
    actor = Column(String, nullable=False)       # 'user' | 'admin' | 'superadmin' | 'system'
    actor_name = Column(String, nullable=False)
    kind = Column(String, nullable=False)         # 'submission' | 'assignment' | 'comment' | 'decision' | 'publish' | 'status_change' | 'note'
    title = Column(String, nullable=False)
    body = Column(Text, nullable=True)
    scope = Column(String, nullable=True)         # e.g. 'Resource Validation', 'Cost', 'GPS'

    onboarding = relationship("Onboarding", back_populates="interaction_events")
