"""SQLAlchemy model for cost estimations."""

from datetime import datetime
from typing import TYPE_CHECKING, Optional

from sqlalchemy import JSON, Float, ForeignKey, Text, func
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.database import Base

if TYPE_CHECKING:
    from app.models.onboarding import Onboarding


class CostEstimation(Base):
    """Cost estimation for a cloud onboarding, prepared by admin."""

    __tablename__ = "cost_estimations"

    id: Mapped[str] = mapped_column(primary_key=True)
    onboarding_id: Mapped[str] = mapped_column(
        ForeignKey("onboardings.id", ondelete="CASCADE"),
        unique=True,
    )
    admin_id: Mapped[str] = mapped_column(
        ForeignKey("users.id"),
    )
    # JSON array: [{resource_name, unit_cost, quantity, monthly_cost}]
    resource_costs: Mapped[list] = mapped_column(JSON, default=list)
    infra_support_cost: Mapped[float] = mapped_column(Float, default=0.0)
    total_monthly_cost: Mapped[float] = mapped_column(Float, default=0.0)
    total_annual_cost: Mapped[float] = mapped_column(Float, default=0.0)
    currency: Mapped[str] = mapped_column(default="INR")
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(
        server_default=func.now(),
        onupdate=func.now(),
    )

    # Back-reference to parent onboarding
    onboarding: Mapped["Onboarding"] = relationship(
        "Onboarding",
        back_populates="cost_estimation",
    )
