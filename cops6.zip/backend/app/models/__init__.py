"""Shared SQLAlchemy models — the persistence layer.

Both `app.domains` (end-user) and `app.admin` (admin) import from here.
Neither depends on the other.
"""

from app.models.onboarding import (
    DisclaimerClause,
    EligibilityQuestion,
    Onboarding,
)
from app.models.account_details import AccountDetails
from app.models.requirements import RequirementAssessment
from app.models.cloud_resources import CloudResourceBucket
from app.models.architecture_rules import ArchitectureRule
from app.models.architecture_validation import ArchitectureValidation
from app.models.user import User
from app.models.admin_assignment import AdminAssignment
from app.models.validation_feedback import ValidationFeedback
from app.models.cost_estimation import CostEstimation
from app.models.approval_rule import ApprovalRule
from app.models.recommendation import Recommendation
from app.models.interaction_event import InteractionEvent

__all__ = [
    "AccountDetails",
    "AdminAssignment",
    "ApprovalRule",
    "ArchitectureRule",
    "ArchitectureValidation",
    "CloudResourceBucket",
    "CostEstimation",
    "DisclaimerClause",
    "EligibilityQuestion",
    "InteractionEvent",
    "Onboarding",
    "Recommendation",
    "RequirementAssessment",
    "User",
    "ValidationFeedback",
]
