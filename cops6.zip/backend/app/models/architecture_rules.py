"""SQLAlchemy model for architecture validation rules."""

from sqlalchemy import Text
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base


class ArchitectureRule(Base):
    """A single architecture-validation rule scoped to a cloud provider."""

    __tablename__ = "architecture_rules"

    id: Mapped[str] = mapped_column(primary_key=True)
    cloud_provider: Mapped[str] = mapped_column()        # "AWS", "Azure", "GCP"
    category: Mapped[str] = mapped_column()               # e.g. "Network Security"
    rule_text: Mapped[str] = mapped_column(Text)          # the rule description
    severity: Mapped[str] = mapped_column(default="CRITICAL")  # CRITICAL / HIGH / MEDIUM / LOW
