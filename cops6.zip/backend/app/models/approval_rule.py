"""SQLAlchemy model for approval rules."""

from sqlalchemy import Text
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base


class ApprovalRule(Base):
    """Defines an approval step required for cloud provisioning."""

    __tablename__ = "approval_rules"

    id: Mapped[str] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column()  # e.g. 'ISM Approval', 'Data Privacy Approval'
    description: Mapped[str] = mapped_column(Text)
    approver_role: Mapped[str] = mapped_column()  # e.g. 'ISM', 'Legal', 'Data Privacy'
    is_mandatory: Mapped[bool] = mapped_column(default=True)
    applies_to: Mapped[str] = mapped_column(default="all")  # 'all', 'generative-ai', 'non-generative-ai'
    sort_order: Mapped[int] = mapped_column()
