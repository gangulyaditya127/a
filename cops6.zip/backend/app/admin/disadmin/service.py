"""Service layer for DIS Admin operations."""

import json
import uuid

from sqlalchemy.orm import Session, joinedload

from app.core.llm import gemini_invoke
from app.core.logger import get_logger
from app.models.admin_assignment import AdminAssignment
from app.models.approval_rule import ApprovalRule
from app.models.cost_estimation import CostEstimation
from app.models.onboarding import Onboarding
from app.models.recommendation import Recommendation
from app.models.user import User
from app.models.validation_feedback import ValidationFeedback
from app.models.interaction_event import InteractionEvent
from app.admin.disadmin.schemas import (
    CostEstimationUpsert,
    FeedbackCreate,
    RecommendationUpdate,
)

logger = get_logger(__name__)


# ── Helpers ──────────────────────────────────────────────────────────────────

def _log_event(
    db: Session,
    onboarding_id: str,
    actor: str,
    actor_name: str,
    kind: str,
    title: str,
    body: str | None = None,
    scope: str | None = None,
) -> InteractionEvent:
    """Append an interaction event to the onboarding's activity timeline."""
    event = InteractionEvent(
        id=str(uuid.uuid4()),
        onboarding_id=onboarding_id,
        actor=actor,
        actor_name=actor_name,
        kind=kind,
        title=title,
        body=body,
        scope=scope,
    )
    db.add(event)
    return event


def _load_onboarding(db: Session, onboarding_id: str) -> Onboarding:
    """Load an onboarding with all eager-loaded relationships."""
    ob = (
        db.query(Onboarding)
        .options(
            joinedload(Onboarding.account_details),
            joinedload(Onboarding.requirement_assessment),
            joinedload(Onboarding.cloud_resource_bucket),
            joinedload(Onboarding.architecture_validation),
            joinedload(Onboarding.admin_assignment),
            joinedload(Onboarding.validation_feedbacks),
            joinedload(Onboarding.cost_estimation),
            joinedload(Onboarding.recommendations),
            joinedload(Onboarding.interaction_events),
        )
        .filter(Onboarding.id == onboarding_id)
        .first()
    )
    return ob


def _is_assigned_to_admin(ob: Onboarding, admin: User) -> bool:
    """Check whether the onboarding is assigned to this admin."""
    if admin.role == "superadmin":
        return True
    return ob.admin_assignment is not None and ob.admin_assignment.admin_id == admin.id


# ── Dashboard ────────────────────────────────────────────────────────────────

def get_dashboard(
    db: Session,
    admin: User,
    status: str | None = None,
    search: str | None = None,
) -> dict:
    """Return dashboard data: stats + onboardings assigned to this admin."""
    query = (
        db.query(Onboarding)
        .join(AdminAssignment, AdminAssignment.onboarding_id == Onboarding.id)
        .options(
            joinedload(Onboarding.account_details),
            joinedload(Onboarding.requirement_assessment),
            joinedload(Onboarding.admin_assignment),
        )
        .filter(AdminAssignment.admin_id == admin.id)
        .filter(AdminAssignment.status == "active")
    )

    all_onboardings = query.order_by(Onboarding.created_at.desc()).all()

    # Count by admin_status
    total = len(all_onboardings)
    pending_review = sum(1 for o in all_onboardings if o.admin_status in ("assigned", "under_review"))
    approved = sum(1 for o in all_onboardings if o.admin_status == "approved")
    sent_back = sum(1 for o in all_onboardings if o.admin_status == "sent_back")
    cost_pending = sum(1 for o in all_onboardings if o.admin_status == "cost_pending")
    recommendations_pending = sum(1 for o in all_onboardings if o.admin_status in ("cost_done", "recommendations_sent"))

    # Apply filters for the returned list
    filtered = all_onboardings
    if status:
        filtered = [o for o in all_onboardings if o.admin_status == status]
    if search:
        filtered = [o for o in filtered if search.lower() in (o.name or "").lower()]

    return {
        "total_assigned": total,
        "pending_review": pending_review,
        "approved": approved,
        "sent_back": sent_back,
        "cost_pending": cost_pending,
        "recommendations_pending": recommendations_pending,
        "onboardings": filtered,
    }


# ── Detail ───────────────────────────────────────────────────────────────────

def get_onboarding_detail(
    db: Session, onboarding_id: str, admin: User,
) -> Onboarding | None:
    """Return full onboarding detail if assigned to admin."""
    ob = _load_onboarding(db, onboarding_id)
    if ob is None:
        return None
    if not _is_assigned_to_admin(ob, admin):
        return None
    return ob


# ── Feedback ─────────────────────────────────────────────────────────────────

def submit_feedback(
    db: Session, onboarding_id: str, admin: User, data: FeedbackCreate,
) -> ValidationFeedback:
    """Create validation feedback for a section."""
    feedback = ValidationFeedback(
        id=str(uuid.uuid4()),
        onboarding_id=onboarding_id,
        admin_id=admin.id,
        section=data.section,
        status=data.status,
        comment=data.comment,
    )
    db.add(feedback)

    ob = db.query(Onboarding).filter(Onboarding.id == onboarding_id).first()
    if ob and ob.admin_status in ("assigned", "under_review"):
        ob.admin_status = "under_review"

    db.commit()
    _log_event(
        db, onboarding_id, "admin", admin.name,
        "decision" if data.status == "approved" else "comment",
        f"{'Approved' if data.status == 'approved' else 'Requested changes for'} {data.section.replace('_', ' ').title()}",
        body=data.comment,
        scope=data.section.replace('_', ' ').title(),
    )
    db.commit()
    db.refresh(feedback)
    return feedback


# ── Approve ──────────────────────────────────────────────────────────────────

def approve_onboarding(db: Session, onboarding_id: str, admin: User) -> bool:
    """Approve the full onboarding — all 4 sections must be approved."""
    ob = _load_onboarding(db, onboarding_id)
    if ob is None:
        return False

    required_sections = {"account_details", "requirements", "cloud_resources", "architecture"}
    approved_sections = set()
    for fb in ob.validation_feedbacks:
        if fb.status == "approved":
            approved_sections.add(fb.section)

    if not required_sections.issubset(approved_sections):
        return False

    ob.admin_status = "cost_pending"
    _log_event(
        db, onboarding_id, "admin", admin.name,
        "decision", "Approved all sections — proceeding to cost budgeting",
    )
    db.commit()
    return True


# ── Send-back ────────────────────────────────────────────────────────────────

def send_back(db: Session, onboarding_id: str, admin: User, comment: str) -> bool:
    """Send onboarding back to user with a comment.
    
    Collects both the overall send-back comment and any per-section
    rejected feedback comments into admin_comments for the user to see.
    """
    ob = (
        db.query(Onboarding)
        .options(joinedload(Onboarding.validation_feedbacks))
        .filter(Onboarding.id == onboarding_id)
        .first()
    )
    if ob is None:
        return False

    ob.admin_status = "sent_back"
    
    # Create a fresh copy so SQLAlchemy detects the change
    comments = list(ob.admin_comments) if ob.admin_comments else []

    # Collect per-section rejected feedback comments
    section_labels = {
        "account_details": "Account Details",
        "requirements": "Requirements",
        "cloud_resources": "Cloud Resources",
        "architecture": "Architecture",
    }
    section_comments = []
    for fb in ob.validation_feedbacks:
        if fb.status == "rejected" and fb.comment:
            section_comments.append({
                "section": fb.section,
                "section_label": section_labels.get(fb.section, fb.section),
                "comment": fb.comment,
            })

    comments.append({
        "admin_id": admin.id,
        "admin_name": admin.name,
        "comment": comment,
        "section_comments": section_comments,
        "timestamp": str(uuid.uuid4())[:8],  # short ref
    })
    ob.admin_comments = comments

    _log_event(
        db, onboarding_id, "admin", admin.name,
        "decision", "Sent back to user for changes",
        body=comment,
    )
    db.commit()
    return True


# ── Resubmit (User) ──────────────────────────────────────────────────────────

def resubmit_onboarding(db: Session, onboarding_id: str) -> bool:
    """User resubmits after making changes — reset for admin re-review.

    Clears old validation feedbacks and sets admin_status back to
    'assigned' (if already assigned to an admin) or 'pending_assignment'.
    """
    ob = (
        db.query(Onboarding)
        .options(
            joinedload(Onboarding.admin_assignment),
            joinedload(Onboarding.validation_feedbacks),
        )
        .filter(Onboarding.id == onboarding_id)
        .first()
    )
    if ob is None:
        return False

    # Clear old per-section validation feedbacks so admin starts fresh
    db.query(ValidationFeedback).filter(
        ValidationFeedback.onboarding_id == onboarding_id,
    ).delete()

    # Keep the same admin assignment — just re-queue for review
    if ob.admin_assignment is not None:
        ob.admin_status = "assigned"
    else:
        ob.admin_status = "pending_assignment"

    _log_event(
        db, onboarding_id, "user", "Requestor",
        "submission", "Resubmitted onboarding for review",
    )
    db.commit()
    return True


# ── Cost Estimation ──────────────────────────────────────────────────────────

def upsert_cost(
    db: Session, onboarding_id: str, admin: User, data: CostEstimationUpsert,
) -> CostEstimation:
    """Create or update cost estimation."""
    existing = (
        db.query(CostEstimation)
        .filter(CostEstimation.onboarding_id == onboarding_id)
        .first()
    )

    cost_data = [item.model_dump() for item in data.resource_costs]

    if existing:
        existing.resource_costs = cost_data
        existing.infra_support_cost = data.infra_support_cost
        existing.total_monthly_cost = data.total_monthly_cost
        existing.total_annual_cost = data.total_annual_cost
        existing.currency = data.currency
        existing.notes = data.notes
        existing.admin_id = admin.id
        cost = existing
    else:
        cost = CostEstimation(
            id=str(uuid.uuid4()),
            onboarding_id=onboarding_id,
            admin_id=admin.id,
            resource_costs=cost_data,
            infra_support_cost=data.infra_support_cost,
            total_monthly_cost=data.total_monthly_cost,
            total_annual_cost=data.total_annual_cost,
            currency=data.currency,
            notes=data.notes,
        )
        db.add(cost)

    ob = db.query(Onboarding).filter(Onboarding.id == onboarding_id).first()
    if ob:
        ob.admin_status = "cost_done"
        _log_event(
            db, onboarding_id, "admin", admin.id,
            "publish", "Cost estimation saved",
            scope="Cost",
        )

    db.commit()
    db.refresh(cost)
    return cost


def get_cost(db: Session, onboarding_id: str) -> CostEstimation | None:
    """Return cost estimation for an onboarding."""
    return (
        db.query(CostEstimation)
        .filter(CostEstimation.onboarding_id == onboarding_id)
        .first()
    )


def seed_cost_from_bucket(db: Session, onboarding_id: str) -> list[dict]:
    """Read cloud resource bucket and return pre-populated cost items."""
    ob = _load_onboarding(db, onboarding_id)
    if ob is None or ob.cloud_resource_bucket is None:
        return []

    items = []
    bucket = ob.cloud_resource_bucket
    for resource in (bucket.resources or []):
        items.append({
            "resource_name": resource.get("service", "Unknown"),
            "unit_cost": 0,
            "quantity": resource.get("count", 1),
            "monthly_cost": 0,
        })
    return items


# ── Recommendations ─────────────────────────────────────────────────────────

def get_recommendations(db: Session, onboarding_id: str) -> list[Recommendation]:
    """Return all recommendations for an onboarding."""
    return (
        db.query(Recommendation)
        .filter(Recommendation.onboarding_id == onboarding_id)
        .order_by(Recommendation.created_at)
        .all()
    )


def update_recommendation(
    db: Session, rec_id: str, data: RecommendationUpdate,
) -> Recommendation | None:
    """Update a single recommendation."""
    rec = db.query(Recommendation).filter(Recommendation.id == rec_id).first()
    if rec is None:
        return None

    update_data = data.model_dump(exclude_unset=True)
    for field, value in update_data.items():
        setattr(rec, field, value)
    rec.status = "edited"

    db.commit()
    db.refresh(rec)
    return rec


def _parse_llm_json(raw: str) -> dict:
    """Extract JSON from LLM response, handling markdown code fences."""
    text = raw.strip()
    if text.startswith("```"):
        # Remove ```json ... ``` wrapping
        lines = text.split("\n")
        lines = [l for l in lines if not l.strip().startswith("```")]
        text = "\n".join(lines)
    return json.loads(text)


def generate_recommendations(
    db: Session, onboarding_id: str, admin: User,
) -> list[Recommendation]:
    """Generate GPS, RFC, and approval recommendations using the LLM."""
    ob = _load_onboarding(db, onboarding_id)
    if ob is None:
        raise ValueError("Onboarding not found")

    acct = ob.account_details
    reqs = ob.requirement_assessment
    bucket = ob.cloud_resource_bucket

    # Delete previous recommendations for a clean regeneration
    db.query(Recommendation).filter(
        Recommendation.onboarding_id == onboarding_id,
    ).delete()
    db.flush()

    results: list[Recommendation] = []

    # ── 1. GPS Recommendation ────────────────────────────────────────────
    gps_system = (
        "You are a TCS DIS (Digital Infrastructure Services) Cloud Operations expert. "
        "Generate a GPS (Global Provisioning Service) request for provisioning a new cloud account.\n\n"
        "You will receive project details, cloud provider info, and required resources. "
        "Generate a structured GPS request that includes all necessary information for the provisioning team.\n\n"
        "Respond ONLY with a valid JSON object in this exact format:\n"
        "{\n"
        '  "title": "GPS – Cloud Account Provisioning for [Project Name]",\n'
        '  "summary": "Detailed summary of what needs to be provisioned...",\n'
        '  "parameters": [\n'
        '    {"label": "GPS Category", "value": "..."},\n'
        '    {"label": "Request Type", "value": "New Cloud Account Provisioning"},\n'
        '    {"label": "Cloud Provider", "value": "..."},\n'
        '    {"label": "Region", "value": "..."},\n'
        '    {"label": "Priority", "value": "..."},\n'
        '    {"label": "Business Justification", "value": "..."},\n'
        '    {"label": "Deployment Environments", "value": "..."},\n'
        '    {"label": "Estimated Resources", "value": "..."},\n'
        '    {"label": "Approval Chain", "value": "Project Manager → Delivery Head → ISM → DIS CloudOps"},\n'
        '    {"label": "SLA", "value": "5 business days post-approval"}\n'
        "  ],\n"
        '  "copy_text": "Full copy-pasteable GPS request text..."\n'
        "}"
    )

    resources_text = ""
    if bucket and bucket.resources:
        for r in bucket.resources:
            resources_text += f"- {r.get('service', 'N/A')} × {r.get('count', 1)}: {r.get('configDetails', '')}\n"

    gps_message = (
        f"Project Name: {acct.project_name if acct else 'N/A'}\n"
        f"Description: {acct.description if acct else 'N/A'}\n"
        f"ISU: {acct.isu if acct else 'N/A'}\n"
        f"Business Unit: {acct.business_unit if acct else 'N/A'}\n"
        f"Cloud Provider: {reqs.cloud_provider if reqs else 'N/A'}\n"
        f"Region: {reqs.region if reqs else 'N/A'}\n"
        f"Solution Type: {reqs.solution_type if reqs else 'N/A'}\n"
        f"Deployment Environments: {json.dumps(reqs.deployment_environments) if reqs else '[]'}\n"
        f"Cloud Resources:\n{resources_text or 'None specified'}"
    )

    try:
        gps_raw = gemini_invoke(gps_system, [], gps_message)
        gps_data = _parse_llm_json(gps_raw)

        gps_rec = Recommendation(
            id=str(uuid.uuid4()),
            onboarding_id=onboarding_id,
            category="gps",
            title=gps_data.get("title", "GPS Request"),
            summary=gps_data.get("summary", ""),
            parameters=gps_data.get("parameters", []),
            copy_text=gps_data.get("copy_text"),
            status="generated",
        )
        db.add(gps_rec)
        results.append(gps_rec)
    except Exception as exc:
        logger.error("GPS recommendation generation failed: %s", exc)
        # Create a fallback GPS recommendation
        gps_rec = Recommendation(
            id=str(uuid.uuid4()),
            onboarding_id=onboarding_id,
            category="gps",
            title=f"GPS – Cloud Account Provisioning for {acct.project_name if acct else 'Project'}",
            summary="GPS recommendation could not be generated automatically. Please fill in details manually.",
            parameters=[{"label": "Error", "value": str(exc)}],
            status="generated",
        )
        db.add(gps_rec)
        results.append(gps_rec)

    # ── 2. RFC Recommendations (one per resource) ────────────────────────
    rfc_system = (
        "You are a TCS DIS Cloud Operations expert. "
        "Generate an RFC (Request for Change) for provisioning a specific cloud resource.\n\n"
        "Respond ONLY with a valid JSON object in this exact format:\n"
        "{\n"
        '  "title": "RFC – [Resource Name] Provisioning",\n'
        '  "summary": "Detailed summary of the change...",\n'
        '  "parameters": [\n'
        '    {"label": "Change Type", "value": "Standard|Normal|Emergency"},\n'
        '    {"label": "Resource", "value": "..."},\n'
        '    {"label": "Count", "value": "..."},\n'
        '    {"label": "Configuration", "value": "..."},\n'
        '    {"label": "Impact", "value": "..."},\n'
        '    {"label": "Risk Level", "value": "Low|Medium|High"},\n'
        '    {"label": "Rollback Plan", "value": "..."},\n'
        '    {"label": "Implementation Steps", "value": "..."},\n'
        '    {"label": "Estimated Duration", "value": "..."},\n'
        '    {"label": "Change Window", "value": "..."}\n'
        "  ],\n"
        '  "copy_text": "Full copy-pasteable RFC text..."\n'
        "}"
    )

    if bucket and bucket.resources:
        for resource in bucket.resources:
            rfc_message = (
                f"Project: {acct.project_name if acct else 'N/A'}\n"
                f"Cloud Provider: {reqs.cloud_provider if reqs else 'N/A'}\n"
                f"Region: {reqs.region if reqs else 'N/A'}\n"
                f"Resource: {resource.get('service', 'N/A')}\n"
                f"Count: {resource.get('count', 1)}\n"
                f"Configuration Details: {resource.get('configDetails', 'Standard')}\n"
                f"Solution Type: {reqs.solution_type if reqs else 'N/A'}"
            )
            try:
                rfc_raw = gemini_invoke(rfc_system, [], rfc_message)
                rfc_data = _parse_llm_json(rfc_raw)

                rfc_rec = Recommendation(
                    id=str(uuid.uuid4()),
                    onboarding_id=onboarding_id,
                    category="rfc",
                    title=rfc_data.get("title", f"RFC – {resource.get('service', 'Resource')}"),
                    summary=rfc_data.get("summary", ""),
                    parameters=rfc_data.get("parameters", []),
                    copy_text=rfc_data.get("copy_text"),
                    status="generated",
                )
                db.add(rfc_rec)
                results.append(rfc_rec)
            except Exception as exc:
                logger.error("RFC generation failed for %s: %s", resource.get("service"), exc)
                rfc_rec = Recommendation(
                    id=str(uuid.uuid4()),
                    onboarding_id=onboarding_id,
                    category="rfc",
                    title=f"RFC – {resource.get('service', 'Resource')} Provisioning",
                    summary="RFC could not be generated automatically. Please fill in details manually.",
                    parameters=[
                        {"label": "Resource", "value": resource.get("service", "N/A")},
                        {"label": "Count", "value": str(resource.get("count", 1))},
                        {"label": "Error", "value": str(exc)},
                    ],
                    status="generated",
                )
                db.add(rfc_rec)
                results.append(rfc_rec)

    # ── 3. Approval Recommendations ──────────────────────────────────────
    solution_type = reqs.solution_type.lower() if reqs else ""
    approval_rules = (
        db.query(ApprovalRule)
        .order_by(ApprovalRule.sort_order)
        .all()
    )

    for rule in approval_rules:
        # Filter by applies_to
        if rule.applies_to == "generative-ai" and "generative" not in solution_type and "genai" not in solution_type:
            continue
        if rule.applies_to == "non-generative-ai" and ("generative" in solution_type or "genai" in solution_type):
            continue

        approval_rec = Recommendation(
            id=str(uuid.uuid4()),
            onboarding_id=onboarding_id,
            category="approval",
            title=f"Approval – {rule.name}",
            summary=rule.description,
            parameters=[
                {"label": "Approver Role", "value": rule.approver_role},
                {"label": "Mandatory", "value": "Yes" if rule.is_mandatory else "No"},
                {"label": "Applies To", "value": rule.applies_to},
            ],
            status="generated",
        )
        db.add(approval_rec)
        results.append(approval_rec)

    db.commit()
    for r in results:
        db.refresh(r)
    return results


# ── Send to User ─────────────────────────────────────────────────────────────

def send_to_user(db: Session, onboarding_id: str) -> bool:
    """Mark onboarding as recommendations_sent."""
    ob = db.query(Onboarding).filter(Onboarding.id == onboarding_id).first()
    if ob is None:
        return False

    ob.admin_status = "recommendations_sent"

    # Mark all recommendations as 'sent'
    db.query(Recommendation).filter(
        Recommendation.onboarding_id == onboarding_id,
    ).update({"status": "sent"})

    _log_event(
        db, onboarding_id, "system", "System",
        "publish", "Recommendations sent to user",
        scope="Recommendations",
    )
    db.commit()
    return True


# ── Interaction Events ───────────────────────────────────────────────────────

def get_interaction_events(db: Session, onboarding_id: str) -> list[dict]:
    """Return all interaction events for an onboarding, sorted by timestamp."""
    events = (
        db.query(InteractionEvent)
        .filter(InteractionEvent.onboarding_id == onboarding_id)
        .order_by(InteractionEvent.ts)
        .all()
    )
    return [
        {
            "id": e.id,
            "onboarding_id": e.onboarding_id,
            "ts": e.ts.isoformat() if e.ts else None,
            "actor": e.actor,
            "actor_name": e.actor_name,
            "kind": e.kind,
            "title": e.title,
            "body": e.body,
            "scope": e.scope,
        }
        for e in events
    ]

