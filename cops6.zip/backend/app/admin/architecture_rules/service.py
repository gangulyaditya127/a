"""Service layer for architecture-rule admin CRUD."""

import uuid

from sqlalchemy.orm import Session

from app.models.architecture_rules import ArchitectureRule
from app.admin.architecture_rules.schemas import (
    ArchitectureRuleCreate,
    ArchitectureRuleUpdate,
)


def get_all(db: Session) -> list[ArchitectureRule]:
    return db.query(ArchitectureRule).all()


def get_by_id(db: Session, rule_id: str) -> ArchitectureRule | None:
    return db.query(ArchitectureRule).filter(ArchitectureRule.id == rule_id).first()


def get_by_provider(db: Session, cloud_provider: str) -> list[ArchitectureRule]:
    return (
        db.query(ArchitectureRule)
        .filter(ArchitectureRule.cloud_provider == cloud_provider)
        .all()
    )


def create(db: Session, data: ArchitectureRuleCreate) -> ArchitectureRule:
    rule = ArchitectureRule(id=str(uuid.uuid4()), **data.model_dump())
    db.add(rule)
    db.commit()
    db.refresh(rule)
    return rule


def bulk_create(
    db: Session, items: list[ArchitectureRuleCreate]
) -> list[ArchitectureRule]:
    rules = [
        ArchitectureRule(id=str(uuid.uuid4()), **item.model_dump()) for item in items
    ]
    db.add_all(rules)
    db.commit()
    for r in rules:
        db.refresh(r)
    return rules


def update(
    db: Session, rule_id: str, data: ArchitectureRuleUpdate
) -> ArchitectureRule | None:
    rule = get_by_id(db, rule_id)
    if rule is None:
        return None
    update_data = data.model_dump(exclude_unset=True)
    for field, value in update_data.items():
        setattr(rule, field, value)
    db.commit()
    db.refresh(rule)
    return rule


def delete(db: Session, rule_id: str) -> bool:
    rule = get_by_id(db, rule_id)
    if rule is None:
        return False
    db.delete(rule)
    db.commit()
    return True


def delete_all(db: Session) -> int:
    count = db.query(ArchitectureRule).delete()
    db.commit()
    return count
