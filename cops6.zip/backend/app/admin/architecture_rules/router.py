"""Admin API router for architecture validation rules."""

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.admin.architecture_rules import service
from app.admin.architecture_rules.schemas import (
    ArchitectureRuleCreate,
    ArchitectureRuleResponse,
    ArchitectureRuleUpdate,
)

router = APIRouter()


@router.get("/", response_model=list[ArchitectureRuleResponse])
def list_rules(db: Session = Depends(get_db)):
    return service.get_all(db)


@router.post("/", response_model=ArchitectureRuleResponse, status_code=201)
def create_rule(data: ArchitectureRuleCreate, db: Session = Depends(get_db)):
    return service.create(db, data)


@router.post("/bulk", response_model=list[ArchitectureRuleResponse], status_code=201)
def bulk_create_rules(
    items: list[ArchitectureRuleCreate], db: Session = Depends(get_db)
):
    return service.bulk_create(db, items)


@router.get("/provider/{cloud_provider}", response_model=list[ArchitectureRuleResponse])
def get_rules_by_provider(cloud_provider: str, db: Session = Depends(get_db)):
    return service.get_by_provider(db, cloud_provider)


@router.get("/{rule_id}", response_model=ArchitectureRuleResponse)
def get_rule(rule_id: str, db: Session = Depends(get_db)):
    rule = service.get_by_id(db, rule_id)
    if rule is None:
        raise HTTPException(status_code=404, detail="Rule not found")
    return rule


@router.put("/{rule_id}", response_model=ArchitectureRuleResponse)
def update_rule(
    rule_id: str, data: ArchitectureRuleUpdate, db: Session = Depends(get_db)
):
    rule = service.update(db, rule_id, data)
    if rule is None:
        raise HTTPException(status_code=404, detail="Rule not found")
    return rule


@router.delete("/{rule_id}", status_code=204)
def delete_rule(rule_id: str, db: Session = Depends(get_db)):
    deleted = service.delete(db, rule_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="Rule not found")


@router.delete("/", status_code=204)
def delete_all_rules(db: Session = Depends(get_db)):
    service.delete_all(db)
