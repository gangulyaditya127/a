"""SuperAdmin API router — onboarding oversight and admin management."""

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.domains.auth.dependencies import require_superadmin
from app.models.user import User
from app.admin.superadmin import service
from app.admin.superadmin.schemas import (
    AdminCreate,
    AdminResponse,
    AdminUpdate,
    AssignmentResponse,
    AssignRequest,
    DashboardStats,
    OnboardingListItem,
)

router = APIRouter()


@router.get("/dashboard", response_model=DashboardStats)
def dashboard(
    db: Session = Depends(get_db),
    superadmin: User = Depends(require_superadmin),
) -> DashboardStats:
    """Return aggregate stats and admin workloads."""
    return service.get_dashboard(db)


@router.get("/onboardings", response_model=list[OnboardingListItem])
def list_onboardings(
    unassigned: bool | None = None,
    assigned: bool | None = None,
    admin_status: str | None = None,
    search: str | None = None,
    db: Session = Depends(get_db),
    superadmin: User = Depends(require_superadmin),
) -> list[OnboardingListItem]:
    """List all onboardings with optional filters."""
    return service.list_onboardings(
        db,
        unassigned=unassigned,
        assigned=assigned,
        admin_status=admin_status,
        search=search,
    )


@router.post(
    "/onboardings/{onboarding_id}/assign",
    response_model=AssignmentResponse,
    status_code=201,
)
def assign_admin(
    onboarding_id: str,
    data: AssignRequest,
    db: Session = Depends(get_db),
    superadmin: User = Depends(require_superadmin),
) -> AssignmentResponse:
    """Assign an admin to an onboarding."""
    # Validate admin exists
    admin = db.query(User).filter(User.id == data.admin_id, User.role == "admin").first()
    if admin is None:
        raise HTTPException(status_code=404, detail="Admin user not found")

    return service.assign_admin(db, onboarding_id, data.admin_id, superadmin.id)


@router.post(
    "/onboardings/{onboarding_id}/reassign",
    response_model=AssignmentResponse,
    status_code=201,
)
def reassign_admin(
    onboarding_id: str,
    data: AssignRequest,
    db: Session = Depends(get_db),
    superadmin: User = Depends(require_superadmin),
) -> AssignmentResponse:
    """Reassign an onboarding to a different admin."""
    admin = db.query(User).filter(User.id == data.admin_id, User.role == "admin").first()
    if admin is None:
        raise HTTPException(status_code=404, detail="Admin user not found")

    return service.reassign_admin(db, onboarding_id, data.admin_id, superadmin.id)


@router.get("/admins", response_model=list[AdminResponse])
def list_admins(
    db: Session = Depends(get_db),
    superadmin: User = Depends(require_superadmin),
) -> list[AdminResponse]:
    """List all admin users."""
    return service.list_admins(db)


@router.post("/admins", response_model=AdminResponse, status_code=201)
def create_admin(
    data: AdminCreate,
    db: Session = Depends(get_db),
    superadmin: User = Depends(require_superadmin),
) -> AdminResponse:
    """Register a new admin user."""
    # Check email uniqueness
    existing = db.query(User).filter(User.email == data.email).first()
    if existing:
        raise HTTPException(status_code=400, detail="Email already registered")

    return service.create_admin(db, data)


@router.put("/admins/{admin_id}", response_model=AdminResponse)
def update_admin(
    admin_id: str,
    data: AdminUpdate,
    db: Session = Depends(get_db),
    superadmin: User = Depends(require_superadmin),
) -> AdminResponse:
    """Update an admin user."""
    admin = service.update_admin(db, admin_id, data)
    if admin is None:
        raise HTTPException(status_code=404, detail="Admin not found")
    return admin


@router.delete("/admins/{admin_id}", status_code=204)
def delete_admin(
    admin_id: str,
    db: Session = Depends(get_db),
    superadmin: User = Depends(require_superadmin),
) -> None:
    """Deactivate an admin (soft delete)."""
    deleted = service.deactivate_admin(db, admin_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="Admin not found")


# ── Config Management ─────────────────────────────────────────────────


@router.get("/config/summary")
def config_summary(
    db: Session = Depends(get_db),
    superadmin: User = Depends(require_superadmin),
) -> dict:
    """Return counts for each configurable entity."""
    from app.models.approval_rule import ApprovalRule
    from app.models.onboarding import EligibilityQuestion, DisclaimerClause
    from app.models.architecture_rules import ArchitectureRule

    return {
        "eligibility_questions": db.query(EligibilityQuestion).count(),
        "disclaimer_clauses": db.query(DisclaimerClause).count(),
        "architecture_rules": db.query(ArchitectureRule).count(),
        "approval_rules": db.query(ApprovalRule).count(),
    }


@router.get("/config/approval-rules")
def list_approval_rules(
    db: Session = Depends(get_db),
    superadmin: User = Depends(require_superadmin),
) -> list[dict]:
    """Return all approval rules sorted by sort_order."""
    from app.models.approval_rule import ApprovalRule

    rules = db.query(ApprovalRule).order_by(ApprovalRule.sort_order).all()
    return [
        {
            "id": r.id,
            "name": r.name,
            "description": r.description,
            "approver_role": r.approver_role,
            "is_mandatory": r.is_mandatory,
            "applies_to": r.applies_to,
            "sort_order": r.sort_order,
        }
        for r in rules
    ]


@router.post("/config/approval-rules", status_code=201)
def create_approval_rule(
    data: dict,
    db: Session = Depends(get_db),
    superadmin: User = Depends(require_superadmin),
) -> dict:
    """Create a new approval rule."""
    import uuid
    from app.models.approval_rule import ApprovalRule

    # Determine next sort_order
    max_order = db.query(ApprovalRule.sort_order).order_by(ApprovalRule.sort_order.desc()).first()
    next_order = (max_order[0] + 1) if max_order else 1

    rule = ApprovalRule(
        id=str(uuid.uuid4()),
        name=data.get("name", ""),
        description=data.get("description", ""),
        approver_role=data.get("approver_role", ""),
        is_mandatory=data.get("is_mandatory", True),
        applies_to=data.get("applies_to", "all"),
        sort_order=data.get("sort_order", next_order),
    )
    db.add(rule)
    db.commit()
    db.refresh(rule)
    return {
        "id": rule.id,
        "name": rule.name,
        "description": rule.description,
        "approver_role": rule.approver_role,
        "is_mandatory": rule.is_mandatory,
        "applies_to": rule.applies_to,
        "sort_order": rule.sort_order,
    }


@router.put("/config/approval-rules/{rule_id}")
def update_approval_rule(
    rule_id: str,
    data: dict,
    db: Session = Depends(get_db),
    superadmin: User = Depends(require_superadmin),
) -> dict:
    """Update an existing approval rule."""
    from app.models.approval_rule import ApprovalRule

    rule = db.query(ApprovalRule).filter(ApprovalRule.id == rule_id).first()
    if rule is None:
        raise HTTPException(status_code=404, detail="Approval rule not found")

    for field in ("name", "description", "approver_role", "is_mandatory", "applies_to", "sort_order"):
        if field in data:
            setattr(rule, field, data[field])

    db.commit()
    db.refresh(rule)
    return {
        "id": rule.id,
        "name": rule.name,
        "description": rule.description,
        "approver_role": rule.approver_role,
        "is_mandatory": rule.is_mandatory,
        "applies_to": rule.applies_to,
        "sort_order": rule.sort_order,
    }


@router.delete("/config/approval-rules/{rule_id}", status_code=204)
def delete_approval_rule(
    rule_id: str,
    db: Session = Depends(get_db),
    superadmin: User = Depends(require_superadmin),
) -> None:
    """Delete an approval rule."""
    from app.models.approval_rule import ApprovalRule

    rule = db.query(ApprovalRule).filter(ApprovalRule.id == rule_id).first()
    if rule is None:
        raise HTTPException(status_code=404, detail="Approval rule not found")
    db.delete(rule)
    db.commit()

