"""Seed script — populate the database with initial users and approval rules.

Usage:
    cd backend
    python -m seed_data.seed_all
"""

import json
import os
import sys
import uuid

# Ensure the backend package is importable
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from app.core.database import SessionLocal, init_db
from app.models.user import User
from app.models.approval_rule import ApprovalRule


SEED_DIR = os.path.dirname(__file__)


def seed_users(db):
    """Seed user records from seed_users.json."""
    path = os.path.join(SEED_DIR, "seed_users.json")
    with open(path, encoding="utf-8") as f:
        users_data = json.load(f)

    created = 0
    for item in users_data:
        existing = db.query(User).filter(User.email == item["email"]).first()
        if existing:
            print(f"  [SKIP] User already exists: {item['email']}")
            continue

        user = User(
            id=str(uuid.uuid4()),
            name=item["name"],
            email=item["email"],
            emp_id=item["emp_id"],
            role=item["role"],
        )
        db.add(user)
        created += 1
        print(f"  [OK] Created user: {item['name']} ({item['role']})")

    db.commit()
    print(f"  Users seeded: {created} created, {len(users_data) - created} skipped\n")


def seed_approval_rules(db):
    """Seed approval rules from approval_rules_seed.json."""
    path = os.path.join(SEED_DIR, "approval_rules_seed.json")
    with open(path, encoding="utf-8") as f:
        rules_data = json.load(f)

    created = 0
    for item in rules_data:
        existing = db.query(ApprovalRule).filter(ApprovalRule.name == item["name"]).first()
        if existing:
            print(f"  [SKIP] Approval rule already exists: {item['name']}")
            continue

        rule = ApprovalRule(
            id=str(uuid.uuid4()),
            name=item["name"],
            description=item["description"],
            approver_role=item["approver_role"],
            is_mandatory=item["is_mandatory"],
            applies_to=item["applies_to"],
            sort_order=item["sort_order"],
        )
        db.add(rule)
        created += 1
        print(f"  [OK] Created approval rule: {item['name']}")

    db.commit()
    print(f"  Approval rules seeded: {created} created, {len(rules_data) - created} skipped\n")


def main():
    print("=" * 60)
    print("CloudOps Seed Script")
    print("=" * 60)

    # Ensure tables exist
    print("\n[INFO] Initializing database tables...")
    init_db()

    db = SessionLocal()
    try:
        print("\n[INFO] Seeding users...")
        seed_users(db)

        print("[INFO] Seeding approval rules...")
        seed_approval_rules(db)

        print("[OK] Seeding complete!")
    except Exception as exc:
        db.rollback()
        print(f"\n[ERROR] Seeding failed: {exc}")
        raise
    finally:
        db.close()


if __name__ == "__main__":
    main()
