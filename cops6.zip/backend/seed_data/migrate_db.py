"""Migrate the existing database to match the current models.

Adds missing columns to existing tables.
"""
import sys, os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from app.core.database import engine
from sqlalchemy import text, inspect

def migrate():
    insp = inspect(engine)

    with engine.begin() as conn:
        # --- users table ---
        user_cols = {c["name"] for c in insp.get_columns("users")}

        if "emp_id" not in user_cols:
            print("[MIGRATE] Adding users.emp_id ...")
            conn.execute(text("ALTER TABLE users ADD COLUMN emp_id VARCHAR NOT NULL DEFAULT ''"))

        if "is_active" not in user_cols:
            print("[MIGRATE] Adding users.is_active ...")
            conn.execute(text("ALTER TABLE users ADD COLUMN is_active BOOLEAN NOT NULL DEFAULT TRUE"))

        # --- onboardings table ---
        ob_cols = {c["name"] for c in insp.get_columns("onboardings")}

        if "admin_status" not in ob_cols:
            print("[MIGRATE] Adding onboardings.admin_status ...")
            conn.execute(text("ALTER TABLE onboardings ADD COLUMN admin_status VARCHAR NOT NULL DEFAULT 'pending_assignment'"))

        if "admin_comments" not in ob_cols:
            print("[MIGRATE] Adding onboardings.admin_comments ...")
            conn.execute(text("ALTER TABLE onboardings ADD COLUMN admin_comments JSON"))

        if "user_comments" not in ob_cols:
            print("[MIGRATE] Adding onboardings.user_comments ...")
            conn.execute(text("ALTER TABLE onboardings ADD COLUMN user_comments JSON"))

    print("[OK] Migration complete.")


if __name__ == "__main__":
    migrate()
