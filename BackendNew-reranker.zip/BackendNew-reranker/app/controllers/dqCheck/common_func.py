
# from langchain_tcs_bfsi_genai import APIClient,Auth,TCSChatModel,TCSEmbeddings,TCSLLMs
from .config import Config
from openai import OpenAI
import sys

# def get_client():
#     client = APIClient()
#     auth = Auth(client)
#     auth.login(Config.LLM_USERNAME, Config.LLM_PASSWORD)
#     return client
  

# # def invoke(query, username, password, model):
# #     try:
# #         client = get_client()
# #         # print(client)
# #         chat = TCSLLMs(client=client, model_name=model)
# #         # print(f"{'='*70} Query is\n f{query}\n")
# #         llm_response = chat.invoke(query)
# #         return llm_response
# #     except Exception as e:
# #         print(f"Error is here at {str(e)}")
# #         if "401" in str(e) or "unauthorized" in str(e).lower():
# #            print("Token expired. Refreshing and retrying...")
# #            # Re-login to refresh token
# #            new_client = APIClient()
# #            auth = Auth(new_client)
# #            auth.login(username, password) 
# #            new_chat = TCSChatModel(client=new_client, model_name=model)
# #            llm_response = new_chat.invoke(query)
# #            return llm_response
# #         else:
# #            raise


# import traceback
# #tcs embeding is not in use
# def embed__texts(texts: list[str]):
#     print("embed_text Called")#this function is not in use
#     try:
        
#         client = get_client()
#         embeddings = TCSEmbeddings(client, "bge")
#         resp = embeddings.embed(texts)
#         return resp
#     except Exception as e:
#         print("----------text for embedding failed--------",str(e))
#         # print(texts)
        
#         raise

# import os
# import httpx
# import urllib.request
# is_proxy_enable = urllib.request.getproxies()
# if is_proxy_enable != {}:
#     ips = ['10.170.21.213','localhost','127.0.0.1','10.169.38.3', '10.169.51.2','ismartams.tcsapps.com']
#     os.environ['http_proxy'] = 'http://proxy.tcs.com:8080'
#     os.environ['https_proxy'] = 'http://proxy.tcs.com:8080'
#     os.environ['no_proxy'] = ",".join(ips)
# ollama_client = OpenAI(
#             base_url='https://ismartams.tcsapps.com/ollama/v1/',
#             api_key='ollama',
#             http_client=httpx.Client(verify=False)
#         )
# def ollama_invoke(prompt):
#     try:
#         response = ollama_client.chat.completions.create(
#                 model='gpt-oss:latest',
#                 messages=[
#                     {'role': 'user', 'content': prompt}
#                 ]
#             )
#         llm_response = response.choices[0].message.content
#         return llm_response
#     except Exception as e:
#         print(f"Exception occured in ollama {str(e)}")
#         raise Exception("exception occured in ollama_invoke") from e

# def ollama_embed_texts(texts):
#     try:
#         response = client.embeddings.create(
#             model="all-minilm:l6-v2",
#             input=texts
#         )

#         return [item.embedding for item in response.data]
#     except Exception as e:
#         _,_, tb = sys.exc_info()
#         print("in ollama embed file")
#         print({
#             "error_line": tb.tb_lineno,
#             "error_message": str(e)
#         })
#         raise


import httpx

# 1. Initialize the OpenAI client pointing to your custom base URL
# client = OpenAI(
#     api_key="sk-2HH4rgTVpz3mwaViyYy-rA",
#     base_url="https://ismartams.tcsappsdev.com/litellm_zebster/",
#     http_client=httpx.Client(
#         trust_env=False,
#         verify=False,
#         timeout=60
#     )
# )

# # 2. Chat Invocation Function
# def invoke(query) -> str:
#     """
#     Sends a query to the LLM and returns the response content.
#     """
#     try:
#         response = client.chat.completions.create(
#             model="gpt-5", # Using the model from your snippet
#             messages=[
#                 {"role": "system", "content": "You are a helpful assistant."},
#                 {"role": "user", "content": query}
#             ]
#         )
#         return response.choices[0].message.content.strip()
    
#     except Exception as e:
#         print(f"Error during chat invocation: {e}")
#         raise

client=OpenAI(api_key="sk-DS97_7Vpa5bg3P1AX61dMg",base_url="http://10.73.74.36:20119")

def invoke(query):
    """
    Calls the Ollama API via an OpenAI-compatible client.
    Returns the string content of the LLM response.
    """
    print("inside openai invoke...")
   
    try:
      
        # 3. Request Completion
        response=client.chat.completions.create(model="gpt-5",messages=[
            {"role": "system", "content": "You are a helpful assistant."},
                {"role": "user", "content": query}])

        llm_response = response.choices[0].message.content.strip()
        return llm_response
 
    except Exception as e:
        print(f"Error in invoke: {e}")
        raise

embed_client=OpenAI(api_key="sk-03E_qksDFgcRQg65_MRM8g",base_url="http://10.73.74.36:20119")

def embed_texts(texts: list[str]):
    resp = embed_client.embeddings.create(model="text-embedding-3-large", input=texts)
    return [item.embedding for item in resp.data]
