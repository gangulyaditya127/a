import json

from .common_func import invoke
from .config import Config
import os
import re

        

def extract_closing_note_fields(text: str) -> dict:
    patterns = {
        "Alert": r"Alert:\s*(.*?)(?=\n[A-Za-z ]+:\s|\Z)",
        "Disposition": r"Disposition:\s*(.*?)(?=\n[A-Za-z ]+:\s|\Z)",
        "Impact": r"Impact:\s*(.*?)(?=\n[A-Za-z ]+:\s|\Z)",
        "Actions Taken": r"Actions Taken:\s*(.*?)(?=\n[A-Za-z ]+:\s|\Z)",
        "Closure Justification": r"Closure Justification:\s*(.*?)(?=\n[A-Za-z ]+:\s|\Z)",
    }

    extracted = {}
    for key, pattern in patterns.items():
        match = re.search(pattern, text, re.DOTALL | re.IGNORECASE)
        extracted[key] = (
            " ".join(match.group(1).strip().split()) if match else None
        )

    return extracted

def extract_investigation_fields(text: str) -> dict:
    patterns = {
        "Investigation Summary": r"Investigation Summary:\s*(.*?)(?=\n[A-Za-z ]+:\s|\Z)",
        "Detection Context": r"Detection Context:\s*(.*?)(?=\n[A-Za-z ]+:\s|\Z)",
        "Analysis Performed": r"Analysis Performed:\s*(.*?)(?=\n[A-Za-z ]+:\s|\Z)",
        "Findings": r"Findings:\s*(.*?)(?=\n[A-Za-z ]+:\s|\Z)",
        "Conclusion": r"Conclusion:\s*(.*?)(?=\n[A-Za-z ]+:\s|\Z)",
    }

    extracted = {}
    for key, pattern in patterns.items():
        match = re.search(pattern, text, re.DOTALL | re.IGNORECASE)
        extracted[key] = (
            " ".join(match.group(1).strip().split()) if match else None
        )

    return extracted


def validate_note(alert_details, close_note):
    # -------------------------------
    # 1. FORMAT VALIDATION (LOCAL)
    # -------------------------------
    print("-----closing note validation------------")
    extracted_dict = extract_closing_note_fields(close_note)

    required_fields = [
        "Alert",
        "Disposition",
        "Impact",
        "Actions Taken",
        "Closure Justification"
    ]

    format_valid = True
    for key in required_fields:
        if not extracted_dict.get(key):
            format_valid = False
            break

  
    prompt = f"""
You are a SOC Quality Assurance Analyst.

Your task is to determine whether the provided Close Note
is RELEVANT to the given Alert Details.

IMPORTANT CONTEXT:
- The Close Note may be structured or unstructured
- You MUST NOT validate formatting or section presence
- You MUST NOT rewrite, fix, or improve the Close Note
- Your task is ONLY to assess content relevance

INPUTS:

Alert Details:
{alert_details}

Close Note Content:
{close_note}

RELEVANCE EVALUATION CRITERIA:

Determine whether the Close Note:
- Accurately reflects the alert behavior and outcome
- Is logically consistent with the alert context
- Does NOT reference unrelated alerts, incidents, tools, or attack types
- Avoids speculative or unsupported conclusions

If the content meaningfully aligns with the alert, it is relevant.
If it is unrelated or misleading, it is NOT relevant.

OUTPUT REQUIREMENTS (STRICT):

Return ONLY raw JSON in the exact structure below:

{{
  "content_relevant": true | false,
  "explanation": "Concise justification for the relevance checking decision."
}}

Rules:
- Output JSON ONLY
- No markdown
- No additional keys
- No extra text
- The response MUST begin with '{{' and end with '}}'
"""

    try:
        llm_response = invoke(
            prompt
           
        )
        
        # llm_response = ollama_invoke(prompt)
        print("-----------output of closing note relevance----------")
        print(llm_response)

        result = json.loads(llm_response)

        
        cr = result.get("content_relevant")
        

        # -------------------------------
        # 4. CLASSIFICATION (PYTHON)
        # -------------------------------
        result["format_valid"] = format_valid

        if format_valid and cr:
            result["classification"] = "VALID_AND_MEANINGFUL"
        elif format_valid and not cr:
            result["classification"] = "VALID_BUT_IRRELEVANT"
        elif not format_valid and cr:
            result["classification"] = "INVALID_BUT_RELEVANT"
        else:
            result["classification"] = "INVALID_AND_IRRELEVANT"
        print("closing note validaion end")
        return result

    except Exception as e:
        print("Error occurred in validate_note:", str(e))
        raise

def validate_investigation(alert_details,investigation_analysis):
    extracted_dict=extract_investigation_fields(investigation_analysis)
    
    required_fields=[
                    "Investigation Summary",
                    "Detection Context",
                    "Analysis Performed",
                    "Findings",
                    "Conclusion"
                    ]
    format_valid=True
    
    for key in required_fields:
        if not extracted_dict.get(key):
            format_valid=False
    
    prompt = f"""
    You are a SOC Quality Assurance Analyst.

    Your task is to determine whether the provided Investigation Analysis content
    is RELEVANT to the given Alert Details.

    IMPORTANT CONTEXT:
    - The Investigation Analysis may be provided as:
    - Structured JSON with key–value pairs, OR
    - Unstructured raw free text
    - You MUST treat the input purely as content, regardless of format.
    - You MUST NOT validate formatting, headings, or structure.
    - You MUST NOT rewrite, summarize, reformat, or normalize the content.
    - Your task is ONLY to assess relevance.

    INPUTS:

    Alert Details:
    {alert_details}

    Investigation Analysis Content (JSON or Raw Text):
    {investigation_analysis}

    RELEVANCE EVALUATION CRITERIA:

    Determine whether the Investigation Analysis content:
    - Logically aligns with the alert behavior and context
    - Describes investigation steps, observations, or conclusions related to the alert
    - Avoids unrelated alerts, incidents, tools, users, or attack types
    - Avoids speculative or unsupported statements unrelated to the alert

    If the content meaningfully relates to the alert, it is relevant.
    If the content is unrelated, misleading, or generic, it is not relevant.

    OUTPUT REQUIREMENTS (STRICT):

    Return ONLY raw JSON in the exact structure below:

    {{
    "content_relevant": true/false,
    "explanation": "Concise justification for the relevance checking decision."
    }}

    Rules:
    - Output JSON ONLY
    - No markdown
    - No additional keys
    - No extra text
    - No formatting commentary
    - The response MUST begin with '{' and end with '}'
    """
    try:
        llm_response=invoke(prompt)
        
        # llm_response = ollama_invoke(prompt)
        print("-----------output of investigation analysis----------")
        print(llm_response)
        result=json.loads(llm_response)
    
        result['format_valid']=format_valid
        if format_valid and result.get('content_relevant'):
            result['classification']='VALID_AND_MEANINGFUL'
        elif format_valid and not result.get('content_relevant'):
            result['classification']='VALID_BUT_IRRELEVANT'
        elif not format_valid and result.get('content_relevant'):
            result['classification']='INVALID_BUT_RELEVANT'
        else:
            result['classification']='INVALID_AND_IRRELEVANT'
        return result
    except Exception as e:
        print(f"Error occured in validate_investigation,{str(e)}")
        raise

