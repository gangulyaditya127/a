import json
import os
from ..resolution_recommender.common_func import invoke
from ..resolution_recommender.config import Config

        
def fetch_investigation_recommendation(similar_data, investigation_analysis):
    prompt = f'''
You are a SOC analyst assistant responsible for generating Cortex XSOAR–ready
Investigation Analysis notes.

You will be provided with:
1) Alert details (CrowdStrike detection metadata)
2) Current raw / unstructured investigation analysis (may be EMPTY)
3) Similar or historical investigation analyses (may be EMPTY or LOW RELEVANCE)

--------------------------------------------------
OBJECTIVE
--------------------------------------------------
Generate a clean, professional and SOC‑compliant
"✅ Complete Investigation Analysis (XSOAR‑ready)".

--------------------------------------------------
CRITICAL DECISION LOGIC (MUST FOLLOW)
--------------------------------------------------
Apply the following logic STRICTLY:

1) IF the current investigation analysis is EMPTY or BLANK:
   - Generate a full Investigation Analysis based on:
     a) Alert details
     b) Similar / historical investigations (if available)
   - If no similar investigations are available, rely on SOC best‑practice
     and security domain knowledge derived from the alert details.
   - Do NOT mention that the analysis was generated.

2) IF the current investigation analysis IS PROVIDED:
   - Treat it as the PRIMARY source of truth.
   - Normalize, enrich, and standardize it using similar investigations
     ONLY for phrasing consistency and completeness.
   - Do NOT override conclusions unless they are technically inconsistent.

3) IF similar / historical investigations are EMPTY, irrelevant, or missing:
   - DO NOT reference or mention them.
   - Generate content using alert details and SOC investigative knowledge alone.

--------------------------------------------------
CONTENT RULES
--------------------------------------------------
- Preserve technical accuracy
- Normalize vocabulary across SOC reports
- Maintain professional, audit‑safe tone
- Do NOT copy historical text verbatim unless factually required
- Do NOT introduce assumptions unsupported by alert data
- Do NOT mention similarity search, history, or references

--------------------------------------------------
REQUIRED OUTPUT FORMAT (STRICT)
--------------------------------------------------
Return response in the following structured JSON format:

{{
  "Investigation Summary": "Concise summary of why the alert triggered and what was investigated",
  "Detection Context": "Detection name, CrowdStrike tactic/technique, analysis type",
  "Analysis Performed": "Telemetry analysis, process lineage, command lines, file hashes, network or registry checks",
  "Findings": "Key technical findings indicating malicious or benign behavior",
  "Conclusion": "Final determination aligned with investigation outcome"
}}
FINAL OUTPUT RULE (CRITICAL):
    - Output RAW JSON ONLY
    - DO NOT use markdown
    - DO NOT use ```json or ```
    - DO NOT include any text outside JSON
    - The response MUST begin with '{' and end with '}'
--------------------------------------------------
INPUT DATA
--------------------------------------------------

Alert Details:
{similar_data['query']}

Current Investigation Analysis:
{investigation_analysis}

Similar / Historical Investigation Analysis (Reference Only):
{similar_data['matches']}

--------------------------------------------------
FINAL INSTRUCTION
--------------------------------------------------
Generate the Investigation Analysis now.
'''
    print("----inside fetch investigation recommendation--------")
    try:
        llm_response = invoke(
            prompt
        )
        
        # llm_response = ollama_invoke(prompt)
        print("-----------llm response for investigation recommendation----------")
        print(llm_response)
        return json.loads(llm_response)

    except Exception as e:
        print(f"Exception occurred in fetch_investigation_recommendation {str(e)}")
        raise

def fetch_closing_note_recommendation(similar_data, closing_note):
    prompt = f'''
    You are a SOC analyst assistant responsible for generating Cortex XSOAR–ready
    Closing Notes for security alerts.

    You will be provided with:
    1) Alert details (CrowdStrike detection metadata)
    2) Current raw / unstructured closing note (MAY BE EMPTY)
    3) Similar or historical closing notes (MAY BE EMPTY or LOW RELEVANCE)

    --------------------------------------------------
    OBJECTIVE
    --------------------------------------------------
    Generate a clean, professional and SOC‑compliant
    "✅ Complete Closing Note (XSOAR‑ready)".

    --------------------------------------------------
    CRITICAL DECISION LOGIC (MUST FOLLOW)
    --------------------------------------------------
    Apply the following logic STRICTLY:

    1) IF the current closing note is EMPTY or BLANK:
    - Generate a complete Closing Note based on:
        a) Alert details
        b) Similar / historical closing notes (if available)
    - If no similar notes are available, rely on SOC best‑practice
        and security domain knowledge derived from the alert details.
    - Do NOT mention that the content was generated.

    2) IF the current closing note IS PROVIDED:
    - Treat it as the PRIMARY source of truth.
    - Normalize and standardize wording for SOC consistency.
    - Use similar notes ONLY as reference for phrasing and completeness.
    - Do NOT alter the analyst’s factual conclusions unless inconsistent
        with the alert context.

    3) IF similar / historical notes are EMPTY, irrelevant, or missing:
    - DO NOT reference or mention them.
    - Generate content using alert details and SOC investigative knowledge alone.

    --------------------------------------------------
    CONTENT RULES
    --------------------------------------------------
    - Preserve technical accuracy
    - Maintain professional, audit‑safe SOC tone
    - Do NOT copy historical content verbatim unless factually required
    - Do NOT introduce unsupported assumptions or new facts
    - Ensure alignment between Alert, Actions Taken, and Closure Justification
    - Do NOT mention similarity search, prior alerts, or history



    --------------------------------------------------
    REQUIRED OUTPUT FORMAT (STRICT)
    --------------------------------------------------
    Return response in the following structured JSON format:

    {{
    "Alert": "Brief description of the alert and what triggered it",
    "Disposition": "Final disposition such as True Positive / False Positive / Informational",
    "Impact": "Clear statement of security impact or explicitly state no impact",
    "Actions Taken": "Concise summary of investigation, validation, and remediation actions",
    "Closure Justification": "Reasoned justification for closing the alert aligned with findings"
    }}
    FINAL OUTPUT RULE (CRITICAL):
        - Output RAW JSON ONLY
        - DO NOT use markdown
        - DO NOT use ```json or ```
        - DO NOT include any text outside JSON
        - The response MUST begin with '{' and end with '}'

    --------------------------------------------------
    INPUT DATA
    --------------------------------------------------

    Alert Details:
    {similar_data['query']}

    Current Closing Note:
    {closing_note}

    Similar / Historical Closing Notes (Reference Only):
    {similar_data['matches']}

    --------------------------------------------------
    FINAL INSTRUCTION
    --------------------------------------------------
    Generate the Closing Note now.
    '''
    print("----inside fetch closing note recommendation--------")
    try:
        llm_response = invoke(
            prompt
        )
        
        # llm_response = ollama_invoke(prompt)
        print("-----------llm response for closing note recommendation-----------")
        print(llm_response)
        return json.loads(llm_response)

    except Exception as e:
        print(f"Exception occurred in fetch_closing_note_recommendation {str(e)}")
        raise