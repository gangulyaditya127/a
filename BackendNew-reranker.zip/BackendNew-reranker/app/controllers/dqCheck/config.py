import os
from dotenv import load_dotenv
load_dotenv()

class Config:
    
    LLM_USERNAME    = os.getenv("LLM_USERNAME")
    LLM_PASSWORD    = os.getenv("LLM_PASSWORD") 
    LLM_MODEL    = os.getenv("LLM_MODEL")  

    DIRECTORY_PATH=os.getenv('DIRECTORY_PATH')
    SEMANTIC_TOP_K = int(os.getenv("SEMANTIC_TOP_K", 10))
    BM25_TOP_K = int(os.getenv("BM25_TOP_K", 10))

    SEMANTIC_WEIGHT = float(os.getenv("SEMANTIC_WEIGHT", 0.7))
    KEYWORD_WEIGHT = float(os.getenv("KEYWORD_WEIGHT", 0.3))

    BM25_STORE_PATH = os.getenv("BM25_STORE_PATH")

    RERANKER_MODEL_PATH = os.getenv("RERANKER_MODEL_PATH")
    RERANKER_TOP_K = int(os.getenv("RERANKER_TOP_K", 5))

    MIN_SIMILARITY_THRESHOLD = float(
        os.getenv("MIN_SIMILARITY_THRESHOLD", 0.65)
)

    MIN_RERANKER_SCORE = float(
    os.getenv("MIN_RERANKER_SCORE", "0.50")
    )
    
    # Confidence classification for normalized reranker scores
    CONFIDENCE_HIGH_THRESHOLD = float(
    os.getenv("CONFIDENCE_HIGH_THRESHOLD", "0.80")
    )
    
    CONFIDENCE_MEDIUM_THRESHOLD = float(
    os.getenv("CONFIDENCE_MEDIUM_THRESHOLD", "0.60")
    )

