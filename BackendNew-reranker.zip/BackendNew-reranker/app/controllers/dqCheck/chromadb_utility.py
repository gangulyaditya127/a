
import psycopg2
from pgvector.psycopg2 import register_vector
from sentence_transformers import SentenceTransformer

# def search_similar_record(query: str, top_k: int = 3):
  
#     print("\n==================== search_similar_incident ================================\n")

#     # base_dir = os.getcwd()
#     vector_dir = os.path.join(Config.DIRECTORY_PATH, 'vector')

#     client = chromadb.PersistentClient(vector_dir)
#     collection = client.get_or_create_collection(name='my_collection_historical_crowdstrike')

#     print("query embedding")
#     docs = [query]
#     username, password = Config.LLM_USERNAME, Config.LLM_PASSWORD
#     # query_vector = embed__texts(docs, username, password)[0]
#     query_vector=embed_model.encode(query)
#     print("similarity search")
    
#     results = collection.query(
#         query_embeddings=[query_vector],
#         n_results=top_k,
#         include=["documents", "metadatas", "distances"]
#     )

#     # ---------------------------------------------------------
#     # 3. FORMAT RESULTS FOR LLM
#     # ---------------------------------------------------------
#     matches = []

    
#     if not results or not results.get("distances") or not results["distances"][0]:
#             return {
#                 "query": query,
#                 "matches": [],
#                 "reason": "No similar records found"
#             }

#     matches = []
#     MIN_SIMILARITY_THRESHOLD=0.65
#     # ------------------------------------------------------------------
#     # 3. Evaluate matches
#     # ------------------------------------------------------------------
#     for i, inc_id in enumerate(results["ids"][0]):
#         distance = float(results["distances"][0][i])
#         similarity = round(1 - distance, 3)

#         # ❌ Skip weak / irrelevant matches
#         if similarity < MIN_SIMILARITY_THRESHOLD:
#             continue

#         if similarity >= 0.85:
#             confidence = "High"
#         elif similarity >= 0.7:
#             confidence = "Medium"
#         else:
#             confidence = "Low"

#         matches.append({
#             "incident_id": inc_id,
#             "similarity_score": similarity,
#             "confidence": confidence,
#             "investigated_outcome": results["documents"][0][i],
#             "metadata": results["metadatas"][0][i],
#         })

#     # ------------------------------------------------------------------
#     # 4. Final guard — no good matches survived
#     # ------------------------------------------------------------------
#     if not matches:
#         return {
#             "query": query,
#             "matches": [],
#             "reason": "Query is not semantically related to historical records"
#         }

#     print("-------------similarity Search Completed-------------------")
#     return {
#         "query": query,
#         "matches": matches
#     }


# def search_similar_record_postgres(query: str, top_k: int = 3):
#     print("\n==================== PostgreSQL Similarity Search ================================\n")
    
#     # 1. Connection settings
#     db_params = {
#         "host": "localhost",
#         "database": "db1",
#         "user": "postgres",
#         "password": "admin",
#         "port": 5432
#     }
    
#     conn = psycopg2.connect(**db_params)
#     register_vector(conn)
#     cur = conn.cursor()

#     # 2. Generate Embedding for the incoming Query
#     print("Generating query embedding...")
#     query_vector = embed_model.encode(query)

#     # 3. Perform Vector Similarity Search in SQL
#     # <=> is the Cosine Distance operator in pgvector
#     # 1 - distance = Cosine Similarity
#     search_query = """
#         SELECT 
#             id, 
#             document, 
#             metadata, 
#             1 - (embedding <=> %s) AS similarity 
#         FROM crowdstrike_alerts
#         ORDER BY embedding <=> %s 
#         LIMIT %s;
#     """
    
#     print("Executing similarity search in Postgres...")
#     cur.execute(search_query, (query_vector, query_vector, top_k))
#     results = cur.fetchall()

#     # 4. Process and Format Results (Matching your logic)
#     matches = []
#     MIN_SIMILARITY_THRESHOLD = 0.65

#     for row in results:
#         inc_id, doc_content, metadata, similarity = row
#         similarity = round(float(similarity), 3)

#         # Skip weak matches
#         if similarity < MIN_SIMILARITY_THRESHOLD:
#             continue

#         # Confidence categorization
#         if similarity >= 0.85:
#             confidence = "High"
#         elif similarity >= 0.7:
#             confidence = "Medium"
#         else:
#             confidence = "Low"

#         matches.append({
#             "incident_id": str(inc_id),
#             "similarity_score": similarity,
#             "confidence": confidence,
#             "investigated_outcome": doc_content,
#             "metadata": metadata, # Postgres returns JSONB as a Python dict automatically
#         })

#     cur.close()
#     conn.close()

#     if not matches:
#         return {
#             "query": query,
#             "matches": [],
#             "reason": "Query is not semantically related to historical records"
#         }

#     print("------------- Postgres Similarity Search Completed -------------------")
#     return {
#         "query": query,
#         "matches": matches
#     }

import os
import json
import chromadb
from .config import Config
from langchain_core.documents import Document
from langchain_core.runnables import RunnableLambda
from langchain_classic.retrievers import EnsembleRetriever
from langchain_community.retrievers import BM25Retriever
from sentence_transformers import SentenceTransformer
from FlagEmbedding import FlagReranker

# Assuming DB imports are available
from app.controllers.dqCheck.pg_models import get_session, SourceConfig

reranker = FlagReranker(os.path.join(Config.DIRECTORY_PATH,'ms-marco-MiniLM-L-6-v2'), use_fp16=True)

def search_similar_record_postgres(query_text: dict, source_brand: str, filters: dict = None, top_k: int = 3):
    """
    Dynamic Hybrid Search (ChromaDB + BM25 + Reranker)
    """
    print(f"\n==================== Dynamic Hybrid Search for {source_brand} ================================\n")
    
    session = None
    try:
        session = get_session()
        config = session.query(SourceConfig).filter_by(source_brand=source_brand).first()
        
        if not config:
            return {"query": query_text, "matches": [], "reason": f"No routing config found for {source_brand}"}

        # 1. Extract the semantic search string
        search_string = query_text.get(config.search_content_key, "")
        if not search_string:
            search_string = json.dumps(query_text)

        # ---------------------------------------------------------
        # 2. LOAD BM25 CORPUS
        # ---------------------------------------------------------
        bm25_base_path = getattr(Config, 'BM25_STORE_PATH')
        bm25_file_path = os.path.join(bm25_base_path, config.bm25_folder, f"bm25_{config.bm25_folder}.json")

        corpus = []
        if os.path.exists(bm25_file_path):
            with open(bm25_file_path, "r", encoding="utf-8") as file:
                corpus = json.load(file)

        bm25_documents = [
            Document(
                page_content=str(item.get("page_content", "")).strip(),
                metadata={**item.get("metadata", {}), "id": str(item.get("id", ""))}
            )
            for item in corpus if str(item.get("page_content", "")).strip()
        ]

        bm25_retriever = None
        if bm25_documents:
            bm25_retriever = BM25Retriever.from_documents(bm25_documents)
            bm25_retriever.k = getattr(Config, 'BM25_TOP_K', 5)

        # ---------------------------------------------------------
        # 3. INITIALIZE CHROMADB
        # ---------------------------------------------------------
        vector_dir = os.path.join(Config.DIRECTORY_PATH, "vector")
        chroma_client = chromadb.PersistentClient(path=vector_dir)
        chroma_collection = chroma_client.get_collection(name=config.chroma_collection)

        # ---------------------------------------------------------
        # 4. DEFINE SEMANTIC SEARCH
        # ---------------------------------------------------------
        def semantic_search(search_query: str):
            try:
                # Generate embedding using the local sentence transformer
                query_vector = embed_model.encode(search_query).tolist()

                where_filter = None
                if filters:
                    valid_filters = [{f"{k}": {"$eq": str(v).strip()}} for k, v in filters.items() if v]
                    if len(valid_filters) > 1:
                        where_filter = {"$and": valid_filters}
                    elif len(valid_filters) == 1:
                        where_filter = valid_filters[0]

                semantic_top_k = min(getattr(Config, 'SEMANTIC_TOP_K', 5), chroma_collection.count())
                if semantic_top_k == 0: return []

                query_args = {
                    "query_embeddings": [query_vector],
                    "n_results": semantic_top_k,
                    "include": ["documents", "metadatas", "distances"]
                }
                if where_filter:
                    query_args["where"] = where_filter

                results = chroma_collection.query(**query_args)
                
                docs = results.get("documents", [[]])[0]
                metas = results.get("metadatas", [[]])[0]
                ids = results.get("ids", [[]])[0]
                dists = results.get("distances", [[]])[0]

                semantic_docs = []
                for idx, doc_id in enumerate(ids):
                    distance = float(dists[idx])
                    semantic_score = 1.0 - distance # Cosine similarity conversion
                    
                    if semantic_score < getattr(Config, 'MIN_SIMILARITY_THRESHOLD', 0.65):
                        continue
                        
                    doc_meta = metas[idx] if metas else {}
                    semantic_docs.append(Document(
                        page_content=docs[idx],
                        metadata={**doc_meta, "id": str(doc_id), "semantic_score": semantic_score, "retrieval_source": "semantic"}
                    ))
                return semantic_docs
            except Exception as e:
                print(f"Chroma DB search error: {e}")
                return []

        # ---------------------------------------------------------
        # 5. DEFINE KEYWORD SEARCH
        # ---------------------------------------------------------
        def keyword_search(search_query: str):
            if not bm25_retriever: return []
            try:
                results = bm25_retriever.invoke(search_query)
                filtered_docs = []
                for doc in results:
                    doc_meta = doc.metadata or {}
                    skip = False
                    if filters:
                        for k, v in filters.items():
                            if v and str(doc_meta.get(k, "")).strip().lower() != str(v).strip().lower():
                                skip = True
                                break
                    if not skip:
                        filtered_docs.append(Document(
                            page_content=doc.page_content, 
                            metadata={**doc_meta, "retrieval_source": "bm25"}
                        ))
                return filtered_docs
            except Exception as e:
                print(f"BM25 search error: {e}")
                return []

        # ---------------------------------------------------------
        # 6. ENSEMBLE & RERANK
        # ---------------------------------------------------------
        semantic_retriever = RunnableLambda(semantic_search)
        keyword_retriever = RunnableLambda(keyword_search)

        ensemble_retriever = EnsembleRetriever(
            retrievers=[semantic_retriever, keyword_retriever],
            weights=[getattr(Config, 'SEMANTIC_WEIGHT', 0.5), getattr(Config, 'KEYWORD_WEIGHT', 0.5)],
            id_key="id"
        )

        hybrid_documents = ensemble_retriever.invoke(search_string)
        hybrid_documents = hybrid_documents[:getattr(Config, "HYBRID_CANDIDATE_TOP_K", 10)]

        if not hybrid_documents:
            return {"query": query_text, "matches": [], "reason": "No matches found."}

        # Format pairs for the reranker
        reranker_pairs = [[search_string, doc.page_content] for doc in hybrid_documents]
        reranker_scores = reranker.compute_score(reranker_pairs, normalize=True)
        
        if isinstance(reranker_scores, (float, int)):
            reranker_scores = [reranker_scores]

        all_reranked = [
            {"document": doc, "reranker_score": float(score)}
            for doc, score in zip(hybrid_documents, reranker_scores)
        ]
        
        all_reranked.sort(key=lambda x: x["reranker_score"], reverse=True)

        reranked_results = [
            item for item in all_reranked 
        ][:top_k]

        # ---------------------------------------------------------
        # 7. FORMAT RESULTS
        # ---------------------------------------------------------
        matches = []
        for item in reranked_results:
            doc = item["document"]
            meta = doc.metadata or {}
            score = item["reranker_score"]

            confidence = "High" if score >= 0.85 else ("Medium" if score >= 0.70 else "Low")
            
            clean_metadata = {k: v for k, v in meta.items() if k not in ["semantic_score", "retrieval_source", "id"]}
            
            matches.append({
                "incident_id": meta.get("id", ""),
                "similarity_score": round(score, 5),
                "confidence": confidence,
                "investigated_outcome": doc.page_content,
                "metadata": clean_metadata
            })

        print("------------- Dynamic Search Completed -------------------")
        return {"query": query_text, "matches": matches}
        
    except Exception as e:
        print(f"Dynamic search error: {e}")
        return {"query": query_text, "matches": [], "reason": "Search failed", "error": str(e)}
    finally:
        if session:
            session.close()