from flask import Flask, request, jsonify, current_app, Blueprint, json,Response,make_response
import os, sys, traceback
from datetime import datetime
import re
import yaml
import chromadb
from .config import Config
from app.controllers.dqCheck.validation import validate_investigation,validate_note
from app.controllers.dqCheck.recommendation import fetch_closing_note_recommendation,fetch_investigation_recommendation

from app.controllers.dqCheck.chromadb_utility import search_similar_record_postgres

app = Blueprint("dqCheck", __name__, url_prefix="/dqCheck")

@app.route('/validateClosingNote',methods=['POST'])
def validat_closing_note():
  
    """
    Validate Closing Note Content
    ---
    tags:
      - dq check
    summary: Validate SOC closing note against alert context
    description: >
      This API validates whether the provided closing note is relevant
      to the given alert details and follows the expected format.
    consumes:
      - application/json
    produces:
      - application/json
    parameters:
      - in: body
        name: body
        required: true
        schema:
          type: object
          required:
            - Alert_details
            - closing_note
          properties:
            Alert_details:
              type: object
              description: Alert metadata and detection details
              example:
                CrowdStrike:
                  Detection:
                    Technique: Malicious Macro
            closing_note:
              type: string
              description: Analyst-written closing note to be validated
              example: |
                Alert: Suspicious Excel macro execution
                Disposition: True Positive
                Impact: Medium
                Actions Taken: Macro removed
                Closure Justification: Threat mitigated
    responses:
      200:
        description: Validation result
        schema:
          type: object
          properties:
            classification:
              type: string
              example: RELEVANT_BUT_FORMAT_INVALID
            content_relevant:
              type: boolean
              example: false
            explanation:
              type: string
            format_valid:
              type: boolean
      400:
        description: Validation error
    """

    data=request.get_json()
    alert_details=data.get('Alert_details')
    closing_note=data.get('closing_note')    
    try:
        response=validate_note(alert_details,closing_note)
        return jsonify(response),200
    #     return jsonify({
    #     "classification": "RELEVANT_BUT_FORMAT_INVALID",
    #     "content_relevant": True,
    #     "explanation": "The Close Note content is relevant to the provided Alert Description and Recommendations, but it does not follow the required format with the specified section headings (Alert, Disposition, Impact, Actions Taken, Closure Justification).",
    #     "format_valid": True
    # })
    except Exception as e:
        return jsonify({"msg":f"Error in validation of close note {str(e)}"}),400

@app.route('/validateInvestigationAnalysis',methods=['POST'])
def validate_investigation_analysis():
  
    """
    Validate Investigation Analysis
    ---
    tags:
      - dq check
    summary: Validate investigation analysis quality
    description: >
      Checks whether the investigation analysis references
      the alert details correctly and follows expected SOC standards.
    consumes:
      - application/json
    produces:
      - application/json
    parameters:
      - in: body
        name: body
        required: true
        schema:
          type: object
          required:
            - Alert_details
            - investigation_analysis
          properties:
            Alert_details:
              type: object
              description: Full alert context used for validation
            investigation_analysis:
              type: string
              description: SOC investigation write-up
              example: |
                The alert was triggered due to execution of an Excel macro.
                File hash analysis confirmed malicious behavior.
    responses:
      200:
        description: Validation output
        schema:
          type: object
          properties:
            classification:
              type: string
              example: INVALID_AND_IRRELEVANT
            content_relevant:
              type: boolean
            explanation:
              type: string
            format_valid:
              type: boolean
      400:
        description: Validation error
    """

    data=request.get_json(force=True)
    alert_details=data.get('Alert_details')
    investigation=data.get('investigation_analysis')    
    try:
        response=validate_investigation(alert_details,investigation)

        return jsonify(response),200
    #     return jsonify({
    #     "classification": "INVALID_AND_IRRELEVANT",
    #     "content_relevant": True,
    #     "explanation": "The Investigation Analysis does not reference the provided alert description or recommendations. It discusses activity associated with git.exe, which is unrelated to the alert about an Office file with a malicious macro. Additionally, the findings and conclusions are inconsistent with the alert's context and recommendations.",
    #     "format_valid": False
    # })
    except Exception as e:
        return jsonify({"msg":f"Error in validation of investigation Analysis {str(e)}"}),400

# @app.route('/recommendInvestigationAnalysis',methods=['POST'])
# def recommendInvestigationAnalysis():
    
#     """
#     Recommend Investigation Analysis
#     ---
#     tags:
#       - dq check
#     summary: Generate investigation analysis recommendation
#     description: >
#       Uses alert details and similarity search to generate
#       a recommended Investigation Analysis for SOC analysts.
#     consumes:
#       - application/json
#     produces:
#       - application/json
#     parameters:
#       - in: body
#         name: body
#         required: true
#         schema:
#           type: object
#           required:
#             - Alert_details
#           properties:
#             Alert_details:
#               type: object
#               description: CrowdStrike detection payload
#             investigation_analysis:
#               type: string
#               description: Existing investigation text (optional)
#     responses:
#       200:
#         description: Investigation recommendation
#         schema:
#           type: object
#           properties:
#             success:
#               type: boolean
#               example: true
#             investigation_recommendation:
#               type: object
#               description: AI‑generated investigation analysis
#       400:
#         description: Recommendation failure
#     """

#     data=request.get_json(force=True)
#     payload = data.get("Alert_details")
#     # print(payload)
#     detection = payload.get("CrowdStrike", {}).get("Detection", {})

#     # ---------------------------------------------------------
#     # 1. REQUIRED CORE FIELDS
#     # ---------------------------------------------------------
#     tactic = detection.get("Tactic", "")
#     technique = detection.get("Technique", "")
#     filename = detection.get("FileName", "")
#     description = detection.get("Description", "")

#     # ---------------------------------------------------------
#     # 3. COMMAND LINE & FILEPATH EXTRACTION
#     # ---------------------------------------------------------
#     cmdline = detection.get("cmdline", "")


#     # ---------------------------------------------------------
#     # 4. IOC (MACRO INDICATORS)
#     # ---------------------------------------------------------
#     macros = detection.get("macros", {})

#     # ---------------------------------------------------------
#     # 6. FINAL QUERY TEXT (VECTOR INPUT)
#     # ---------------------------------------------------------
    
#     query_text = {
#         "Tactic":tactic,
#         "technique":technique,
#         "filename":filename,
#         "description":description,
#         "cmdline":cmdline,
#         "macros_details":macros,
#         "fileHash":detection.get("SHA256",""),
#         "ioc_value":detection.get("IOCValue",""),
#         "ioc_type":detection.get("IOCType",""),
#         "parent_filename":detection.get("parent_details", {}).get("filename", ""),
#         "parent_filepath":detection.get("parent_details", {}).get("filepath", ""),
#         "parent_cmdline":detection.get("parent_details", {}).get("parent_cmdline", ""),
#         "parent_filehash":detection.get("parent_details", {}).get("parent_sha256", ""),
#         "grandparent_filename":detection.get("grandparent_details", {}).get("filename", ""),
#         "grandparent_filepath":detection.get("grandparent_details", {}).get("filepath", ""),
#         "grandparent_cmdline":detection.get("grandparent_details", {}).get("cmdline", ""),"grandparent_filehash":detection.get("grandparent_details", {}).get("sha256", ""),
#         "investigation_analysis":data.get("investigation_analysis")
#     }
        
#     try:
#         print("----------query_text-----------------")
#         print(query_text)
#         # response=search_similar_record(json.dumps(query_text))
#         response=search_similar_record_postgres(json.dumps(query_text))
#         print("output of similarity search for investigation")
#         print(response)
#         recommendation=fetch_investigation_recommendation(response,data.get('investigation_analysis'))
#         return jsonify({"success":True,'investigation_recommendation':recommendation}),200

#     except Exception as e:
#         return jsonify({"success":False,"msg":f"Error generating recommendation for the investigation {str(e)}"}),400

# @app.route('/recommendClosingNote',methods=['POST'])
# def recommendClosingNote():
    
#     """
#     Recommend Closing Note
#     ---
#     tags:
#       - dq check
#     summary: Generate SOC closing note recommendation
#     description: >
#       Generates a structured and compliant closing note based on
#       alert details and similarity search.
#     consumes:
#       - application/json
#     produces:
#       - application/json
#     parameters:
#       - in: body
#         name: body
#         required: true
#         schema:
#           type: object
#           required:
#             - Alert_details
#             - closing_note
#           properties:
#             Alert_details:
#               type: object
#               description: Alert and detection context
#             closing_note:
#               type: string
#               description: Analyst draft closing note
#     responses:
#       200:
#         description: Closing note recommendation
#         schema:
#           type: object
#           properties:
#             success:
#               type: boolean
#             close_note_recommendation:
#               type: object
#               properties:
#                 Alert:
#                   type: string
#                 Disposition:
#                   type: string
#                 Impact:
#                   type: string
#                 Actions Taken:
#                   type: string
#                 Closure Justification:
#                   type: string
#       400:
#         description: Recommendation error
#     """

#     data=request.get_json(force=True)
#     payload = data.get("Alert_details")
#     # print(payload)
#     detection = payload.get("CrowdStrike", {}).get("Detection", {})

#     # ---------------------------------------------------------
#     # 1. REQUIRED CORE FIELDS
#     # ---------------------------------------------------------
#     tactic = detection.get("Tactic", "")
#     technique = detection.get("Technique", "")
#     filename = detection.get("FileName", "")
#     description = detection.get("Description", "")

#     # ---------------------------------------------------------
#     # 3. COMMAND LINE & FILEPATH EXTRACTION
#     # ---------------------------------------------------------
#     cmdline = detection.get("cmdline", "")


#     # ---------------------------------------------------------
#     # 4. IOC (MACRO INDICATORS)
#     # ---------------------------------------------------------
#     macros = detection.get("macros", {})

#     # ---------------------------------------------------------
#     # 6. FINAL QUERY TEXT (VECTOR INPUT)
#     # ---------------------------------------------------------
    
#     query_text = {
#         "Tactic":tactic,
#         "technique":technique,
#         "filename":filename,
#         "description":description,
#         "cmdline":cmdline,
#         "macros_details":macros,
#         "fileHash":detection.get("SHA256",""),
#         "ioc_value":detection.get("IOCValue",""),
#         "ioc_type":detection.get("IOCType",""),
#         "parent_filename":detection.get("parent_details", {}).get("filename", ""),
#         "parent_filepath":detection.get("parent_details", {}).get("filepath", ""),
#         "parent_cmdline":detection.get("parent_details", {}).get("parent_cmdline", ""),
#         "parent_filehash":detection.get("parent_details", {}).get("parent_sha256", ""),
#         "grandparent_filename":detection.get("grandparent_details", {}).get("filename", ""),
#         "grandparent_filepath":detection.get("grandparent_details", {}).get("filepath", ""),
#         "grandparent_cmdline":detection.get("grandparent_details", {}).get("cmdline", ""),"grandparent_filehash":detection.get("grandparent_details", {}).get("sha256", ""),
#         "closing_note":data.get("closing_note")
#     }
        
#     try:
#         print("------------query_text-----------------")
#         print(query_text)
#         # response=search_similar_record(json.dumps(query_text))
#         response=search_similar_record_postgres(json.dumps(query_text))
#         print("output of similarity search for investigation")
#         print(response)
#         recommendation=fetch_closing_note_recommendation(response,data.get('closing_note'))
#         return jsonify({"success":True,'close_note_recommendation':recommendation}),200
       
#     except Exception as e:
#         return jsonify({"success":False,"msg":f"Error generating recommendation for the close note {str(e)}"}),400

import sys
import json
from flask import request, jsonify

# Helper function to dynamically extract paths
def extract_payload_field(record, path):
    keys = path.split('.')
    val = record
    for k in keys:
        if isinstance(val, dict):
            val = val.get(k)
            if isinstance(val, str) and val.strip().startswith(('{', '[')):
                try:
                    val = json.loads(val)
                except json.JSONDecodeError:
                    pass
        else:
            return ""
        if val is None:
            return ""
    return val

@app.route('/recommendInvestigationAnalysis', methods=['POST'])
def recommendInvestigationAnalysis():
    """
    Recommend Investigation Analysis (Dynamically Routed)
    """
    data = request.get_json(force=True)
    payload = data.get("Alert_details", {})
    
    # ---------------------------------------------------------
    # 1. IDENTIFY SOURCE BRAND DYNAMICALLY
    # ---------------------------------------------------------
    source_brand = payload.get("sourceBrand")

    session = None
    try:
        # Import your db session maker here if not globally available
        from app.controllers.dqCheck.pg_models import get_session, SourceConfig
        session = get_session()
        
        # ---------------------------------------------------------
        # 2. FETCH DB CONFIGURATION
        # ---------------------------------------------------------
        config = session.query(SourceConfig).filter_by(source_brand=source_brand).first()
        if not config:
            return jsonify({"success": False, "msg": f"No configuration found in DB for {source_brand}."}), 500

        # ---------------------------------------------------------
        # 3. DYNAMICALLY BUILD QUERY TEXT DICTIONARY
        # ---------------------------------------------------------
        query_text = {}
        for target_key, json_path in config.query_text_mapping.items():
            query_text[target_key] = extract_payload_field(payload, json_path)

        # Include investigation_analysis from the root data object
        query_text["investigation_analysis"] = data.get("investigation_analysis", "")

        # ---------------------------------------------------------
        # 4. DYNAMICALLY BUILD FILTERS DICTIONARY
        # ---------------------------------------------------------
        search_filters = {}
        for filter_key in config.search_filter_keys:
            val = query_text.get(filter_key)
            if val:
                search_filters[filter_key] = val

        # ---------------------------------------------------------
        # 5. EXECUTE DYNAMIC HYBRID SEARCH
        # ---------------------------------------------------------
        print("----------query_text-----------------")
        print(query_text)
        
        # Pass the full dictionaries + source_brand to the updated utility function
        response = search_similar_record_postgres(
            query_text=query_text,
            source_brand=source_brand,
            filters=search_filters
        )
        
        print("output of similarity search for investigation")
        print(response)
        
        recommendation = fetch_investigation_recommendation(response, data.get('investigation_analysis'))
        return jsonify({"success": True, 'investigation_recommendation': recommendation}), 200

    except Exception as e:
        print(str(e))
        exc_type, exc_value, tb = sys.exc_info()
        return jsonify({
            "success": False, 
            "msg": f"Error generating recommendation: {str(e)} at line {tb.tb_lineno}"
        }), 400
    finally:
        if session:
            session.close()
  
@app.route('/recommendClosingNote', methods=['POST'])
def recommendClosingNote():
    """
    Recommend Closing Note (Dynamically Routed)
    ---
    tags:
      - dq check
    summary: Generate SOC closing note recommendation
    description: >
      Generates a structured and compliant closing note based on
      alert details and similarity search dynamically routed via DB config.
    consumes:
      - application/json
    produces:
      - application/json
    """

    data = request.get_json(force=True)
    payload = data.get("Alert_details", {})
    
    # ---------------------------------------------------------
    # 1. IDENTIFY SOURCE BRAND DYNAMICALLY
    # ---------------------------------------------------------
    source_brand = payload.get("sourceBrand")

    session = None
    try:
        from app.controllers.dqCheck.pg_models import get_session, SourceConfig
        session = get_session()
        
        # ---------------------------------------------------------
        # 2. FETCH DB CONFIGURATION
        # ---------------------------------------------------------
        config = session.query(SourceConfig).filter_by(source_brand=source_brand).first()
        if not config:
            return jsonify({"success": False, "msg": f"No configuration found in DB for {source_brand}."}), 500

        # ---------------------------------------------------------
        # 3. DYNAMICALLY BUILD QUERY TEXT DICTIONARY
        # ---------------------------------------------------------
        query_text = {}
        for target_key, json_path in config.query_text_mapping.items():
            query_text[target_key] = extract_payload_field(payload, json_path)

        # Include the analyst's draft closing note from the root data object
        draft_closing_note = data.get("closing_note", "")
        query_text["closing_note"] = draft_closing_note

        # ---------------------------------------------------------
        # 4. DYNAMICALLY BUILD FILTERS DICTIONARY
        # ---------------------------------------------------------
        search_filters = {}
        for filter_key in config.search_filter_keys:
            val = query_text.get(filter_key)
            if val:
                search_filters[filter_key] = val

        # ---------------------------------------------------------
        # 5. EXECUTE DYNAMIC HYBRID SEARCH
        # ---------------------------------------------------------
        print("------------query_text-----------------")
        print(query_text)
        
        # Pass the full dictionaries + source_brand to the updated utility function
        response = search_similar_record_postgres(
            query_text=query_text,
            source_brand=source_brand,
            filters=search_filters
        )
        
        print("output of similarity search for close note")
        print(response)
        
        # Pass the search response and the draft note to the recommendation LLM call
        recommendation = fetch_closing_note_recommendation(response, draft_closing_note)
        
        return jsonify({"success": True, 'close_note_recommendation': recommendation}), 200

    except Exception as e:
        print(str(e))
        exc_type, exc_value, tb = sys.exc_info()
        return jsonify({
            "success": False, 
            "msg": f"Error generating recommendation for the close note {str(e)} at line {tb.tb_lineno}"
        }), 400
    finally:
        if session:
            session.close()
