from sqlalchemy import Column, String, JSON
from sqlalchemy.orm import declarative_base
import urllib.parse
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker


SQLALCHEMY_DATABASE_URL = f"postgresql+psycopg2://postgres:StrongPassword123@10.73.74.37:5432/DIS"

engine = create_engine(SQLALCHEMY_DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

def get_session():
    return SessionLocal()
   

Base = declarative_base()

class SourceConfig(Base):
    __tablename__ = "source_configs"

    source_brand = Column(String(100), primary_key=True)
    chroma_collection = Column(String(100), nullable=False)
    bm25_folder = Column(String(100), nullable=False)
    embedding_fields = Column(JSON, nullable=False) 
    metadata_fields = Column(JSON, nullable=False)
    
    # NEW COLUMNS FOR RETRIEVAL ROUTING
    query_text_mapping = Column(JSON, nullable=False)
    search_filter_keys = Column(JSON, nullable=False)