from flask import Flask, request, jsonify, current_app, Blueprint, json,Response,make_response
import os, sys, traceback
from datetime import datetime
from flask_cors import CORS, cross_origin
from pathlib import Path
import time
from .categorise import get_resolution,fetch_recommendation_filtered
import json
import re
from typing import List
from .config import Config
import sys
import pandas as pd
from app.controllers.resolution_recommender.chromadb_utility import (
    # save_to_postgres,
    save_to_chromadb
)


import pdfkit
import html

import yaml

appy = Blueprint("resolution", __name__, url_prefix="/resolution")

ALLOWED_EXTENSIONS = {".xlsx", ".xls"}


def save_file(file_storage, dest_dir, subfolder):
    dest_dir.mkdir(parents=True, exist_ok=True)
    original_name = Path(file_storage.filename).stem
    ext = Path(file_storage.filename).suffix.lower()
    timestamp = time.strftime("%Y%m%d_%H%M%S")  # e.g., 20251118_184500
    new_filename = f"{subfolder}_{timestamp}{ext}"
    file_path = dest_dir / new_filename
    file_storage.save(file_path)
    return new_filename


def allowed_file(filename):
    return Path(filename).suffix.lower() in ALLOWED_EXTENSIONS


@appy.route("/health", methods=["GET"])
def health():
    """
    Health check endpoint
    ---
    tags:
      - Resolution Recommender
    responses:
      200:
        description: Returns the health status of the API
    """
    return jsonify({"status": "ok", "time": datetime.utcnow().isoformat()}), 200

# from flask import Flask, render_template, send_file
# from weasyprint import HTML
# import io
@appy.route('/uploadData',methods=['POST'])
def uploadData():
    """
    Upload historical json data to ChromaDB
    ---
    tags:
      - Resolution Recommender
    consumes:
      - multipart/form-data
    
    

    parameters:
      - name: file
        in: formData
        type: file
        required: true
        description: The json file (.json) to upload
    responses:
      200:
        description: File uploaded successfully
      400:
        description: Invalid file format or missing file
    """
 
    if 'file' not in request.files:
        return jsonify({"status": "failed", "error": "No file part"}), 400
        
    file = request.files['file']
    if file.filename == '':
        return jsonify({"status": "failed", "error": "No selected file"}), 400
        
    if not file.filename.endswith('.json'):
        return jsonify({"status": "failed", "error": "Only JSON files are supported"}), 400

    try:
        # Load JSON directly from the request
        data = json.load(file)
        
        # Convert to Pandas DataFrame to align with the existing processing pipeline
        df = pd.DataFrame(data)
        
        # Execute processing, embedding, and storage logic
        result = save_to_chromadb(df)
        
        if result.get("status") == "success":
            return jsonify(result), 200
        else:
            return jsonify(result), 500
            
    except Exception as e:
        return jsonify({"status": "failed", "error": str(e)}), 500

       


        

    except Exception as e:
        print(f"Error processing historical data: {str(e)}")
        return jsonify({"success":False,"msg":f"file upload unsuccessful {str(e)}"}),400
import sys
import json
from flask import request, jsonify
from app.controllers.resolution_recommender.pg_models import get_session,SourceConfig

def extract_payload_field(record, path):
    """Safely extracts values from nested dictionaries, preserving entire dicts if targeted."""
    keys = path.split('.')
    val = record
    for k in keys:
        if isinstance(val, dict):
            val = val.get(k)
        else:
            return ""
        if val is None:
            return ""
    return val

@appy.route('/recommend', methods=['POST'])
def resolution_recommender():
    payload = request.get_json(force=True)
    
    # ---------------------------------------------------------
    # 1. IDENTIFY SOURCE BRAND DYNAMICALLY
    # ---------------------------------------------------------
    source_brand = payload.get("sourceBrand")
    

    session = None
    try:
        session = get_session()
        
        # ---------------------------------------------------------
        # 2. FETCH DB CONFIGURATION
        # ---------------------------------------------------------
        config = session.query(SourceConfig).filter_by(source_brand=source_brand).first()
        if not config:
            return jsonify({"error": f"No configuration found in DB for {source_brand}."}), 500

        # ---------------------------------------------------------
        # 3. DYNAMICALLY BUILD QUERY TEXT DICTIONARY
        # ---------------------------------------------------------
        query_text = {}
        for target_key, json_path in config.query_text_mapping.items():
            query_text[target_key] = extract_payload_field(payload, json_path)

        # ---------------------------------------------------------
        # 4. DYNAMICALLY BUILD FILTERS DICTIONARY
        # ---------------------------------------------------------
        # This dynamically captures whatever keys were specified in the database
        search_filters = {}
        for filter_key in config.search_filter_keys:
            val = query_text.get(filter_key)
            if val:
                search_filters[filter_key] = val
        print("------query text------")          
        print(query_text)
        # ---------------------------------------------------------
        # 5. EXECUTE SEARCH & PASS FULL DICTIONARIES
        # ---------------------------------------------------------
        # Note: fetch_recommendation_filtered must be updated to accept `filters` as a dict
        response = fetch_recommendation_filtered(
            query_text=json.dumps(query_text), 
            source_brand=source_brand,
            filters=search_filters
        )
        
        print("-------------Output of Similarity Search------------------")
        print(response.get('matches', []))
        
        llm_response = get_resolution(response)
        
        return jsonify(llm_response)
        # return jsonify({})
    
    except Exception as e:
        print(str(e))
        exc_type, exc_value, tb = sys.exc_info()
        return (
            jsonify(
                {
                    "error": f"Error at line no {tb.tb_lineno}",
                    "message": str(e),
                }
            ),
            500,
        )
    finally:
        if session:
            session.close()




