import os
import json
import psycopg2
import pdfplumber
from pgvector.psycopg2 import register_vector
from sentence_transformers import SentenceTransformer
from langchain_core.documents import Document
from langchain_text_splitters import RecursiveCharacterTextSplitter
from config import Config
from common_func import invoke

# --- CONFIGURATION ---


DIRECTORY_PATH = "C:/Users/2856265/Desktop/soc/raw_data_training"  # Path where 'all-MiniLM-L6-v2' is stored

DB_PARAMS = {
        "host": "localhost",
        "port": 5433,
        "dbname": "db1",
        "user": "postgres",
        "password": "Anshuman@02"
    }
PDF_PATH = r"C:/Users/2856265/Desktop/PageIndex-main/examples/documents/2023-annual-report-truncated.pdf"
# --- CORE FUNCTIONS ---

def get_db_connection():
    """Establishes and returns a connection to PostgreSQL."""
    conn = psycopg2.connect(**DB_PARAMS)
    # Register pgvector for this connection
    register_vector(conn)
    return conn

def load_embedding_model():
    """Loads the sentence transformer model."""
    model_path = os.path.join(DIRECTORY_PATH, 'all-MiniLM-L6-v2')
    # If the local path doesn't exist, it will try to download from HuggingFace
    return SentenceTransformer(model_path if os.path.exists(model_path) else "sentence-transformers/all-MiniLM-L6-v2")

def extract_and_chunk_pdf(pdf_path):
    """Extracts text from PDF and splits into chunks."""
    documents = []
    with pdfplumber.open(pdf_path) as pdf:
        for i, page in enumerate(pdf.pages):
            text = page.extract_text()
            if text:
                documents.append(Document(page_content=text, metadata={"page": i + 1}))

    splitter = RecursiveCharacterTextSplitter(
        chunk_size=800,
        chunk_overlap=100,
        separators=["\n\n", "\n", ".", " ", ""]
    )
    return splitter.split_documents(documents)

def ingest_documents(chunks, embed_model, conn):
    """Generates embeddings and stores chunks in Postgres."""
    cur = conn.cursor()
    print(f"Starting ingestion of {len(chunks)} chunks...")
    try:
        for i, chunk in enumerate(chunks):
            content = chunk.page_content
            metadata = json.dumps(chunk.metadata)
            # Generate embedding
            embedding = embed_model.encode(content, normalize_embeddings=True).tolist()
            
            # Insert with Full Text Search tokens
            query = """
                INSERT INTO pdf_chunks (content, metadata, embedding, fts_tokens)
                VALUES (%s, %s, %s, to_tsvector('english', %s))
            """
            cur.execute(query, (content, metadata, embedding, content))
            
            if (i + 1) % 10 == 0:
                print(f"Stored {i + 1}/{len(chunks)} chunks...")
        
        conn.commit()
        print("Successfully ingested all documents.")
    except Exception as e:
        print(f"Error during ingestion: {e}")
        conn.rollback()
    finally:
        cur.close()

def hybrid_search(user_query, embed_model, conn, limit=5):
    """Performs RRF-based hybrid search (Semantic + Keyword)."""
    cur = conn.cursor()
    query_embedding = embed_model.encode([user_query], normalize_embeddings=True)[0]
    
    k_constant = 60   #this constant is added in denominator to reduce gap between search results.. 
    hybrid_query = """
    WITH semantic_search AS (
        SELECT id, ROW_NUMBER() OVER (ORDER BY embedding <=> %s::vector) as rank
        FROM pdf_chunks
        ORDER BY embedding <=> %s::vector
        LIMIT 50
    ),
    keyword_search AS (
        SELECT id, ROW_NUMBER() OVER (ORDER BY ts_rank_cd(fts_tokens, plainto_tsquery('english', %s)) DESC) as rank
        FROM pdf_chunks
        WHERE fts_tokens @@ plainto_tsquery('english', %s)
        LIMIT 50
    )
    SELECT 
        p.content, 
        p.metadata,
        COALESCE(1.0 / (%s + s.rank), 0.0) + COALESCE(1.0 / (%s + k_s.rank), 0.0) AS combined_score
    FROM pdf_chunks p
    LEFT JOIN semantic_search s ON p.id = s.id
    LEFT JOIN keyword_search k_s ON p.id = k_s.id
    WHERE s.id IS NOT NULL OR k_s.id IS NOT NULL
    ORDER BY combined_score DESC
    LIMIT %s;
    """
    
    try:
        cur.execute(hybrid_query, (
            query_embedding.tolist(), query_embedding.tolist(),
            user_query, user_query,
            k_constant, k_constant, limit
        ))
        return cur.fetchall()
    finally:
        cur.close()

def create_llm_prompt(query, retrieval_results):
    """Builds the final prompt for the LLM."""
    context_sections = []
    for i, r in enumerate(retrieval_results):
        content, metadata, score = r
        page = metadata.get('page', 'N/A')
        context_sections.append(f"--- DATA CHUNK {i+1} (Source: Page {page}) ---\n{content}")

    context_str = "\n\n".join(context_sections)
    return f"""
        ### INSTRUCTION
        You are a highly accurate document assistant. Your task is to answer the USER QUESTION using ONLY the provided DOCUMENT CONTEXT below. 

        ### CONSTRAINTS
        - If the answer is not contained within the context, state: "I'm sorry, but the provided document does not contain enough information to answer this question."
        - Do not use outside knowledge.
        - Always cite the page number (e.g., "As stated on page 5...").

        ### DOCUMENT CONTEXT
        {context_str}

        ### USER QUESTION
        {query}

        ### FINAL ANSWER:
        """


# --- MAIN EXECUTION ---
if __name__ == "__main__":
    # 1. Initialize
    db_conn = get_db_connection()
    model = load_embedding_model()

    # 2. Ingestion (Run this once or wrap in a check)
    # chunks = extract_and_chunk_pdf(PDF_PATH)
    # ingest_documents(chunks, model, db_conn)

    # 3. Query Phase
    user_query = "What is Crypto-Asset Supervision?"
    results = hybrid_search(user_query, model, db_conn)
    
    if results:
        final_prompt = create_llm_prompt(user_query, results)
        answer = invoke(final_prompt,"152459","Surajit@152459","gpt-4o")
        # answer = invoke("what can you do","152459","Surajit@15245","gpt-4o")
        print("\n--- FINAL ANSWER ---")
        print(answer)
    else:
        print("No relevant context found.")

    db_conn.close()