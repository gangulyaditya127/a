
import json
import os
import chromadb
from .common_func import embed_texts,invoke
from .config import Config

from typing import Dict, List
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import joblib
from sentence_transformers import SentenceTransformer
from FlagEmbedding import FlagReranker
from langchain_core.documents import Document
from langchain_core.runnables import RunnableLambda
from langchain_classic.retrievers import EnsembleRetriever
from langchain_community.retrievers import BM25Retriever
reranker = FlagReranker(
    os.path.join(Config.DIRECTORY_PATH,'ms-marco-MiniLM-L-6-v2'),
    use_fp16=True
)

import psycopg2
# from pgvector.psycopg2 import register_vector

# db_params = {
#         "host": "localhost",
#         "database": "db2",
#         "user": "postgres",
#         "password": "admin",
#         "port": 5432
#     }
# def search_similar_record_postgres(query: str, top_k: int = 3):
#     print("\n==================== PostgreSQL Similarity Search ================================\n")
    
#     # 1. Connection settings
#     # db_params = {
#     #     "host": "localhost",
#     #     "database": "db1",
#     #     "user": "postgres",
#     #     "password": "Anshuman@02",
#     #     "port": 5433
#     # }
    
#     conn = psycopg2.connect(**db_params)
#     register_vector(conn)
#     cur = conn.cursor()

#     # 2. Generate Embedding for the incoming Query
#     print("Generating query embedding...")
#     query_vector = embed_model.encode(query)

#     # 3. Perform Vector Similarity Search in SQL
#     # <=> is the Cosine Distance operator in pgvector
#     # 1 - distance = Cosine Similarity
#     search_query = """
#         SELECT 
#             id, 
#             document, 
#             metadata, 
#             1 - (embedding <=> %s) AS similarity 
#         FROM crowdstrike_alerts
#         ORDER BY embedding <=> %s 
#         LIMIT %s;
#     """
    
#     print("Executing similarity search in Postgres...")
#     cur.execute(search_query, (query_vector, query_vector, top_k))
#     results = cur.fetchall()

#     # 4. Process and Format Results (Matching your logic)
#     matches = []
#     MIN_SIMILARITY_THRESHOLD = 0.65

#     for row in results:
#         inc_id, doc_content, metadata, similarity = row
#         similarity = round(float(similarity), 3)

#         # Skip weak matches
#         if similarity < MIN_SIMILARITY_THRESHOLD:
#             continue

#         # Confidence categorization
#         if similarity >= 0.85:
#             confidence = "High"
#         elif similarity >= 0.7:
#             confidence = "Medium"
#         else:
#             confidence = "Low"

#         matches.append({
#             "incident_id": str(inc_id),
#             "similarity_score": similarity,
#             "confidence": confidence,
#             "investigated_outcome": doc_content,
#             "metadata": metadata, # Postgres returns JSONB as a Python dict automatically
#         })

#     cur.close()
#     conn.close()

#     if not matches:
#         return {
#             "query": query,
#             "matches": [],
#             "reason": "Query is not semantically related to historical records"
#         }

#     print("------------- Postgres Similarity Search Completed -------------------")
#     return {
#         "query": query,
#         "matches": matches
#     }
# def fetch_recommendation(query):
#     result=search_similar_record_postgres(query)
#     return result

# def search_filtered_record(
#     query: str,
#     tactic_filter=None,
#     tech_filter=None,
#     top_k=5
# ):
#     print(
#         "search_filtered_record function called...................."
#         f"{tactic_filter} and {tech_filter}"
#     )
#     with open(
#     Config.BM25_STORE_PATH,
#     "r",
#     encoding="utf-8"
# ) as f:
#         corpus = json.load(f)

#     documents = [
#         Document(
#             page_content=item["page_content"],
#             metadata=item["metadata"]
#         )
#         for item in corpus
#     ]

#     bm25_retriever = BM25Retriever.from_documents(documents)

#     bm25_retriever.k = Config.BM25_TOP_K
#     conn = None
#     cur = None

#     try:
#         # ---------------------------------------------------------
#         # Semantic search function for PGVector
#         # ---------------------------------------------------------
#         def semantic_search(search_query: str):
#             semantic_conn = None
#             semantic_cur = None

#             try:
#                 semantic_conn = psycopg2.connect(**db_params)
#                 register_vector(semantic_conn)
#                 semantic_cur = semantic_conn.cursor()

#                 print("Postgres connection established....................")

#                 query_vector = embed_model.encode(search_query)

#                 base_query = """
#                     SELECT
#                         id,
#                         document,
#                         metadata,
#                         1 - (embedding <=> %s) AS similarity
#                     FROM crowdstrike_alerts
#                     WHERE 1 = 1
#                 """

#                 params = [query_vector]

#                 if tactic_filter:
#                     base_query += """
#                         AND LOWER(metadata->>'tactic') = LOWER(%s)
#                     """
#                     params.append(tactic_filter)

#                 if tech_filter:
#                     base_query += """
#                         AND LOWER(metadata->>'technique') = LOWER(%s)
#                     """
#                     params.append(tech_filter)

#                 base_query += """
#                     ORDER BY embedding <=> %s
#                     LIMIT %s;
#                 """

#                 params.extend([
#                     query_vector,
#                     Config.SEMANTIC_TOP_K
#                 ])

#                 semantic_cur.execute(
#                     base_query,
#                     tuple(params)
#                 )

#                 semantic_results = semantic_cur.fetchall()

#                 semantic_documents = []

#                 for row in semantic_results:
#                     inc_id, doc_content, metadata, similarity = row

#                     metadata = metadata or {}
#                     similarity = float(similarity)

#                     # Keep semantic threshold only for PGVector results.
#                     if similarity < Config.MIN_SIMILARITY_THRESHOLD:
#                         continue

#                     semantic_documents.append(
#                         Document(
#                             page_content=doc_content,
#                             metadata={
#                                 **metadata,
#                                 "id": str(inc_id),
#                                 "semantic_score": similarity,
#                                 "retrieval_source": "semantic"
#                             }
#                         )
#                     )

#                 print(
#                     f"PGVector returned "
#                     f"{len(semantic_documents)} semantic documents"
#                 )

#                 return semantic_documents

#             except Exception as semantic_error:
#                 print(
#                     f"Postgres semantic search error: "
#                     f"{semantic_error}"
#                 )
#                 return []

#             finally:
#                 if semantic_cur is not None:
#                     semantic_cur.close()

#                 if semantic_conn is not None:
#                     semantic_conn.close()

#         # ---------------------------------------------------------
#         # BM25 keyword search function
#         # ---------------------------------------------------------
#         def keyword_search(search_query: str):
#             try:
#                 bm25_results = bm25_retriever.invoke(search_query)

#                 keyword_documents = []

#                 for document in bm25_results:
#                     metadata = document.metadata or {}

#                     document_tactic = str(
#                         metadata.get("tactic") or ""
#                     ).strip().lower()

#                     document_technique = str(
#                         metadata.get("technique") or ""
#                     ).strip().lower()

#                     if tactic_filter:
#                         if (
#                             document_tactic
#                             != str(tactic_filter).strip().lower()
#                         ):
#                             continue

#                     if tech_filter:
#                         if (
#                             document_technique
#                             != str(tech_filter).strip().lower()
#                         ):
#                             continue

#                     keyword_documents.append(
#                         Document(
#                             page_content=document.page_content,
#                             metadata={
#                                 **metadata,
#                                 "id": str(metadata.get("id", "")),
#                                 "retrieval_source": "bm25"
#                             }
#                         )
#                     )

#                 print(
#                     f"BM25 returned "
#                     f"{len(keyword_documents)} keyword documents"
#                 )

#                 return keyword_documents

#             except Exception as bm25_error:
#                 print(f"BM25 search error: {bm25_error}")
#                 return []

#         # ---------------------------------------------------------
#         # Wrap both search functions as LangChain retrievers
#         # ---------------------------------------------------------
#         semantic_retriever = RunnableLambda(semantic_search)
#         keyword_retriever = RunnableLambda(keyword_search)

#         # ---------------------------------------------------------
#         # Combine PGVector and BM25 using EnsembleRetriever
#         # ---------------------------------------------------------
#         ensemble_retriever = EnsembleRetriever(
#             retrievers=[
#                 semantic_retriever,
#                 keyword_retriever
#             ],
#             weights=[
#                 Config.SEMANTIC_WEIGHT,
#                 Config.KEYWORD_WEIGHT
#             ],
#             id_key="id"
#         )

#         print("Running hybrid similarity search....................")

#         hybrid_documents = ensemble_retriever.invoke(query)

#         # Limit the number of documents sent to the reranker.
#         hybrid_candidate_top_k = getattr(
#             Config,
#             "HYBRID_CANDIDATE_TOP_K",
#             Config.SEMANTIC_TOP_K + Config.BM25_TOP_K
#         )

#         hybrid_documents = hybrid_documents[
#             :hybrid_candidate_top_k
#         ]

#         print(
#             f"Hybrid search returned "
#             f"{len(hybrid_documents)} unique candidates"
#         )

#         if not hybrid_documents:
#             print("No hybrid search matches found--------------")

#             return {
#                 "query": query,
#                 "matches": [],
#                 "reason": (
#                     "Query is not related to historical records"
#                 )
#             }

#         # ---------------------------------------------------------
#         # Rerank hybrid candidates using the local reranker
#         # ---------------------------------------------------------
#         reranker_pairs = [
#             [query, document.page_content]
#             for document in hybrid_documents
#         ]

#         reranker_scores = reranker.compute_score(
#             reranker_pairs,
#             normalize=True
#         )

#         # FlagReranker can return a single float for one document.
#         if isinstance(reranker_scores, (float, int)):
#             reranker_scores = [reranker_scores]
#         print("Reranker scores:", reranker_scores)
#         print(
#         "Configured minimum reranker score:",
#         Config.MIN_RERANKER_SCORE
#         )
#         reranked_results = []

#         for document, reranker_score in zip(
#             hybrid_documents,
#             reranker_scores
#         ):
#             reranker_score = float(reranker_score)

#             # if (
#             #     reranker_score
#             #     < Config.MIN_RERANKER_SCORE
#             # ):
#             #     continue

#             reranked_results.append({
#                 "document": document,
#                 "reranker_score": reranker_score
#             })

#         reranked_results.sort(
#             key=lambda item: item["reranker_score"],
#             reverse=True
#         )

#         # Respect the top_k passed to this function.
#         reranked_results = reranked_results[:top_k]

#         # ---------------------------------------------------------
#         # Format final results using the existing response structure
#         # ---------------------------------------------------------
#         matches = []

#         for item in reranked_results:
#             document = item["document"]
#             metadata = document.metadata or {}

#             reranker_score = round(
#                 float(item["reranker_score"]),
#                 3
#             )

#             if (
#                 reranker_score
#                 >= Config.CONFIDENCE_HIGH_THRESHOLD
#             ):
#                 confidence = "High"

#             elif (
#                 reranker_score
#                 >= Config.CONFIDENCE_MEDIUM_THRESHOLD
#             ):
#                 confidence = "Medium"

#             else:
#                 confidence = "Low"

#             # Remove internal retrieval fields from returned metadata.
#             response_metadata = {
#                 key: value
#                 for key, value in metadata.items()
#                 if key not in {
#                     "id",
#                     "semantic_score",
#                     "retrieval_source"
#                 }
#             }

#             matches.append({
#                 "incident_id": str(metadata.get("id", "")),
#                 "similarity_score": reranker_score,
#                 "confidence": confidence,
#                 "investigated_outcome": document.page_content,
#                 "metadata": response_metadata
#             })

#         if not matches:
#             print("No matches passed the reranker threshold--------------")

#             return {
#                 "query": query,
#                 "matches": [],
#                 "reason": (
#                     "Hybrid candidates were found, but none passed "
#                     "the reranker threshold"
#                 )
#             }

#         print(
#             "------------- Hybrid Similarity Search and "
#             "Reranking Completed -------------------"
#         )

#         return {
#             "query": query,
#             "matches": matches
#         }

#     except Exception as error:
#         print(f"Hybrid search error: {error}")

#         return {
#             "query": query,
#             "matches": [],
#             "reason": "Hybrid similarity search failed",
#             "error": str(error)
#         }

#     finally:
#         if cur is not None:
#             cur.close()

#         if conn is not None:
#             conn.close()

import chromadb
# from app.controllers.resolution_recommender.models import Base,engine,get_session,CrowdStrikeAlertDetails

def model_to_dict(record):
    if record is None:
        return {}

    record_data = {}

    for column in record.__table__.columns:
        value = getattr(record, column.name)

        if hasattr(value, "isoformat"):
            value = value.isoformat()
        elif value is not None and not isinstance(
            value,
            (str, int, float, bool, list, dict)
        ):
            value = str(value)

        record_data[column.name] = value

    return record_data

# def search_filtered_record(
#     query: str,
#     tactic_filter=None,
#     tech_filter=None,
#     top_k=5
# ):
#     """
#     Hybrid retrieval flow:

#     1. Generate the query embedding using embed__text().
#     2. Search ChromaDB using the description embedding.
#     3. Retrieve complete records from SQLite using vector_id.
#     4. Search the full alert corpus using BM25.
#     5. Combine ChromaDB and BM25 results.
#     6. Rerank hybrid candidates.
#     7. Apply MIN_RERANKER_SCORE.
#     8. Return the final top_k results.
#     """

#     print(
#         "search_filtered_record function called...................."
#         f"{tactic_filter} and {tech_filter}"
#     )

#     session = None

#     try:
#         # ---------------------------------------------------------
#         # Validate input and configuration
#         # ---------------------------------------------------------
#         if not query or not str(query).strip():
#             return {
#                 "query": query,
#                 "matches": [],
#                 "reason": "Search query is empty"
#             }

#         query = str(query).strip()

#         if not Config.DIRECTORY_PATH:
#             raise ValueError(
#                 "DIRECTORY_PATH is not configured."
#             )

#         if not Config.BM25_STORE_PATH:
#             raise ValueError(
#                 "BM25_STORE_PATH is not configured."
#             )

#         final_top_k = (
#             int(top_k)
#             if top_k is not None
#             else Config.RERANKER_TOP_K
#         )

#         # ---------------------------------------------------------
#         # Create SQLite session
#         # ---------------------------------------------------------
#         session = get_session()

#         # ---------------------------------------------------------
#         # Helper to construct full alert text from SQLite record
#         # ---------------------------------------------------------
#         def build_alert_text(record):
#             return f"""
# Incident Type: {record.incident_type or ""}
# Severity: {record.severity or ""}

# Description:
# {record.description or ""}

# File Details:
# Filename: {record.filename or ""}
# File Path: {record.file_path or ""}
# File Hash: {record.file_hash or ""}

# Tactics and Techniques:
# Tactic: {record.tactic or ""}
# Technique: {record.technique or ""}
# Objective: {record.objective or ""}

# Command Line Details:
# Command Line: {record.command_line or ""}
# Parent Command Line: {record.parent_command_line or ""}
# Grandparent Command Line: {record.grandparent_command_line or ""}

# Containment and Outcome:
# Containment Status: {record.containment_status or ""}
# Investigation Conclusion: {
#     record.investigation_conclusion or ""
# }
#             """.strip()

#         # ---------------------------------------------------------
#         # Helper to create response metadata from SQLite record
#         # ---------------------------------------------------------
#         def build_response_metadata(record):
#             return {
#                 "severity": record.severity or "",
#                 "conclusion": (
#                     record.investigation_conclusion or ""
#                 ),
#                 "tactic": record.tactic or "",
#                 "technique": record.technique or "",
#                 "filename": record.filename or "",
#                 "analysis_notes": (
#                     record.investigation_analysis or ""
#                 )
#             }

#         # ---------------------------------------------------------
#         # Initialize ChromaDB
#         # ---------------------------------------------------------
#         vector_dir = os.path.join(
#             Config.DIRECTORY_PATH,
#             "vector"
#         )

#         os.makedirs(
#             vector_dir,
#             exist_ok=True
#         )

#         chroma_client = chromadb.PersistentClient(
#             path=vector_dir
#         )

#         collection_name = (
#             "my_collection_historical_crowdstrike"
#         )

#         chroma_collection = (
#             chroma_client.get_or_create_collection(
#                 name=collection_name
#             )
#         )

#         # ---------------------------------------------------------
#         # Load BM25 JSON corpus
#         # ---------------------------------------------------------
#         corpus = []

#         if os.path.exists(Config.BM25_STORE_PATH):
#             try:
#                 with open(
#                     Config.BM25_STORE_PATH,
#                     "r",
#                     encoding="utf-8-sig"
#                 ) as file:
#                     corpus = json.load(file)

#                 if not isinstance(corpus, list):
#                     print(
#                         "BM25 corpus is not a JSON list. "
#                         "Using an empty corpus."
#                     )
#                     corpus = []

#             except json.JSONDecodeError as error:
#                 print(
#                     f"BM25 corpus contains invalid JSON: {error}"
#                 )
#                 corpus = []

#             except UnicodeDecodeError as error:
#                 print(
#                     f"Unable to decode BM25 corpus: {error}"
#                 )
#                 corpus = []

#             except OSError as error:
#                 print(
#                     f"Unable to read BM25 corpus: {error}"
#                 )
#                 corpus = []

#         else:
#             print(
#                 f"BM25 corpus does not exist: "
#                 f"{Config.BM25_STORE_PATH}"
#             )

#         # ---------------------------------------------------------
#         # Build BM25 LangChain documents
#         #
#         # The ID must be copied into metadata because the
#         # EnsembleRetriever uses id_key="id".
#         # ---------------------------------------------------------
#         bm25_documents = []

#         for item in corpus:
#             page_content = str(
#                 item.get("page_content") or ""
#             ).strip()

#             vector_id = str(
#                 item.get("id") or ""
#             ).strip()

#             if not page_content or not vector_id:
#                 continue

#             item_metadata = item.get("metadata") or {}

#             bm25_documents.append(
#                 Document(
#                     page_content=page_content,
#                     metadata={
#                         **item_metadata,
#                         "id": vector_id
#                     }
#                 )
#             )

#         bm25_retriever = None

#         if bm25_documents:
#             bm25_retriever = (
#                 BM25Retriever.from_documents(
#                     bm25_documents
#                 )
#             )

#             bm25_retriever.k = Config.BM25_TOP_K

#             print(
#                 f"BM25 retriever initialized with "
#                 f"{len(bm25_documents)} documents."
#             )

#         else:
#             print(
#                 "BM25 corpus is empty. "
#                 "Only ChromaDB semantic search will be used."
#             )

#         # ---------------------------------------------------------
#         # ChromaDB semantic search function
#         # ---------------------------------------------------------
#         def semantic_search(search_query: str):
#             try:
#                 # Only the query text is embedded here.
#                 query_embeddings = embed__text(
#                     [search_query]
#                 )

#                 if not query_embeddings:
#                     print(
#                         "No query embedding was returned."
#                     )
#                     return []

#                 query_embedding = query_embeddings[0]

#                 # ---------------------------------------------
#                 # Chroma metadata filter
#                 # ---------------------------------------------
#                 where_filter = None

#                 if tactic_filter and tech_filter:
#                     where_filter = {
#                         "$and": [
#                             {
#                                 "tactic": {
#                                     "$eq": str(
#                                         tactic_filter
#                                     ).strip()
#                                 }
#                             },
#                             {
#                                 "technique": {
#                                     "$eq": str(
#                                         tech_filter
#                                     ).strip()
#                                 }
#                             }
#                         ]
#                     }

#                 elif tactic_filter:
#                     where_filter = {
#                         "tactic": {
#                             "$eq": str(
#                                 tactic_filter
#                             ).strip()
#                         }
#                     }

#                 elif tech_filter:
#                     where_filter = {
#                         "technique": {
#                             "$eq": str(
#                                 tech_filter
#                             ).strip()
#                         }
#                     }

#                 collection_count = (
#                     chroma_collection.count()
#                 )

#                 if collection_count == 0:
#                     print(
#                         "ChromaDB collection is empty."
#                     )
#                     return []

#                 semantic_top_k = min(
#                     Config.SEMANTIC_TOP_K,
#                     collection_count
#                 )

#                 query_arguments = {
#                     "query_embeddings": [
#                         query_embedding
#                     ],
#                     "n_results": semantic_top_k,
#                     "include": [
#                         "documents",
#                         "metadatas",
#                         "distances"
#                     ]
#                 }

#                 if where_filter:
#                     query_arguments["where"] = (
#                         where_filter
#                     )

#                 chroma_results = (
#                     chroma_collection.query(
#                         **query_arguments
#                     )
#                 )

#                 result_ids = (
#                     chroma_results.get("ids", [[]])[0]
#                     or []
#                 )

#                 result_distances = (
#                     chroma_results.get(
#                         "distances",
#                         [[]]
#                     )[0]
#                     or []
#                 )

#                 if not result_ids:
#                     print(
#                         "ChromaDB returned no semantic results."
#                     )
#                     return []

#                 # ---------------------------------------------
#                 # Get complete details from SQLite
#                 # ---------------------------------------------
#                 sqlite_records = (
#                     session.query(
#                         CrowdStrikeAlertDetails
#                     )
#                     .filter(
#                         CrowdStrikeAlertDetails.vector_id.in_(
#                             result_ids
#                         )
#                     )
#                     .all()
#                 )

#                 records_by_id = {
#                     str(record.vector_id): record
#                     for record in sqlite_records
#                 }

#                 semantic_documents = []

#                 for result_index, vector_id in enumerate(
#                     result_ids
#                 ):
#                     vector_id = str(vector_id)

#                     record = records_by_id.get(
#                         vector_id
#                     )

#                     if record is None:
#                         print(
#                             f"SQLite record not found for "
#                             f"Chroma ID: {vector_id}"
#                         )
#                         continue

#                     distance = None

#                     if result_index < len(
#                         result_distances
#                     ):
#                         distance = float(
#                             result_distances[
#                                 result_index
#                             ]
#                         )

#                     # This calculation is valid when the Chroma
#                     # collection uses cosine distance.
#                     semantic_score = (
#                         1.0 - distance
#                         if distance is not None
#                         else None
#                     )

#                     # Apply the semantic threshold only when a
#                     # usable similarity score is available.
#                     if (
#                         semantic_score is not None
#                         and semantic_score
#                         < Config.MIN_SIMILARITY_THRESHOLD
#                     ):
                        
#                         continue

#                     full_alert_text = build_alert_text(
#                         record
#                     )

#                     response_metadata = (
#                         build_response_metadata(record)
#                     )

#                     semantic_documents.append(
#                         Document(
#                             page_content=full_alert_text,
#                             metadata={
#                                 **response_metadata,
#                                 "id": vector_id,
#                                 "semantic_score": (
#                                     semantic_score
#                                 ),
#                                 "chroma_distance": distance,
#                                 "retrieval_source": (
#                                     "semantic"
#                                 )
#                             }
#                         )
#                     )

#                 print(
#                     f"ChromaDB returned "
#                     f"{len(semantic_documents)} "
#                     "semantic documents."
#                 )

#                 return semantic_documents

#             except Exception as semantic_error:
#                 print(
#                     "ChromaDB semantic search error: "
#                     f"{semantic_error}"
#                 )

#                 return []

#         # ---------------------------------------------------------
#         # BM25 keyword search function
#         # ---------------------------------------------------------
#         def keyword_search(search_query: str):
#             try:
#                 if bm25_retriever is None:
#                     print(
#                         "BM25 retriever is unavailable because "
#                         "the corpus is empty."
#                     )
#                     return []

#                 bm25_results = (
#                     bm25_retriever.invoke(
#                         search_query
#                     )
#                 )

#                 keyword_documents = []

#                 requested_tactic = (
#                     str(tactic_filter).strip().lower()
#                     if tactic_filter
#                     else None
#                 )

#                 requested_technique = (
#                     str(tech_filter).strip().lower()
#                     if tech_filter
#                     else None
#                 )

#                 for document in bm25_results:
#                     document_metadata = (
#                         document.metadata or {}
#                     )

#                     document_id = str(
#                         document_metadata.get("id")
#                         or ""
#                     ).strip()

#                     if not document_id:
#                         continue

#                     document_tactic = str(
#                         document_metadata.get("tactic")
#                         or ""
#                     ).strip().lower()

#                     document_technique = str(
#                         document_metadata.get(
#                             "technique"
#                         )
#                         or ""
#                     ).strip().lower()

#                     if (
#                         requested_tactic
#                         and document_tactic
#                         != requested_tactic
#                     ):
#                         continue

#                     if (
#                         requested_technique
#                         and document_technique
#                         != requested_technique
#                     ):
#                         continue

#                     keyword_documents.append(
#                         Document(
#                             page_content=(
#                                 document.page_content
#                             ),
#                             metadata={
#                                 **document_metadata,
#                                 "id": document_id,
#                                 "retrieval_source": "bm25"
#                             }
#                         )
#                     )

#                 print(
#                     f"BM25 returned "
#                     f"{len(keyword_documents)} "
#                     "keyword documents."
#                 )

#                 return keyword_documents

#             except Exception as bm25_error:
#                 print(
#                     f"BM25 search error: {bm25_error}"
#                 )

#                 return []

#         # ---------------------------------------------------------
#         # Wrap Chroma and BM25 as LangChain retrievers
#         # ---------------------------------------------------------
#         semantic_retriever = RunnableLambda(semantic_search)
#         keyword_retriever = RunnableLambda(keyword_search)

#         # ---------------------------------------------------------
#         # Hybrid rank fusion
#         # ---------------------------------------------------------
#         ensemble_retriever = EnsembleRetriever(
#             retrievers=[semantic_retriever, keyword_retriever],
#             weights=[
#                 Config.SEMANTIC_WEIGHT,
#                 Config.KEYWORD_WEIGHT
#             ],
#             id_key="id"
#         )

#         print("Running hybrid similarity search....................")

#         hybrid_documents = ensemble_retriever.invoke(query)

#         hybrid_candidate_top_k = getattr(
#             Config,
#             "HYBRID_CANDIDATE_TOP_K",
#             Config.SEMANTIC_TOP_K + Config.BM25_TOP_K
#         )

#         hybrid_documents = hybrid_documents[:hybrid_candidate_top_k]

#         print(
#             f"Hybrid search returned "
#             f"{len(hybrid_documents)} unique candidates."
#         )

#         if not hybrid_documents:
#             print("Query is not related to historical records.")
#             return {
#                 "query": query,
#                 "matches": []
#             }

#         # ---------------------------------------------------------
#         # Fetch complete SQLite records for hybrid candidates
#         # ---------------------------------------------------------
#         hybrid_ids = []

#         for document in hybrid_documents:
#             document_id = str(
#                 (document.metadata or {}).get("id") or ""
#             ).strip()

#             if document_id and document_id not in hybrid_ids:
#                 hybrid_ids.append(document_id)

#         hybrid_sqlite_records = []

#         if hybrid_ids:
#             hybrid_sqlite_records = (
#                 session.query(CrowdStrikeAlertDetails)
#                 .filter(
#                     CrowdStrikeAlertDetails.vector_id.in_(hybrid_ids)
#                 )
#                 .all()
#             )

#         hybrid_records_by_id = {
#             str(record.vector_id): record
#             for record in hybrid_sqlite_records
#         }

#         # ---------------------------------------------------------
#         # Hydrate every hybrid document using its SQLite record
#         # ---------------------------------------------------------
#         hydrated_hybrid_documents = []

#         for document in hybrid_documents:
#             original_metadata = document.metadata or {}

#             document_id = str(
#                 original_metadata.get("id") or ""
#             ).strip()

#             record = hybrid_records_by_id.get(document_id)

#             if record is None:
#                 print(
#                     f"SQLite record not found for hybrid "
#                     f"vector_id: {document_id}"
#                 )
#                 continue

#             full_alert_text = build_alert_text(record)
#             full_metadata = build_response_metadata(record)

#             hydrated_hybrid_documents.append(
#                 Document(
#                     page_content=full_alert_text,
#                     metadata={
#                         **full_metadata,
#                         "id": document_id,
#                         "semantic_score": original_metadata.get(
#                             "semantic_score"
#                         ),
#                         "chroma_distance": original_metadata.get(
#                             "chroma_distance"
#                         ),
#                         "retrieval_source": original_metadata.get(
#                             "retrieval_source",
#                             "hybrid"
#                         )
#                     }
#                 )
#             )

#         hybrid_documents = hydrated_hybrid_documents

#         if not hybrid_documents:
#             print(
#                 "Hybrid candidates were found, but corresponding "
#                 "SQLite records were not available."
#             )
#             return {
#                 "query": query,
#                 "matches": []
#             }

#         # ---------------------------------------------------------
#         # Rerank hydrated hybrid candidates
#         # ---------------------------------------------------------
#         reranker_pairs = [
#             [query, document.page_content]
#             for document in hybrid_documents
#         ]

#         reranker_scores = reranker.compute_score(
#             reranker_pairs,
#             normalize=True
#         )

#         if isinstance(reranker_scores, (float, int)):
#             reranker_scores = [reranker_scores]

#         reranker_scores = [
#             float(score)
#             for score in reranker_scores
#         ]

#         print("Reranker scores:", reranker_scores)
#         print(
#             "Configured minimum reranker score:",
#             Config.MIN_RERANKER_SCORE
#         )

#         if len(reranker_scores) != len(hybrid_documents):
#             raise ValueError(
#                 "Reranker score count does not match hybrid "
#                 "candidate count. "
#                 f"Candidates: {len(hybrid_documents)}, "
#                 f"scores: {len(reranker_scores)}"
#             )

#         # ---------------------------------------------------------
#         # Sort candidates by reranker score
#         # ---------------------------------------------------------
#         all_reranked_results = []

#         for document, reranker_score in zip(
#             hybrid_documents,
#             reranker_scores
#         ):
#             document_id = str(
#                 (document.metadata or {}).get("id") or ""
#             ).strip()

#             print(
#                 f"Candidate {document_id}: "
#                 f"reranker score={reranker_score:.10f}"
#             )

#             all_reranked_results.append({
#                 "document": document,
#                 "reranker_score": reranker_score
#             })

#         all_reranked_results.sort(
#             key=lambda item: item["reranker_score"],
#             reverse=True
#         )

#         # ---------------------------------------------------------
#         # Apply reranker threshold
#         # ---------------------------------------------------------
#         reranked_results = [
#             item
#             for item in all_reranked_results
#             if item["reranker_score"]
#             >= Config.MIN_RERANKER_SCORE
#         ]

#         rejected_count = (
#             len(all_reranked_results)
#             - len(reranked_results)
#         )

#         print(
#             f"Reranker threshold accepted "
#             f"{len(reranked_results)} candidates and "
#             f"rejected {rejected_count} candidates."
#         )

#         if not reranked_results:
#             highest_score = (
#                 all_reranked_results[0]["reranker_score"]
#                 if all_reranked_results
#                 else None
#             )

#             print(
#                 "Hybrid candidates were found, but none passed "
#                 "the reranker threshold."
#             )

#             print(
#                 f"Highest reranker score: {highest_score}, "
#                 f"required threshold: "
#                 f"{Config.MIN_RERANKER_SCORE}"
#             )

#             return {
#                 "query": query,
#                 "matches": []
#             }

#         reranked_results = reranked_results[:final_top_k]

#         # ---------------------------------------------------------
#         # Fetch complete database rows for final reranked IDs
#         # ---------------------------------------------------------
#         final_vector_ids = []

#         for item in reranked_results:
#             document = item["document"]

#             vector_id = str(
#                 (document.metadata or {}).get("id") or ""
#             ).strip()

#             if vector_id and vector_id not in final_vector_ids:
#                 final_vector_ids.append(vector_id)

#         final_database_records = []

#         if final_vector_ids:
#             final_database_records = (
#                 session.query(CrowdStrikeAlertDetails)
#                 .filter(
#                     CrowdStrikeAlertDetails.vector_id.in_(
#                         final_vector_ids
#                     )
#                 )
#                 .all()
#             )

#         final_records_by_id = {
#             str(record.vector_id): record
#             for record in final_database_records
#         }

#         # ---------------------------------------------------------
#         # Format final response with every database column
#         # ---------------------------------------------------------
#         matches = []

#         for item in reranked_results:
#             document = item["document"]
#             metadata = document.metadata or {}

#             vector_id = str(
#                 metadata.get("id") or ""
#             ).strip()

#             database_record = final_records_by_id.get(vector_id)

#             if database_record is None:
#                 print(
#                     f"Final SQLite record not found for "
#                     f"vector_id: {vector_id}"
#                 )
#                 continue

#             raw_reranker_score = float(
#                 item["reranker_score"]
#             )

#             displayed_reranker_score = round(
#                 raw_reranker_score,
#                 8
#             )

#             if (
#                 raw_reranker_score
#                 >= Config.CONFIDENCE_HIGH_THRESHOLD
#             ):
#                 confidence = "High"
#             elif (
#                 raw_reranker_score
#                 >= Config.CONFIDENCE_MEDIUM_THRESHOLD
#             ):
#                 confidence = "Medium"
#             else:
#                 confidence = "Low"

#             semantic_score = metadata.get("semantic_score")

#             # Dynamically includes all columns from the model
#             complete_database_record = model_to_dict(
#                 database_record
#             )

#             matches.append({
#                 "incident_id": vector_id,
#                 "similarity_score": displayed_reranker_score,
#                 "semantic_score": (
#                     round(float(semantic_score), 6)
#                     if semantic_score is not None
#                     else None
#                 ),
#                 "confidence": confidence,
#                 "database_record": complete_database_record
#             })

#         print(
#             "------------- Hybrid Similarity Search and "
#             "Reranking Completed -------------------"
#         )

#         return {
#             "query": query,
#             "matches": matches
#         }

#     except Exception as error:
#         print(
#             f"Hybrid search error: {error}"
#         )

#         if session is not None:
#             session.rollback()

#         return {
#             "query": query,
#             "matches": [],
#             "reason": (
#                 "Hybrid similarity search failed"
#             ),
#             "error": str(error)
#         }

#     finally:
#         if session is not None:
#             session.close()


# def fetch_recommendation_filtered(query,tactic,tech):
    
#     # if isinstance(query, str):
#     #     query = json.loads(query)

#     # tactic=query.get("tactic")
#     # tech=query.get("technique")
#     print("searching on filter tactic ",tactic,"   technique", tech )
#     result=search_filtered_record(query,tactic,tech)
#     return result

import json
import os
import chromadb
from langchain_core.documents import Document
from langchain_core.runnables import RunnableLambda
from langchain_classic.retrievers import EnsembleRetriever
from langchain_community.retrievers import BM25Retriever
from app.controllers.resolution_recommender.pg_models import SourceConfig, get_session
# Assuming embed__text, Config, reranker, etc. are already imported

def search_filtered_record(
    query: str,
    source_brand: str,
    filters: dict = None,
    top_k: int = 5
):
    """
    Dynamic Hybrid Retrieval Flow:
    1. Look up source_brand in SourceConfig DB to get paths and collections.
    2. Load the isolated BM25 JSON corpus.
    3. Initialize the isolated ChromaDB collection.
    4. Perform Semantic Search on ChromaDB with dynamic metadata filters.
    5. Perform Keyword Search on BM25 with dynamic metadata filters.
    6. Combine, rerank, and return ONLY the embedded text and metadata.
    """
    print(f"search_filtered_record called for brand: '{source_brand}' with filters: {filters}")

    session = None

    try:
        if not query or not str(query).strip():
            return {"query": query, "matches": [], "reason": "Search query is empty"}

        session = get_session()

        # ---------------------------------------------------------
        # 1. Fetch Dynamic Configuration for the Source Brand
        # ---------------------------------------------------------
        config = session.query(SourceConfig).filter_by(source_brand=source_brand).first()
        if not config:
            print("noconfig")
            return {
                "query": query, 
                "matches": [], 
                "reason": f"No routing configuration found for sourceBrand: {source_brand}"
            }

        # ---------------------------------------------------------
        # 2. Load the specific BM25 JSON corpus
        # ---------------------------------------------------------
        bm25_base_path = getattr(Config, 'BM25_STORE_PATH', './bm25_indices')
        bm25_file_path = os.path.join(bm25_base_path, config.bm25_folder, f"bm25_{config.bm25_folder}.json")

        corpus = []
        if os.path.exists(bm25_file_path):
            with open(bm25_file_path, "r", encoding="utf-8") as file:
                corpus = json.load(file)

        bm25_documents = [
            Document(
                page_content=str(item.get("page_content", "")).strip(),
                metadata={**item.get("metadata", {}), "id": str(item.get("id", ""))}
            )
            for item in corpus if str(item.get("page_content", "")).strip()
        ]

        bm25_retriever = None
        if bm25_documents:
            bm25_retriever = BM25Retriever.from_documents(bm25_documents)
            bm25_retriever.k = getattr(Config, 'BM25_TOP_K', 5)

        # ---------------------------------------------------------
        # 3. Initialize the specific ChromaDB Collection
        # ---------------------------------------------------------
        vector_dir = os.path.join(Config.DIRECTORY_PATH, "vector")
        chroma_client = chromadb.PersistentClient(path=vector_dir)
        
        # Using get_collection to ensure it reads the existing collection
        chroma_collection = chroma_client.get_collection(name=config.chroma_collection)

        # ---------------------------------------------------------
        # 4. ChromaDB Semantic Search Function
        # ---------------------------------------------------------
        def semantic_search(search_query: str):
            try:
                # Use your existing embedding wrapper function
                query_embeddings = embed__text([search_query]) 
                if not query_embeddings:
                    return []

                # Build dynamic where_filter from the passed 'filters' dict
                where_filter = None
                if filters:
                    # e.g., {"tactic": "Execution", "severity": "High"}
                    valid_filters = [{f"{k}": {"$eq": str(v).strip()}} for k, v in filters.items() if v]
                    
                    if len(valid_filters) > 1:
                        where_filter = {"$and": valid_filters}
                    elif len(valid_filters) == 1:
                        where_filter = valid_filters[0]

                semantic_top_k = min(getattr(Config, 'SEMANTIC_TOP_K', 5), chroma_collection.count())
                if semantic_top_k == 0:
                    return []

                query_args = {
                    "query_embeddings": query_embeddings,
                    "n_results": semantic_top_k,
                    "include": ["documents", "metadatas", "distances"]
                }
                
                if where_filter:
                    query_args["where"] = where_filter

                results = chroma_collection.query(**query_args)

                docs = results.get("documents", [[]])[0]
                metas = results.get("metadatas", [[]])[0]
                ids = results.get("ids", [[]])[0]
                dists = results.get("distances", [[]])[0]

                semantic_docs = []
                for idx, doc_id in enumerate(ids):
                    distance = float(dists[idx])
                    semantic_score = 1.0 - distance # Works if Chroma is configured for cosine distance
                    
                    if semantic_score < getattr(Config, 'MIN_SIMILARITY_THRESHOLD', 0.65):
                        continue

                    doc_meta = metas[idx] if metas else {}
                    semantic_docs.append(
                        Document(
                            page_content=docs[idx],
                            metadata={
                                **doc_meta,
                                "id": str(doc_id),
                                "semantic_score": semantic_score,
                                "retrieval_source": "semantic"
                            }
                        )
                    )
                print("from semntic seacrh-------",len(semantic_docs))
                print(semantic_docs)
                return semantic_docs
            except Exception as e:
                print(f"ChromaDB search error: {e}")
                return []

        # ---------------------------------------------------------
        # 5. BM25 Keyword Search Function
        # ---------------------------------------------------------
        def keyword_search(search_query: str):
            if not bm25_retriever:
                return []
            try:
                results = bm25_retriever.invoke(search_query)
                filtered_docs = []

                for doc in results:
                    doc_meta = doc.metadata or {}
                    
                    # Apply dynamic filters
                    skip = False
                    if filters:
                        for k, v in filters.items():
                            if v and str(doc_meta.get(k, "")).strip().lower() != str(v).strip().lower():
                                skip = True
                                break
                    if skip:
                        continue

                    filtered_docs.append(
                        Document(
                            page_content=doc.page_content,
                            metadata={**doc_meta, "retrieval_source": "bm25"}
                        )
                    )
                print("from keyword search-----",len(filtered_docs))
                print(filtered_docs)
                return filtered_docs
            except Exception as e:
                print(f"BM25 search error: {e}")
                return []

        # ---------------------------------------------------------
        # 6. Ensemble and Rerank
        # ---------------------------------------------------------
        semantic_retriever = RunnableLambda(semantic_search)
        keyword_retriever = RunnableLambda(keyword_search)

        ensemble_retriever = EnsembleRetriever(
            retrievers=[semantic_retriever, keyword_retriever],
            weights=[getattr(Config, 'SEMANTIC_WEIGHT', 0.5), getattr(Config, 'KEYWORD_WEIGHT', 0.5)],
            id_key="id"
        )

        hybrid_documents = ensemble_retriever.invoke(query)
        hybrid_candidate_top_k = getattr(Config, "HYBRID_CANDIDATE_TOP_K", 10)
        hybrid_documents = hybrid_documents[:hybrid_candidate_top_k]

        if not hybrid_documents:
            return {"query": query, "matches": [], "reason": "No matches found."}

        reranker_pairs = [[query, doc.page_content] for doc in hybrid_documents]
        reranker_scores = reranker.compute_score(reranker_pairs, normalize=True)
        
        if isinstance(reranker_scores, (float, int)):
            reranker_scores = [reranker_scores]
        print("reranker scores----")
        print(reranker_scores)
        all_reranked = [
            {"document": doc, "reranker_score": float(score)}
            for doc, score in zip(hybrid_documents, reranker_scores)
        ]
        
        all_reranked.sort(key=lambda x: x["reranker_score"], reverse=True)

        reranked_results = [
            item for item in all_reranked 
        ][:top_k]
        print("----reranked")
        # ---------------------------------------------------------
        # 7. Format Final Output (Direct from Embeddings/Metadata)
        # ---------------------------------------------------------
        matches = []
        for item in reranked_results:
            doc = item["document"]
            meta = doc.metadata or {}
            score = item["reranker_score"]

            if score >= getattr(Config, 'CONFIDENCE_HIGH_THRESHOLD', 0.85):
                confidence = "High"
            elif score >= getattr(Config, 'CONFIDENCE_MEDIUM_THRESHOLD', 0.70):
                confidence = "Medium"
            else:
                confidence = "Low"

            # Filter out internal retrieval keys
            clean_metadata = {k: v for k, v in meta.items() if k not in ["semantic_score", "retrieval_source", "id"]}

            matches.append({
                "incident_id": meta.get("id", ""),
                "similarity_score": round(score, 5),
                "confidence": confidence,
                "embedded_data": doc.page_content, # The complete text we embedded
                "metadata": clean_metadata         # The dynamically generated metadata
            })

        return {"query": query, "matches": matches}

    except Exception as error:
        print(f"Hybrid search error: {error}")
        return {"query": query, "matches": [], "error": str(error)}
    finally:
        if session is not None:
            session.close()


def fetch_recommendation_filtered(query_text: dict, source_brand: str, filters: dict = None):
    print(f"Filtering on brand: {source_brand} | Filters: {filters}")
    result = search_filtered_record(
        query=query_text, 
        source_brand=source_brand, 
        filters=filters
    )
    return result




       

def get_resolution(context):
    prompt = f'''You are a Senior SOC Analyst and Incident Responder specializing in EDR-based investigations.
 
    Your task is to generate a precise and actionable Investigation Recommendation based on historical alert data.

    -----------------------------
    INPUT DATA
    -----------------------------

    Alert Details:
    {context['query']}

    Historical Alert Matches (from RAG):
    {context['matches']}

    -----------------------------
    INSTRUCTIONS
    -----------------------------

    1. STRICT GROUNDING:
    - Your recommendations MUST be based ONLY on the provided Historical Alert Matches.
    - Do NOT use external knowledge, assumptions, or generic playbooks unless explicitly reflected in historical data.

    2. MATCH ANALYSIS:
    - Analyze similarities between the current alert and historical alerts such as:
        - File name, hash, command line
        - Process hierarchy (parent/child)
        - Detection type / technique
        - User behavior and host details
    - Identify patterns in how similar alerts were investigated and resolved.

    3.NO-HISTORICAL-MATCH RULE:
        If historical alert matches are empty or irrelevant from alert details, you MUST NOT generate investigative recommended_actions, remediation steps, or inferred indicators.

        In this scenario:
        - The "key_indicators" field MUST either be empty or explicitly state that no historical indicators were identified.
        - The "recommended_actions" field MUST NOT suggest next steps and should instead explain that no historical-based recommendations can be made.
        - The explanation should reinforce that the absence of historical matches limits historical analysis.
        - The output structure and keys MUST remain unchanged.

    4. RECOMMENDATION GENERATION:
    Based on historical Investigation Analysis and Closure Notes, generate:

    a) Investigation Steps:
        - Step-by-step actions taken previously for similar alerts
        - Prioritize most frequently occurring or most effective steps

    b) Key Indicators to Validate:
        - Specific artifacts (file paths, hashes, processes, domains, users)

    c) Likely Root Cause (if inferable from history)

    d) Suggested Remediation Actions:
        - Only if present in historical records

    5. CONFIDENCE SCORING:
    - Provide a confidence level (High / Medium / Low)
    - Based on similarity strength of matches

    6. Recommendation Availability:
    - Provide true in recommendation_available field if you are able to generate some recommendation based on historical alerts otherwise false
    7. OUTPUT FORMAT (STRICT):
    - Final output should contain all the mentioned field
    Return response in the following structured JSON format without any markdown:

    {{
        "summary": "<short explanation of similarity with historical alerts without any similarity score>",
        "investigation_steps_recommended": [
            "<step 1>",
            "<step 2>"
        ],
        "key_indicators": [
            "<indicator 1>",
            "<indicator 2>"
        ],
        "likely_root_cause": "<based on historical data or 'Not available'>",
        "recommended_actions": [
            "<action 1>",
            "<action 2>"
        ],
        "confidence": "<High | Medium | Low>",
        "notes": "<mention if limited or no matches found>",
        "recommendation_available" :true | false
    }}

    -----------------------------
    IMPORTANT RULES
    -----------------------------

    - Do NOT hallucinate.
    - Do NOT include generic SOC playbooks unless seen in historical data.
    - Be concise, precise, and actionable.
    - Prefer patterns over one-off observations.

    Output Requirements:
    - The final output should contain all the fields mentioned in output format
    - Response MUST be valid JSON only.
    - Do NOT include markdown.
    - Do NOT include text outside the JSON.
    '''
    try:
        # print("--------------Input of LLM-----------")
        # print(prompt)
        
        llm_response=invoke(prompt)
        # llm_response=ollama_invoke(prompt)
        

        print("--------------output of LLM------------------")
        print(llm_response)
        return json.loads(llm_response)
    except Exception as e:
        print("LLM initialization failed:", str(e))
        raise Exception(f"Exception occured in get_resolution") from e


