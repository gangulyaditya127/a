import os
from pathlib import Path
from datetime import datetime

from dotenv import load_dotenv

from sqlalchemy import (
    Column,
    DateTime,
    String,
    Text,
    create_engine,
    func,
    JSON
)

from sqlalchemy.orm import (
    declarative_base,
    sessionmaker
)


load_dotenv()


# =========================================================
# SQLAlchemy declarative base
# All SQLite model classes will inherit from this Base
# =========================================================
Base = declarative_base()


# =========================================================
# Configuration
# =========================================================
class Config:

    SQLITE_DATABASE_PATH = os.getenv(
        "SQLITE_DATABASE_PATH",
        "data/crowdstrike_alerts.db"
    )

    SQLALCHEMY_ECHO = (
        os.getenv(
            "SQLALCHEMY_ECHO",
            "false"
        ).strip().lower()
        == "true"
    )

    

    


# =========================================================
# Prepare SQLite database path
# =========================================================
sqlite_database_path = Path(
    Config.SQLITE_DATABASE_PATH
).expanduser().resolve()


# Create the parent directory if it does not exist
sqlite_database_path.parent.mkdir(
    parents=True,
    exist_ok=True
)


# SQLite URI
SQLALCHEMY_DATABASE_URI = (
    f"sqlite+pysqlite:///{sqlite_database_path.as_posix()}"
)


# =========================================================
# SQLite engine
# =========================================================
engine = create_engine(
    SQLALCHEMY_DATABASE_URI,
    echo=Config.SQLALCHEMY_ECHO,
    connect_args={
        "check_same_thread": False
    }
)


# =========================================================
# SQLite session factory
# =========================================================
SessionLocal = sessionmaker(
    bind=engine,
    autoflush=False,
    autocommit=False,
    expire_on_commit=False
)


# =========================================================
# SQLite model
# =========================================================
class CrowdStrikeAlertDetails(Base):
    __tablename__ = "crowdstrike_alert_details"

    # Same ID will be stored in:
    # 1. ChromaDB
    # 2. SQLite
    # 3. BM25 JSON
    vector_id = Column(
        String(36),
        primary_key=True,
        index=True,
        nullable=False
    )

    incident_type = Column(
        String(255),
        nullable=True
    )

    severity = Column(
        String(100),
        nullable=True,
        index=True
    )

    description = Column(
        Text,
        nullable=False
    )

    filename = Column(
        String(1000),
        nullable=True
    )

    file_path = Column(
        Text,
        nullable=True
    )

    file_hash = Column(
        String(500),
        nullable=True,
        index=True
    )

    tactic = Column(
        String(500),
        nullable=True,
        index=True
    )

    technique = Column(
        String(500),
        nullable=True,
        index=True
    )

    objective = Column(
        String(500),
        nullable=True
    )

    command_line = Column(
        Text,
        nullable=True
    )

    parent_command_line = Column(
        Text,
        nullable=True
    )

    grandparent_command_line = Column(
        Text,
        nullable=True
    )

    containment_status = Column(
        String(255),
        nullable=True
    )

    investigation_conclusion = Column(
        String(500),
        nullable=True
    )

    investigation_analysis = Column(
        Text,
        nullable=True
    )

    created_at = Column(
        DateTime,
        nullable=False,
        server_default=func.current_timestamp()
    )

    updated_at = Column(
        DateTime,
        nullable=False,
        server_default=func.current_timestamp(),
        onupdate=func.current_timestamp()
    )


class QRadarAlertDetails(Base):
    __tablename__ = "qradar_alert_details"

    # Same ID will be stored in:
    # 1. ChromaDB
    # 2. SQLite
    # 3. BM25 JSON
    vector_id = Column(
        String(36),
        primary_key=True,
        index=True,
        nullable=False
    )

    incident_type = Column(
        String(255),
        nullable=True
    )

    severity = Column(
        String(100),
        nullable=True,
        index=True
    )

    description = Column(
        Text,
        nullable=False
    )

    offense_source = Column(
        String(500),
        nullable=True,
        index=True
    )

    categories = Column(
        Text,
        nullable=True
    )

    magnitude = Column(
        String(50),
        nullable=True,
        index=True
    )

    investigation_conclusion = Column(
        String(500),
        nullable=True
    )

    investigation_analysis = Column(
        Text,
        nullable=True
    )

    created_at = Column(
        DateTime,
        nullable=False,
        server_default=func.current_timestamp()
    )

    updated_at = Column(
        DateTime,
        nullable=False,
        server_default=func.current_timestamp(),
        onupdate=func.current_timestamp()
    )




class SourceConfig(Base):
    __tablename__ = "source_configs"

    source_brand = Column(String(100), primary_key=True)
    chroma_collection = Column(String(100), nullable=False)
    bm25_folder = Column(String(100), nullable=False)
    
    # List of JSON dot-notation paths to extract for the embedding string
    embedding_fields = Column(JSON, nullable=False) 
    
    # Dictionary mapping metadata keys to their JSON dot-notation paths
    metadata_fields = Column(JSON, nullable=False)
# =========================================================
# Add any other SQLite model classes above this line.
#
# create_all() must run only after all model classes have
# been imported or defined.
# =========================================================
Base.metadata.create_all(
    bind=engine
)


# =========================================================
# Session helper
# =========================================================
def get_session():
    """
    Create and return a new SQLite SQLAlchemy session.

    The caller is responsible for closing the session.
    """

    return SessionLocal()