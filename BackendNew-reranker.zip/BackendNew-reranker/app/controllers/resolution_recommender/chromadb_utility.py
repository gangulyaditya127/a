import pandas as pd
import chromadb
import json
import os
from .config import Config
from .common_func import invoke,embed_texts
import uuid
import pandas as pd
import numpy as np
import joblib
import psycopg2
from pgvector.psycopg2 import register_vector
import sys
# import tra



from sentence_transformers import SentenceTransformer


# Initialize the embedding model (downloads on first run, ~80MB)


def clean_val(val):
    """Helper to handle NaNs and convert to None for JSON/Postgres safety."""
    if pd.isna(val) or str(val).lower() == 'nan':
        return "not available"
    return val

# def save_to_postgres(df):
#     db_params = {
#         "host": "localhost",
#         "database": "db2",
#         "user": "postgres",
#         "password": "admin",
#         "port": 5432
#     }

#     try:
#         conn = psycopg2.connect(**db_params)
#         cur = conn.cursor()
#         cur.execute("CREATE EXTENSION IF NOT EXISTS vector;")
#         register_vector(conn)

#         # Create table if not exists
#         cur.execute("""
#             CREATE TABLE IF NOT EXISTS crowdstrike_alerts (
#                 id UUID PRIMARY KEY,
#                 document TEXT,
#                 embedding vector(384),
#                 metadata JSONB,
#                 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
#             );
#         """)
#         conn.commit()

#         print("Preparing full alert profiles for embedding...")

#         embeddings_input = []
#         rows_to_insert = []
#         bm25_documents = []
#         for _, row in df.iterrows():
#             vector_id = str(uuid.uuid4())

#             # Construct the comprehensive alert profile exactly as requested
#             # We use 'clean_val' and 'or ""' to ensure no 'NaN' strings enter the text
#             alert_text = f"""
#             Incident Type: {clean_val(row.get("type")) or ""}
#             Severity: {clean_val(row.get("severity")) or ""}

#             Description:
#             {clean_val(row.get("Description")) or ""}

#             File Details:
#             Filename: {clean_val(row.get("CrowdStrike Filename")) or ""}
#             File Path: {clean_val(row.get("Crowdstrike File Path")) or ""}
#             File Hash: {clean_val(row.get("CrowdStrike FileHash")) or ""}

#             Tactics and Techniques:
#             Tactic: {clean_val(row.get("CrowdStrike Tactic")) or ""}
#             Technique: {clean_val(row.get("CrowdStrike Technique")) or ""}
#             Objective: {clean_val(row.get("CrowdStrike Objective")) or ""}

#             Command Line Details:
#             Command Line: {clean_val(row.get("CrowdStrike Cmdline")) or ""}
#             Parent Command Line: {clean_val(row.get("CS Parent Cmdline")) or ""}
#             Grandparent Command Line: {clean_val(row.get("Crowdstrike Grandparent_Commandline")) or ""}

#             Containment and Outcome:
#             Containment Status: {clean_val(row.get("CrowdStrike Contain Status")) or ""}
#             Investigation Conclusion: {clean_val(row.get("Investigation Conclusion")) or ""}
#             """.strip()

#             # Store this profile for embedding generation
#             embeddings_input.append(alert_text)

#             # Metadata for filtering/sorting
#             meta = {
#                 "severity": clean_val(row.get("severity")),
#                 "conclusion": clean_val(row.get("Investigation Conclusion")),
#                 "tactic": clean_val(row.get("CrowdStrike Tactic")),
#                 "technique": clean_val(row.get("CrowdStrike Technique")),
#                 "filename": clean_val(row.get("CrowdStrike Filename")),
#                 "analysis_notes": clean_val(row.get("Investigation Analysis")) # Keep notes in meta
#             }
#             bm25_documents.append({
#                 "id": vector_id,
#                 "page_content": alert_text,
#                 "metadata": meta
#             })
#             # We store the FULL alert_text in the 'document' column
#             rows_to_insert.append((vector_id, alert_text, meta))

#         print(f"Generating vectors for {len(embeddings_input)} profiles...")
#         vectors = embed_model.encode(embeddings_input).tolist()

#         print("Syncing with Postgres...")
#         insert_query = "INSERT INTO crowdstrike_alerts (id, document, metadata, embedding) VALUES (%s, %s, %s, %s)"
        
#         for i in range(len(rows_to_insert)):
#             cur.execute(
#                 insert_query,
#                 (rows_to_insert[i][0], rows_to_insert[i][1], json.dumps(rows_to_insert[i][2]), vectors[i])
#             )

#         conn.commit()
#         print(f"Successfully embedded and stored {len(rows_to_insert)} full alert profiles.")
#         with open(Config.BM25_STORE_PATH, "w", encoding="utf-8") as f:
#             json.dump(bm25_documents, f, ensure_ascii=False)
#     except Exception as e:
#         print(f"Database Error: {e}")
#         if 'conn' in locals(): conn.rollback()
#     finally:
#         if 'cur' in locals(): cur.close()
#         if 'conn' in locals(): conn.close()
 
import chromadb
# from app.controllers.resolution_recommender.models import Base,engine,get_session,CrowdStrikeAlertDetails,QRadarAlertDetails
from app.controllers.resolution_recommender.pg_models import get_session,SourceConfig

import json
import pandas as pd
import uuid
import os
from flask import request, jsonify

def get_nested_value(record, path):
    """Safely extracts values from nested dictionaries using dot notation."""
    keys = path.split('.')
    val = record
    
    for k in keys:
        if isinstance(val, dict):
            val = val.get(k)
            
            # Dynamically detect and parse stringified JSON at any level
            if isinstance(val, str) and val.strip().startswith(('{', '[')):
                try:
                    val = json.loads(val)
                except json.JSONDecodeError:
                    pass # Keep it as a string if it's not actually valid JSON
        else:
            return ""
        
        if val is None:
            return ""
            
    if isinstance(val, list):
        return ", ".join(map(str, val))
    
    return str(val).strip()


def save_to_chromadb(df):
    session = None
    try:
        session = get_session()
        
        if df is None or df.empty:
            return {"status": "success", "message": "No records available."}

        # 1. Fetch all configurations from the database
        configs = session.query(SourceConfig).all()
        config_map = {c.source_brand: c for c in configs}

        # 2. Setup Vector Directory
        vector_dir = os.path.join(Config.DIRECTORY_PATH, "vector")
        os.makedirs(vector_dir, exist_ok=True)
        chroma_client = chromadb.PersistentClient(path=vector_dir)

        # 3. Group processed records by sourceBrand for bulk insertion
        brand_payloads = {
            brand: {"documents": [], "ids": [], "metadatas": [], "bm25": []}
            for brand in config_map.keys()
        }

        skipped_records = 0

        # 4. Iterate and extract dynamically
        for _, row in df.iterrows():
            record = row.to_dict()
            source_brand = record.get("sourceBrand", "")
            
            if source_brand not in config_map:
                skipped_records += 1
                continue

            config = config_map[source_brand]
            vector_id = str(uuid.uuid4())

            # Dynamically build embedding text
            embed_parts = []
            for field_path in config.embedding_fields:
                val = get_nested_value(record, field_path)
                if val:
                    field_name = field_path.split('.')[-1]
                    embed_parts.append(f"{field_name}: {val}")
            
            embed_text = "\n".join(embed_parts)
            
            if not embed_text:
                skipped_records += 1
                continue

            # Dynamically build metadata dictionary
            metadata = {"sourceBrand": source_brand}
            for meta_key, field_path in config.metadata_fields.items():
                val = get_nested_value(record, field_path)
                if val:
                    metadata[meta_key] = val

            # Append to brand-specific payload
            payload = brand_payloads[source_brand]
            payload["documents"].append(embed_text)
            payload["ids"].append(vector_id)
            payload["metadatas"].append(metadata)
            payload["bm25"].append({
                "id": vector_id,
                "page_content": embed_text,
                "metadata": metadata
            })

        # 5. Process each brand's payloads (Chroma & BM25)
        total_saved = 0
        bm25_base_path = getattr(Config, 'BM25_STORE_PATH', './bm25_indices')

        for brand, payload in brand_payloads.items():
            if not payload["documents"]:
                continue
                
            config = config_map[brand]

            # Upsert to ChromaDB
            collection = chroma_client.get_or_create_collection(name=config.chroma_collection)
            embeddings = embed_texts(payload["documents"]) # Ensure this uses your embedding function
            
            collection.upsert(
                ids=payload["ids"],
                embeddings=embeddings,
                documents=payload["documents"],
                metadatas=payload["metadatas"]
            )

            # Update BM25 JSON
            bm25_folder_path = os.path.join(bm25_base_path, config.bm25_folder)
            os.makedirs(bm25_folder_path, exist_ok=True)
            bm25_file_path = os.path.join(bm25_folder_path, f"bm25_{config.bm25_folder}.json")

            existing_bm25 = []
            if os.path.exists(bm25_file_path):
                with open(bm25_file_path, "r", encoding="utf-8") as f:
                    existing_bm25 = json.load(f)
            
            # Merge using dictionary comprehension for speed
            bm25_dict = {doc["id"]: doc for doc in existing_bm25 if "id" in doc}
            for new_doc in payload["bm25"]:
                bm25_dict[new_doc["id"]] = new_doc

            # Write updated BM25
            temp_path = f"{bm25_file_path}.tmp"
            with open(temp_path, "w", encoding="utf-8") as f:
                json.dump(list(bm25_dict.values()), f, ensure_ascii=False, indent=4)
            os.replace(temp_path, bm25_file_path)

            total_saved += len(payload["ids"])

        return {
            "status": "success",
            "records_received": len(df),
            "records_saved": total_saved,
            "records_skipped": skipped_records
        }

    except Exception as error:
        return {
            "status": "failed",
            "error": str(error)
        }
    finally:
        if session:
            session.close()