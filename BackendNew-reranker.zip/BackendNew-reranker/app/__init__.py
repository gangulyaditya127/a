from app.controllers.resolution_recommender.resolution_recommender import appy
from app.controllers.dqCheck.main import app as dqApp

from flask import Flask, request, jsonify, render_template
from flask_cors import CORS, cross_origin
import os
from flasgger import Swagger

def create_app(test_config=None):
    app = Flask(__name__, instance_relative_config=True)
    CORS(app)
    print(os.getcwd())
    swagger = Swagger(app)
    app.config.from_pyfile('../app/config.cfg', silent=True)
    app.register_blueprint(appy)
    app.register_blueprint(dqApp)
    try:
        os.makedirs(app.instance_path)
    except OSError:
        pass
    return app