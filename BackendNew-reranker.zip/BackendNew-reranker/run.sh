export FLASK_ENV=development
flask run -h 0.0.0.0 -p 8004 --cert=ismartams.crt --key=ismartams.key