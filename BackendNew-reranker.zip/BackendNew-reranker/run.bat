@set FLASK_ENV=development
@REM @set FLASK_DEBUG=1
flask run -h 0.0.0.0 -p 8004 