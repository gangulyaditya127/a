# ============================================================
# SSL / CORPORATE PROXY BYPASS (FOR GEMINI ONLY)
# ============================================================
import os
import ssl

os.environ["PYTHONHTTPSVERIFY"] = "0"
os.environ["CURL_CA_BUNDLE"] = ""
os.environ["REQUESTS_CA_BUNDLE"] = ""
os.environ["SSL_CERT_FILE"] = ""

ssl._create_default_https_context = ssl._create_unverified_context

# ============================================================
# IMPORTS
# ============================================================
import streamlit as st
import pandas as pd
import numpy as np
import io

from google import genai
from docx import Document

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# ============================================================
# STREAMLIT CONFIG
# ============================================================
st.set_page_config(
    page_title="ARE AI – Large Dataset Analyzer",
    layout="wide"
)

st.title("📊 ARE AI – Large Dataset Analyzer")
st.caption("Offline TF‑IDF RAG + Google Gemini (Enterprise Safe)")

# ============================================================
# GEMINI CLIENT (TEXT GENERATION ONLY ✅)
# ============================================================
GEMINI_API_KEY = "AIzaSyDk4nEylbyBhq1fdpy6TsP1GpD5sJTZyEY"
gemini_client = genai.Client(api_key=GEMINI_API_KEY)

# ============================================================
# WORD REPORT
# ============================================================
def create_docx(text):
    doc = Document()
    doc.add_heading("AI Data Analysis Report", 0)
    for line in text.split("\n"):
        if line.strip():
            doc.add_paragraph(line)
    buffer = io.BytesIO()
    doc.save(buffer)
    buffer.seek(0)
    return buffer

# ============================================================
# DATAFRAME → TEXT CHUNKS
# ============================================================
def dataframe_to_chunks(df, chunk_size=40):
    chunks = []
    for i in range(0, len(df), chunk_size):
        chunk_df = df.iloc[i:i + chunk_size]
        chunks.append(chunk_df.to_string(index=False))
    return chunks

# ============================================================
# TF‑IDF EMBEDDINGS (OFFLINE ✅)
# ============================================================
def build_tfidf_embeddings(chunks):
    vectorizer = TfidfVectorizer(
        stop_words="english",
        max_features=5000
    )
    embeddings = vectorizer.fit_transform(chunks)
    return vectorizer, embeddings

# ============================================================
# RETRIEVE TOP‑K CHUNKS
# ============================================================
def retrieve_chunks(query, vectorizer, chunk_embeddings, chunks, k=3):
    query_vec = vectorizer.transform([query])
    similarities = cosine_similarity(query_vec, chunk_embeddings)[0]
    top_indices = np.argsort(similarities)[-k:][::-1]
    return [chunks[i] for i in top_indices]

# ============================================================
# UI
# ============================================================
uploaded_file = st.file_uploader(
    "Upload CSV or Excel (Large datasets supported)",
    type=["csv", "xlsx"]
)

if uploaded_file:

    df = (
        pd.read_csv(uploaded_file)
        if uploaded_file.name.endswith(".csv")
        else pd.read_excel(uploaded_file)
    )

    st.subheader("🔍 Data Preview")
    st.dataframe(df.head(), use_container_width=True)

    query = st.text_area(
        "Ask a question about your data",
        value="Summarize trends, anomalies, risks, and recommendations"
    )

    if st.button("🚀 Analyze"):

        with st.spinner("Analyzing data using offline RAG..."):
            
            # 1. Chunk data
            chunks = dataframe_to_chunks(df)

            # 2. Build TF‑IDF embeddings (LOCAL ✅)
            vectorizer, chunk_embeddings = build_tfidf_embeddings(chunks)

            # 3. Retrieve relevant chunks
            relevant_chunks = retrieve_chunks(
                query=query,
                vectorizer=vectorizer,
                chunk_embeddings=chunk_embeddings,
                chunks=chunks,
                k=3
            )

            context = "\n\n".join(relevant_chunks)
            st.subheader("📊 Context")
            st.write(context)
            # 4. Gemini generation
            prompt = f"""
You are a senior enterprise data analyst.

Context retrieved from dataset:
{context}

User Question:
{query}

Provide:
- Key observations
- Trends
- Anomalies
- Risks
- Actionable recommendations
"""

            response = gemini_client.models.generate_content(
                model="gemini-2.5-flash-lite",
                contents=prompt
            )

            result = response.text
        st.subheader("📊 Context")
        st.write(context)
        st.subheader("📊 AI Insights")
        st.write(result)

        st.download_button(
            label="📄 Download Report (Word)",
            data=create_docx(result),
            file_name="ARE_AI_Analysis_Report.docx",
            mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        )

else:
    st.info("⬅️ Upload a file to begin analysis")