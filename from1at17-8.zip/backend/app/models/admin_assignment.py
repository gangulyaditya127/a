"""SQLAlchemy model for admin-to-onboarding assignments."""

from datetime import datetime

from sqlalchemy import ForeignKey, func
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.database import Base


class AdminAssignment(Base):
    """Tracks admin assignment to an onboarding workflow."""

    __tablename__ = "admin_assignments"

    id: Mapped[str] = mapped_column(primary_key=True)
    onboarding_id: Mapped[str] = mapped_column(
        ForeignKey("onboardings.id", ondelete="CASCADE"),
    )
    admin_id: Mapped[str] = mapped_column(
        ForeignKey("users.id"),
    )
    assigned_by: Mapped[str] = mapped_column(
        ForeignKey("users.id"),
    )
    assigned_at: Mapped[datetime] = mapped_column(server_default=func.now())
    status: Mapped[str] = mapped_column(default="active")  # 'active', 'completed', 'reassigned'

    admin = relationship("User", foreign_keys=[admin_id], lazy="joined")
