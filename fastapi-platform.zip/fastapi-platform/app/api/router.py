from fastapi import APIRouter
from app.services.postmortem.routes import router as postmortem_router
# from app.services.ams_analytics.routes import router as ams_router  # future

api_router = APIRouter()
api_router.include_router(postmortem_router)
# api_router.include_router(ams_router)
