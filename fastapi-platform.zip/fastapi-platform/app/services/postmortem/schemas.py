from pydantic import BaseModel
from typing import Optional, Dict, Any

class InitRequest(BaseModel):
    req_id: str
    incident_no: str

class ConversationRequest(BaseModel):
    req_id: str
    answer: Optional[str] = ""
    incident: Optional[Dict[str, Any]] = None
