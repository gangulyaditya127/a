from sqlalchemy import Column, Integer, String, Text, DateTime
from datetime import datetime
from app.core.db import Base

class Postmortem(Base):
    __tablename__ = "postmortems"
    id = Column(Integer, primary_key=True, index=True)
    req_id = Column(String, unique=True, index=True, nullable=False)
    incident_no = Column(String, nullable=True)
    title = Column(String, nullable=True)
    status = Column(String, default="open")
    chat_history = Column(Text, default="[]")
    final_report = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow)
