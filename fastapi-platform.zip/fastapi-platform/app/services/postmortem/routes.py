from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from datetime import datetime
import json
from agents import Runner, SQLiteSession

from app.core.db import get_db, Base, engine
from app.services.postmortem.models import Postmortem
from app.services.postmortem.schemas import InitRequest, ConversationRequest
from app.services.postmortem.agents import init_agent, qa_agent
from app.core.config import settings

Base.metadata.create_all(bind=engine)

router = APIRouter(prefix="/postmortem", tags=["postmortem"])

def append_chat(db: Session, req_id: str, item: dict):
    row = db.query(Postmortem).filter(Postmortem.req_id == req_id).first()
    if not row:
        raise ValueError("Session not found")
    chat = json.loads(row.chat_history or "[]")
    chat.append(item)
    row.chat_history = json.dumps(chat)
    row.updated_at = datetime.utcnow()
    db.add(row)
    db.commit()

@router.post("/init")
async def postmortem_init(payload: InitRequest, db: Session = Depends(get_db)):
    row = db.query(Postmortem).filter(Postmortem.req_id == payload.req_id).first()
    if row:
        raise HTTPException(status_code=400, detail="req_id already exists")
    row = Postmortem(req_id=payload.req_id, incident_no=payload.incident_no,
                     chat_history="[]", status="open")
    db.add(row)
    db.commit()

    runner_session = SQLiteSession(payload.req_id, settings.POSTMORTEM_SESSION_DB)
    input_payload = json.dumps({"cmd": "fetch_incident",
                                "incident_no": payload.incident_no,
                                "req_id": payload.req_id})
    result = await Runner.run(starting_agent=init_agent,
                              input=input_payload,
                              session=runner_session)

    try:
        agent_out = json.loads(result.final_output)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Init agent non-JSON: {e}")

    incident = agent_out.get("incident")
    question = agent_out.get("question")
    if not incident or not question:
        raise HTTPException(status_code=500, detail="Init agent missing incident/question")

    now = datetime.utcnow().strftime("%Y/%m/%d %H:%M:%S")

    incident_msg = {
        "isBot": True,
        "response": json.dumps({"incident_summary": incident}),
        "showOptions": False,
        "options": [],
        "timestamp": now,
    }
    append_chat(db, payload.req_id, incident_msg)

    question_msg = {
        "isBot": True,
        "response": question,
        "showOptions": agent_out.get("isoptions", False),
        "options": agent_out.get("listOfOptions", []),
        "timestamp": now,
    }
    append_chat(db, payload.req_id, question_msg)

    return {
        "incident": incident,
        "question": question,
        "isoptions": agent_out.get("isoptions", False),
        "listOfOptions": agent_out.get("listOfOptions", []),
        "isLast": agent_out.get("isLast", False),
    }

@router.post("/conversation")
async def postmortem_conversation(payload: ConversationRequest,
                                  db: Session = Depends(get_db)):
    row = db.query(Postmortem).filter(Postmortem.req_id == payload.req_id).first()
    if not row:
        raise HTTPException(status_code=404, detail="req_id not found")

    incident = payload.incident
    if not incident:
        chat = json.loads(row.chat_history or "[]")
        for msg in chat:
            if msg.get("isBot") and msg.get("response"):
                try:
                    parsed = json.loads(msg["response"])
                    if isinstance(parsed, dict) and parsed.get("incident_summary"):
                        incident = parsed["incident_summary"]
                        break
                except Exception:
                    continue

    agent_input = {
        "req_id": payload.req_id,
        "incident": incident,
        "answer": payload.answer or "",
    }
    runner_session = SQLiteSession(payload.req_id, settings.POSTMORTEM_SESSION_DB)
    result = await Runner.run(starting_agent=qa_agent,
                              input=json.dumps(agent_input),
                              session=runner_session)

    try:
        agent_out = json.loads(result.final_output)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"QA agent non-JSON: {e}")

    now = datetime.utcnow().strftime("%Y/%m/%d %H:%M:%S")

    if payload.answer:
        append_chat(db, payload.req_id, {
            "isBot": False,
            "response": payload.answer,
            "timestamp": now,
        })

    if agent_out.get("isLast") is not True:
        qmsg = {
            "isBot": True,
            "response": agent_out.get("question"),
            "showOptions": agent_out.get("isoptions", False),
            "options": agent_out.get("listOfOptions", []),
            "timestamp": now,
        }
        append_chat(db, payload.req_id, qmsg)
        return {
            "question": agent_out.get("question"),
            "isoptions": agent_out.get("isoptions", False),
            "listOfOptions": agent_out.get("listOfOptions", []),
            "isLast": False,
        }

    postmortem_html = agent_out.get("postmortem")
    if not postmortem_html:
        raise HTTPException(status_code=500,
                            detail="Agent final report missing 'postmortem' key")

    row.final_report = json.dumps(postmortem_html, indent=2)
    row.status = "closed"
    row.updated_at = datetime.utcnow()
    db.add(row)
    db.commit()

    append_chat(db, payload.req_id, {
        "isBot": True,
        "response": "Final Postmortem generated",
        "showOptions": False,
        "options": [],
        "timestamp": now,
    })

    return {
        "question": "Final Postmortem generated",
        "isoptions": False,
        "listOfOptions": [],
        "isLast": True,
        "postmortem": postmortem_html,
    }
