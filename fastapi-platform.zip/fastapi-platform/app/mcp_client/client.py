from agents.mcp import MCPServerSse, create_static_tool_filter
from app.core.config import settings

mcp_server = None  # shared instance

async def init_mcp_client():
    global mcp_server
    if mcp_server is None:
        mcp_server = MCPServerSse(
            {"url": settings.MCP_SERVER_URL},
            client_session_timeout_seconds=60,
            tool_filter=create_static_tool_filter(
                allowed_tool_names=["fetch_incident_details"]
            ),
        )
        await mcp_server.connect()
