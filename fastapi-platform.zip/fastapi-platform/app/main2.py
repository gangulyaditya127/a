# app/main.py
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.api.router import api_router
from app.services.postmortem.agents import init_postmortem_agents  # see below

app = FastAPI(title="Agentic Platform")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event("startup")
async def startup_event():
    # Initialize MCP client and all agents for all modules
    await init_postmortem_agents()
    # await init_ams_agents()  # future service modules, same server

app.include_router(api_router)
