import os
from pydantic import BaseSettings

class Settings(BaseSettings):
    DB_URL: str = "sqlite:///./postmortem.db"
    POSTMORTEM_SESSION_DB: str = "postmortem_conversation.db"
    MCP_SERVER_URL: str = "http://127.0.0.1:8000/sse"
    OPENAI_BASE_URL: str = "http://10.170.21.213:20119"
    OPENAI_API_KEY: str = "YOUR_KEY"  # move your key here
    # proxy, etc.

    class Config:
        env_file = ".env"

settings = Settings()
