# CloudOps Onboarding — Complete API Flow Guide
### Frontend ↔ Backend for User, Admin, and SuperAdmin

---

## 📖 How to read this guide

Each flow entry shows:
- **User action** — what the user clicks/does
- **Frontend file** — which component triggers it
- **API call** — HTTP method + endpoint
- **Request body** — what is sent
- **Response** — what comes back
- **Backend file** — which router + service handles it

Auth header sent on **every** request: `X-User-Id: <uuid from localStorage>`

---

---

# 👤 USER FLOW

---

## Phase 1 — App Startup / Login

### Step 1.1 — App loads, auto-login
**Trigger:** `AuthProvider` mounts  
**Frontend:** [`AuthContext.tsx`](file:///c:/Users/SaikatMaji/Documents/from1at17-8/frontend/src/contexts/AuthContext.tsx) → `useEffect` on mount

**API Call 1:** Check saved user
```
GET /api/auth/me
Headers: X-User-Id: <saved_id from localStorage>
```
**Response:**
```json
{ "id": "uuid", "name": "John Doe", "email": "john@tcs.com", "emp_id": "TCS001", "role": "user" }
```
**Backend:** [`domains/auth/router.py`](file:///c:/Users/SaikatMaji/Documents/from1at17-8/backend/app/domains/auth/router.py) → `GET /me` → reads `X-User-Id` header → returns user

---

**If no saved user → Auto-login (dev mode)**

**API Call 2:**
```
GET /api/auth/users
```
**Response:**
```json
[
  { "id": "uuid1", "name": "Super Admin", "role": "superadmin", ... },
  { "id": "uuid2", "name": "DIS Admin", "role": "admin", ... },
  { "id": "uuid3", "name": "John User", "role": "user", ... }
]
```
→ Picks superadmin first, saves `uuid` to localStorage as `auth_user_id`  
**Backend:** [`domains/auth/router.py`](file:///c:/Users/SaikatMaji/Documents/from1at17-8/backend/app/domains/auth/router.py) → `GET /users`

---

## Phase 2 — Dashboard

### Step 2.1 — Dashboard loads user's onboardings
**Trigger:** `<Dashboard />` mounts  
**Frontend:** [`components/Dashboard.tsx`](file:///c:/Users/SaikatMaji/Documents/from1at17-8/frontend/src/components/Dashboard.tsx) → `useEffect` → `fetchOnboardings()`

```
GET /api/onboardings
Headers: X-User-Id: <user_id>
```
**Response:**
```json
[
  {
    "id": "onb_abc123",
    "name": "My Cloud Project",
    "status": "draft",
    "current_step": 2,
    "created_at": "2026-08-01T10:00:00Z",
    "updated_at": "2026-08-01T12:00:00Z"
  }
]
```
**Backend:** [`domains/onboarding/router.py`](file:///c:/Users/SaikatMaji/Documents/from1at17-8/backend/app/domains/onboarding/router.py) → `GET /`  
→ `service.get_all_onboardings(db, user_id=user.id)` → filters by `user_id`

---

### Step 2.2 — User resumes an existing onboarding
**Trigger:** User clicks "Resume" on a card  
**Frontend:** [`pages/Index.tsx`](file:///c:/Users/SaikatMaji/Documents/from1at17-8/frontend/src/pages/Index.tsx) → `handleResume(id)` → `getOnboarding(id)`

```
GET /api/onboardings/onb_abc123
Headers: X-User-Id: <user_id>
```
**Response:**
```json
{
  "id": "onb_abc123",
  "name": "My Cloud Project",
  "status": "draft",
  "current_step": 3,
  "admin_status": null,
  "account_details": {
    "project_name": "MyApp", "isu": "ISU001", "account_name": "dev-account",
    "owner": "John Doe", "emp_id": "TCS001", "description": "...", "business_unit": "TCS-DIS"
  },
  "requirement_assessment": {
    "solution_type": "generative-ai", "deployment_environments": ["dev","uat"],
    "cloud_provider": "AWS", "region": "ap-south-1"
  },
  "remaining_state": { "cloudResources": [...], "architectureOverview": {...}, ... },
  "admin_comments": []
}
```
→ Wizard is opened pre-filled with this data  
**Backend:** [`domains/onboarding/router.py`](file:///c:/Users/SaikatMaji/Documents/from1at17-8/backend/app/domains/onboarding/router.py) → `GET /{onboarding_id}` → `service.get_onboarding(db, id)`

---

### Step 2.3 — User deletes an onboarding
**Frontend:** Dashboard → trash icon → `apiDeleteOnboarding(id)`, then reloads list

```
DELETE /api/onboardings/onb_abc123
```
**Response:** `204 No Content`  
**Backend:** `DELETE /{onboarding_id}` → `service.delete_onboarding(db, id)` — cascades all related data

---

## Phase 3 — Eligibility Assessment

### Step 3.1 — Load eligibility questions
**Trigger:** User clicks "New Onboarding" → `<EligibilityAssessment />` mounts  
**Frontend:** [`components/EligibilityAssessment.tsx`](file:///c:/Users/SaikatMaji/Documents/from1at17-8/frontend/src/components/EligibilityAssessment.tsx) → `fetchEligibilityQuestions()`

```
GET /api/onboardings/eligibility/questions
```
**Response:**
```json
[
  {
    "section": "Project Classification",
    "title": "Is this project hosted on TCS-approved cloud infrastructure?",
    "note": null,
    "question_type": "single",
    "options": ["Yes", "No"],
    "correct_answer": "Yes",
    "fail_message": "Only TCS-approved cloud providers are supported.",
    "sort_order": 1
  }
]
```
→ Each question is shown one-by-one. Wrong answer = fail screen shown. All correct = moves to Disclaimer.  
**Backend:** [`domains/onboarding/router.py`](file:///c:/Users/SaikatMaji/Documents/from1at17-8/backend/app/domains/onboarding/router.py) → `GET /eligibility/questions` → `service.get_eligibility_questions(db)`

---

## Phase 4 — Disclaimer

### Step 4.1 — Load disclaimer clauses
**Trigger:** Passes eligibility → `<EligibilityDisclaimer />` mounts  
**Frontend:** [`components/EligibilityDisclaimer.tsx`](file:///c:/Users/SaikatMaji/Documents/from1at17-8/frontend/src/components/EligibilityDisclaimer.tsx)

```
GET /api/onboardings/disclaimer/clauses
```
**Response:**
```json
[
  {
    "title": "Data Residency",
    "text": "All data must remain within approved TCS data centers...",
    "sort_order": 1
  }
]
```
→ User must read and click "I Agree" to continue  
**Backend:** `GET /disclaimer/clauses` → `service.get_disclaimer_clauses(db)`

---

## Phase 5 — Onboarding Wizard (Steps 1–9)

### Step 5.1 — Wizard initializes (NEW onboarding)
**Trigger:** User clicks "I Agree" on disclaimer  
**Frontend:** [`components/OnboardingWizard.tsx`](file:///c:/Users/SaikatMaji/Documents/from1at17-8/frontend/src/components/OnboardingWizard.tsx) → `useEffect` on mount → `createOnboarding()`

```
POST /api/onboardings
Body: { "name": "Untitled Onboarding" }
Headers: X-User-Id: <user_id>
```
**Response:**
```json
{
  "id": "onb_ff3a12",
  "name": "Untitled Onboarding",
  "status": "draft",
  "current_step": 1,
  "created_at": "2026-08-26T10:00:00Z"
}
```
→ `id` saved in `idRef.current` — used for all subsequent saves  
**Backend:** `POST /` → `service.create_onboarding(db, data, user_id=user.id)` → ID = `onb_` + 4 random hex bytes

---

### Step 5.2 — Step 1: Account Details → Next
**Trigger:** User fills form, clicks "Next"  
**Frontend:** `OnboardingWizard.tsx` → `saveCurrentStep()` → **two parallel calls:**

**Call A:**
```
PUT /api/onboardings/onb_ff3a12
Body: {
  "name": "MyApp Project",
  "current_step": 2,
  "remaining_state": { "cloudResources": [], "architectureOverview": {...}, ... }
}
```
**Response:** Full updated onboarding object

**Call B:**
```
PUT /api/account-details/onb_ff3a12
Body: {
  "project_name": "MyApp Project",
  "isu": "ISU001",
  "account_name": "dev-account",
  "owner": "John Doe",
  "emp_id": "TCS001",
  "description": "Cloud migration project",
  "business_unit": "TCS-DIS"
}
```
**Response:**
```json
{
  "id": "acct_uuid",
  "onboarding_id": "onb_ff3a12",
  "project_name": "MyApp Project",
  "isu": "ISU001", ...
}
```
**Backend:**  
- `PUT /api/onboardings/{id}` → [`domains/onboarding/router.py`](file:///c:/Users/SaikatMaji/Documents/from1at17-8/backend/app/domains/onboarding/router.py)  
- `PUT /api/account-details/{id}` → [`domains/account_details/router.py`](file:///c:/Users/SaikatMaji/Documents/from1at17-8/backend/app/domains/account_details/router.py)

---

### Step 5.3 — Step 2: Requirement Assessment → Next
**Two parallel calls:**

**Call A:** `PUT /api/onboardings/onb_ff3a12` (updates `current_step: 3`)

**Call B:**
```
PUT /api/requirements/onb_ff3a12
Body: {
  "solution_type": "generative-ai",
  "deployment_environments": ["dev", "uat", "prod"],
  "cloud_provider": "AWS",
  "region": "ap-south-1"
}
```
**Response:**
```json
{
  "id": "req_uuid",
  "onboarding_id": "onb_ff3a12",
  "solution_type": "generative-ai",
  "deployment_environments": ["dev","uat","prod"],
  "cloud_provider": "AWS",
  "region": "ap-south-1"
}
```
**Backend:** `PUT /api/requirements/{id}` → [`domains/requirements/router.py`](file:///c:/Users/SaikatMaji/Documents/from1at17-8/backend/app/domains/requirements/router.py)

---

### Step 5.4 — Step 3: Cloud Resources — AI Chat
**Trigger:** User types message and presses Enter/Send  
**Frontend:** [`components/steps/StepCloudResources.tsx`](file:///c:/Users/SaikatMaji/Documents/from1at17-8/frontend/src/components/steps/StepCloudResources.tsx) → `sendMessage()` → `chatCloudResources()`

```
POST /api/cloud-resources/chat
Body: {
  "provider": "AWS",
  "message": "I need a 3-tier web app with high availability",
  "history": [
    { "role": "model", "text": "Hello! I'm your AI Cloud Architect..." }
  ]
}
```
**Response:**
```json
{
  "reply": "For a 3-tier web app on AWS, I recommend the following setup...",
  "proposed_resources": [
    { "service": "EC2 (t3.medium)", "count": 2, "configDetails": "Auto Scaling Group, Multi-AZ" },
    { "service": "RDS MySQL (db.t3.medium)", "count": 1, "configDetails": "Multi-AZ, 100GB storage" },
    { "service": "Application Load Balancer", "count": 1, "configDetails": "HTTPS listener" }
  ]
}
```
→ Proposed resources shown in a panel. User clicks "Add to Bucket" → `generateId()` assigns local IDs  
**Backend:** `POST /api/cloud-resources/chat` → [`domains/cloud_resources/router.py`](file:///c:/Users/SaikatMaji/Documents/from1at17-8/backend/app/domains/cloud_resources/router.py) → calls Gemini LLM

---

### Step 5.5 — Step 3: Cloud Resources → Next (saves bucket)
**Two parallel calls:**

**Call A:** `PUT /api/onboardings/onb_ff3a12` (updates step)

**Call B:**
```
PUT /api/cloud-resources/onb_ff3a12/bucket
Body: {
  "provider": "AWS",
  "resources": [
    { "service": "EC2 (t3.medium)", "count": 2, "configDetails": "Auto Scaling Group, Multi-AZ" },
    { "service": "RDS MySQL", "count": 1, "configDetails": "Multi-AZ" }
  ]
}
```
**Response:**
```json
{
  "id": "bucket_uuid",
  "onboarding_id": "onb_ff3a12",
  "provider": "AWS",
  "resources": [ ... ]
}
```
**Backend:** `PUT /api/cloud-resources/{id}/bucket` → [`domains/cloud_resources/router.py`](file:///c:/Users/SaikatMaji/Documents/from1at17-8/backend/app/domains/cloud_resources/router.py)

---

### Step 5.6 — Step 4: Architecture Overview — Load existing (on mount)
**Frontend:** [`components/steps/StepArchitectureOverview.tsx`](file:///c:/Users/SaikatMaji/Documents/from1at17-8/frontend/src/components/steps/StepArchitectureOverview.tsx) → `useEffect` → `getArchitectureValidation()`

```
GET /api/architecture-validation/onb_ff3a12
```
**Response (if no diagram yet):** `404 Not Found`  
**Response (if diagram exists):**
```json
{
  "id": "arch_uuid",
  "onboarding_id": "onb_ff3a12",
  "image_filename": "diagram.png",
  "verdict": "PASS",
  "violations": [],
  "validated_at": "2026-08-26T10:00:00Z"
}
```
**Backend:** `GET /api/architecture-validation/{id}` → [`domains/architecture/router.py`](file:///c:/Users/SaikatMaji/Documents/from1at17-8/backend/app/domains/architecture/router.py)

---

### Step 5.7 — Step 4: Upload architecture diagram
**Trigger:** User selects a file

```
POST /api/architecture-validation/onb_ff3a12/upload
Content-Type: multipart/form-data
Body: file=<image_binary>
Headers: X-User-Id: <user_id>   (NO Content-Type header — browser sets boundary)
```
**Response:**
```json
{
  "id": "arch_uuid",
  "onboarding_id": "onb_ff3a12",
  "image_filename": "my-diagram.png",
  "message": "Diagram uploaded successfully."
}
```
**Backend:** `POST /{id}/upload` → `service.upload_image()` → stores image as base64 in DB

---

### Step 5.8 — Step 4: Validate architecture with LLM
**Trigger:** User clicks "Validate Architecture"

```
POST /api/architecture-validation/onb_ff3a12/validate
Headers: X-User-Id: <user_id>
```
**Response:**
```json
{
  "id": "arch_uuid",
  "onboarding_id": "onb_ff3a12",
  "image_filename": "my-diagram.png",
  "verdict": "FAIL",
  "violations": [
    {
      "category": "Security",
      "rule_text": "All data stores must be in private subnets",
      "severity": "HIGH",
      "finding": "RDS instance appears to be in a public subnet"
    }
  ],
  "validated_at": "2026-08-26T10:05:00Z"
}
```
→ Violations are shown per severity. User sees what to fix.  
**Backend:** `POST /{id}/validate` → `service.validate_architecture()` → sends diagram + rules to Gemini Vision LLM

---

### Step 5.9 — Step 4: Submit for Admin Review
**Trigger:** User clicks "Submit for Review" (after step 4)  
**Frontend:** `OnboardingWizard.tsx` → `handleSubmitForReview()` → `saveCurrentStep(state, 5)`

```
PUT /api/onboardings/onb_ff3a12
Body: {
  "name": "MyApp Project",
  "current_step": 5,
  "remaining_state": { ... },
  "status": "submitted"
}
```
→ User sees a **Pending Admin Review** locked screen  
→ `admin_status` changes to `pending_assignment` (superadmin must assign an admin)

---

### Step 5.10 — Pending State: Load interaction timeline
**Trigger:** Wizard renders pending view → `fetchUserEvents()`

```
GET /api/onboardings/onb_ff3a12/events
```
**Response:**
```json
[
  {
    "id": "evt_uuid",
    "onboarding_id": "onb_ff3a12",
    "ts": "2026-08-26T10:00:00Z",
    "actor": "system",
    "actor_name": "System",
    "kind": "submitted",
    "title": "Onboarding submitted for review",
    "body": null
  },
  {
    "actor": "admin",
    "actor_name": "DIS Admin",
    "kind": "feedback",
    "title": "Section Reviewed: Account Details",
    "body": "Looks good, approved."
  }
]
```
**Backend:** `GET /{id}/events` → [`domains/onboarding/router.py`](file:///c:/Users/SaikatMaji/Documents/from1at17-8/backend/app/domains/onboarding/router.py) → delegates to `disadmin.service.get_interaction_events()`

---

### Step 5.11 — Resubmit after "Sent Back"
**Trigger:** Admin sent back the onboarding → user fixes and clicks "Resubmit"

```
POST /api/onboardings/onb_ff3a12/resubmit
Body: { "comment": "Fixed the subnet configuration as requested" }
```
**Response:** `{ "status": "resubmitted" }`  
→ `admin_status` resets to `under_review` — admin can review again  
**Backend:** `POST /{id}/resubmit` → `disadmin.service.resubmit_onboarding()` → logs an event

---

### Step 5.12 — Step 5: Cost Estimation (after admin publishes)
**Trigger:** Step 5 mounts (only reachable after `admin_status = approval_checklist_sent`)

```
GET /api/onboardings/onb_ff3a12/cost
Headers: X-User-Id: <user_id>
```
**Response (admin has published):**
```json
{
  "status": "published",
  "resource_costs": [
    { "resource_name": "EC2 t3.medium x2", "unit_cost": 3500, "quantity": 2, "monthly_cost": 7000 },
    { "resource_name": "RDS MySQL db.t3.medium", "unit_cost": 5000, "quantity": 1, "monthly_cost": 5000 }
  ],
  "infra_support_cost": 2000,
  "total_monthly_cost": 14000,
  "total_annual_cost": 168000,
  "currency": "INR",
  "notes": "Costs estimated for Mumbai region. Subject to change."
}
```
**Response (admin not yet published):**
```json
{ "status": "pending" }
```
→ Shows "Waiting for admin cost budgeting..." screen  
**Backend:** `GET /{id}/cost` → [`domains/onboarding/router.py`](file:///c:/Users/SaikatMaji/Documents/from1at17-8/backend/app/domains/onboarding/router.py) → reads from `cost_estimation` table

---

### Step 5.13 — Step 6: Recommendations
**Trigger:** Step 6 mounts → `fetchUserRecommendations()`

```
GET /api/onboardings/onb_ff3a12/recommendations
```
**Response (published):**
```json
{
  "status": "published",
  "recommendations": [
    {
      "id": "rec_uuid1",
      "category": "gps",
      "title": "GPS – Cloud Infrastructure Provisioning",
      "summary": "Raise a GPS ticket for EC2 and RDS provisioning",
      "parameters": [
        { "label": "GPS Category", "value": "IaaS Provisioning" },
        { "label": "SLA", "value": "5 business days" }
      ],
      "copy_text": "GPS Request: Cloud Infrastructure...",
      "status": "active"
    },
    {
      "category": "rfc",
      "title": "RFC – AD Group Creation",
      "summary": "Create security groups for cloud RBAC"
    }
  ]
}
```
**Response (pending):** `{ "status": "pending", "recommendations": [] }`  
**Backend:** `GET /{id}/recommendations` → checks `admin_status == "approval_checklist_sent"` first

---

---

# 🛠️ ADMIN (DIS Admin) FLOW

---

## Phase 1 — Admin Dashboard

### Step A1.1 — Load dashboard
**Trigger:** Admin navigates to `/admin`  
**Frontend:** [`pages/admin/AdminDashboard.tsx`](file:///c:/Users/SaikatMaji/Documents/from1at17-8/frontend/src/pages/admin/AdminDashboard.tsx) → `fetchAdminDashboard()`

```
GET /api/admin/dashboard
Headers: X-User-Id: <admin_id>
```
**Response:**
```json
{
  "total_assigned": 5,
  "pending_review": 2,
  "approved": 1,
  "sent_back": 1,
  "cost_pending": 1,
  "recommendations_pending": 0,
  "onboardings": [
    {
      "id": "onb_ff3a12",
      "name": "MyApp Project",
      "status": "submitted",
      "admin_status": "under_review",
      "user_name": "John Doe",
      "user_email": "john@tcs.com",
      "account_details": { "project_name": "MyApp Project", ... },
      "created_at": "2026-08-01T10:00:00Z"
    }
  ]
}
```
**Backend:** `GET /api/admin/dashboard` → [`admin/disadmin/router.py`](file:///c:/Users/SaikatMaji/Documents/from1at17-8/backend/app/admin/disadmin/router.py) → `service.get_dashboard(db, admin)` → only returns onboardings assigned to this admin

---

## Phase 2 — Admin Review Page

### Step A2.1 — Load full onboarding detail
**Trigger:** Admin clicks "Review" on a card → `/admin/review/onb_ff3a12`  
**Frontend:** [`pages/admin/AdminOnboardingReview.tsx`](file:///c:/Users/SaikatMaji/Documents/from1at17-8/frontend/src/pages/admin/AdminOnboardingReview.tsx) → `Promise.all([fetchAdminOnboarding, getRecommendations, fetchInteractionEvents])`

**Call 1:**
```
GET /api/admin/onboardings/onb_ff3a12
Headers: X-User-Id: <admin_id>
```
**Response:**
```json
{
  "id": "onb_ff3a12",
  "name": "MyApp Project",
  "admin_status": "under_review",
  "is_read_only": false,
  "account_details": { "project_name": "MyApp", "isu": "ISU001", ... },
  "requirement_assessment": { "solution_type": "generative-ai", "cloud_provider": "AWS", ... },
  "cloud_resource_bucket": {
    "provider": "AWS",
    "resources": [ { "service": "EC2 t3.medium", "count": 2, "configDetails": "Multi-AZ" } ]
  },
  "architecture_validation": {
    "image_filename": "diagram.png",
    "verdict": "PASS",
    "violations": [],
    "validated_at": "2026-08-26T10:05:00Z"
  },
  "validation_feedbacks": [],
  "cost_estimation": null,
  "recommendations": []
}
```
> `is_read_only: true` if this onboarding is assigned to a DIFFERENT admin

**Call 2:** `GET /api/admin/onboardings/onb_ff3a12/recommendations` → existing recs

**Call 3:** `GET /api/admin/onboardings/onb_ff3a12/events` → activity timeline

**Backend:** `GET /api/admin/onboardings/{id}` → [`admin/disadmin/router.py`](file:///c:/Users/SaikatMaji/Documents/from1at17-8/backend/app/admin/disadmin/router.py) → `service.get_onboarding_detail()` → eager-loads all relationships

---

### Step A2.2 — Submit section feedback (Approve / Reject / Comment)
**Trigger:** Admin clicks "Approve", "Reject", or "Comment" on a section  
**Frontend:** `AdminOnboardingReview.tsx` → `submitFeedback(id, { section, status, comment })`

```
POST /api/admin/onboardings/onb_ff3a12/feedback
Headers: X-User-Id: <admin_id>
Body: {
  "section": "account_details",
  "status": "approved",
  "comment": "Looks good"
}
```
Valid sections: `account_details | requirements | cloud_resources | architecture`  
Valid statuses: `approved | rejected | comment`

**Response:** `{ "ok": true }`  
→ A `ValidationFeedback` row is saved. An `InteractionEvent` is logged.  
**Backend:** `POST /api/admin/onboardings/{id}/feedback` → `service.submit_feedback()` → saves feedback + logs event

---

### Step A2.3 — Approve entire onboarding (all 4 sections must be approved first)
**Trigger:** Admin clicks "Approve Onboarding"

```
POST /api/admin/onboardings/onb_ff3a12/approve
Headers: X-User-Id: <admin_id>
```
**Response (success):**
```json
{ "message": "Onboarding approved", "admin_status": "cost_pending" }
```
**Response (fail — not all sections approved):**
```json
{ "detail": "Cannot approve: all sections must be approved first" }
```
→ `admin_status` changes to `cost_pending`  
**Backend:** `service.approve_onboarding()` → checks all 4 section feedbacks are `approved` → updates `admin_status`

---

### Step A2.4 — Send back to user
**Trigger:** Admin clicks "Send Back" + writes a comment

```
POST /api/admin/onboardings/onb_ff3a12/send-back
Body: { "comment": "Please update the subnet configuration in the architecture diagram" }
```
**Response:** `{ "message": "Onboarding sent back to user", "admin_status": "sent_back" }`  
→ User sees resubmit screen. Event is logged to timeline.  
**Backend:** `service.send_back()` → sets `admin_status = sent_back` + logs event

---

## Phase 3 — Cost Estimation

### Step A3.1 — Seed cost from cloud resource bucket
**Trigger:** Admin clicks "Import from Bucket" (auto-populate cost rows)

```
GET /api/admin/onboardings/onb_ff3a12/cost/seed-from-bucket
Headers: X-User-Id: <admin_id>
```
**Response:**
```json
[
  { "resource_name": "EC2 t3.medium x2", "unit_cost": 3500, "quantity": 2, "monthly_cost": 7000 },
  { "resource_name": "RDS MySQL db.t3.medium", "unit_cost": 5000, "quantity": 1, "monthly_cost": 5000 }
]
```
→ Pre-fills the cost table for the admin to edit  
**Backend:** `service.seed_cost_from_bucket()` → reads `cloud_resource_bucket` → maps services to estimated costs

---

### Step A3.2 — Save cost estimation
**Trigger:** Admin edits cost table and clicks "Save Cost"

```
PUT /api/admin/onboardings/onb_ff3a12/cost
Body: {
  "resource_costs": [
    { "resource_name": "EC2 t3.medium x2", "unit_cost": 3500, "quantity": 2, "monthly_cost": 7000 }
  ],
  "infra_support_cost": 2000,
  "total_monthly_cost": 14000,
  "total_annual_cost": 168000,
  "currency": "INR",
  "notes": "Mumbai region estimate"
}
```
**Response:** The saved cost estimation object  
**Backend:** `PUT /api/admin/onboardings/{id}/cost` → `service.upsert_cost()` → upserts `CostEstimation` row

---

## Phase 4 — Recommendations

### Step A4.1 — Generate recommendations via LLM
**Trigger:** Admin clicks "Generate Recommendations"

```
POST /api/admin/onboardings/onb_ff3a12/recommendations/generate
Headers: X-User-Id: <admin_id>
```
**Response:**
```json
[
  {
    "id": "rec_uuid1",
    "category": "gps",
    "title": "GPS – IaaS Provisioning for AWS EC2 and RDS",
    "summary": "Raise GPS ticket for compute and database provisioning in ap-south-1",
    "parameters": [
      { "label": "GPS Category", "value": "Cloud Infrastructure" },
      { "label": "Priority", "value": "High" }
    ],
    "copy_text": "GPS: IaaS Provisioning...",
    "status": "active"
  },
  {
    "category": "rfc",
    "title": "RFC – AD Security Group Creation"
  },
  {
    "category": "approval",
    "title": "ISM Architecture Approval"
  }
]
```
**Backend:** `service.generate_recommendations()` → calls Gemini LLM with full onboarding context → saves `Recommendation` rows

---

### Step A4.2 — Edit a recommendation
**Trigger:** Admin edits recommendation text

```
PUT /api/admin/onboardings/onb_ff3a12/recommendations/rec_uuid1
Body: {
  "title": "GPS – IaaS Provisioning (Updated)",
  "summary": "Updated summary...",
  "parameters": [...]
}
```
**Response:** Updated recommendation object  
**Backend:** `service.update_recommendation()` → updates `Recommendation` row

---

### Step A4.3 — Send recommendations to user
**Trigger:** Admin clicks "Send to User" (final step)

```
POST /api/admin/onboardings/onb_ff3a12/send-to-user
Headers: X-User-Id: <admin_id>
```
**Response:** `{ "message": "Recommendations sent to user", "admin_status": "approval_checklist_sent" }`  
→ User's wizard unlocks steps 5–9  
→ Event logged to timeline  
**Backend:** `service.send_to_user()` → sets `admin_status = approval_checklist_sent` + logs event

---

---

# 👑 SUPERADMIN FLOW

---

## Phase 1 — SuperAdmin Dashboard

### Step S1.1 — Load dashboard stats
**Trigger:** SuperAdmin navigates to `/superadmin`  
**Frontend:** [`pages/superadmin/SuperAdminDashboard.tsx`](file:///c:/Users/SaikatMaji/Documents/from1at17-8/frontend/src/pages/superadmin/SuperAdminDashboard.tsx) → `fetchSuperAdminDashboard()`

```
GET /api/superadmin/dashboard
Headers: X-User-Id: <superadmin_id>
```
**Response:**
```json
{
  "total_onboardings": 25,
  "unassigned": 3,
  "in_progress": 15,
  "completed": 7,
  "active_admins": 4,
  "recent_onboardings": [ ... ]
}
```
**Backend:** `GET /api/superadmin/dashboard` → [`admin/superadmin/router.py`](file:///c:/Users/SaikatMaji/Documents/from1at17-8/backend/app/admin/superadmin/router.py) → `service.get_dashboard(db)`

---

### Step S1.2 — Load ALL onboardings + admins
**Trigger:** Dashboard loads (to show assign dialog)

```
GET /api/superadmin/onboardings
GET /api/superadmin/admins
```
**Onboardings response:**
```json
[
  {
    "id": "onb_ff3a12",
    "name": "MyApp Project",
    "admin_status": "pending_assignment",
    "assigned_admin_id": null,
    "assigned_admin_name": null,
    "user_name": "John Doe"
  }
]
```
**Admins response:**
```json
[
  {
    "id": "admin_uuid1",
    "name": "DIS Admin 1",
    "email": "admin1@tcs.com",
    "emp_id": "TCS002",
    "role": "admin",
    "is_active": true,
    "workload": 3
  }
]
```
**Backend:**  
- `GET /api/superadmin/onboardings` → `service.list_onboardings(db)`  
- `GET /api/superadmin/admins` → `service.list_admins(db)` (includes `workload` = count of assigned onboardings)

---

## Phase 2 — Onboarding Assignment

### Step S2.1 — Assign admin to onboarding
**Trigger:** SuperAdmin selects admin from dropdown, clicks "Assign"  
**Frontend:** [`pages/superadmin/OnboardingAssignment.tsx`](file:///c:/Users/SaikatMaji/Documents/from1at17-8/frontend/src/pages/superadmin/OnboardingAssignment.tsx) → `assignAdmin(onboardingId, { admin_id })`

```
POST /api/superadmin/onboardings/onb_ff3a12/assign
Body: { "admin_id": "admin_uuid1" }
Headers: X-User-Id: <superadmin_id>
```
**Response:**
```json
{
  "id": "assign_uuid",
  "onboarding_id": "onb_ff3a12",
  "admin_id": "admin_uuid1",
  "admin_name": "DIS Admin 1",
  "assigned_by": "superadmin_uuid",
  "assigned_at": "2026-08-26T10:00:00Z",
  "status": "active"
}
```
→ `admin_status` changes to `assigned`  
→ Onboarding now appears in that admin's dashboard  
**Backend:** `service.assign_admin()` → creates `AdminAssignment` row, updates `admin_status = assigned`

---

### Step S2.2 — Reassign to different admin
**Trigger:** SuperAdmin changes the assigned admin

```
POST /api/superadmin/onboardings/onb_ff3a12/reassign
Body: { "admin_id": "admin_uuid2" }
```
**Response:** New assignment object (same shape as assign)  
**Backend:** `service.reassign_admin()` → deactivates old `AdminAssignment`, creates new one

---

## Phase 3 — Admin Management

### Step S3.1 — Create a new admin
**Trigger:** SuperAdmin fills form in `/superadmin/admins`, clicks "Create"  
**Frontend:** [`pages/superadmin/AdminManagement.tsx`](file:///c:/Users/SaikatMaji/Documents/from1at17-8/frontend/src/pages/superadmin/AdminManagement.tsx) → `createAdmin()`

```
POST /api/superadmin/admins
Body: {
  "name": "New DIS Admin",
  "email": "newadmin@tcs.com",
  "emp_id": "TCS099"
}
```
**Response:**
```json
{
  "id": "new_admin_uuid",
  "name": "New DIS Admin",
  "email": "newadmin@tcs.com",
  "emp_id": "TCS099",
  "role": "admin",
  "is_active": true,
  "workload": 0
}
```
**Backend:** `POST /api/superadmin/admins` → `service.create_admin()` → creates `User` with `role="admin"`

---

### Step S3.2 — Update admin
```
PUT /api/superadmin/admins/admin_uuid1
Body: { "name": "Updated Name", "is_active": false }
```
**Response:** Updated admin object  
**Backend:** `service.update_admin()` → patches `User` row fields

---

### Step S3.3 — Delete (deactivate) admin
```
DELETE /api/superadmin/admins/admin_uuid1
```
**Response:** `204 No Content`  
**Backend:** `service.deactivate_admin()` → sets `is_active = False` (soft delete, not physical delete)

---

## Phase 4 — Configuration Management

### Step S4.1 — Config summary
**Trigger:** SuperAdmin navigates to `/superadmin/config`

```
GET /api/superadmin/config/summary
```
**Response:**
```json
{
  "eligibility_questions": 8,
  "disclaimer_clauses": 5,
  "architecture_rules": 24,
  "approval_rules": 6
}
```
**Backend:** `GET /config/summary` → counts rows in each config table

---

### Step S4.2 — Manage Eligibility Questions
```
GET  /api/admin/eligibility          → List all questions
POST /api/admin/eligibility          → Create question
PUT  /api/admin/eligibility/{id}     → Edit question
DELETE /api/admin/eligibility/{id}   → Delete question
```
**Create body:**
```json
{
  "section": "Security",
  "title": "Is your data classified as confidential?",
  "question_type": "single",
  "options": ["Yes", "No"],
  "correct_answer": "Yes",
  "fail_message": "Confidential data requires special handling.",
  "sort_order": 5
}
```
**Backend:** [`admin/eligibility/router.py`](file:///c:/Users/SaikatMaji/Documents/from1at17-8/backend/app/admin/eligibility/router.py)

---

### Step S4.3 — Manage Architecture Rules
```
GET    /api/admin/architecture-rules                    → All rules
GET    /api/admin/architecture-rules/provider/AWS       → Filter by provider
POST   /api/admin/architecture-rules                    → Create rule
PUT    /api/admin/architecture-rules/{id}               → Edit rule
DELETE /api/admin/architecture-rules/{id}               → Delete rule
```
**Create body:**
```json
{
  "cloud_provider": "AWS",
  "category": "Security",
  "rule_text": "All databases must be in private subnets with no public IP",
  "severity": "HIGH"
}
```
> These rules are fed to Gemini when validating architecture diagrams.  
**Backend:** [`admin/architecture_rules/router.py`](file:///c:/Users/SaikatMaji/Documents/from1at17-8/backend/app/admin/architecture_rules/router.py)

---

### Step S4.4 — Manage Approval Rules
```
GET    /api/superadmin/config/approval-rules
POST   /api/superadmin/config/approval-rules
PUT    /api/superadmin/config/approval-rules/{id}
DELETE /api/superadmin/config/approval-rules/{id}
```
**Backend:** [`admin/superadmin/router.py`](file:///c:/Users/SaikatMaji/Documents/from1at17-8/backend/app/admin/superadmin/router.py)

---

---

# 🔄 Complete admin_status State Machine

```
User submits step 4
        ↓
  pending_assignment   ← waiting for superadmin to assign
        ↓  POST /superadmin/onboardings/{id}/assign
     assigned          ← admin can see it in dashboard
        ↓  Admin opens review
   under_review
        ↓                             ↘
   (all 4 sections                  (send-back)
    approved)                    sent_back
   POST /admin/onboardings/{id}/approve    ↓ user resubmits
        ↓                         POST /{id}/resubmit
   cost_pending         ←──────── under_review again
        ↓  Admin saves cost estimation
      cost_done
        ↓  Admin generates + sends recommendations
  approval_checklist_sent  ← USER can now access steps 5-9
```

---

# 📋 Quick Reference: All API Endpoints by Role

## User APIs (`api.ts`)
| Method | Endpoint | Purpose |
|--------|----------|---------|
| GET | `/api/auth/me` | Get current user |
| GET | `/api/auth/users` | List all users (dev) |
| GET | `/api/onboardings` | My onboardings list |
| POST | `/api/onboardings` | Create new onboarding |
| GET | `/api/onboardings/{id}` | Get onboarding (resume) |
| PUT | `/api/onboardings/{id}` | Save step progress |
| DELETE | `/api/onboardings/{id}` | Delete onboarding |
| POST | `/api/onboardings/{id}/resubmit` | Resubmit after sent-back |
| GET | `/api/onboardings/{id}/events` | Activity timeline |
| GET | `/api/onboardings/{id}/cost` | View published cost |
| GET | `/api/onboardings/{id}/recommendations` | View published recommendations |
| GET | `/api/onboardings/eligibility/questions` | Eligibility questions |
| GET | `/api/onboardings/disclaimer/clauses` | Disclaimer clauses |
| PUT | `/api/account-details/{id}` | Save step 1 |
| PUT | `/api/requirements/{id}` | Save step 2 |
| POST | `/api/cloud-resources/chat` | AI chat (step 3) |
| GET | `/api/cloud-resources/{id}/bucket` | Load bucket |
| PUT | `/api/cloud-resources/{id}/bucket` | Save bucket (step 3) |
| POST | `/api/architecture-validation/{id}/upload` | Upload diagram (step 4) |
| POST | `/api/architecture-validation/{id}/validate` | LLM validate (step 4) |
| GET | `/api/architecture-validation/{id}` | Load validation result |

## Admin APIs (`adminApi.ts`)
| Method | Endpoint | Purpose |
|--------|----------|---------|
| GET | `/api/admin/dashboard` | Admin's assigned onboardings |
| GET | `/api/admin/onboardings/{id}` | Full detail for review |
| GET | `/api/admin/other-onboardings` | Other admins' onboardings |
| POST | `/api/admin/onboardings/{id}/feedback` | Approve/reject/comment section |
| POST | `/api/admin/onboardings/{id}/approve` | Final approval |
| POST | `/api/admin/onboardings/{id}/send-back` | Send back to user |
| GET | `/api/admin/onboardings/{id}/cost` | Load cost |
| PUT | `/api/admin/onboardings/{id}/cost` | Save cost |
| GET | `/api/admin/onboardings/{id}/cost/seed-from-bucket` | Pre-fill cost from resources |
| POST | `/api/admin/onboardings/{id}/recommendations/generate` | LLM generate recommendations |
| GET | `/api/admin/onboardings/{id}/recommendations` | Load recommendations |
| PUT | `/api/admin/onboardings/{id}/recommendations/{recId}` | Edit recommendation |
| POST | `/api/admin/onboardings/{id}/send-to-user` | Publish to user |
| GET | `/api/admin/onboardings/{id}/events` | Activity timeline |
| GET | `/api/admin/eligibility` | List eligibility questions |
| POST/PUT/DELETE | `/api/admin/eligibility/{id}` | Manage questions |
| GET/POST/PUT/DELETE | `/api/admin/disclaimer/{id}` | Manage clauses |
| GET/POST/PUT/DELETE | `/api/admin/architecture-rules/{id}` | Manage arch rules |

## SuperAdmin APIs (`adminApi.ts`)
| Method | Endpoint | Purpose |
|--------|----------|---------|
| GET | `/api/superadmin/dashboard` | Global stats |
| GET | `/api/superadmin/onboardings` | All onboardings |
| POST | `/api/superadmin/onboardings/{id}/assign` | Assign admin |
| POST | `/api/superadmin/onboardings/{id}/reassign` | Change admin |
| GET | `/api/superadmin/admins` | List admins |
| POST | `/api/superadmin/admins` | Create admin |
| PUT | `/api/superadmin/admins/{id}` | Update admin |
| DELETE | `/api/superadmin/admins/{id}` | Deactivate admin |
| GET | `/api/superadmin/config/summary` | Config counts |
| GET/POST/PUT/DELETE | `/api/superadmin/config/approval-rules/{id}` | Manage approval rules |
