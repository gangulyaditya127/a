import React, { useState, useEffect } from "react";
import { type ServiceIdCreation } from "@/types/onboarding";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { CheckCircle2, Copy, Check, Mail, Clock, ShieldCheck } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { getOnboardingCbId } from "@/lib/api";

interface Props {
  data: ServiceIdCreation;
  onboardingId?: string;
  onChange: (data: ServiceIdCreation) => void;
}

export const StepServiceIdCreation = ({ data, onboardingId, onChange }: Props) => {
  const [cbId, setCbId] = useState<string | null>(data.serviceId || null);
  const [adminEmail, setAdminEmail] = useState<string>("cloudops-admin@tcs.com");
  const [copiedId, setCopiedId] = useState(false);
  const [copiedEmail, setCopiedEmail] = useState(false);

  useEffect(() => {
    if (!onboardingId) return;

    const fetchCb = () => {
      getOnboardingCbId(onboardingId)
        .then((res) => {
          if (res.admin_email) {
            setAdminEmail(res.admin_email);
          }
          if (res.cb_id) {
            setCbId(res.cb_id);
            if (data.serviceId !== res.cb_id || data.status !== "completed") {
              onChange({
                ...data,
                serviceId: res.cb_id,
                status: "completed",
                createdDate: data.createdDate || new Date().toISOString().split("T")[0],
                disTeamAssigned: "DIS Cloud COE Team",
              });
            }
          }
        })
        .catch(() => {});
    };

    fetchCb();
    const timer = setInterval(() => {
      fetchCb();
    }, 5000);

    return () => clearInterval(timer);
  }, [onboardingId, data, onChange]);

  const copyToClipboard = (text: string, isEmail = false) => {
    navigator.clipboard.writeText(text);
    if (isEmail) {
      setCopiedEmail(true);
      setTimeout(() => setCopiedEmail(false), 2000);
      toast({ title: "Copied", description: "Admin email copied to clipboard." });
    } else {
      setCopiedId(true);
      setTimeout(() => setCopiedId(false), 2000);
      toast({ title: "Copied", description: "CB ID copied to clipboard." });
    }
  };

  return (
    <div className="max-w-2xl mx-auto py-8 px-4 text-center">
      {cbId ? (
        <div className="space-y-6">
          {/* Header Status & Icon */}
          <div className="space-y-2">
            <div className="w-16 h-16 rounded-full bg-emerald-50 text-emerald-600 border border-emerald-200 flex items-center justify-center mx-auto ring-8 ring-emerald-50/50 shadow-sm">
              <CheckCircle2 className="h-8 w-8 text-emerald-600" />
            </div>
            <h2 className="text-2xl font-bold tracking-tight text-foreground">
              Cloud Business ID Provisioned
            </h2>
            {/* <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-100/80 text-emerald-800 border border-emerald-300/80 text-xs font-medium">
              <ShieldCheck className="h-3.5 w-3.5 text-emerald-700" /> CB ID Active
            </div> */}
          </div>

          {/* Hero CB ID Display */}
          <div className="max-w-md mx-auto rounded-2xl bg-gradient-to-br from-primary/10 via-primary/5 to-emerald-500/10 border border-primary/20 p-6 shadow-sm">
            <span className="text-[11px] font-semibold text-primary uppercase tracking-widest block">
              Assigned CB ID
            </span>
            <div className="flex items-center justify-center gap-3 mt-2 flex-wrap">
              <span className="text-3xl sm:text-4xl font-mono font-extrabold text-foreground tracking-wider">
                {cbId}
              </span>
              <Button
                variant="outline"
                size="sm"
                onClick={() => copyToClipboard(cbId)}
                className="gap-1.5 h-9 px-3.5 rounded-lg text-xs font-medium bg-background shadow-xs hover:bg-accent"
              >
                {copiedId ? <Check className="h-3.5 w-3.5 text-emerald-600" /> : <Copy className="h-3.5 w-3.5" />}
                {copiedId ? "Copied" : "Copy CB ID"}
              </Button>
            </div>
          </div>

          {/* RFC Creation Guidance */}
          <p className="text-base text-slate-700 max-w-md mx-auto leading-relaxed">
            Your CB ID is <strong className="font-mono text-primary font-bold">{cbId}</strong>. Now you can proceed with RFC creation through GHD.
          </p>

          {/* Assistance Footer */}
          <div className="pt-6 border-t border-border/80 max-w-md mx-auto flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-muted-foreground">
            <div className="flex items-center gap-2">
              <Mail className="h-4 w-4 text-muted-foreground shrink-0" />
              <span>Need assistance? Contact DIS Admin: <strong className="text-foreground">{adminEmail}</strong></span>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => copyToClipboard(adminEmail, true)}
              className="h-7 text-xs gap-1 text-muted-foreground hover:text-foreground shrink-0"
            >
              {copiedEmail ? <Check className="h-3 w-3 text-emerald-600" /> : <Copy className="h-3 w-3" />}
              {copiedEmail ? "Copied" : "Copy Email"}
            </Button>
          </div>
        </div>
      ) : (
        <div className="space-y-6">
          <div className="space-y-2">
            <div className="w-16 h-16 rounded-full bg-amber-50 text-amber-600 border border-amber-200 flex items-center justify-center mx-auto ring-8 ring-amber-50/50 shadow-sm">
              <Clock className="h-8 w-8 text-amber-600" />
            </div>
            <h2 className="text-2xl font-bold tracking-tight text-foreground">
              CB ID Generation Pending
            </h2>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-100 text-amber-800 border border-amber-300 text-xs font-medium">
              Pending Admin Action
            </div>
          </div>

          <p className="text-sm text-foreground max-w-md mx-auto leading-relaxed">
            Your CB ID is currently being generated by the DIS Admin. Once generated, your CB ID will appear here and you can proceed with RFC creation through GHD.
          </p>

          <div className="pt-6 border-t border-border/80 max-w-md mx-auto text-xs text-muted-foreground">
            For any help you can reach out to{" "}
            <a
              href={`mailto:${adminEmail}`}
              className="text-primary font-semibold underline hover:text-primary/80"
            >
              {adminEmail}
            </a>.
          </div>
        </div>
      )}
    </div>
  );
};