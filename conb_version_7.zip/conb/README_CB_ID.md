# CB ID Generation Explained: Sequential vs. Timestamp Approaches

This document explains the business logic and operations behind generating a Cloud Blueprint / Cloud Bridge ID (**CB ID**) in simple, non-technical terms.

---

## Part 1: How the Current Sequential Approach Works (`CB001` / `CBAI001`)

When an admin clicks **"Generate CB ID"**, the system performs the following business steps:

1. **Duplicate Check**:
   - First, the system checks if a CB ID has already been created for this project.
   - If it has, it simply displays the existing ID so that duplicate IDs are never issued.

2. **Identify Application Type**:
   - It examines the type of application being onboarded:
     - If it is a **Generative AI** project, it assigns the label **`CBAI`**.
     - If it is a **Standard / Non-AI** project, it assigns the label **`CB`**.

3. **Find the Next Number in Line**:
   - The system looks through all previously issued IDs for that category to find the highest number given out so far:
     - If no projects exist yet, it starts at **1**.
     - If the highest number so far is **5**, the next number becomes **6**.

4. **Format the ID**:
   - It formats the number with leading zeros so that it always looks clean and standardized:
     - Numbers 1 through 9 are written as `001` to `009`.
     - Numbers 10 through 99 are written as `010` to `099`.
     - Numbers 100 through 999 are written as `100` to `999`.
     - When it reaches 1000, it naturally becomes `1000` (e.g., `CB1000` or `CBAI1000`).

5. **Save and Update Status**:
   - The system saves this ID in the database table dedicated to CB IDs (`cbid`).
   - It updates the project status from *Approvals Verified* to **"CB ID Created"**.
   - It sends the ID to the user’s screen so they can proceed with their RFC and cloud setup.

---

## Part 2: How the Previous Timestamp Approach Worked (`cb_1788855113`)

1. **Duplicate Check**:
   - Checks if an ID was already generated for this project.

2. **Identify Application Type**:
   - Picks `cbai_` for GenAI or `cb_` for Non-GenAI.

3. **Check the Clock**:
   - Instead of searching past records, it simply reads the computer’s live clock down to the exact second (the Unix timestamp, representing seconds elapsed since 1970, e.g., `1788855113`).

4. **Combine and Save**:
   - It joins the label and the clock time (e.g., `cb_1788855113`) and immediately saves it.

---

## Part 3: Why the Timestamp Approach is Better in Reducing Extra Operations

While sequential numbers (`CB001`) look friendlier to human eyes, the **Timestamp approach is technically simpler and much more efficient** because:

1. **No Database Searching**:
   - **Sequential**: Every time a new ID is generated, the system must query the database, pull out all previous IDs, read through them, and calculate the maximum number.
   - **Timestamp**: It does **zero database lookups**. It does not care about what IDs were created in the past; it just looks at the clock.

2. **Faster Performance as Data Grows**:
   - As your database grows to thousands of records, searching and calculating the highest sequential number takes more time and memory.
   - The timestamp approach takes the exact same split-second speed whether you have 1 onboarding or 1,000,000 onboardings.

3. **No Collision or Concurrency Conflict**:
   - If two admins click "Generate CB ID" at the exact same fraction of a second, a sequential system could try to calculate the same number for both, requiring collision loops or row locking.
   - A timestamp is naturally unique because time is always moving forward, avoiding locking or waiting in the database.

4. **Zero State / Maintenance**:
   - The timestamp generation is completely independent and requires zero tracking logic, making it simpler, faster, and lighter on system resources.
