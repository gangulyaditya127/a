"""SQLAlchemy model for CB ID generation."""

from datetime import datetime
from typing import TYPE_CHECKING, Optional
import uuid

from sqlalchemy import ForeignKey, String, func
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.database import Base

if TYPE_CHECKING:
    from app.models.onboarding import Onboarding
    from app.models.user import User


class CbId(Base):
    """Stores the generated Cloud Blueprint / Cloud Bridge ID for an onboarding."""

    __tablename__ = "cbid"

    id: Mapped[str] = mapped_column(primary_key=True, default=lambda: str(uuid.uuid4()))
    onboarding_id: Mapped[str] = mapped_column(
        ForeignKey("onboardings.id", ondelete="CASCADE"),
        unique=True,
        index=True,
    )
    cb_id: Mapped[str] = mapped_column(String, unique=True, index=True, nullable=False)
    application_name: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    created_at: Mapped[datetime] = mapped_column(server_default=func.now())
    created_by: Mapped[Optional[str]] = mapped_column(
        ForeignKey("users.id"),
        nullable=True,
    )

    onboarding: Mapped["Onboarding"] = relationship(
        "Onboarding",
        back_populates="cb_id_record",
    )
    creator: Mapped[Optional["User"]] = relationship(
        "User",
        foreign_keys=[created_by],
        lazy="joined",
    )
