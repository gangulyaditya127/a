"""API router for the onboarding domain."""

from typing import Annotated
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.domains.auth.dependencies import get_optional_user
from app.models.user import User
from app.domains.onboarding import service
from app.domains.onboarding.schemas import (
    ClauseOut,
    CbIdUserResponse,
    OnboardingCreate,
    OnboardingListItem,
    OnboardingResponse,
    OnboardingUpdate,
    QuestionOut,
)

ONBOARDING_NOT_FOUND_MSG = "Onboarding not found"
NOT_FOUND_RESPONSE = {404: {"description": ONBOARDING_NOT_FOUND_MSG}}

router = APIRouter()


@router.get("/")
def list_onboardings(
    db: Annotated[Session, Depends(get_db)],
    user: Annotated[User | None, Depends(get_optional_user)] = None,
) -> list[OnboardingListItem]:
    """Return onboardings. If a user is authenticated, only their own."""
    user_id = user.id if user and user.role == "user" else None
    return service.get_all_onboardings(db, user_id=user_id)


@router.post("/", status_code=201)
def create_onboarding(
    data: OnboardingCreate,
    db: Annotated[Session, Depends(get_db)],
    user: Annotated[User | None, Depends(get_optional_user)] = None,
) -> OnboardingResponse:
    """Create a new onboarding workflow."""
    user_id = user.id if user else None
    return service.create_onboarding(db, data, user_id=user_id)


# ── Static routes MUST appear before the /{onboarding_id} param route ──


@router.get("/eligibility/questions")
def get_eligibility_questions(
    db: Annotated[Session, Depends(get_db)],
) -> list[QuestionOut]:
    """Return all eligibility check questions in order."""
    return service.get_eligibility_questions(db)


@router.get("/disclaimer/clauses")
def get_disclaimer_clauses(
    db: Annotated[Session, Depends(get_db)],
) -> list[ClauseOut]:
    """Return all disclaimer clauses in order."""
    return service.get_disclaimer_clauses(db)


@router.get("/{onboarding_id}/cost")
def get_onboarding_cost(
    onboarding_id: str,
    db: Annotated[Session, Depends(get_db)],
) -> dict:
    """Return cost estimation for user view (no admin auth required)."""
    from app.admin.disadmin.service import get_cost
    cost = get_cost(db, onboarding_id)
    if cost is None:
        return {"status": "pending"}
    return {
        "status": "published",
        "resource_costs": cost.resource_costs,
        "infra_support_cost": cost.infra_support_cost,
        "total_monthly_cost": cost.total_monthly_cost,
        "total_annual_cost": cost.total_annual_cost,
        "currency": cost.currency,
        "notes": cost.notes,
    }


@router.get("/{onboarding_id}/events")
def get_onboarding_events(
    onboarding_id: str,
    db: Annotated[Session, Depends(get_db)],
) -> list[dict]:
    """Return interaction events for user-facing activity timeline."""
    from app.admin.disadmin.service import get_interaction_events
    return get_interaction_events(db, onboarding_id)


@router.get("/{onboarding_id}/cbid", response_model=CbIdUserResponse, responses=NOT_FOUND_RESPONSE)
def get_onboarding_cbid(
    onboarding_id: str,
    db: Annotated[Session, Depends(get_db)],
) -> CbIdUserResponse:
    """Return CB ID and admin contact email for user view."""
    from app.models.onboarding import Onboarding
    from app.models.cbid import CbId
    from app.admin.disadmin.service import get_onboarding_admin_email

    ob = db.query(Onboarding).filter(Onboarding.id == onboarding_id).first()
    if ob is None:
        raise HTTPException(status_code=404, detail=ONBOARDING_NOT_FOUND_MSG)

    admin_email = get_onboarding_admin_email(db, ob)
    cb_record = db.query(CbId).filter(CbId.onboarding_id == onboarding_id).first()

    if cb_record is None:
        # Check if saved in remaining_state['serviceId']
        rem_cb = None
        if ob.remaining_state and isinstance(ob.remaining_state, dict):
            svc = ob.remaining_state.get("serviceId", {})
            if isinstance(svc, dict):
                rem_cb = svc.get("cbId") or svc.get("serviceId")
        if rem_cb:
            app_name = (
                (ob.account_details.project_name if ob.account_details and ob.account_details.project_name else None)
                or ob.name
                or "Untitled Application"
            )
            return CbIdUserResponse(
                status="generated",
                cb_id=rem_cb,
                application_name=app_name,
                admin_email=admin_email,
            )
        return CbIdUserResponse(
            status="pending",
            cb_id=None,
            application_name=ob.name,
            admin_email=admin_email,
        )

    return CbIdUserResponse(
        status="generated",
        cb_id=cb_record.cb_id,
        application_name=cb_record.application_name or ob.name,
        admin_email=admin_email,
    )


@router.get("/{onboarding_id}/recommendations", responses=NOT_FOUND_RESPONSE)
def get_onboarding_recommendations(
    onboarding_id: str,
    db: Annotated[Session, Depends(get_db)],
) -> dict:
    """Return admin-generated recommendations for the user view."""
    from app.admin.disadmin.service import get_recommendations
    from app.models.onboarding import Onboarding

    ob = db.query(Onboarding).filter(Onboarding.id == onboarding_id).first()
    if ob is None:
        raise HTTPException(status_code=404, detail=ONBOARDING_NOT_FOUND_MSG)

    # Only show recommendations once admin has sent them
    allowed_statuses = (
        "approval_checklist_sent",
        "approvals_under_review",
        "approvals_sent_back",
        "approvals_approved",
        "cb_id_created",
        "completed",
    )
    if ob.admin_status not in allowed_statuses:
        return {"status": "pending", "recommendations": []}

    recs = get_recommendations(db, onboarding_id)
    return {
        "status": "published",
        "recommendations": [
            {
                "id": r.id,
                "category": r.category,
                "title": r.title,
                "summary": r.summary,
                "parameters": r.parameters or [],
                "copy_text": r.copy_text or "",
                "status": r.status,
            }
            for r in recs
        ],
    }


# ── Dynamic routes with path parameter ──


@router.get("/{onboarding_id}", responses=NOT_FOUND_RESPONSE)
def get_onboarding(
    onboarding_id: str,
    db: Annotated[Session, Depends(get_db)],
) -> OnboardingResponse:
    """Return a single onboarding with nested account_details and requirement_assessment."""
    onboarding = service.get_onboarding(db, onboarding_id)
    if onboarding is None:
        raise HTTPException(status_code=404, detail=ONBOARDING_NOT_FOUND_MSG)
    return onboarding


@router.put("/{onboarding_id}", responses=NOT_FOUND_RESPONSE)
def update_onboarding(
    onboarding_id: str,
    data: OnboardingUpdate,
    db: Annotated[Session, Depends(get_db)],
) -> OnboardingResponse:
    """Update an existing onboarding's fields."""
    onboarding = service.update_onboarding(db, onboarding_id, data)
    if onboarding is None:
        raise HTTPException(status_code=404, detail=ONBOARDING_NOT_FOUND_MSG)
    return onboarding


@router.post("/{onboarding_id}/resubmit", status_code=200, responses=NOT_FOUND_RESPONSE)
def resubmit_onboarding(
    onboarding_id: str,
    db: Annotated[Session, Depends(get_db)],
    user: Annotated[User | None, Depends(get_optional_user)] = None,
    body: dict | None = None,
) -> dict:
    """Resubmit an onboarding after making changes requested by admin."""
    from app.admin.disadmin.service import resubmit_onboarding as do_resubmit

    user_name = user.name if user else None
    comment = (body or {}).get("comment")
    success = do_resubmit(db, onboarding_id, user_name=user_name, comment=comment)
    if not success:
        raise HTTPException(status_code=404, detail=ONBOARDING_NOT_FOUND_MSG)
    return {"status": "resubmitted"}


@router.delete("/{onboarding_id}", status_code=204, responses=NOT_FOUND_RESPONSE)
def delete_onboarding(
    onboarding_id: str,
    db: Annotated[Session, Depends(get_db)],
) -> None:
    """Delete an onboarding and all associated data (cascading)."""
    deleted = service.delete_onboarding(db, onboarding_id)
    if not deleted:
        raise HTTPException(status_code=404, detail=ONBOARDING_NOT_FOUND_MSG)