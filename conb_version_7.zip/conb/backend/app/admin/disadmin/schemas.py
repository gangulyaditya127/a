"""Pydantic schemas for DIS Admin endpoints."""

from datetime import datetime
from typing import Any, Optional

from pydantic import BaseModel, ConfigDict, model_validator


# ── Validation Feedback ──────────────────────────────────────────────────────

class FeedbackCreate(BaseModel):
    """Submit approval/rejection for a single onboarding section."""

    section: str  # 'account_details', 'requirements', 'cloud_resources', 'architecture'
    status: str  # 'approved', 'rejected', 'comment'
    comment: Optional[str] = None


class FeedbackResponse(BaseModel):
    """Validation feedback record."""

    id: str
    onboarding_id: str
    admin_id: str
    section: str
    status: str
    comment: Optional[str] = None
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)


class InteractionEventOut(BaseModel):
    """Interaction event for activity timeline."""
    id: str
    onboarding_id: str
    ts: datetime
    actor: str
    actor_name: str
    kind: str
    title: str
    body: Optional[str] = None
    scope: Optional[str] = None

    model_config = ConfigDict(from_attributes=True)


# ── Send-back ────────────────────────────────────────────────────────────────

class SendBackRequest(BaseModel):
    """Body for sending an onboarding back to the user."""

    comment: str


# ── Cost Estimation ──────────────────────────────────────────────────────────

class ResourceCostItem(BaseModel):
    """Single resource cost line item."""

    resource_name: str
    unit_cost: float
    quantity: int
    monthly_cost: float


class CostEstimationUpsert(BaseModel):
    """Create or update cost estimation."""

    resource_costs: list[ResourceCostItem]
    infra_support_cost: float = 0.0
    total_monthly_cost: float = 0.0
    total_annual_cost: float = 0.0
    currency: str = "INR"
    notes: Optional[str] = None


class CostEstimationResponse(BaseModel):
    """Cost estimation response."""

    id: str
    onboarding_id: str
    admin_id: str
    resource_costs: list[dict[str, Any]]
    infra_support_cost: float
    total_monthly_cost: float
    total_annual_cost: float
    currency: str
    notes: Optional[str] = None
    created_at: datetime
    updated_at: datetime

    model_config = ConfigDict(from_attributes=True)


# ── Recommendations ─────────────────────────────────────────────────────────

class RecommendationUpdate(BaseModel):
    """Partial update for a recommendation."""

    title: Optional[str] = None
    summary: Optional[str] = None
    parameters: Optional[list[dict[str, str]]] = None
    copy_text: Optional[str] = None


class RecommendationResponse(BaseModel):
    """Single recommendation."""

    id: str
    onboarding_id: str
    category: str
    title: str
    summary: str
    parameters: list[dict[str, Any]]
    copy_text: Optional[str] = None
    status: str
    created_at: datetime
    updated_at: datetime

    model_config = ConfigDict(from_attributes=True)


# ── Nested onboarding detail schemas ────────────────────────────────────────

class AccountDetailsOut(BaseModel):
    id: str
    project_name: str
    isu: str
    account_name: str
    owner: str
    emp_id: str
    description: str
    business_unit: str

    model_config = ConfigDict(from_attributes=True)


class RequirementAssessmentOut(BaseModel):
    id: str
    solution_type: str
    deployment_environments: list[Any]
    cloud_provider: str
    region: str

    model_config = ConfigDict(from_attributes=True)


class CloudResourceBucketOut(BaseModel):
    id: str
    provider: str
    resources: list[dict[str, Any]]

    model_config = ConfigDict(from_attributes=True)


# ── Admin: Cloud Resource Bucket Edit ────────────────────────────────────────

class AdminBucketEditItem(BaseModel):
    """A single resource row submitted by the admin when editing the bucket."""

    service: str
    count: int
    configDetails: str


class AdminBucketEditRequest(BaseModel):
    """Request body for admin edit of the cloud resource bucket."""

    provider: str
    resources: list[AdminBucketEditItem]


class AdminBucketEditResponse(BaseModel):
    """Response after admin saves the cloud resource bucket."""

    id: str
    onboarding_id: str
    provider: str
    resources: list[dict[str, Any]]

    model_config = ConfigDict(from_attributes=True)


class ArchitectureValidationOut(BaseModel):
    id: str
    image_filename: str
    image_content_type: str
    user_context: Optional[str] = None
    verdict: Optional[str] = None
    violations: list[Any]
    validated_at: Optional[datetime] = None

    model_config = ConfigDict(from_attributes=True)


class AdminAssignmentOut(BaseModel):
    id: str
    admin_id: str
    admin_name: Optional[str] = None
    assigned_by: str
    assigned_at: datetime
    status: str

    model_config = ConfigDict(from_attributes=True)

    @model_validator(mode="before")
    @classmethod
    def _populate_admin_name(cls, data: Any) -> Any:
        if hasattr(data, "admin") and data.admin is not None:
            data.admin_name = data.admin.name
        return data


# ── Dashboard / detail responses ────────────────────────────────────────────

class OnboardingSummary(BaseModel):
    """Lightweight onboarding summary for dashboard listing."""

    id: str
    name: str
    status: str
    current_step: int
    admin_status: str
    created_at: datetime
    updated_at: datetime
    user_id: Optional[str] = None
    user_name: Optional[str] = None
    user_email: Optional[str] = None
    user_emp_id: Optional[str] = None
    account_details: Optional[AccountDetailsOut] = None
    requirement_assessment: Optional[RequirementAssessmentOut] = None
    admin_assignment: Optional[AdminAssignmentOut] = None

    model_config = ConfigDict(from_attributes=True)

    @model_validator(mode="before")
    @classmethod
    def _populate_user_fields(cls, data: Any) -> Any:
        if hasattr(data, "user") and data.user is not None:
            data.user_name = data.user.name
            data.user_email = data.user.email
            data.user_emp_id = data.user.emp_id
        return data


class AdminDashboardData(BaseModel):
    """Dashboard response with stats and onboardings list."""

    total_assigned: int = 0
    pending_review: int = 0
    approved: int = 0
    sent_back: int = 0
    cost_pending: int = 0
    recommendations_pending: int = 0
    onboardings: list[OnboardingSummary] = []


class CbIdResponse(BaseModel):
    """Response schema for CB ID details."""

    id: str
    onboarding_id: str
    cb_id: str
    application_name: Optional[str] = None
    created_at: datetime
    admin_email: Optional[str] = None
    solution_type: Optional[str] = None

    model_config = ConfigDict(from_attributes=True)


class OnboardingDetail(BaseModel):
    """Full onboarding detail for admin review."""

    id: str
    name: str
    status: str
    current_step: int
    admin_status: str
    admin_comments: Optional[list[Any]] = None
    user_comments: Optional[list[Any]] = None
    created_at: datetime
    updated_at: datetime
    user_id: Optional[str] = None
    user_name: Optional[str] = None
    user_email: Optional[str] = None
    user_emp_id: Optional[str] = None
    account_details: Optional[AccountDetailsOut] = None
    requirement_assessment: Optional[RequirementAssessmentOut] = None
    cloud_resource_bucket: Optional[CloudResourceBucketOut] = None
    architecture_validation: Optional[ArchitectureValidationOut] = None
    admin_assignment: Optional[AdminAssignmentOut] = None
    validation_feedbacks: list[FeedbackResponse] = []
    cost_estimation: Optional[CostEstimationResponse] = None
    recommendations: list[RecommendationResponse] = []
    interaction_events: list[InteractionEventOut] = []
    cb_id_record: Optional[CbIdResponse] = None
    is_read_only: bool = False

    model_config = ConfigDict(from_attributes=True)

    @model_validator(mode="before")
    @classmethod
    def _populate_user_fields(cls, data: Any) -> Any:
        if hasattr(data, "user") and data.user is not None:
            data.user_name = data.user.name
            data.user_email = data.user.email
            data.user_emp_id = data.user.emp_id
        return data


class OtherOnboardingsResponse(BaseModel):
    """Paginated response for onboardings not assigned to the current admin."""

    total_count: int = 0
    onboardings: list[OnboardingSummary] = []
